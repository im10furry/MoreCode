# AI 编码助手 — 多 Agent 编排架构设计 · 技术选型与架构总览

> Rust + Ratatui + Actor 并发模型

---

## 第一部分：技术选型

### 1.1 核心技术栈

| 类别 | 技术 | 说明 |
|------|------|------|
| 主语言 | Rust | 高性能、内存安全、强类型系统，适合构建高并发 Agent 系统 |
| 并发模型 | Actor | 每个 Agent 为独立 Actor，拥有私有状态和邮箱 |
| 异步运行时 | Tokio | Reactor 模式调度，提供高性能异步 I/O；Rust 生态事实标准，所有核心依赖（reqwest/rmcp/rig 等）均基于 Tokio |
| 通信机制 | Channel (CSP) | Agent 间通过 Channel 进行异步消息传递 |
| UI 界面 | Ratatui | 终端 TUI 框架，实时展示 Agent 执行状态 |
| 安全沙箱 | Landlock + Seccomp + WASM | 双层沙箱：OS 层（Landlock 文件系统白名单 + Seccomp 系统调用过滤）作为安全基座；WASM 层（Wasmtime + WASI）提供函数级能力控制和跨平台隔离 |
| 工具协议 | MCP (rmcp) | Model Context Protocol，AI 工具互操作事实标准；使用 rmcp v1.4+（官方 Rust SDK），支持 Stdio / Streamable HTTP / Unix Domain Socket 三种传输 |
| 代码解析 | Tree-sitter | 增量语法解析引擎，用于生成 Repo Map（精简仓库映射）；支持 40+ 语言，为上下文管理提供结构化代码理解能力 |

### 1.2 组合架构模式

| 模式 | 用途 |
|------|------|
| **Actor** | 核心并发模型，每个 Agent 为独立 Actor，拥有私有状态和邮箱 |
| **Reactor** | Tokio 调度器负责事件循环和异步 I/O 分发 |
| **CSP** | Channel 通信，Agent 间通过结构化消息（JSON）进行异步通信 |
| **Pipeline** | 请求处理链，如 Explorer → Impact Analyzer → Planner → Coder → Reviewer → Tester |
| **DAG** | 工具并行执行，无依赖关系的任务可由多个 Agent 同时执行 |
| **Event Sourcing** | 会话持久化，所有状态变更以事件形式记录，支持回溯和重放 |

### 1.3 安全沙箱策略

采用双层沙箱设计，从外到内逐层收紧权限：

```
┌─────────────────────────────────────────────────────┐
│  第一层：OS 沙箱（Landlock + Seccomp）                │
│  · Landlock：Linux 5.13+ 文件系统访问控制，读写路径白名单 │
│  · Seccomp-BPF：系统调用白名单过滤，无需 root 权限      │
│  · 作为安全基座，最后一道防线，极低性能开销              │
│  · 跨平台降级：macOS 用 sandbox-exec，Windows 用       │
│    Restricted Token + Job Objects                     │
├─────────────────────────────────────────────────────┤
│  第二层：WASM 沙箱（Wasmtime + WASI）                 │
│  · 函数级能力控制（Capability-based Security）         │
│  · Deny-by-default：默认拒绝所有系统资源访问            │
│  · 精确 CPU/内存资源计量                              │
│  · 跨平台（Linux/macOS/Windows）                      │
│  · 用于执行用户提供的代码或第三方工具                    │
└─────────────────────────────────────────────────────┘
```

**分层使用策略：**

| 执行场景 | 沙箱选择 | 说明 |
|---------|---------|------|
| Shell 命令（`cargo build`、`pytest` 等） | Landlock + Seccomp | 低开销，OS 级过滤足够 |
| 用户提供的代码 / 第三方工具 | WASM 沙箱 | 高安全，函数级隔离 |
| 只读文件操作 | Landlock 只读模式 | 最小权限 |
| 平台不支持时 | 降级为应用层权限检查 + 资源限制 | 优雅降级 |

**Rust 依赖：**
```toml
landlock = "0.4"                                    # Linux 文件系统沙箱
wasmtime = { version = "28", features = ["wasi"] }  # WASM 运行时
```

#### 🆕 P3-1: WASM 沙箱性能基准

以下为 Wasmtime v28 在典型开发环境下的性能基准数据（基于社区 benchmark + 官方数据综合）：

| 指标 | 典型值 | 说明 |
|------|--------|------|
| **冷启动时间** | 1-5 ms | 首次编译 + 实例化 WASM 模块（不含编译缓存） |
| **热启动时间** | 0.1-0.5 ms | 使用 Cranelift 编译缓存后的实例化时间 |
| **函数调用延迟** | 10-100 μs | 简单计算函数的单次调用开销（不含 I/O） |
| **内存开销（基座）** | ~5 MB | Wasmtime 运行时本身的内存占用 |
| **内存开销（每实例）** | 1-10 MB | 取决于 WASM 模块的内存声明 |
| **Fuel 计量开销** | < 5% | 启用 `consume_fuel` 后的性能损耗 |
| **Epoch 中断延迟** | < 1 ms | `epoch_interruption` 检查的响应延迟 |

**与 OS 沙箱的对比：**

| 维度 | Landlock + Seccomp | WASM (Wasmtime) |
|------|-------------------|-----------------|
| 启动开销 | ~0.1 ms（系统调用） | 1-5 ms（冷启动） |
| 调用延迟 | ~10 μs（系统调用） | 10-100 μs（WASM 调用） |
| 隔离粒度 | 进程级 | 函数级 |
| 跨平台 | Linux only | Linux/macOS/Windows |
| 适用场景 | Shell 命令执行 | 用户代码/第三方工具 |

**结论**：WASM 沙箱的冷启动开销（1-5ms）在 Agent 编排场景中可忽略（LLM 调用通常 500ms-5s），但应避免在高频循环中反复创建/销毁实例。建议使用实例池复用 WASM 实例。

### 1.4 MCP 协议集成

MCP（Model Context Protocol）是 AI 工具互操作的事实标准，决定系统能否接入外部工具生态（数据库、API、自定义工具等）。

**选型：rmcp v1.4+（官方 Rust SDK）**

| 维度 | 说明 |
|------|------|
| 维护方 | `modelcontextprotocol` 官方组织 |
| 传输方式 | Stdio、Streamable HTTP（含 SSE）、Unix Domain Socket |
| 核心能力 | Client/Server 双角色、OAuth 2.0、Tool Schema 自动生成、Elicitation 人机交互确认 |
| 定位 | 同时作为 MCP 客户端（调用外部工具）和 MCP 服务端（暴露自身能力给 IDE 等） |

**配置作用域（优先级：全局 < 项目 < 环境变量）：**

```toml
# ~/.morecode/config.toml
[mcp.servers.filesystem]
command = "npx"
args = ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/project"]

[mcp.servers.github]
command = "npx"
args = ["-y", "@modelcontextprotocol/server-github"]
env = { GITHUB_TOKEN = "ghp_xxx" }

# .morecode/config.toml（项目级，优先级更高）
[mcp.servers.database]
command = "npx"
args = ["-y", "@modelcontextprotocol/server-postgres", "postgresql://..."]
```

**Rust 依赖：**
```toml
rmcp = { version = "1.4", features = ["client", "server"] }
```

### 1.5 Repo Map（精简仓库映射）

借鉴 Aider（GitHub 40k+ stars）的 Repo Map 思路，通过 Tree-sitter 解析源码生成精简的仓库结构映射，大幅降低 Token 消耗。

**核心原理：**

```
传统方案（全量文件列表）：
  src/main.rs (150 行完整内容)
  src/auth/login.rs (200 行完整内容)
  ... 每次请求都发送完整文件内容

Repo Map（精简映射）：
  src/main.rs
    - App::new()
    - async fn run(addr: SocketAddr)
  src/auth/login.rs
    - pub async fn login(req: LoginRequest) -> Result<LoginResponse>
    - struct LoginRequest { username: String, password: String }
  ... 仅发送函数签名和类型定义，不含实现体
```

**生成流程：**

```
1. Tree-sitter 解析源码 → 提取函数签名、类型定义、导入关系
2. 构建调用图 → 识别与当前任务相关的文件子集
3. 生成精简映射 → 只包含签名，不含实现体
4. 按相关性排序 → 最相关的文件排在前面
```

**与现有上下文管理的集成：**

- Explorer 首次扫描时生成 Repo Map，缓存到 `.assistant-memory/cache/repo-map.json`
- 后续通过文件 hash 检测变更，增量更新（非全量重建）
- Planner 用 Repo Map 理解项目结构，精准分配子任务
- Coder 用 Repo Map 定位修改点，只读取相关文件
- Impact Analyzer 用 Repo Map 追踪依赖链

**预期收益：** Token 消耗降低 30-50%（特别是大型项目），Agent 理解项目结构速度更快。

**Rust 依赖：**
```toml
tree-sitter = "0.24"
# 按需引入各语言 parser：
# tree-sitter-rust = "0.23"
# tree-sitter-typescript = "0.23"
# tree-sitter-python = "0.23"
```

### 1.6 Token 计算方案

统一 Token 计算架构支持多模态内容（文本/图像/音频）和多提供商（Anthropic/OpenAI/Google）：

- **文本**：默认 byte/4，CJK 场景乘以 1.5x-2x 安全系数
- **图像**：按提供商分别计算（Anthropic: w*h/750，OpenAI/Google 各有专属公式）
- **音频**：统一走 STT 管道，OpenAI 按 500 token/min，Google 按 32 token/s
- **70/85 规则**：上下文使用率达 70% 告警，85% 自动触发压缩

### 1.7 LLM Provider 接入层

采用 **OpenAI 兼容协议统一层** + 非兼容 Provider 可选编译：

```rust
#[async_trait]
pub trait LlmProvider: Send + Sync {
    async fn chat_stream(&self, request: ChatRequest) -> Result<ChatStream>;
    async fn chat(&self, request: ChatRequest) -> Result<ChatResponse>;
    fn cache_capability(&self) -> CacheCapability;
    fn model_info(&self) -> &ModelInfo;
}
```

- Provider 层之上增加**可选语义缓存中间件**：默认仅对 Explorer / Research 的只读查询启用，按 `agent_type + model + repo_fingerprint` 分 namespace，余弦相似度阈值默认 `0.90`
- 双层缓存分工：Provider Prompt Caching 负责稳定前缀；语义缓存负责问题重述、重复扫描和事实型重复查询

| 后端 | 覆盖范围 | 接入方式 | 说明 |
|------|---------|---------|------|
| **OpenAI Compatible** | OpenAI / DeepSeek / 智谱 GLM / 通义千问 / 百川 / Moonshot / Ollama / LM Studio / vLLM | `OpenAiCompatibleProvider` + 预设注册表 | **默认后端**，一行配置接入，覆盖绝大多数 Provider |
| **Anthropic** | Claude / Bedrock / Vertex | `AnthropicProvider`（feature flag） | Messages API 格式不同，单独实现 |
| **Google Gemini** | Gemini 系列 | `GeminiProvider`（feature flag） | 可选编译 |

- 预设注册表内置 7 个 Provider（openai/deepseek/zhipu/qwen/moonshot/ollama/lmstudio），支持自定义 base_url/model/pricing 覆盖
- 事前估算：`BytesPer4`（UTF-8 友好）；事后校准：API 返回值
- 可选精确计数：riptoken（`--features precise-token-count`，速度 tiktoken 2.4x-6.2x）

### 1.7.1 树状 Token 预算模型

子 Agent **独立构建上下文窗口** + 上级下发的任务描述和文件引用，不是从父 Agent 的 token 预算中切分。采用树状预算分配：

- **上下文窗口**（硬限制）：每个 Agent 独立拥有模型的物理上下文限制（如 128K tokens）
- **Token 预算**（软限制）：父 Agent 为子任务分配费用额度（如 $0.50），子 Agent 独立记账
- **预算分配**：按任务类型比例分配（Coder 30-50%、Reviewer 10-20%、Explorer 5-15%）
- 超出分配预算触发告警，不中断执行；会话级总预算超支触发 Exceeded 事件

> 详见 → [14-LLM Provider 与 Token 管理 §14.4](02-系统机制/14-LLM-Provider与Token管理.md)

### 1.8 上下文压缩策略

采用四层渐进式压缩，分阶段实现：

| 层级 | 名称 | 触发条件 | 实现方式 | 阶段 |
|------|------|---------|---------|------|
| L1 | **微压缩** | 工具结果 > 10K 字符且轮次 > 3 | 清除旧工具结果，替换为 `[Old result cleared]`，不调 LLM | Phase 1 |
| L2 | **自动压缩** | token 使用率 > 85% | LLM 生成摘要，保留 6 类关键信息 | Phase 2 |
| L3 | **记忆压缩** | ~90% 阈值 | 提取关键信息到持久记忆文件 | Phase 3 |
| L4 | **反应式截断** | API 返回 `prompt_too_long` | 截断最旧消息，保留尾部 80% | Phase 1 |

**Phase 3 创新方向**：融入 Focus 式"主动压缩"理念——Agent 通过 `start_focus`/`complete_focus` 原语自主决定压缩时机；Phase 4 用 ACON 蒸馏小模型替代 LLM 摘要。

### 1.9 Prompt 缓存优化

五层缓存架构，按内容稳定性分层：

| 层级 | 内容 | 更新频率 | 缓存 |
|------|------|---------|------|
| L1 全局层 | 系统提示、工具定义 | 月更新 | ✅ 最长 TTL |
| L2 组织层 | 团队约定、代码规范 | 周更新 | ✅ 长 TTL |
| L3 项目层 | 技术栈、项目约定 | 日更新 | ✅ 中 TTL |
| L4 会话层 | 任务描述、执行计划 | 会话级 | ❌ 不缓存 |
| L5 轮次层 | 当前对话历史 | 每轮变化 | ❌ 不缓存 |

- L1-L3 标记为可缓存，利用 Provider 的 prompt caching
- L1 层变更时版本号自增，自动打破缓存
- 预期节省：**50-67%** 输入 token 成本

> 说明：这里的五层缓存只覆盖 Prompt 前缀缓存；Explorer / Research 的语义相似查询走第 14 章的应用侧语义缓存中间件。

### 1.10 权限管理系统

Guardian 白名单 + 任务级权限 + 多模式：

```rust
pub enum PermissionMode {
    Default,   // 每次操作询问用户
    Auto,      // 自动批准只读，写操作询问
    ReadOnly,  // 拒绝所有写操作
    Plan,      // 只分析不执行
    Bypass,    // 跳过检查（仅 CLI 标志）
}

pub struct TaskPermission {
    task_id: String,
    capabilities: HashSet<Capability>,
    expires_at: Instant,
}
```

- 只读工具（read_file、search）自动放行
- 写操作工具根据 PermissionMode 决定
- `run_command` 经过 Guardian 白名单检查
- 危险命令（`rm -rf /`、`git push --force`）无论什么模式都需确认
- Phase 2 引入任务级权限，权限随任务生命周期管理

### 1.11 记忆系统（Letta 式分层）

参考 Letta（MemGPT）架构，四层分层记忆：

| 层级 | 说明 | 管理 |
|------|------|------|
| **Core Memory** | 始终在上下文窗口内，Agent 可自主编辑 | Agent 通过工具调用管理 |
| **Working Memory** | 当前会话的文件缓存和工具结果 | LRU 策略，100 文件 / 25MB |
| **Recall Memory** | 完整对话历史，支持搜索 | 自动持久化 |
| **Archival Memory** | 经过处理的结构化知识 | 初期 SQLite+tantivy，后期向量检索 |

- Sleep-Time Compute：Daemon 模式下异步记忆整合
- Core Memory 分类：UserPreference / ProjectConvention / TaskState / ErrorPattern

### 1.12 可观测性

AgentTelemetry 理念 + tracing + OTel + Langfuse：

- **采集层**：`tracing` crate + 自定义 Agent 专用 Span（9 种类型）
- **导出层**：`tracing-opentelemetry`
- **展示层**：Langfuse（自托管开源）或 Grafana
- **隐私控制**：默认 METADATA_ONLY（含模型名/token/成本），可选 FULL

### 1.13 代码分析三层架构

```
Layer 1: ripgrep（正则搜索，已有）
Layer 2: Probe（ripgrep + tree-sitter 混合搜索，AI 友好，返回完整 AST 节点）
Layer 3: LSP-MCP Bridge（语义级理解，类型推断/跨文件引用）
```

- Phase 1：ripgrep + tree-sitter（基础）
- Phase 2：引入 Probe 替代纯 tree-sitter
- Phase 3：引入 LSP-MCP Bridge

---

## 第二部分：整体架构

### 2.1 架构分层

系统采用四层架构，从上到下依次为：

| 层级 | 组件 | 职责 |
|------|------|------|
| **用户界面层** | Ratatui TUI | 终端交互界面，实时展示 Agent 执行状态、日志输出、用户输入 |
| **编排层** | Coordinator + Agents | 任务调度、意图理解、路由决策、多 Agent 协作编排 |
| **工具层** | Tool Layer | 文件读写、代码搜索、Git 操作、终端执行、LLM 调用 |
| **持久化层** | 项目文件系统 + 记忆 | .assistant-memory/ 目录存储项目记忆、会话历史、缓存 |

### 2.2 整体架构图

```
┌─────────────────────────────────────────────────────────────────────┐
│                          用户输入 (CLI / TUI)                        │
│                      Ratatui 终端界面层                              │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│                     ┌─────────────────┐                             │
│                     │   Coordinator   │                             │
│                     │   (主协调者)     │                             │
│                     │                 │                             │
│                     │ · 意图理解       │                             │
│                     │ · 路由决策       │                             │
│                     │ · 执行监控       │                             │
│                     │ · 结果整合       │                             │
│                     └────────┬────────┘                             │
│                              │                                      │
│              ┌───────────────┼───────────────┐                      │
│              │               │               │                      │
│     ┌────────▼──────┐ ┌─────▼──────┐ ┌──────▼────────┐             │
│     │   Explorer    │ │  Planner   │ │ ImpactAnalyzer│             │
│     │  (项目探索者)  │ │ (任务规划者) │ │  (影响分析者)  │             │
│     └───────────────┘ └─────┬──────┘ └───────────────┘             │
│                            │                                       │
│              ┌─────────────┼─────────────┐                         │
│              │             │             │                         │
│     ┌────────▼──────┐ ┌───▼────────┐ ┌──▼──────────┐              │
│     │    Coder      │ │  Reviewer  │ │   Tester    │              │
│     │  (编码执行者)  │ │(代码审查者) │ │ (测试生成者) │              │
│     └───────────────┘ └────────────┘ └─────────────┘              │
│                                                                     │
│  ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─  │
│  专项能力型 (On-Demand Capability Agents)                           │
│                                                                     │
│     ┌──────────────┐ ┌──────────────┐ ┌──────────────┐             │
│     │   Research   │ │  DocWriter   │ │   Debugger   │             │
│     │  (研究调查者)  │ │ (文档撰写者) │ │  (调试排错者) │             │
│     └──────────────┘ └──────────────┘ └──────────────┘             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        工具层 (Tool Layer)                          │
│                                                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│  │ 文件读写  │ │ 代码搜索  │ │ Git 操作  │ │ 终端执行  │ │ LLM 调用  │ │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘ │
└─────────────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     项目文件系统 + .assistant-memory/                │
└─────────────────────────────────────────────────────────────────────┘
```

### 2.3 设计原则

| # | 原则 | 说明 |
|---|------|------|
| 1 | **先理解再分析后执行** | 任何编码任务都必须经过 Explorer → Impact Analyzer → Coder 流程 |
| 2 | **简单任务单 Agent** | 简单任务直接路由到单个 Agent，避免不必要的编排开销 |
| 3 | **上下文按需注入** | 每个 Agent 只接收完成其职责所需的最小上下文 |
| 4 | **同步共享异步隔离** | 共享数据通过摘要同步传递，内部推理过程异步隔离 |
| 5 | **摘要通信** | Agent 间通过结构化摘要（JSON）通信，而非传递原始上下文 |

---

## 第三部分：Agent 体系

### 3.1 Agent 分类与职责

系统包含 10 个 Agent，不再按“扩展层”划分，而是按能力类型组织：

| 能力类型 | Agent | 职责 | 触发方式 | 数量 |
|------|-------|------|----------|------|
| **协调能力** | Coordinator | 意图理解、路由决策、执行监控、结果整合 | 每次任务必触发 | 1 |
| **认知分析能力** | Explorer | 项目结构扫描、技术栈识别、架构模式识别 | 首次任务或项目变化时 | 1 |
| **认知分析能力** | Impact Analyzer | 改动点识别、依赖链追踪、风险评估 | 涉及多文件修改时 | 1 |
| **认知分析能力** | Planner | 任务分解、依赖分析、Agent 分配、并行组划分 | 中等及以上复杂度任务 | 1 |
| **执行交付能力** | Coder | 代码编写与修改 | 需要编码操作时 | 1~N（可并行） |
| **执行交付能力** | Reviewer | 代码审查、安全检查、风格一致性检查 | Coder 完成后 | 1~N（可并行） |
| **执行交付能力** | Tester | 测试用例生成与执行 | Reviewer 通过后 | 1~N（可并行） |
| **专项能力** | Research | 外部文档查阅、技术方案调研 | 需要外部信息时 | 按需 |
| **专项能力** | DocWriter | 文档生成与更新（可异步，优先级最低） | 需要文档操作时 | 按需 |
| **专项能力** | Debugger | 错误诊断与修复 | 测试失败或运行时错误时 | 按需 |

### 3.2 各 Agent 核心能力

#### Coordinator（主协调者）
- **六步管道**：了解意图 → 询问补全 → 路由决策 → 监控执行 → 结果整合 → 最终交付
- 集成项目记忆加载，每次任务开始前读取已有记忆
- 支持记忆感知路由，根据历史信息优化决策

#### Explorer（项目探索者）
- 项目结构扫描（目录树、入口文件、配置文件）
- 技术栈识别（语言、框架、构建工具、包管理器）
- 架构模式识别（MVC、微服务、单体等）
- 依赖关系图构建
- 代码风格与约定提取
- 风险区域标注（复杂文件、循环依赖、遗留代码）
- 支持递归代码阅读（分层递归 + 懒递归机制）

#### Impact Analyzer（影响分析者）
- 改动点识别（直接/间接影响文件）
- 依赖链追踪（上下游双向追踪）
- 风险评估（高/中/低风险分级）
- 不可变约束标注（不可修改的接口/契约）
- 执行顺序建议
- 支持递归影响追踪

#### Planner（任务规划者）
- 任务分解为子任务
- 依赖分析（DAG 构建）
- Agent 分配（每个子任务指定执行 Agent）
- 并行组划分（无依赖任务可并行）
- 上下文分配（每个子任务的最小上下文）
- 输出 DAG 可视化的执行计划

#### Coder（编码执行者）
- 按照执行计划进行代码编写与修改
- 支持递归并行修改（复杂修改拆分为子任务）
- 完成后更新项目记忆

#### Reviewer（代码审查者）
- 获取变更内容（diff）
- 安全审查（注入、XSS、敏感信息泄露）
- 正确性审查（逻辑错误、边界条件）
- 风格一致性检查
- 输出审查报告（通过/需修改/拒绝）
- 支持递归并行审查

#### Tester（测试生成者）
- 理解变更内容
- 生成测试用例
- 编写测试代码
- 运行测试
- 输出测试报告
- 支持递归并行测试

#### Research（研究调查者）
- 外部文档查阅
- 技术方案调研
- API 文档检索
- 支持递归调研编排

#### DocWriter（文档编写者）
- 文档生成与更新
- 可异步执行，优先级最低
- API 文档、README、变更日志等

#### Debugger（调试排错者）
- 错误诊断与修复
- 编译错误、运行时错误、测试失败
- 支持递归 Bug 验证

---

## 第四部分：核心流程

### 4.1 Coordinator 六步管道

| 步骤 | 名称 | 说明 |
|------|------|------|
| 1 | 了解意图 | 解析用户输入，识别任务类型和复杂度 |
| 2 | 询问补全 | 当信息不足时向用户确认，避免错误假设 |
| 3 | 路由决策 | 根据复杂度评估决定启动哪些 Agent（单 Agent / 完整管道 / 自定义组合） |
| 4 | 监控执行 | 实时监控 Agent 执行状态，处理异常和重试 |
| 5 | 结果整合 | 汇总所有 Agent 的输出，生成统一的变更摘要 |
| 6 | 最终交付 | 向用户展示结果，包括变更摘要、影响范围、后续建议 |

### 4.2 数据流概览

```
用户请求
   │
   ▼
Coordinator ──→ Explorer ──→ ProjectContext
   │                              │
   │                              ▼
   │                        Impact Analyzer ──→ ImpactReport
   │                              │
   │                              ▼
   │                        Planner ──→ ExecutionPlan
   │                    ┌─────────┼─────────┐
   │                    ▼         ▼         ▼
   │                 Coder[1]  Coder[2]  Coder[3]  ...
   │                    │         │         │
   │                    ▼         ▼         ▼
   │               Reviewer[1] Reviewer[2] ...
   │                    │         │
   │                    ▼         ▼
   │                Tester[1]  Tester[2]  ...
   │                    │         │
   └────────────────────┼─────────┘
                        ▼
                   结果整合
                        │
                        ▼
                   变更摘要 ──→ 用户
```

---

## 第五部分：系统机制

### 5.1 路由决策机制

Coordinator 根据任务复杂度进行四级路由：

| 复杂度 | 启动的 Agent | 示例 |
|--------|-------------|------|
| **简单** | 单个 Agent（直接执行） | 格式化代码、修复拼写错误、简单重命名 |
| **中等** | Coordinator + 部分 Agent | 添加新功能、修改单个模块、重构函数 |
| **复杂** | 完整管道（所有 Agent） | 跨模块重构、API 重新设计、新增多个端点 |
| **研究** | Research + 降级路由 | 技术选型调研、外部文档查阅、兼容性评估 |

复杂度评估规则：
- 涉及文件数 > 5 → 至少中等
- 涉及跨模块修改 → 复杂
- 涉及公共 API 变更 → 复杂
- 用户显式要求多 Agent → 强制复杂模式

### 5.2 Git 并发控制策略

并行 Coder 的 Git 冲突通过"两阶段 + Commit Point"解决：

- **第一阶段**：各 Coder 在独立分支上工作，避免冲突
- **Commit Point**：在执行计划中标记合并点，等待所有相关 Coder 完成后统一合并
- **第二阶段**：合并到主分支，如有冲突则回滚到最近 Commit Point

```
Planner 输出:
  Task A (Coder-1, branch: feat/login) ──┐
  Task B (Coder-2, branch: feat/signup) ──┼── Commit Point 1 ── Review ── Test
  Task C (Coder-3, branch: feat/logout) ──┘
```

### 5.3 上下文管理策略

采用分层上下文池设计：

- **全局上下文池**：存储平台信息、项目摘要、用户偏好等全局共享数据
- **Agent 独立上下文**：每个 Agent 拥有独立的上下文窗口，只包含完成其职责所需的最小上下文
- **摘要通信**：Agent 间通过结构化摘要（JSON）传递信息，而非全量上下文
- **Repo Map 注入**：通过 Tree-sitter 生成的精简仓库映射（详见 §1.6），替代全量文件列表注入 Agent 上下文。Explorer 生成并缓存 Repo Map，其他 Agent 按需读取相关子集，预期 Token 消耗降低 30-50%

### 5.4 Agent 间通信协议

通信基于结构化消息，主要消息类型包括：

- **任务分配消息**：Coordinator → Agent，包含任务描述、上下文、Token 预算
- **结果报告消息**：Agent → Coordinator，包含执行结果、变更列表、异常信息
- **交接摘要**：Agent 间传递的结构化摘要，包含关键发现、风险提示、后续建议

---

## 第六部分：高级模式

### 6.1 递归编排（Map-Filter-Reduce）

任何 Agent 在执行复杂任务时，都可作为"子协调者"启动更小的子 Agent 并行处理子任务：

```
┌─────────────────────────────────────────────────────────────┐
│                    父 Agent (Parent)                         │
│                                                             │
│  1. MAP   ──→ 拆分子任务，启动 N 个子 Agent 并行执行          │
│                                                             │
│     ┌──────────┐  ┌──────────┐  ┌──────────┐               │
│     │ 子Agent-1 │  │ 子Agent-2 │  │ 子Agent-3 │  ...         │
│     │ (独立上下文)│  │ (独立上下文)│  │ (独立上下文)│              │
│     └─────┬────┘  └─────┬────┘  └─────┬────┘               │
│           │              │              │                     │
│  2. FILTER──→ 收集结果，筛选有效/关键信息                     │
│           │              │              │                     │
│           ▼              ▼              ▼                     │
│     ┌─────────────────────────────────────┐                 │
│     │        筛选后的结构化结果             │                 │
│     └─────────────────┬───────────────────┘                 │
│                       │                                      │
│  3. REDUCE ──→ 汇总结果，生成统一输出                         │
│                       │                                      │
│                       ▼                                      │
│               最终输出给父 Agent                              │
└─────────────────────────────────────────────────────────────┘
```

- **Map 阶段**：拆分子任务，启动 N 个子 Agent 并行执行（每个拥有独立上下文）
- **Filter 阶段**：收集结果，筛选有效/关键信息
- **Reduce 阶段**：汇总筛选后的结果，生成统一输出
- 递归深度受 Token 预算动态分配约束，子 Agent 的 Token 预算由父 Agent 根据任务复杂度动态分配

### 6.2 项目记忆系统

通过 `.assistant-memory/` 目录实现项目级记忆持久化：

- **记忆内容**：项目结构摘要、技术栈信息、架构模式、代码风格约定、设计决策记录、历史任务摘要
- **增量更新**：每次任务完成后更新相关记忆，避免重复扫描
- **失效检测**：通过文件 hash 和时间戳检测记忆是否过期，触发重新扫描
- **各 Agent 使用**：Coordinator 加载记忆 → Explorer 写入记忆 → Impact Analyzer/Planner 读取记忆 → Coder 更新记忆

记忆目录结构：
```
.assistant-memory/
├── project-summary.md      # 项目概览
├── tech-stack.json         # 技术栈信息
├── architecture.md         # 架构模式
├── code-style.md           # 代码风格约定
├── module-map.json         # 模块映射与依赖关系
├── risk-areas.json         # 风险区域标注
├── file-hashes.json        # 文件哈希列表（增量扫描用）
├── decisions/              # 设计决策记录
│   ├── 001-auth-design.md
│   └── 002-db-migration.md
├── task-history/           # 历史任务摘要
│   ├── 2026-04-15-add-login.md
│   └── 2026-04-16-refactor-api.md
├── agent-notes/            # 各 Agent 的工作笔记
│   ├── impact-analyzer/
│   ├── planner/
│   ├── research/
│   └── ...
└── cache/                  # 缓存数据
    ├── structure.json      # 项目结构缓存
    └── dependency-graph.json
```

### 6.3 长程自主运行（Daemon 模式）

支持无人值守的自主运行模式：

- **任务来源**：CLI 命令、配置文件、文件监视、定时任务
- **自主级别**：从"仅建议"到"全自主执行"的多级自主度
- **Checkpoint 与恢复**：定期保存执行状态，支持中断后恢复
- **成本控制**：每日/每周预算上限、安静时段、优先级调度
- **通知系统**：终端、桌面通知、Webhook、邮件（可选）

### 6.4 平台与环境检测

自动检测并适配运行环境，确保跨平台兼容：

- **操作系统**：自动识别 Linux/macOS/Windows/WSL，并进行特殊处理（如 WSL 路径转换）
- **Shell 检测**：自动识别 Bash/Zsh/Fish/PowerShell，适配命令语法
- **文件编码**：自动检测 UTF-8/GBK/Shift-JIS 等编码，必要时转换
- **三层注入保障**：编译期强制注入（Agent 创建工厂）+ 运行时防御（工具层兜底）

### 6.5 大文件智能读取

分级策略处理大文件，避免 Token 浪费：

| 文件大小 | 策略 |
|----------|------|
| 小文件 (< 500 行) | 直接读取全文 |
| 中文件 (500-2000 行) | 读取结构图 + 按需读取关键部分 |
| 大文件 (> 2000 行) | 结构感知解析器生成结构图摘要，再按需展开 |

---

## 第七部分：设计决策记录

| 决策领域 | 关键决策 |
|----------|----------|
| **核心架构** | Actor 模型 + CSP Channel 通信，每个 Agent 为独立 Actor |
| **异步运行时** | Tokio，Rust 生态事实标准，所有核心依赖（reqwest/rmcp/rig 等）均基于 Tokio，LLM I/O 密集场景无瓶颈 |
| **安全沙箱** | 双层设计：OS 层（Landlock + Seccomp）作为安全基座 + WASM 层（Wasmtime + WASI）提供函数级隔离和跨平台能力 |
| **工具协议** | MCP（rmcp v1.4+ 官方 SDK），同时作为客户端和服务器，支持 Stdio/HTTP/Unix Socket 三种传输 |
| **代码理解** | Tree-sitter 生成 Repo Map（精简仓库映射），替代全量文件列表，Token 消耗降低 30-50% |
| **路由与调度** | 四级复杂度路由，简单任务不启动多 Agent 编排 |
| **上下文管理** | 分层上下文池 + 摘要通信 + Repo Map 注入，避免全量上下文传递 |
| **记忆系统** | .assistant-memory/ 目录存储，支持增量更新和失效检测 |
| **递归编排** | Map-Filter-Reduce 模式，递归深度受 Token 预算约束 |
| **Git 并发** | 两阶段 + Commit Point 策略，避免并行 Coder 冲突 |
| **工具与安全** | 工具层兜底检测 + 双层沙箱，确保跨平台安全执行 |
| **TUI 与交互** | Ratatui 终端界面，实时展示 Agent 执行状态 |
| **错误处理** | Checkpoint 恢复 + 回滚策略 + 优雅降级 |

---

## 第八部分：详细设计文档索引

> 以下子文档包含各模块的完整详细设计，从 `MoreCode-多Agent编排架构设计.md` 拆分而来。

### 导航入口

- 完整索引与推荐阅读路径见 [README.md](README.md)。
- 本节表格中的 `#` 是拆分后的文件编号。
- 各子文档内部的 `##/###` 章节号是保留的概念章节号，两者不是同一套序号。

### 第一部分：Agent 定义

| # | 文档 | 说明 |
|---|------|------|
| 1 | [01-架构总览](01-Agent定义/01-架构总览.md) | 系统定位、整体架构图、设计原则、Agent 分类、数据流概览 |
| 2 | [02-Coordinator](01-Agent定义/02-Coordinator.md) | 主协调者：六步管道、意图理解、路由决策、项目记忆集成 |
| 3 | [03-认知层Agent](01-Agent定义/03-认知层Agent.md) | **Explorer + Impact Analyzer + Planner**：项目探索→影响分析→任务规划 |
| 4 | [04-执行层Agent](01-Agent定义/04-执行层Agent.md) | **Coder + Reviewer + Tester**：编码→审查→测试 质量保障流水线 |
| 5 | [05-专项能力Agent](01-Agent定义/05-专项能力Agent.md) | **Research + DocWriter + Debugger**：专项研究/文档/调试能力 |

### 第二部分：系统机制

| # | 文档 | 说明 |
|---|------|------|
| 6 | [06-平台与环境检测](02-系统机制/06-平台与环境检测.md) | OS/Shell/编码检测、路径处理、平台信息注入、移动端适配 |
| 7 | [07-路由决策机制](02-系统机制/07-路由决策机制.md) | 三级复杂度路由、决策矩阵、记忆感知路由 |
| 8 | [08-Git并发控制](02-系统机制/08-Git并发控制.md) | 两阶段 + Commit Point、Pipeline Commit Executor、回滚策略 |
| 9 | [09-上下文管理与通信](02-系统机制/09-上下文管理与通信.md) | 分层上下文池、摘要通信、Token 预算分配、递归上下文隔离 |
| 10 | [10-完整流程示例](02-系统机制/10-完整流程示例.md) | 端到端任务执行示例、Token 消耗总结 |
| 11 | [11-能力矩阵与代码实现](02-系统机制/11-能力矩阵与代码实现.md) | Agent 能力矩阵、Rust 核心代码实现（枚举/消息/协调器/记忆管理器） |
| 12 | [12-上下文压缩策略](02-系统机制/12-上下文压缩策略.md) | 四层渐进式压缩（微压缩→LLM摘要→记忆压缩→截断）+ Focus 主动压缩创新方向 |
| 13 | [13-权限与沙箱安全](02-系统机制/13-权限与沙箱安全.md) | Guardian 权限管理 + 任务级权限 + Landlock/Seccomp/WASM 双层沙箱 + MCP 安全加固 |
| 14 | [14-LLM Provider 与 Token 管理](02-系统机制/14-LLM-Provider与Token管理.md) | OpenAI 兼容统一层（DeepSeek/智谱/通义/Moonshot 等）+ 语义缓存中间件 + 树状 Token 预算 + 成本追踪 |
| 15 | [15-Prompt 缓存与模板管理](02-系统机制/15-Prompt缓存与模板管理.md) | 五层缓存架构 + 版本化失效 + Prompt 模板文件管理 + prompts.lock |
| 16 | [16-可观测性与 Hook 系统](02-系统机制/16-可观测性与Hook系统.md) | Agent 专用 Span + tracing/OTel + Langfuse + Pre/Post Hook + 隐私控制 |

### 第三部分：高级模式

| # | 文档 | 说明 |
|---|------|------|
| 17 | [17-递归编排模式](03-高级模式/17-递归编排模式.md) | Map-Filter-Reduce 递归编排、各 Agent 递归场景、Rust 实现 |
| 18 | [18-项目记忆系统](03-高级模式/18-项目记忆系统.md) | 记忆目录结构、生命周期、增量更新、失效检测、Rust 实现 |
| 19 | [19-设计决策记录](03-高级模式/19-设计决策记录.md) | 核心架构/路由/上下文/记忆/递归/工具/TUI/错误处理/技术选型决策 |
| 20 | [20-Daemon模式](03-高级模式/20-Daemon模式.md) | 长程自主运行、配置设计、Checkpoint 恢复、成本控制、通知系统 |
| 21 | [21-大文件智能读取](03-高级模式/21-大文件智能读取.md) | 分级策略、结构感知解析器、分块读取、缓存与增量更新 |
| 22 | [22-中断与取消机制](03-高级模式/22-中断与取消机制.md) | 行业主流方案调研、五大决策点、选型总结 |
| 23 | [23-记忆系统增强（Letta 式）](03-高级模式/23-记忆系统增强(Letta式).md) | 四层分层记忆（Core/Working/Recall/Archival）+ Sleep-Time Compute + 迁移策略 |

### 附录：技术选型调研

| # | 文档 | 说明 |
|---|------|------|
| 24 | [技术选型清单（含前沿调研）](临时文件-技术选型清单.md) | 25 个选型点完整调研：原方案、前沿替代、最终推荐、风险与验证 |

---

## 附录：选型优先级与实现路线

### 全部选型点总览

| 优先级 | # | 选型点 | 最终推荐方案 | 主文档章节 |
|--------|---|--------|-------------|-----------|
| **P0** | 1 | 上下文压缩 | 四层渐进式 + Focus 主动压缩 + LLMLingua-2 微压缩 | §1.8 |
| **P0** | 2 | 沙箱安全 | Landlock+seccomp + WASM 能力型安全 | §1.3 |
| **P0** | 3 | 权限管理 | Guardian 白名单 + 任务级权限 | §1.10 |
| **P0** | 4 | LLM Provider | Trait 抽象 + 多后端 + 缓存能力适配 | §1.7 |
| **P0** | 5 | Token 计数 | API 返回值 + BytesPer4 + riptoken（可选） | §1.6 |
| **P1** | 6 | 通信协议 | mpsc + StreamEvent（纯内部，否决 A2A） | §5.4 |
| **P1** | 7 | 记忆系统 | Letta 式四层分层记忆 + Sleep-Time Compute | §1.11 |
| **P1** | 8 | 流式输出 | Agent 结果流式 + 工具过程流式 | — |
| **P1** | 9 | 中断取消 | CancellationToken 继承链 | 第22章 |
| **P1** | 10 | MCP 协议 | rmcp v1.4+ + 安全加固 | §1.4 |
| **P1** | 11 | Hook 系统 | Pre/Post 事件 Hook | — |
| **P1** | 12 | AST 解析 | ripgrep → Probe → LSP-MCP Bridge 三层架构 | §1.13 |
| **P1** | 13 | Prompt 缓存 | 五层缓存 + 版本化失效 | §1.9 |
| **P2** | 14 | 遥测 | tracing + AgentTelemetry + Langfuse | §1.12 |
| **P2** | 15 | 配置管理 | 多级 TOML + 环境变量 | — |
| **P2** | 16 | IDE 集成 | JSON-RPC Bridge（Phase 2） | — |
| **P2** | 17 | 认证系统 | API Key + OAuth + keyring | — |
| **P2** | 18 | 构建系统 | Cargo + Feature flags | — |
| **P2** | 19 | 文件变更监听 | notify + Git hook | — |
| **P2** | 20 | Prompt 模板 | Markdown 文件 + 动态拼接 + 版本管理 | — |
| **P2** | 21 | 输出结构化 | 三层容错（JSON Mode → 代码块提取 → LLM 修复） | — |
| **P2** | 22 | 语义检索 | tantivy → sqlite-vss → Mem0-G 图谱 | — |
| **P2** | 23 | Checkpoint | SQLite 持久化 | 第20章 |
| **P2** | 24 | 工具注册 | Trait + Registry + WASM 动态加载 | — |
| **P2** | 25 | 多入口 | CLI + TUI + Exec + MCP Server | — |

### 实现路线

```
Phase 1（MVP）:
  §1.7 LLM Provider → §1.6 Token 计数 → §1.8 上下文压缩(L1+L4) → §1.10 权限 → §1.3 沙箱 → §5.4 通信 → §1.13 AST(基础)

Phase 2（增强）:
  §1.9 Prompt 缓存(五层) → 流式输出 → 第22章 中断取消 → 第23章 记忆(Letta式) → Hook → §1.4 MCP → Prompt 模板 → 工具注册

Phase 3（创新）:
  §1.8 上下文压缩(Focus) → §1.13 AST(Probe+LSP-MCP) → §1.12 遥测 → 配置 → 文件监听 → 输出结构化 → Checkpoint

Phase 4（前沿）:
  §1.8 上下文压缩(ACON 蒸馏) → §1.3 Hyperlight 评估 → 语义检索(Mem0-G) → WASM 加载 → MCP Server → IDE → 认证
```

### 文档补充优化项（2026-04）

| 编号 | 问题 | 关联文档 | 建议补充 | 预期收益 |
|------|------|----------|----------|----------|
| **P1-3** | **步骤 1+2 可合并为一次 LLM 调用** | [02-Coordinator](01-Agent定义/02-Coordinator.md) | 意图识别 + 信息补全合并为一次 LLM 调用，输出 `IntentAnalysis { intent, clarifications }` | 减少 1 次 LLM 调用，响应快 1-3 秒 |
| **P1-5** | **缺少背压机制** | [09-上下文管理与通信](02-系统机制/09-上下文管理与通信.md) | 使用有界 Channel `mpsc::channel(16)`，Coordinator 感知 Agent 处理速度，队列满时暂停分配 | 防止内存溢出 |
| **P1-7** | **LLM 输出解析静默失败** | [02-Coordinator](01-Agent定义/02-Coordinator.md) | `serde_json::from_str` 失败时用 LLM 二次解析，非静默使用默认值 | 避免路由决策完全错误 |
| **P1-9** | **init_observability 嵌套 runtime 会 panic** | [16-可观测性与Hook系统](02-系统机制/16-可观测性与Hook系统.md) | 用 `opentelemetry_sdk::runtime::Tokio` 替代手动 `Runtime::new()` | 修复运行时 panic |
| **P1-10** | **collect_changed_files 范围过大** | [08-Git并发控制](02-系统机制/08-Git并发控制.md) | Commit Point 只提交 `expected_files` 与 `git status` 的交集 | 防止误提交无关文件 |
