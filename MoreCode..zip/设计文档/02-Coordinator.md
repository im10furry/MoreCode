# MoreCode — Coordinator

## 2. Coordinator（主协调者）

### 2.1 角色定位

Coordinator 是整个多 Agent 系统的**大脑和中枢**，负责接收用户请求、理解意图、决策路由、监控执行、整合结果并最终交付。它是用户与 Agent 系统之间的唯一接口，所有任务都必须经过 Coordinator 进行调度。

**核心特征**：
- **唯一入口**：用户的所有请求都通过 Coordinator 进入系统
- **不执行具体任务**：Coordinator 本身不读写文件、不编写代码，只做决策和协调
- **全生命周期管理**：从任务接收到最终交付，Coordinator 贯穿始终
- **记忆驱动**：启动时读取项目记忆，避免重复探索

### 2.2 六步管道

Coordinator 的核心工作流程是一个六步管道：

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  1.了解   │───→│  2.询问   │───→│  3.路由   │───→│  4.监控   │───→│  5.结果   │───→│  6.最终   │
│   意图    │    │   补全    │    │   决策    │    │   执行    │    │   整合    │    │   交付    │
└──────────┘    └──────────┘    └──────────┘    └──────────┘    └──────────┘    └──────────┘
     │               │               │               │               │               │
  分析用户请求    识别信息缺口     决定执行策略     跟踪Agent状态    汇总所有结果    生成变更摘要
  提取关键信息    向用户提问       分配Agent任务    处理异常情况    检查完整性      展示给用户
```

> **实现优化（P1-3）**：六步管道是概念模型。在首轮请求分析时，步骤 1「了解意图」与步骤 2「询问补全」可以合并为一次结构化 LLM 调用，统一返回 `IntentAnalysis { intent, clarifications }`。这样通常可减少 1 次 LLM 往返，响应速度提升约 1-3 秒。
>
> **健壮性优化（P1-7）**：LLM 输出解析不能静默失败。`serde_json::from_str` 首次失败时，应触发一次“仅修复格式、不新增事实”的二次 LLM 解析；如果仍失败，Coordinator 必须显式上报 `IntentParseFailed`，而不是悄悄回退到默认 `UserIntent`，否则可能把复杂任务误路由为简单任务。

#### 步骤 1：了解意图

**目标**：从用户的自然语言请求中提取结构化的任务信息。

**输入**：用户原始请求文本

**输出**：`UserIntent` 结构

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserIntent {
    /// 原始请求文本
    pub raw_request: String,
    /// 任务类型
    pub task_type: TaskType,
    /// 涉及的文件/模块（已识别）
    pub target_files: Vec<String>,
    /// 涉及的技术领域
    pub domains: Vec<String>,
    /// 初步复杂度评估
    pub estimated_complexity: Complexity,
    /// 是否需要项目上下文
    pub needs_project_context: bool,
    /// 是否需要外部研究
    pub needs_research: bool,
}

/// 任务类型（静态分类，用于路由决策和 Agent 选择）
///
/// **与 TaskIntent 的职责分工**：
/// - `TaskType`（本枚举）：**静态分类**，由 Coordinator 根据用户输入确定，
///   用于路由决策（选择哪些 Agent）和资源分配（Token 预算）。
///   值域稳定，不会频繁变化。
/// - `TaskIntent`（第 11 章）：**动态意图**，由 LLM 意图识别模块生成，
///   用于细化任务描述和调整 Agent 行为参数。
///   值域可扩展，支持自定义意图。
///
/// **映射关系**：TaskType 是 TaskIntent 的粗粒度超集。
/// 例如 TaskType::BugFix 对应 TaskIntent::BugFix，
/// 但 TaskType::Other(String) 可涵盖 TaskIntent 的所有自定义值。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TaskType {
    /// 新功能开发
    FeatureDevelopment,
    /// Bug 修复
    BugFix,
    /// 代码重构
    Refactoring,
    /// 文档编写
    Documentation,
    /// 测试编写
    Testing,
    /// 项目配置
    Configuration,
    /// 代码审查
    CodeReview,
    /// 调试排错
    Debugging,
    /// 其他（可涵盖 TaskIntent 的自定义值）
    Other(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Complexity {
    /// 简单：单文件、单 Agent 可完成
    Simple,
    /// 中等：多文件、需要 Planner 规划
    Medium,
    /// 复杂：涉及架构变更、需要多 Agent 协作
    Complex,
    /// 研究：需要外部信息收集
    Research,
}
```

**处理逻辑**：

```rust
impl Coordinator {
    /// 步骤 1：了解用户意图
    async fn understand_intent(&self, request: &str) -> anyhow::Result<UserIntent> {
        let prompt = format!(
            r#"分析以下用户请求，提取结构化意图信息：

用户请求：{request}

请以 JSON 格式返回：
- task_type: 任务类型（feature/bugfix/refactor/docs/test/config/review/debug/other）
- target_files: 可能涉及的文件路径列表
- domains: 涉及的技术领域
- estimated_complexity: 初步复杂度评估（simple/medium/complex/research）
- needs_project_context: 是否需要了解项目上下文
- needs_research: 是否需要外部信息研究"#
        );

        let response = self.llm_client.complete(&prompt).await;
        self.parse_or_repair_json::<UserIntent>("user_intent", request, &response)
            .await
    }

    async fn parse_or_repair_json<T>(
        &self,
        schema_name: &str,
        user_request: &str,
        raw: &str,
    ) -> anyhow::Result<T>
    where
        T: serde::de::DeserializeOwned,
    {
        match serde_json::from_str(raw) {
            Ok(value) => Ok(value),
            Err(first_err) => {
                tracing::warn!(
                    %schema_name,
                    %first_err,
                    "LLM JSON parse failed, attempting structured extraction"
                );

                // 策略 1（优先）：使用 JSON mode 重新提取，而非让 LLM "修复"原文
                // JSON mode 由模型保证输出合法性，避免修复过程引入语义偏差
                let extract_prompt = format!(
                    r#"从以下文本中提取结构化信息，输出为合法 JSON。
要求：
1. 仅提取原文中明确存在的信息，不得新增或推断
2. 无法确定的字段使用 null
3. 直接输出 JSON，不要解释

原始用户请求：
{user_request}

目标结构名：{schema_name}

待提取的原始文本：
{raw}"#
                );

                let repaired = self.llm_client
                    .complete(LlmRequest {
                        messages: vec![ChatMessage::system(&extract_prompt)],
                        response_format: Some(ResponseFormat::Json),
                        temperature: Some(0.0), // 确定性输出，减少语义偏差
                        max_tokens: Some(500),
                        ..Default::default()
                    })
                    .await?
                    .content;

                serde_json::from_str(&repaired).map_err(|second_err| {
                    anyhow::anyhow!(
                        "IntentParseFailed: first_parse={first_err}; json_mode_extract={second_err}"
                    )
                })
            }
        }
    }
}
```

**示例**：

用户输入：`"给所有 API 端点添加速率限制中间件"`

提取结果：
```json
{
  "raw_request": "给所有 API 端点添加速率限制中间件",
  "task_type": "feature",
  "target_files": ["src/middleware/", "src/routes/", "src/config/"],
  "domains": ["middleware", "api", "configuration"],
  "estimated_complexity": "complex",
  "needs_project_context": true,
  "needs_research": false
}
```

#### 步骤 2：询问补全

**目标**：识别用户请求中的信息缺口，向用户提问以补全必要信息。

**触发条件**：
- 用户请求模糊，存在多种理解方式
- 缺少关键的技术决策信息（如使用哪个库、采用什么方案）
- 涉及破坏性变更，需要确认影响范围

**不触发条件**：
- 请求足够明确，可以直接执行
- 缺失的信息可以通过项目上下文推断
- 是简单的格式化、lint 等无歧义操作

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Clarification {
    /// 需要确认的问题
    pub questions: Vec<Question>,
    /// 推荐的默认答案（如果有）
    pub suggestions: HashMap<String, String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Question {
    /// 问题 ID
    pub id: String,
    /// 问题内容
    pub question: String,
    /// 选项（如果是选择题）
    pub options: Option<Vec<String>>,
    /// 是否必答
    pub required: bool,
    /// 默认值
    pub default: Option<String>,
}
```

**示例**：

用户输入：`"优化数据库查询性能"`

补全问题：
```json
{
  "questions": [
    {
      "id": "target_query",
      "question": "您希望优化哪些查询？请提供具体的查询场景或端点。",
      "options": null,
      "required": true,
      "default": null
    },
    {
      "id": "optimization_approach",
      "question": "您偏好哪种优化方式？",
      "options": ["添加数据库索引", "优化查询语句", "引入缓存层", "综合方案"],
      "required": false,
      "default": "综合方案"
    }
  ],
  "suggestions": {
    "target_query": "可以通过运行 EXPLAIN ANALYZE 来定位慢查询"
  }
}
```

#### 步骤 1 + 2 合并实现（运行时优化）

在实现层面，Coordinator 不必先调用一次 LLM 做意图识别，再调用一次 LLM 判断是否需要追问。更高效的做法是让同一次结构化调用同时输出：

- `intent`：结构化任务意图
- `clarifications`：需要向用户补问的问题；如果可直接执行则返回 `null`

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IntentAnalysis {
    pub intent: UserIntent,
    pub clarifications: Option<Clarification>,
}

impl Coordinator {
    /// 运行时优化：步骤 1 + 2 合并为一次结构化调用
    async fn analyze_intent_and_clarify(
        &self,
        request: &str,
    ) -> anyhow::Result<IntentAnalysis> {
        let prompt = format!(
            r#"分析以下用户请求，并一次性返回：
1. 结构化任务意图 intent
2. 如信息不足，需要补问的 clarifications；如果可以直接执行则返回 null

用户请求：{request}

请返回 JSON：
{{
  "intent": {{
    "task_type": "feature|bugfix|refactor|docs|test|config|review|debug|other",
    "target_files": [],
    "domains": [],
    "estimated_complexity": "simple|medium|complex|research",
    "needs_project_context": true,
    "needs_research": false
  }},
  "clarifications": {{
    "questions": [],
    "suggestions": {{}}
  }} | null
}}"#
        );

        let response = self.llm_client.complete(&prompt).await;
        self.parse_or_repair_json::<IntentAnalysis>("intent_analysis", request, &response)
            .await
    }
}
```

```rust
let analysis = self.analyze_intent_and_clarify(request).await?;

match analysis.clarifications {
    Some(clarification) if !clarification.questions.is_empty() => {
        self.ask_for_clarification(clarification).await?;
    }
    _ => {
        self.route_task(&analysis.intent).await?;
    }
}
```

这样文档层面仍保持“先理解、再补全”的认知顺序，但运行时只需一次 LLM 调用即可完成首轮分析。

#### LLM 输出解析容错（P1-7）

Coordinator 对结构化输出的处理遵循以下顺序：

1. 首次 `serde_json::from_str` 解析
2. 失败后发起一次“格式修复型” LLM 调用，只做 JSON 修复，不允许补造事实
3. 二次解析仍失败时，返回显式错误，如 `IntentParseFailed`
4. 由上层决定降级策略，例如：
   - 直接向用户确认需求
   - 回退到保守路由（例如先进入 Explorer / Clarification）
   - 记录观测指标并终止本轮自动决策

**禁止的做法**：

- 解析失败后静默构造 `TaskType::Other + Complexity::Simple`
- 在没有告警的情况下直接进入路由决策
- 把“解析失败”和“用户请求本身简单”混为一谈

#### 步骤 3：路由决策

**目标**：根据任务复杂度和类型，决定执行策略和 Agent 分配。

这是 Coordinator 最核心的决策步骤，决定了任务将如何被执行。

##### 四级路由

```
┌─────────────────────────────────────────────────────────────────┐
│                        路由决策矩阵                               │
├─────────┬──────────────┬──────────────┬─────────────────────────┤
│  级别    │   复杂度      │   执行策略    │      Agent 编排         │
├─────────┼──────────────┼──────────────┼─────────────────────────┤
│ 简单   │ 单文件/单操作  │ 直接执行      │ 单个 Agent 直接执行      │
│         │ 无依赖关系    │              │ Coder / Reviewer / ...  │
├─────────┼──────────────┼──────────────┼─────────────────────────┤
│ 中等   │ 多文件修改    │ 规划后执行    │ Planner → Coder →       │
│         │ 有明确依赖    │              │ Reviewer → Tester       │
├─────────┼──────────────┼──────────────┼─────────────────────────┤
│ 复杂   │ 跨模块变更    │ 全面分析后    │ Explorer → ImpactAnalyzer│
│         │ 架构级影响    │ 分阶段执行    │ → Planner → Coder[N] →  │
│         │              │              │ Reviewer → Tester       │
├─────────┼──────────────┼──────────────┼─────────────────────────┤
│ 研究   │ 需要外部信息  │ 先研究后执行  │ Research → (降级为       │
│         │ 技术方案调研  │              │ 简单/中等/复杂)              │
└─────────┴──────────────┴──────────────┴─────────────────────────┘
```

##### 路由决策详细说明

**简单路由 (Simple)**

适用场景：
- 修复单个文件中的拼写错误
- 格式化代码
- 添加/修改单个函数
- 简单的配置修改
- 添加注释

执行流程：
```
Coordinator → Coder → (可选) Reviewer → 完成
```

Token 预算：8,000 ~ 15,000 tokens（由 TokenBudgetAllocator 动态计算）

**中等路由 (Medium)**

适用场景：
- 修改多个相关文件
- 新增一个完整的功能模块
- 重构一个模块的内部实现
- 添加新的 API 端点（含测试）

执行流程（含预飞检查）：
```
Coordinator → Planner → Coder(方案) → Reviewer(预飞) → Coder(执行) → Reviewer → Tester → 完成
                                    │                │              │
                                    └── 方案输出 ───→┘              │
                                                     │              │
                                              注入注意点 ──────────┘
```

> **预飞检查**：Coder 先输出修改方案（不写代码），Reviewer 做可行性分析，
> 将注意点注入 Coder 后再执行编写。详见第 4 章 §6.2.1。
> 简单任务（单文件、低风险）可跳过预飞检查。

Token 预算：8,000 ~ 16,000 tokens

**复杂路由 (Complex)**

适用场景：
- 跨多个模块的架构变更
- 引入新的技术栈或依赖
- 数据库 schema 变更
- 认证/授权系统改造
- 性能优化（涉及多个层面）

执行流程（含预飞检查）：
```
Coordinator → Explorer → ImpactAnalyzer → Planner → Coder(方案) → Reviewer(预飞) → Coder[N](执行) → Reviewer → Tester → 完成
                                                         │                │                  │
                                                         └── 方案输出 ───→┘                  │
                                                                          │                  │
                                                                   注入注意点 ──────────┘
```

> **预飞检查**：复杂路由始终启用预飞检查。Coder 的方案需覆盖所有子 Coder 的修改计划，
> Reviewer 的可行性分析包含跨模块影响评估。

Token 预算：20,000 ~ 50,000 tokens

**研究路由 (Research)**

适用场景：
- 需要查阅外部文档或 API 参考
- 技术选型决策
- 不熟悉的库或框架的使用
- 安全漏洞调研

执行流程：
```
Coordinator → Research → (评估后降级为 简单/中等/复杂) → 正常执行
```

##### Agent 间通信优化策略

**核心原则**：10 个 Agent 是**能力池**，每次任务仅启用路由决策所需的子集。
通信开销取决于启用的 Agent 数量和交接方式，而非池的总大小。

**优化 1：按复杂度最小化 Agent 集合**

| 路由级别 | 启用 Agent 数 | 交接次数 | 优化策略 |
|----------|-------------|---------|----------|
| Simple | 1-2 | 0-1 | Coder 单 Agent 完成；Reviewer 仅在 `auto_review=true` 时启用 |
| Medium | 3-4 | 2-3 | Planner→Coder 交接使用结构化 `ExecutionPlan`（非自然语言摘要） |
| Complex | 5-7 | 4-6 | Explorer+ImpactAnalyzer 合并为单次 LLM 调用（双角色 Prompt） |
| Research | 1+后续 | 1+后续 | Research 结果直接注入 Planner 上下文，跳过 Explorer |

**优化 2：结构化交接替代自然语言摘要**

Agent 间交接使用结构化数据（`AgentExecutionReport`），而非 LLM 生成自然语言摘要：

```rust
/// 交接数据格式选择（按场景）
pub enum HandoffFormat {
    /// 结构化 JSON（推荐）：零 LLM 调用，直接序列化/反序列化
    /// 适用于：Planner→Coder（ExecutionPlan）、Coder→Reviewer（变更列表）
    Structured,

    /// 压缩摘要：LLM 生成简短摘要（≤200 tokens）
    /// 适用于：Explorer→Planner（项目结构总结）、Research→Planner（调研结论）
    CompressedSummary,

    /// 直接注入：不生成摘要，将上游完整输出作为下游上下文
    /// 适用于：单 Agent 管道（Simple 路由）、Daemon 模式记忆已加载
    DirectInjection,
}
```

**优化 3：Daemon 模式下的通信零开销**

Daemon 模式（7×24）运行时，项目上下文和记忆已预加载到 Coordinator，Agent 间无需重复传递：

```rust
/// Daemon 模式下的任务执行（通信优化版）
impl Coordinator {
    pub async fn handle_daemon_task(&self, task: DaemonTask) -> Result<TaskResult> {
        // 项目上下文已在 Daemon 启动时加载，所有 Agent 共享
        let shared_context = self.project_context.as_ref().unwrap();

        match task.route_level {
            RouteLevel::Simple => {
                // 单 Agent：零交接，直接执行
                let coder = self.create_agent(AgentType::Coder)?;
                coder.execute_with_context(task.description, shared_context).await
            }
            RouteLevel::Medium => {
                // 结构化交接：Planner 生成 ExecutionPlan，Coder 直接消费
                let plan = self.planner.plan(task.description, shared_context).await?;
                let coder = self.create_agent(AgentType::Coder)?;
                coder.execute_plan(plan, shared_context).await
            }
            // Complex/Research 类似，但使用共享上下文减少重复传递
            _ => self.dispatch_complex(task, shared_context).await,
        }
    }
}
```

**优化 4：批量任务复用上下文**

Daemon 模式下连续处理多个任务时，Agent 间共享上下文，避免重复加载：

```
任务队列: [Task A, Task B, Task C]
                    ↓
┌─────────────────────────────────────────┐
│ 共享上下文（一次性加载）                    │
│ - 项目结构、依赖图、代码约定               │
│ - 已完成的任务结果（避免重复修改）          │
└─────────────────────────────────────────┘
                    ↓
Task A → Coder → Reviewer → 完成
Task B → Coder → Reviewer → 完成  （复用同一上下文）
Task C → Planner → Coder[N] → ...  （复用同一上下文）
```

**量化效果**：

| 场景 | 优化前交接开销 | 优化后交接开销 | 节省 |
|------|-------------|-------------|------|
| Simple（单文件修复） | ~2K tokens（摘要生成+解析） | 0 tokens（单 Agent） | 100% |
| Medium（新功能） | ~6K tokens（3 次交接摘要） | ~1K tokens（结构化 Plan） | 83% |
| Complex（架构变更） | ~12K tokens（5 次交接摘要） | ~4K tokens（共享上下文+结构化） | 67% |
| Daemon 批量（10 个 Simple） | ~20K tokens | ~0 tokens（共享上下文） | ~100% |

Token 预算：10,000 ~ 30,000 tokens（研究阶段）

##### 复杂度评估规则

```rust
/// 复杂度评估配置（可从配置文件加载，支持运行时调整）
///
/// **设计原则**：评分规则外部化为配置，支持：
/// 1. 按项目特征定制权重（如文档项目降低代码复杂度权重）
/// 2. 基于历史数据的自动校准（通过 `calibrate_from_history` 方法）
/// 3. 不同任务类型的差异化评分（FeatureDevelopment 不再固定 20 分）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComplexityConfig {
    /// LLM 预判复杂度的基础分
    pub llm_complexity_weights: HashMap<Complexity, i32>,
    /// 文件数量分档及对应分数
    pub file_count_tiers: Vec<(usize, usize, i32)>, // (min, max, score)
    /// 任务类型权重（不再固定，可按项目调整）
    pub task_type_weights: HashMap<String, i32>,
    /// 需要项目上下文的加分
    pub needs_context_bonus: i32,
    /// 每个额外技术领域的加分
    pub domain_bonus: i32,
    /// 项目规模分档及对应分数
    pub project_size_tiers: Vec<(usize, usize, i32)>, // (min_files, max_files, score)
    /// 路由阈值
    pub route_thresholds: RouteThresholds,
    /// LLM 预判权重倍率（控制 LLM 预判在总分中的影响力）
    /// 设为 0.0 则完全忽略 LLM 预判，设为 2.0 则加倍
    pub llm_weight_multiplier: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteThresholds {
    pub simple_max: i32,
    pub medium_max: i32,
}

impl Default for ComplexityConfig {
    fn default() -> Self {
        // 默认配置：与原始硬编码规则行为一致，但可外部化调整
        Self {
            llm_complexity_weights: HashMap::from([
                (Complexity::Simple, 0),
                (Complexity::Medium, 10),
                (Complexity::Complex, 25),
            ]),
            file_count_tiers: vec![
                (0, 1, 0),
                (2, 5, 10),
                (6, 15, 25),
                (16, usize::MAX, 40),
            ],
            task_type_weights: HashMap::from([
                ("FeatureDevelopment".into(), 20),
                ("BugFix".into(), 15),
                ("Refactoring".into(), 30),
                ("Documentation".into(), 5),
                ("Testing".into(), 10),
                ("Configuration".into(), 5),
                ("CodeReview".into(), 10),
                ("Debugging".into(), 15),
            ]),
            needs_context_bonus: 10,
            domain_bonus: 5,
            project_size_tiers: vec![
                (0, 50, 0),
                (51, 200, 5),
                (201, 500, 10),
                (501, usize::MAX, 15),
            ],
            route_thresholds: RouteThresholds {
                simple_max: 15,
                medium_max: 35,
            },
            llm_weight_multiplier: 1.0,
        }
    }
}

/// 复杂度评估器
pub struct ComplexityEvaluator {
    config: ComplexityConfig,
    /// 历史校准数据：记录每次评估的分数与实际执行结果
    calibration_history: Vec<CalibrationRecord>,
}

/// 校准记录：评估分数 vs 实际执行复杂度
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalibrationRecord {
    /// 评估时的各项因素快照
    pub factors: ComplexityFactors,
    /// 评估分数
    pub evaluated_score: i32,
    /// 评估结果
    pub evaluated_route: RouteLevel,
    /// 实际执行是否需要更多 Agent（用于校准）
    pub actual_needed_more_agents: bool,
    /// 实际 Token 消耗
    pub actual_tokens_used: u64,
    /// 记录时间
    pub timestamp: DateTime<Utc>,
}

/// 评估因素快照（用于校准分析）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComplexityFactors {
    pub file_count: usize,
    pub task_type: String,
    pub needs_context: bool,
    pub domain_count: usize,
    pub project_size: usize,
    pub llm_complexity: Complexity,
}

impl ComplexityEvaluator {
    pub fn new(config: ComplexityConfig) -> Self {
        Self {
            config,
            calibration_history: Vec::new(),
        }
    }

    /// 从配置文件加载（支持 TOML/YAML/JSON）
    pub fn from_file(path: &Path) -> Result<Self, CoordinatorError> {
        let content = tokio::fs::read_to_string(path)
            .map_err(|e| CoordinatorError::ConfigLoadFailed(path.to_path_buf(), e.to_string()))?;
        let config: ComplexityConfig = serde_json::from_str(&content)
            .map_err(|e| CoordinatorError::ConfigParseFailed(path.to_path_buf(), e.to_string()))?;
        Ok(Self::new(config))
    }

    /// 评估任务复杂度
    pub fn evaluate(
        &self,
        intent: &UserIntent,
        project_ctx: Option<&ProjectContext>,
    ) -> RouteLevel {
        let mut score = 0i32;

        // 因素 0：LLM 预判（权重可调，默认 1.0）
        if let Some(&base) = self.config.llm_complexity_weights.get(&intent.estimated_complexity) {
            score += (base as f32 * self.config.llm_weight_multiplier) as i32;
        } else if matches!(intent.estimated_complexity, Complexity::Research) {
            return RouteLevel::Research;
        }

        // 因素 1：涉及的文件数量
        let file_count = intent.target_files.len();
        for (min, max, tier_score) in &self.config.file_count_tiers {
            if file_count >= *min && file_count <= *max {
                score += *tier_score;
                break;
            }
        }

        // 因素 2：任务类型（从配置读取权重，不再硬编码）
        let type_key = format!("{:?}", intent.task_type);
        if let Some(&type_score) = self.config.task_type_weights.get(&type_key) {
            score += type_score;
        } else {
            score += 10; // 未知任务类型默认分
        }

        // 因素 3：是否需要外部研究
        if intent.needs_research {
            return RouteLevel::Research;
        }

        // 因素 4：是否需要项目上下文
        if intent.needs_project_context {
            score += self.config.needs_context_bonus;
        }

        // 因素 5：涉及的技术领域数量
        let domain_count = intent.domains.len();
        if domain_count > 1 {
            score += (domain_count as i32 - 1) * self.config.domain_bonus;
        }

        // 因素 6：项目规模（如果有项目上下文）
        if let Some(ctx) = project_ctx {
            let total = ctx.total_files;
            for (min, max, tier_score) in &self.config.project_size_tiers {
                if total >= *min && total <= *max {
                    score += *tier_score;
                    break;
                }
            }
        }

        // 根据配置的阈值判定路由级别
        let thresholds = &self.config.route_thresholds;
        match score {
            0..=thresholds.simple_max => RouteLevel::Simple,
            (thresholds.simple_max + 1)..=thresholds.medium_max => RouteLevel::Medium,
            _ => RouteLevel::Complex,
        }
    }

    /// 基于历史数据校准配置
    ///
    /// 分析 `calibration_history` 中的评估偏差，自动调整权重：
    /// - 如果某任务类型频繁被低估（evaluated < actual），增加其权重
    /// - 如果某任务类型频繁被高估（evaluated > actual），降低其权重
    /// - 调整路由阈值以匹配实际分布
    ///
    /// 建议在积累 50+ 条校准记录后执行，校准结果持久化到配置文件。
    pub fn calibrate_from_history(&mut self) -> Option<ComplexityConfig> {
        if self.calibration_history.len() < 20 {
            tracing::info!(
                records = self.calibration_history.len(),
                "校准记录不足 20 条，跳过自动校准"
            );
            return None;
        }

        let mut adjusted = self.config.clone();

        // 按任务类型统计低估/高估次数
        let mut type_adjustments: HashMap<String, i32> = HashMap::new();
        for record in &self.calibration_history {
            if record.actual_needed_more_agents {
                // 被低估：增加该任务类型的权重
                let delta = 3i32.min(50 - record.evaluated_score);
                *type_adjustments.entry(record.factors.task_type.clone())
                    .or_insert(0) += delta;
            } else if record.evaluated_score > 30 && record.actual_tokens_used < 5000 {
                // 被高估：简单任务消耗很少 Token
                let delta = -3i32.max(-(record.evaluated_score - 10));
                *type_adjustments.entry(record.factors.task_type.clone())
                    .or_insert(0) += delta;
            }
        }

        // 应用调整（限制单次调整幅度 ±10）
        for (type_key, delta) in &type_adjustments {
            let clamped = delta.clamp(-10, 10);
            if let Some(weight) = adjusted.task_type_weights.get_mut(type_key) {
                *weight = (*weight + clamped).max(1);
            }
        }

        // 调整路由阈值：基于实际分布的 33/66 百分位数
        let mut scores: Vec<i32> = self.calibration_history.iter()
            .map(|r| r.evaluated_score)
            .collect();
        scores.sort();
        if scores.len() >= 20 {
            let p33 = scores[scores.len() / 3];
            let p66 = scores[scores.len() * 2 / 3];
            adjusted.route_thresholds.simple_max = p33;
            adjusted.route_thresholds.medium_max = p66;
        }

        tracing::info!(
            adjustments = type_adjustments.len(),
            new_simple_max = adjusted.route_thresholds.simple_max,
            new_medium_max = adjusted.route_thresholds.medium_max,
            "复杂度校准完成"
        );

        Some(adjusted)
    }

    /// 记录一次校准数据（任务完成后调用）
    pub fn record_calibration(
        &mut self,
        factors: ComplexityFactors,
        evaluated_score: i32,
        evaluated_route: RouteLevel,
        actual_needed_more_agents: bool,
        actual_tokens_used: u64,
    ) {
        self.calibration_history.push(CalibrationRecord {
            factors,
            evaluated_score,
            evaluated_route,
            actual_needed_more_agents,
            actual_tokens_used,
            timestamp: Utc::now(),
        });
        // 保留最近 500 条记录
        if self.calibration_history.len() > 500 {
            self.calibration_history.drain(..self.calibration_history.len() - 500);
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RouteLevel {
    /// 简单：单 Agent 直接执行
    Simple,
    /// 中等：需要 Planner 规划
    Medium,
    /// 复杂：需要全面分析
    Complex,
    /// 研究：需要先收集外部信息
    Research,
}
```

#### 步骤 3.5：流式输出转发

**目标**：Agent 执行 LLM 调用时，实时将流式输出转发到 UI 层。

```rust
impl Coordinator {
    /// 流式执行 Agent 任务（替代同步 dispatch_tasks）
    ///
    /// 每个 Agent 在调用 LLM 时使用 `chat_stream` 而非 `chat`，
    /// 通过 StreamForwarder 实时将内容推送到 EventBus → UI 层。
    async fn dispatch_tasks_streaming(
        &self,
        agents: &[AgentType],
        task: &TaskDescription,
        budget: &HashMap<AgentType, u32>,
    ) -> Result<Vec<AgentResult>, CoordinatorError> {
        let mut handles = Vec::new();

        for agent_type in agents {
            let agent = self.create_agent(*agent_type)?;
            let event_bus = self.event_bus.clone();
            let task = task.clone();
            let token_budget = budget.get(agent_type).copied().unwrap_or(0) as u64;

            let handle = tokio::spawn(async move {
                // 创建流式转发器
                let forwarder = StreamForwarder::new(
                    agent.agent_id().to_string(),
                    event_bus,
                );

                // Agent 使用 chat_stream 执行，forwarder 自动推送事件
                agent.execute_streaming(&task, token_budget, &forwarder).await
            });

            handles.push(handle);
        }

        // 等待所有 Agent 完成
        let mut results = Vec::new();
        for handle in handles {
            match handle.await {
                Ok(Ok(result)) => results.push(result),
                Ok(Err(e)) => tracing::error!(error = %e, "Agent 执行失败"),
                Err(e) => tracing::error!(error = %e, "Agent 任务 panic"),
            }
        }

        Ok(results)
    }
}
```

**流式输出链路**：
```
LLM API (SSE) → chat_stream() → StreamEvent
    → StreamForwarder.on_event()
    → AgentEvent::LlmStreamDelta
    → EventBus.emit()
    → TUI 实时渲染 / CLI 输出
```

#### 步骤 4：监控执行

**目标**：实时跟踪各 Agent 的执行状态，处理异常情况。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionStatus {
    /// 当前执行阶段
    pub current_phase: ExecutionPhase,
    /// 各 Agent 的状态
    pub agent_statuses: HashMap<String, AgentStatus>,
    /// 整体进度百分比
    pub progress_percent: f32,
    /// 已消耗的 token 总量
    pub tokens_used: usize,
    /// 预估剩余 token
    pub tokens_remaining: usize,
    /// 开始时间
    pub started_at: DateTime<Utc>,
    /// 异常信息
    pub errors: Vec<ExecutionError>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ExecutionPhase {
    /// 意图理解中
    Understanding,
    /// 信息补全中
    Clarifying,
    /// 路由决策中
    Routing,
    /// 项目探索中
    Exploring,
    /// 影响分析中
    AnalyzingImpact,
    /// 任务规划中
    Planning,
    /// 编码执行中
    Coding,
    /// 代码审查中
    Reviewing,
    /// 测试执行中
    Testing,
    /// 结果整合中
    Integrating,
    /// 已完成
    Completed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentStatus {
    pub agent_id: String,
    pub agent_type: AgentType,
    pub state: AgentState,
    pub started_at: Option<DateTime<Utc>>,
    pub completed_at: Option<DateTime<Utc>>,
    pub tokens_used: usize,
    pub output_summary: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AgentState {
    /// 等待中
    Pending,
    /// 执行中
    Running,
    /// 已完成
    Completed,
    /// 失败
    Failed(String),
    /// 已取消
    Cancelled,
}
```

**异常处理策略**：

| 异常类型 | 处理方式 | 重试策略 |
|----------|----------|----------|
| Agent 执行超时 | 记录错误，尝试缩小任务范围后重试 | 最多 2 次，每次超时时间翻倍 |
| LLM API 调用失败 | 等待后重试 | 指数退避，最多 3 次 |
| Token 预算超限 | 中断当前 Agent，返回已完成部分 | 不重试，降级处理 |
| 工具调用失败 | 记录错误，尝试替代方案 | 最多 1 次 |
| Reviewer 拒绝变更 | 退回 Coder 修改 | 最多 3 次循环 |

#### 步骤 5：结果整合

**目标**：汇总所有 Agent 的输出，检查完整性，生成统一的变更摘要。

```rust
/// 整合过程中的中间产物（Explorer/ImpactAnalyzer/Research 的输出）
/// 这些数据不直接展示给用户，而是作为后续 Agent 的输入上下文
#[derive(Debug, Clone)]
struct IntegrationContext {
    project_context: Option<ProjectContext>,
    impact_report: Option<ImpactReport>,
    research_report: Option<ResearchReport>,
}

/// 结果整合的最终输出
#[derive(Debug, Clone)]
struct IntegrationResult {
    /// 变更的文件列表
    pub changed_files: Vec<String>,
    /// 测试结果
    pub test_results: Vec<TestReport>,
    /// 审查问题
    pub review_issues: Vec<String>,
    /// 总消耗 token
    pub total_tokens_used: usize,
    /// 总耗时（毫秒）
    pub total_duration_ms: u64,
}

impl Coordinator {
    /// 步骤 5：整合所有 Agent 的结果
    async fn integrate_results(
        &self,
        plan: &ExecutionPlan,
        results: &[AgentResult],
    ) -> IntegrationResult {
        // 中间产物收集器（Explorer/ImpactAnalyzer/Research 的输出）
        let mut integration_context = IntegrationContext {
            project_context: None,
            impact_report: None,
            research_report: None,
        };

        let mut changed_files = Vec::new();
        let mut test_results = Vec::new();
        let mut review_issues = Vec::new();

        for result in results {
            match result.agent_type {
                AgentType::Coder => {
                    if let Some(handoff) = &result.handoff {
                        changed_files.extend(handoff.changed_files.clone());
                    }
                }
                AgentType::Reviewer => {
                    if let Some(report) = &result.review_report {
                        if report.verdict != ReviewVerdict::Passed {
                            review_issues.extend(report.issues.clone());
                        }
                    }
                }
                AgentType::Tester => {
                    if let Some(report) = &result.test_report {
                        test_results.push(report.clone());
                    }
                }
                AgentType::Explorer => {
                    // 提取 ProjectContext 供后续使用
                    if let Some(ctx) = &result.project_context {
                        // 将项目上下文注入到整合结果中
                        integration_context.project_context = Some(ctx.clone());
                    }
                }
                AgentType::ImpactAnalyzer => {
                    // 提取 ImpactReport 供后续使用
                    if let Some(report) = &result.impact_report {
                        // 将影响分析报告注入到整合结果中
                        integration_context.impact_report = Some(report.clone());
                        // 汇总影响分析中发现的风险区域
                        review_issues.extend(
                            report.risk_areas.iter().filter_map(|r| {
                                if r.severity == IssueSeverity::Blocker {
                                    Some(format!("影响分析风险: {} ({})", r.description, r.location))
                                } else {
                                    None
                                }
                            })
                        );
                    }
                }
                AgentType::Research => {
                    // 提取调研结论供后续使用
                    if let Some(research) = &result.research_report {
                        // 将调研结论注入到整合结果中
                        integration_context.research_report = Some(research.clone());
                    }
                }
                _ => {}
            }
        }

        IntegrationResult {
            changed_files,
            test_results,
            review_issues,
            total_tokens_used: results.iter().map(|r| r.tokens_used).sum(),
            total_duration_ms: results.iter().map(|r| r.duration_ms).sum(),
        }
    }
}
```

#### 步骤 6：最终交付

**目标**：生成用户可读的变更摘要，展示任务执行结果。

**输出格式**：

```
═══════════════════════════════════════════════════════════
  任务完成：给所有 API 端点添加速率限制中间件
═══════════════════════════════════════════════════════════

  变更文件 (5)
  ├── 新增  src/middleware/rate_limit.rs        (+156 行)
  ├── 修改  src/middleware/mod.rs               (+3 行)
  ├── 修改  src/routes/auth.rs                  (+12 行)
  ├── 修改  src/routes/users.rs                 (+8 行)
  └── 修改  src/config/app.rs                   (+15 行)

  测试结果
  ├── 新增测试用例: 12
  ├── 通过: 12 / 12
  └── 覆盖率: 94.2% (新增代码)

  审查结果: 通过
  └── 0 个 blocker, 0 个 warning, 2 个 suggestion

  资源消耗
  ├── 总 Token: 23,450
  ├── 总耗时: 45.2s
  └── Agent 调用: 8 次

  注意事项
  └── 速率限制配置目前使用默认值 (100 req/min)，
      建议根据生产环境流量调整 src/config/app.rs 中的参数。

═══════════════════════════════════════════════════════════
```

### 2.3 新增：项目记忆集成

Coordinator 在启动时会检查 `.assistant-memory/` 目录是否存在有效的项目记忆。如果记忆有效且未过期，Coordinator 可以跳过 Explorer 阶段，直接使用缓存的项目上下文进入路由决策，大幅减少首次响应时间。

#### 2.3.1 记忆加载流程

```
Coordinator 启动
      │
      ▼
检查 .assistant-memory/ 是否存在
      │
      ├── 不存在 → 触发 Explorer 进行完整项目扫描
      │
      └── 存在 → 读取 memory-meta.json
                    │
                    ├── 记忆已过期（超过 TTL）→ 触发 Explorer 增量更新
                    │
                    └── 记忆有效 → 加载项目上下文
                                    │
                                    ▼
                              跳过 Explorer
                              直接进入路由决策
```

#### 2.3.2 记忆元数据

```rust
/// 项目记忆元数据
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MemoryMeta {
    /// 记忆创建时间
    pub created_at: DateTime<Utc>,
    /// 最后更新时间
    pub updated_at: DateTime<Utc>,
    /// 记忆版本号
    pub version: u32,
    /// 记忆有效期（秒）
    pub ttl_seconds: u64,
    /// 项目文件哈希（用于检测变化）
    pub file_hash: String,
    /// 包含的记忆文件列表
    pub files: Vec<String>,
    /// 生成此记忆的 Agent 版本
    pub agent_version: String,
}

impl MemoryMeta {
    /// 检查记忆是否有效
    pub fn is_valid(&self) -> bool {
        let elapsed = Utc::now()
            .signed_duration_since(self.updated_at)
            .num_seconds();
        elapsed < self.ttl_seconds as i64
    }

    /// 检查项目文件是否发生变化
    pub fn has_project_changed(&self, project_root: &Path) -> bool {
        let current_hash = compute_project_hash(project_root);
        current_hash != self.file_hash
    }
}
```

#### 2.3.3 记忆加载实现

```rust
impl Coordinator {
    /// 加载项目记忆，返回是否需要重新探索
    async fn load_project_memory(
        &self,
        project_root: &Path,
    ) -> Result<(Option<ProjectContext>, bool), CoordinatorError> {
        let memory_dir = project_root.join(".assistant-memory");
        let meta_path = memory_dir.join("memory-meta.json");

        // 检查记忆目录是否存在 → 正常流程：需要首次探索
        if !meta_path.exists() {
            return Ok((None, true)); // needs_exploration = true
        }

        // 读取元数据
        let meta: MemoryMeta = serde_json::from_str(
            &tokio::fs::read_to_string(&meta_path).await?
        )?;

        // 记忆已过期 → 正常流程：需要增量更新
        if !meta.is_valid() {
            tracing::info!(
                stale_seconds = meta.ttl_seconds,
                "项目记忆已过期，需要增量更新"
            );
            return Ok((None, true)); // needs_exploration = true
        }

        // 项目文件发生变化 → 正常流程：需要重新扫描
        if meta.has_project_changed(project_root) {
            tracing::info!("项目文件已变化，需要重新扫描");
            return Ok((None, true)); // needs_exploration = true
        }

        // 加载项目上下文
        let overview_path = memory_dir.join("project-overview.md");
        let tech_stack_path = memory_dir.join("tech-stack.json");
        let module_map_path = memory_dir.join("module-map.json");

        let project_context = ProjectContext {
            overview: tokio::fs::read_to_string(&overview_path).await?,
            tech_stack: serde_json::from_str(
                &tokio::fs::read_to_string(&tech_stack_path).await?
            )?,
            module_map: serde_json::from_str(
                &tokio::fs::read_to_string(&module_map_path).await?
            )?,
            // 以下字段使用默认值，后续由 Explorer 增量更新时填充：
            // - structure: ProjectStructure（目录树、文件统计等，需完整扫描）
            // - architecture: ArchitecturePattern（架构模式识别，需分析源码）
            // - dependency_graph: DependencyGraph（依赖关系图，需分析 mod.rs 和 use 语句）
            // - conventions: CodeConventions（代码风格约定，需抽样分析）
            // - risk_areas: RiskAreas（风险区域标注，需搜索 unsafe/TODO 等标记）
            // - scan_metadata: ScanMetadata（扫描元数据，本次为记忆加载而非扫描）
        };

        // 记忆有效，不需要重新探索
        Ok((Some(project_context), false)) // needs_exploration = false
    }
}
```

> **注意**：项目记忆的完整生命周期管理、增量更新机制、以及各 Agent 的记忆读写规范，详见第 18 章。
