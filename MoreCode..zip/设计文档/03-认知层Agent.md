# MoreCode — 认知层 Agent（Explorer + Impact Analyzer + Planner）

> 认知层负责项目理解、影响分析和任务规划，是编码执行的前置认知管道。

---

#### 3. Explorer Agent（项目探索者）

#### 3.1 角色定位

Explorer Agent 是系统的**项目理解专家**，负责全面扫描和分析项目结构，为后续所有 Agent 提供准确的项目上下文。它是认知层的第一环，其输出质量直接影响后续所有 Agent 的工作效果。

**核心特征**：
- **只读不写**：Explorer 只读取和分析项目文件，不修改任何文件（除 `.assistant-memory/`）
- **全面但不冗余**：扫描所有关键文件，但通过摘要机制控制输出大小
- **可递归拆分**：大型项目可以递归启动子 Explorer 并行扫描不同目录
- **增量更新**：支持基于文件哈希的增量扫描，避免重复工作

#### 3.2 触发条件

| 条件 | 说明 |
|------|------|
| 首次任务 | 项目记忆不存在时，必须先执行 Explorer |
| 记忆过期 | `.assistant-memory/` 的 TTL 超过有效期 |
| 项目变化 | Git 检测到大量文件变更（超过 20% 的文件） |
| 显式请求 | 用户明确要求"重新分析项目" |
| 路由决策 | Coordinator 判定为 复杂路由且记忆不可用 |

#### 3.3 核心职责

#### 职责 1：项目结构扫描

扫描项目的目录结构和文件组织方式，生成项目结构树。

```rust
/// 项目结构信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectStructure {
    /// 目录树（简化版，最多 3 层深度）
    pub directory_tree: String,
    /// 总文件数
    pub total_files: usize,
    /// 总代码行数（估算）
    pub total_lines: usize,
    /// 主要目录及其用途
    pub key_directories: Vec<DirectoryInfo>,
    /// 入口文件
    pub entry_points: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DirectoryInfo {
    /// 目录路径
    pub path: String,
    /// 用途描述
    pub purpose: String,
    /// 包含的文件数
    pub file_count: usize,
    /// 重要程度 (1-5)
    pub importance: u8,
}
```

#### 职责 2：技术栈识别

识别项目使用的技术栈、框架、库和工具链。

```rust
/// 技术栈信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TechStack {
    /// 编程语言及版本
    pub languages: Vec<LanguageInfo>,
    /// 框架
    pub frameworks: Vec<FrameworkInfo>,
    /// 主要依赖
    pub dependencies: Vec<DependencyInfo>,
    /// 构建工具
    pub build_tools: Vec<String>,
    /// 包管理器
    pub package_managers: Vec<String>,
    /// 代码质量工具
    pub quality_tools: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LanguageInfo {
    pub name: String,
    pub version: Option<String>,
    pub percentage: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FrameworkInfo {
    pub name: String,
    pub version: Option<String>,
    pub purpose: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyInfo {
    pub name: String,
    pub version: String,
    pub category: String, // "core" | "dev" | "optional"
}
```

#### 职责 3：架构模式识别

识别项目采用的架构模式和设计范式。

```rust
/// 架构模式信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArchitecturePattern {
    /// 主要架构模式
    pub primary_pattern: String,
    /// 分层结构
    pub layers: Vec<LayerInfo>,
    /// 关键设计模式
    pub design_patterns: Vec<String>,
    /// 数据流方向
    pub data_flow: String,
    /// 模块间通信方式
    pub communication_style: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerInfo {
    pub name: String,
    pub description: String,
    pub directories: Vec<String>,
    pub dependencies: Vec<String>,
}
```

#### 职责 4：依赖关系图

分析模块间的依赖关系，生成依赖图。

```rust
/// 依赖关系信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyGraph {
    /// 模块节点列表
    pub modules: Vec<ModuleNode>,
    /// 依赖边列表
    pub edges: Vec<DependencyEdge>,
    /// 循环依赖警告
    pub circular_dependencies: Vec<CircularDepWarning>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleNode {
    pub id: String,
    pub name: String,
    pub path: String,
    pub kind: ModuleKind,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ModuleKind {
    Library,
    Binary,
    WorkspaceMember,
    Crate,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyEdge {
    pub from: String,
    pub to: String,
    pub kind: DepKind,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DepKind {
    Compile,
    Runtime,
    Dev,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CircularDepWarning {
    pub cycle: Vec<String>,
    pub severity: String,
    pub suggestion: String,
}
```

#### 职责 5：代码风格与约定

识别项目的代码风格、命名约定和编码规范。

```rust
/// 代码风格信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeConventions {
    /// 命名约定
    pub naming: NamingConventions,
    /// 错误处理模式
    pub error_handling: String,
    /// 异步模式
    pub async_pattern: String,
    /// 测试框架
    pub test_framework: String,
    /// 文档风格
    pub doc_style: String,
    /// 代码格式化工具
    pub formatter: String,
    /// Lint 工具
    pub linter: String,
    /// 自定义约定
    pub custom_conventions: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NamingConventions {
    pub structs: String,
    pub functions: String,
    pub constants: String,
    pub modules: String,
    pub traits: String,
    pub type_aliases: String,
}
```

#### 职责 6：风险区域标注

标注项目中需要特别注意的区域，帮助后续 Agent 避免引入问题。

```rust
/// 风险区域信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskAreas {
    pub areas: Vec<RiskArea>,
}

/// 风险类别（与严重程度 RiskLevel 区分）
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RiskCategory {
    Security,
    DataModel,
    Database,
    Concurrency,
    Untested,
    Performance,
    ApiChange,
    ConfigChange,
    Other(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskArea {
    pub path: String,
    pub risk_type: RiskCategory,
    pub severity: RiskLevel,
    pub description: String,
    pub suggestion: String,
}

```

#### 3.4 输出格式

Explorer 的输出是一个完整的 `ProjectContext` 结构：

```rust
/// 项目上下文 - Explorer 的完整输出
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectContext {
    pub project_info: ProjectInfo,
    pub structure: ProjectStructure,
    pub tech_stack: TechStack,
    pub architecture: ArchitecturePattern,
    pub dependency_graph: DependencyGraph,
    pub conventions: CodeConventions,
    pub risk_areas: RiskAreas,
    pub scan_metadata: ScanMetadata,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectInfo {
    pub name: String,
    pub version: String,
    pub description: String,
    pub repository_url: Option<String>,
    pub license: Option<String>,
    pub rust_edition: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScanMetadata {
    pub scanned_at: DateTime<Utc>,
    pub scan_duration_ms: u64,
    pub files_scanned: usize,
    pub tokens_used: usize,
    pub scan_mode: ScanMode,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ScanMode {
    Full,
    Incremental { changed_files: Vec<String> },
}
```

#### 3.5 输出示例

```json
{
  "project_info": {
    "name": "ai-coding-assistant",
    "version": "0.1.0",
    "description": "A multi-agent AI coding assistant built with Rust and Ratatui",
    "repository_url": "https://github.com/example/ai-coding-assistant",
    "license": "MIT",
    "rust_edition": "2021"
  },
  "structure": {
    "directory_tree": "ai-coding-assistant/\n├── src/\n│   ├── main.rs\n│   ├── app/\n│   │   ├── mod.rs\n│   │   ├── state.rs\n│   │   └── ui.rs\n│   ├── agents/\n│   │   ├── mod.rs\n│   │   ├── coordinator.rs\n│   │   ├── explorer.rs\n│   │   ├── coder.rs\n│   │   ├── reviewer.rs\n│   │   └── tester.rs\n│   ├── tools/\n│   │   ├── mod.rs\n│   │   ├── file_io.rs\n│   │   ├── search.rs\n│   │   └── git.rs\n│   └── config/\n│       └── settings.rs\n├── tests/\n│   ├── integration/\n│   └── fixtures/\n├── Cargo.toml\n└── README.md",
    "total_files": 24,
    "total_lines": 3850,
    "key_directories": [
      { "path": "src/agents/", "purpose": "多 Agent 系统核心实现", "file_count": 7, "importance": 5 },
      { "path": "src/tools/", "purpose": "Agent 可用工具集", "file_count": 4, "importance": 4 },
      { "path": "src/app/", "purpose": "Ratatui TUI 应用层", "file_count": 3, "importance": 4 }
    ],
    "entry_points": ["src/main.rs"]
  },
  "tech_stack": {
    "languages": [
      { "name": "Rust", "version": "1.75.0", "percentage": 95.0 },
      { "name": "Shell", "version": null, "percentage": 5.0 }
    ],
    "frameworks": [
      { "name": "Ratatui", "version": "0.25.0", "purpose": "终端 UI 框架" },
      { "name": "Tokio", "version": "1.35.0", "purpose": "异步运行时" }
    ],
    "dependencies": [
      { "name": "serde", "version": "1.0.193", "category": "core" },
      { "name": "serde_json", "version": "1.0.108", "category": "core" },
      { "name": "tokio", "version": "1.35.1", "category": "core" },
      { "name": "reqwest", "version": "0.11.23", "category": "core" },
      { "name": "ratatui", "version": "0.25.0", "category": "core" }
    ],
    "build_tools": ["cargo"],
    "package_managers": ["cargo"],
    "quality_tools": ["clippy", "rustfmt"]
  },
  "architecture": {
    "primary_pattern": "Agent-based Architecture with Event-driven TUI",
    "layers": [
      { "name": "UI Layer", "description": "Ratatui 终端界面渲染", "directories": ["src/app/ui.rs"], "dependencies": ["State Layer"] },
      { "name": "Agent Layer", "description": "多 Agent 协作系统", "directories": ["src/agents/"], "dependencies": ["Tool Layer", "State Layer"] },
      { "name": "Tool Layer", "description": "文件操作、搜索、Git 等工具", "directories": ["src/tools/"], "dependencies": [] },
      { "name": "State Layer", "description": "应用状态管理", "directories": ["src/app/state.rs"], "dependencies": [] }
    ],
    "design_patterns": ["Coordinator Pattern", "Agent Pattern", "Observer Pattern", "Builder Pattern"],
    "data_flow": "User Input -> Coordinator -> Agent Pipeline -> Tool Layer -> File System",
    "communication_style": "Message passing via tokio channels"
  },
  "dependency_graph": {
    "modules": [
      { "id": "main", "name": "main", "path": "src/main.rs", "kind": "Binary" },
      { "id": "app", "name": "app", "path": "src/app/", "kind": "Library" },
      { "id": "agents", "name": "agents", "path": "src/agents/", "kind": "Library" },
      { "id": "tools", "name": "tools", "path": "src/tools/", "kind": "Library" }
    ],
    "edges": [
      { "from": "main", "to": "app", "kind": "Compile" },
      { "from": "main", "to": "agents", "kind": "Compile" },
      { "from": "agents", "to": "tools", "kind": "Compile" },
      { "from": "app", "to": "agents", "kind": "Runtime" }
    ],
    "circular_dependencies": []
  },
  "conventions": {
    "naming": {
      "structs": "PascalCase",
      "functions": "snake_case",
      "constants": "SCREAMING_SNAKE_CASE",
      "modules": "snake_case",
      "traits": "PascalCase",
      "type_aliases": "PascalCase"
    },
    "error_handling": "Library/domain errors use thiserror; application boundaries use anyhow::Result with context",
    "async_pattern": "tokio with async/await",
    "test_framework": "built-in #[test] + tokio::test for async",
    "doc_style": "/// rustdoc comments with examples",
    "formatter": "rustfmt with rustfmt.toml",
    "linter": "clippy with allowed pedantic lints",
    "custom_conventions": [
      "All public functions must have doc comments",
      "Error types use thiserror derive macro",
      "Async functions prefixed with async_ only when ambiguous",
      "Agent trait implementations in separate files"
    ]
  },
  "risk_areas": {
    "areas": [
      {
        "path": "src/agents/coordinator.rs",
        "risk_type": "Concurrency",
        "severity": "High",
        "description": "Coordinator 使用 tokio::spawn 并行启动多个 Agent，存在竞态条件风险",
        "suggestion": "确保共享状态使用 Arc<Mutex<>> 保护，Agent 间通信使用 Channel"
      },
      {
        "path": "src/tools/git.rs",
        "risk_type": "Untested",
        "severity": "Medium",
        "description": "Git 操作工具缺少单元测试",
        "suggestion": "添加使用 git init --bare 的隔离测试环境"
      }
    ]
  },
  "scan_metadata": {
    "scanned_at": "2026-04-15T10:30:00Z",
    "scan_duration_ms": 3200,
    "files_scanned": 24,
    "tokens_used": 8500,
    "scan_mode": "Full"
  }
}
```

#### 3.6 可用工具

| 工具名称 | 功能 | 用途 |
|----------|------|------|
| `list_directory` | 列出目录内容 | 扫描项目结构 |
| `read_file` | 读取文件内容 | 分析代码文件 |
| `read_file_partial` | 读取文件部分内容（指定行范围） | 大文件分段阅读 |
| `search_files` | 按模式搜索文件名 | 查找特定类型的文件 |
| `grep_content` | 按正则搜索文件内容 | 查找特定代码模式 |
| `parse_cargo_toml` | 解析 Cargo.toml | 识别依赖和项目配置 |
| `parse_lock_file` | 解析 Cargo.lock | 获取精确依赖版本 |
| `git_log` | 获取 Git 提交历史 | 了解项目演进 |
| `git_diff` | 获取文件变更差异 | 增量扫描 |
| `count_lines` | 统计代码行数 | 项目规模估算 |

#### 3.7 Token 预算

| 阶段 | 预算 (tokens) | 说明 |
|------|---------------|------|
| 项目结构扫描 | 1,000 ~ 2,000 | 目录遍历和文件列表 |
| 技术栈识别 | 500 ~ 1,000 | 解析 Cargo.toml 和配置文件 |
| 架构模式识别 | 1,500 ~ 3,000 | 阅读关键源文件 |
| 依赖关系分析 | 1,000 ~ 2,000 | 分析 mod.rs 和 use 语句 |
| 代码风格识别 | 500 ~ 1,000 | 抽样检查代码风格 |
| 风险区域标注 | 500 ~ 1,000 | 搜索 unsafe、TODO 等标记 |
| 输出生成 | 1,000 ~ 2,000 | 生成 ProjectContext JSON |
| **总计** | **6,000 ~ 12,000** | |

#### 3.8 缓存策略

Explorer 的扫描结果会被缓存到 `.assistant-memory/` 目录，避免重复扫描。

```
.assistant-memory/
├── memory-meta.json          # 记忆元数据（创建时间、TTL、版本等）
├── project-overview.md       # 项目概览（Markdown 格式，便于人类阅读）
├── tech-stack.json           # 技术栈信息
├── module-map.json           # 模块映射和依赖关系
├── conventions.md            # 代码约定
├── risk-areas.json           # 风险区域
├── file-hashes.json          # 文件哈希列表（用于增量扫描）
└── agent-notes/              # 各 Agent 的工作笔记
    ├── impact-analyzer/
    ├── planner/
    └── ...
```

**缓存失效条件**：

| 条件 | 处理方式 |
|------|----------|
| TTL 过期（默认 24 小时） | 触发增量扫描 |
| 文件哈希变化超过 20% | 触发完整扫描 |
| Cargo.toml 变更 | 重新识别技术栈 |
| 新增/删除目录 | 更新项目结构 |

#### 3.9 新增：递归代码阅读

Explorer 在面对大型项目时，可以递归拆分阅读任务，启动子 Explorer 并行扫描不同目录/模块，然后筛选聚合结果。这种机制称为**分层递归阅读**。

#### 3.9.1 分层递归阅读架构

```
Layer 1: 项目级 (Project Level)
├── 扫描根目录结构
├── 读取 Cargo.toml / package.json 等配置
├── 识别主要模块/包
│
├── Layer 2: 模块级 (Module Level) — 按需展开
│   ├── src/agents/    → Sub-Explorer-1
│   ├── src/tools/     → Sub-Explorer-2
│   ├── src/app/       → Sub-Explorer-3
│   └── tests/         → Sub-Explorer-4
│
│   ├── Layer 3: 函数级 (Function Level) — 按需展开
│   │   ├── src/agents/coordinator.rs  → Sub-Explorer-1a
│   │   ├── src/agents/coder.rs        → Sub-Explorer-1b
│   │   └── src/agents/reviewer.rs     → Sub-Explorer-1c
│   │
│   └── ... (其他模块类似)
```

#### 3.9.2 懒递归机制

递归阅读采用**懒展开（Lazy Expansion）**策略：不是一次性展开所有层级，而是根据当前任务的需要逐层展开。

```rust
/// 递归阅读配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecursiveReadConfig {
    /// 初始扫描深度
    pub initial_depth: ReadDepth,
    /// 是否启用懒递归
    pub lazy_expansion: bool,
    /// 每层最大并行子 Agent 数
    pub max_parallel_per_layer: usize,
    /// 单个文件最大阅读行数
    pub max_lines_per_file: usize,
    /// 模块重要性阈值（低于此值的模块不深入展开）
    pub importance_threshold: u8,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ReadDepth {
    /// 仅项目级（目录结构 + 配置文件）
    Project,
    /// 模块级（阅读每个模块的 mod.rs 和公开接口）
    Module,
    /// 函数级（阅读具体函数实现）
    Function,
}

impl Default for RecursiveReadConfig {
    fn default() -> Self {
        Self {
            initial_depth: ReadDepth::Module,
            lazy_expansion: true,
            max_parallel_per_layer: 4,
            max_lines_per_file: 500,
            importance_threshold: 3,
        }
    }
}
```

#### 3.9.3 递归阅读执行流程

```rust
impl Explorer {
    /// 递归阅读项目
    async fn recursive_read(
        &self,
        project_root: &Path,
        config: &RecursiveReadConfig,
        depth: usize,
    ) -> ProjectContext {
        // 深度限制检查
        if depth >= self.recursive_config.max_depth {
            return self.direct_read(project_root).await;
        }

        // Layer 1: 项目级扫描
        let project_level = self.scan_project_level(project_root).await;

        // 判断是否需要深入
        if config.initial_depth == ReadDepth::Project && !config.lazy_expansion {
            return project_level;
        }

        // Layer 2: 模块级扫描（并行）
        let modules = self.identify_modules(&project_level).await;
        let mut sub_results = Vec::new();

        let mut handles = Vec::new();
        for module in modules.iter().take(config.max_parallel_per_layer) {
            let handle = tokio::spawn({
                let module_path = project_root.join(&module.path);
                let tools = self.tools.clone();
                async move {
                    let sub_explorer = Explorer::new(tools);
                    sub_explorer.scan_module_level(&module_path).await
                }
            });
            handles.push(handle);
        }

        for handle in handles {
            if let Ok(result) = handle.await {
                sub_results.push(result);
            }
        }

        // FILTER: 筛选有效结果
        let filtered: Vec<_> = sub_results
            .into_iter()
            .filter(|r| r.importance >= config.importance_threshold)
            .collect();

        // REDUCE: 聚合结果
        self.aggregate_module_results(project_level, filtered).await
    }
}
```

> **注意**：递归编排的通用模式、错误处理和资源管理，详见第 17 章。

#### 3.10 新增：项目记忆写入

Explorer 执行完成后，会将扫描结果持久化到 `.assistant-memory/` 目录，供后续 Agent 复用。

#### 3.10.1 记忆文件结构

```
.assistant-memory/
├── memory-meta.json              # 元数据
├── project-overview.md           # 项目概览
├── tech-stack.json               # 技术栈
├── module-map.json               # 模块映射
├── conventions.md                # 代码约定
├── risk-areas.json               # 风险区域
└── file-hashes.json              # 文件哈希（增量扫描用）
```

#### 3.10.2 增量更新机制

```rust
impl Explorer {
    /// 写入项目记忆
    async fn write_memory(
        &self,
        project_root: &Path,
        context: &ProjectContext,
    ) -> Result<(), ExplorerError> {
        let memory_dir = project_root.join(".assistant-memory");
        tokio::fs::create_dir_all(&memory_dir).await?;

        // 计算文件哈希
        let file_hashes = self.compute_file_hashes(project_root).await?;

        // 检查是否需要增量更新
        let meta_path = memory_dir.join("memory-meta.json");
        let is_incremental = if meta_path.exists() {
            let old_meta: MemoryMeta = serde_json::from_str(
                &tokio::fs::read_to_string(&meta_path).await?
            )?;
            let old_hashes: HashMap<String, String> = serde_json::from_str(
                &tokio::fs::read_to_string(
                    memory_dir.join("file-hashes.json")
                ).await?
            )?;

            // 比较哈希，找出变化的文件
            let changed_files: Vec<String> = file_hashes
                .iter()
                .filter(|(path, hash)| {
                    old_hashes.get(*path).map_or(true, |old| old != *hash)
                })
                .map(|(path, _)| path.clone())
                .collect();

            let change_ratio = changed_files.len() as f32
                / file_hashes.len().max(1) as f32;

            // 变化超过 20% 则完整重新扫描
            change_ratio < 0.2
        } else {
            false
        };

        // 写入元数据
        let meta = MemoryMeta {
            created_at: if is_incremental {
                let old: MemoryMeta = serde_json::from_str(
                    &tokio::fs::read_to_string(&meta_path).await?
                )?;
                old.created_at
            } else {
                Utc::now()
            },
            updated_at: Utc::now(),
            version: 1,
            ttl_seconds: 86400,
            file_hash: self.compute_project_hash(&file_hashes),
            files: vec![
                "project-overview.md".into(),
                "tech-stack.json".into(),
                "module-map.json".into(),
                "conventions.md".into(),
                "risk-areas.json".into(),
                "file-hashes.json".into(),
            ],
            agent_version: env!("CARGO_PKG_VERSION").to_string(),
        };

        // 写入各文件
        self.write_json(&memory_dir.join("memory-meta.json"), &meta).await?;
        self.write_json(&memory_dir.join("tech-stack.json"), &context.tech_stack).await?;
        self.write_json(&memory_dir.join("module-map.json"), &context.dependency_graph).await?;
        self.write_json(&memory_dir.join("risk-areas.json"), &context.risk_areas).await?;
        self.write_json(&memory_dir.join("file-hashes.json"), &file_hashes).await?;

        // 写入 Markdown 文件
        self.write_markdown(&memory_dir.join("project-overview.md"), &context).await?;
        self.write_conventions(&memory_dir.join("conventions.md"), &context.conventions).await?;

        Ok(())
    }
}
```

> **注意**：项目记忆的完整生命周期管理、各 Agent 的读写规范、以及记忆一致性保证，详见第 18 章。
## MoreCode — Impact Analyzer

#### 4. Impact Analyzer Agent（影响分析者）

#### 4.1 角色定位

Impact Analyzer Agent 是系统的**变更影响评估专家**，负责在代码修改之前全面分析变更可能产生的影响范围。它确保每处修改都被充分评估，避免"牵一发而动全身"的意外后果。

**核心特征**：
- **前置分析**：在 Coder 执行修改之前运行，提供决策依据
- **双向追踪**：既能追踪"谁依赖了我"（上游影响），也能追踪"我依赖了谁"（下游依赖）
- **风险评估**：为每个影响点标注风险等级，帮助 Planner 优先处理高风险区域
- **可递归拆分**：可以并行追踪不同方向的影响

#### 4.2 触发条件

| 条件 | 说明 |
|------|------|
| 复杂路由 | Coordinator 判定为复杂任务时自动触发 |
| 多文件修改 | 涉及 3 个以上文件的修改 |
| 核心模块变更 | 修改被多个模块依赖的核心类型或函数 |
| 公开 API 变更 | 修改 pub 函数/结构体的签名 |
| 数据模型变更 | 修改数据库 schema 或核心数据结构 |
| 显式请求 | 用户要求"分析影响范围" |

#### 4.3 核心职责

#### 职责 1：改动点识别

精确识别需要修改的代码位置，包括直接修改点和间接影响点。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChangePoint {
    pub file_path: String,
    pub line_range: (usize, usize),
    pub change_type: ChangeType,
    pub description: String,
    pub is_direct: bool,
}

/// 权威定义：变更类型枚举（所有 Agent 共用）
/// 包含所有可能的代码变更类型
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ChangeType {
    Addition,
    Modification,
    Deletion,
    Rename { old_name: String, new_name: String },
    SignatureChange,
}
```

#### 职责 2：依赖链追踪

追踪代码变更的传播路径，包括编译时依赖和运行时依赖。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyChain {
    pub origin: ChangePoint,
    pub propagation_paths: Vec<PropagationPath>,
    pub affected_modules: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PropagationPath {
    pub nodes: Vec<ChainNode>,
    pub propagation_type: PropagationType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChainNode {
    pub file_path: String,
    pub symbol_name: String,
    pub node_type: ChainNodeType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ChainNodeType {
    FunctionCall,
    TypeReference,
    TraitImpl,
    MacroExpansion,
    ConfigReference,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PropagationType {
    CompileTime,
    Runtime,
    Test,
    Config,
}
```

#### 职责 3：风险评估

为每个影响点标注风险等级。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskAssessment {
    pub risks: Vec<Risk>,
    pub overall_risk: RiskLevel,
    pub mitigation_suggestions: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Risk {
    pub location: String,
    pub risk_type: RiskCategory,
    pub level: RiskLevel,
    pub description: String,
    pub impact_scope: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RiskLevel {
    /// 高风险
    High,
    /// 中风险
    Medium,
    /// 低风险
    Low,
}
```

#### 职责 4：不可变约束

识别变更过程中不可修改的约束条件，防止破坏性变更。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImmutableConstraints {
    pub constraints: Vec<Constraint>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Constraint {
    pub description: String,
    pub reason: String,
    pub location: String,
    pub violation_consequence: String,
}
```

#### 职责 5：执行顺序建议

基于依赖关系，建议安全的代码修改执行顺序。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionOrder {
    pub steps: Vec<ExecutionStep>,
    pub parallel_groups: Vec<Vec<usize>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionStep {
    pub step_number: usize,
    pub description: String,
    pub files: Vec<String>,
    pub depends_on: Vec<usize>,
    pub risk_level: RiskLevel,
}
```

#### 4.4 输出格式

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImpactReport {
    pub task_description: String,
    pub change_points: Vec<ChangePoint>,
    pub dependency_chains: Vec<DependencyChain>,
    pub risk_assessment: RiskAssessment,
    pub immutable_constraints: ImmutableConstraints,
    pub execution_order: ExecutionOrder,
    pub analysis_metadata: AnalysisMetadata,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisMetadata {
    pub analyzed_at: DateTime<Utc>,
    pub analysis_duration_ms: u64,
    pub files_analyzed: usize,
    pub tokens_used: usize,
}
```

#### 4.5 输出示例

以"新增用户邮箱登录"为例：

```json
{
  "task_description": "新增用户邮箱登录功能",
  "change_points": [
    {
      "file_path": "src/models/user.rs",
      "line_range": [15, 30],
      "change_type": "Modification",
      "description": "User 结构体新增 email 和 email_verified 字段",
      "is_direct": true
    },
    {
      "file_path": "src/services/auth_service.rs",
      "line_range": [1, 5],
      "change_type": "Addition",
      "description": "新增 email_login 函数",
      "is_direct": true
    },
    {
      "file_path": "src/routes/auth.rs",
      "line_range": [45, 60],
      "change_type": "Addition",
      "description": "新增 POST /auth/email-login 端点",
      "is_direct": true
    },
    {
      "file_path": "migrations/003_add_email_fields.sql",
      "line_range": [1, 20],
      "change_type": "Addition",
      "description": "新增数据库迁移文件",
      "is_direct": true
    },
    {
      "file_path": "src/services/user_service.rs",
      "line_range": [50, 65],
      "change_type": "Modification",
      "description": "create_user 和 update_user 需要处理 email 字段",
      "is_direct": false
    }
  ],
  "dependency_chains": [
    {
      "origin": {
        "file_path": "src/models/user.rs",
        "line_range": [15, 30],
        "change_type": "Modification",
        "description": "User 结构体变更",
        "is_direct": true
      },
      "propagation_paths": [
        {
          "nodes": [
            { "file_path": "src/models/user.rs", "symbol_name": "User", "node_type": "TypeReference" },
            { "file_path": "src/services/user_service.rs", "symbol_name": "create_user", "node_type": "FunctionCall" },
            { "file_path": "src/services/auth_service.rs", "symbol_name": "register", "node_type": "FunctionCall" },
            { "file_path": "src/routes/auth.rs", "symbol_name": "register_handler", "node_type": "FunctionCall" }
          ],
          "propagation_type": "CompileTime"
        }
      ],
      "affected_modules": ["src/models/", "src/services/user_service.rs", "src/services/auth_service.rs", "src/routes/auth.rs"]
    }
  ],
  "risk_assessment": {
    "risks": [
      { "location": "src/models/user.rs:15-30", "risk_type": "DataModel", "level": "High", "description": "User 结构体字段变更会影响序列化/反序列化", "impact_scope": "API 响应格式、数据库查询、缓存序列化" },
      { "location": "migrations/003_add_email_fields.sql", "risk_type": "Database", "level": "High", "description": "数据库 schema 变更需要考虑回滚策略", "impact_scope": "所有依赖 users 表的查询" },
      { "location": "src/services/auth_service.rs", "risk_type": "Security", "level": "Medium", "description": "邮箱登录需要额外的安全措施", "impact_scope": "认证流程" }
    ],
    "overall_risk": "High",
    "mitigation_suggestions": ["数据库迁移使用可逆操作", "邮箱验证使用独立的验证服务", "新增端点的速率限制与其他认证端点保持一致"]
  },
  "immutable_constraints": [
    { "description": "不能修改现有 User 结构体的字段名称", "reason": "现有 API 消费者依赖当前字段名", "location": "src/models/user.rs", "violation_consequence": "API 响应格式变更导致客户端解析失败" },
    { "description": "不能移除现有的用户名登录方式", "reason": "现有用户依赖用户名登录", "location": "src/services/auth_service.rs", "violation_consequence": "现有用户无法登录" }
  ],
  "execution_order": {
    "steps": [
      { "step_number": 1, "description": "创建数据库迁移文件", "files": ["migrations/003_add_email_fields.sql"], "depends_on": [], "risk_level": "High" },
      { "step_number": 2, "description": "修改 User 模型", "files": ["src/models/user.rs"], "depends_on": [1], "risk_level": "High" },
      { "step_number": 3, "description": "修改 user_service", "files": ["src/services/user_service.rs"], "depends_on": [2], "risk_level": "Medium" },
      { "step_number": 4, "description": "实现邮箱登录认证逻辑", "files": ["src/services/auth_service.rs"], "depends_on": [2, 3], "risk_level": "Medium" },
      { "step_number": 5, "description": "添加 API 端点", "files": ["src/routes/auth.rs"], "depends_on": [4], "risk_level": "Low" }
    ],
    "parallel_groups": [[1], [2], [3], [4], [5]]
  },
  "analysis_metadata": {
    "analyzed_at": "2026-04-15T10:35:00Z",
    "analysis_duration_ms": 2800,
    "files_analyzed": 12,
    "tokens_used": 6200
  }
}
```

#### 4.6 可用工具

| 工具名称 | 功能 | 用途 |
|------|------|------|
| `grep_content` | 正则搜索代码内容 | 查找符号引用、函数调用 |
| `read_file` | 读取文件内容 | 阅读相关代码 |
| `read_file_partial` | 读取文件部分内容 | 定向阅读关键代码段 |
| `search_files` | 按模式搜索文件名 | 查找相关文件 |
| `get_references` | 获取符号引用列表 | 追踪依赖链 |
| `get_callers` | 获取函数调用者 | 上游影响分析 |
| `get_callees` | 获取函数被调用者 | 下游依赖分析 |
| `parse_ast` | 解析代码 AST | 精确的类型和符号分析 |
| `git_log` | Git 提交历史 | 了解代码变更历史 |
| `git_blame` | Git blame | 了解代码责任归属 |

#### 4.7 Token 预算

| 阶段 | 预算 (tokens) | 说明 |
|------|---------------|------|
| 改动点识别 | 1,000 ~ 2,000 | 定位需要修改的代码 |
| 依赖链追踪 | 2,000 ~ 4,000 | 追踪影响传播路径 |
| 风险评估 | 1,000 ~ 2,000 | 评估各影响点的风险 |
| 不可变约束识别 | 500 ~ 1,000 | 识别变更限制 |
| 执行顺序建议 | 500 ~ 1,000 | 生成安全的执行顺序 |
| 输出生成 | 500 ~ 1,000 | 生成 ImpactReport JSON |
| **总计** | **5,500 ~ 11,000** | |

#### 4.8 新增：递归影响追踪

Impact Analyzer 在分析复杂变更时，可以递归拆分影响追踪方向，启动子 Agent 并行追踪不同方向的影响。

#### 4.8.1 影响追踪方向

```
                    变更点 (Change Point)
                          │
            ┌─────────────┼─────────────┐
            │             │             │
            ▼             ▼             ▼
     ┌────────────┐ ┌──────────┐ ┌──────────┐
     │ 谁调用了    │ │ 这个函数  │ │ 序列化    │
     │ 这个函数    │ │ 调用了谁  │ │ 影响      │
     │ (上游影响)  │ │ (下游依赖) │ │          │
     └──────┬─────┘ └────┬─────┘ └────┬─────┘
            │             │             │
            ▼             ▼             ▼
     ┌────────────┐ ┌──────────┐ ┌──────────┐
     │ 测试影响    │ │ 配置影响  │ │ 文档影响  │
     │ (测试覆盖)  │ │ (配置项)  │ │ (API文档) │
     └────────────┘ └──────────┘ └──────────┘
```

#### 4.8.2 递归追踪实现

```rust
impl ImpactAnalyzer {
    /// 递归追踪影响
    async fn recursive_trace(
        &self,
        change_points: &[ChangePoint],
        project_ctx: &ProjectContext,
        depth: usize,
    ) -> Vec<DependencyChain> {
        if depth >= self.recursive_config.max_depth {
            return self.direct_trace(change_points, project_ctx).await;
        }

        let directions = vec![
            TraceDirection::Callers,
            TraceDirection::Callees,
            TraceDirection::Serialization,
            TraceDirection::Tests,
        ];

        // MAP: 并行追踪不同方向
        let mut handles = Vec::new();
        for direction in directions {
            let points = change_points.to_vec();
            let ctx = project_ctx.clone();
            let tools = self.tools.clone();
            let handle = tokio::spawn(async move {
                let sub_analyzer = ImpactAnalyzer::new(tools);
                sub_analyzer.trace_direction(&points, &ctx, direction).await
            });
            handles.push(handle);
        }

        let mut all_chains = Vec::new();
        for handle in handles {
            if let Ok(chains) = handle.await {
                all_chains.extend(chains);
            }
        }

        // FILTER: 去重，只保留有传播路径的链
        let filtered: Vec<_> = all_chains
            .into_iter()
            .filter(|chain| !chain.propagation_paths.is_empty())
            .collect();

        // REDUCE: 合并重叠的链
        self.merge_overlapping_chains(filtered)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TraceDirection {
    Callers,
    Callees,
    Serialization,
    Tests,
}
```

> **注意**：递归编排的通用模式详见第 17 章。

#### 4.9 新增：项目记忆读取

Impact Analyzer 在分析之前会先读取项目记忆，避免重复分析已有的依赖关系。

```rust
impl ImpactAnalyzer {
    /// 加载已有的依赖关系图
    async fn load_dependency_graph(
        &self,
        memory_dir: &Path,
    ) -> Result<Option<DependencyGraph>, ImpactError> {
        let graph_path = memory_dir.join("module-map.json");
        if !graph_path.exists() {
            return Ok(None);
        }
        let content = tokio::fs::read_to_string(&graph_path).await?;
        let graph: DependencyGraph = serde_json::from_str(&content)?;
        Ok(Some(graph))
    }

    /// 加载已有的风险区域
    async fn load_risk_areas(
        &self,
        memory_dir: &Path,
    ) -> Result<Option<RiskAreas>, ImpactError> {
        let risk_path = memory_dir.join("risk-areas.json");
        if !risk_path.exists() {
            return Ok(None);
        }
        let content = tokio::fs::read_to_string(&risk_path).await?;
        let areas: RiskAreas = serde_json::from_str(&content)?;
        Ok(Some(areas))
    }

    /// 将分析结果写入 Agent 笔记
    async fn write_agent_notes(
        &self,
        memory_dir: &Path,
        report: &ImpactReport,
    ) -> Result<(), ImpactError> {
        let notes_dir = memory_dir.join("agent-notes/impact-analyzer");
        tokio::fs::create_dir_all(&notes_dir).await?;

        let timestamp = Utc::now().format("%Y%m%d_%H%M%S");
        let note_path = notes_dir.join(format!("impact-{}.json", timestamp));

        let content = serde_json::to_string_pretty(report)?;
        tokio::fs::write(&note_path, content).await?;

        Ok(())
    }
}
```

> **注意**：项目记忆的完整读写规范和一致性保证，详见第 18 章。
## MoreCode — Planner

#### 5. Planner Agent（任务规划者）

#### 5.1 角色定位

Planner Agent 是系统的**任务分解与调度专家**，负责将复杂的编码任务分解为可执行的子任务，确定执行顺序，分配 Agent 资源，并规划并行执行策略。它是认知层到执行层的桥梁。

**核心特征**：
- **只规划不执行**：Planner 只生成执行计划，不直接修改代码
- **DAG 调度**：使用有向无环图（DAG）建模任务依赖，最大化并行度
- **上下文分配**：为每个子任务精确分配所需的上下文，避免浪费
- **资源感知**：考虑 Token 预算和执行时间，生成最优执行计划

#### 5.2 触发条件

| 条件 | 说明 |
|------|------|
| 中等路由 | 涉及多文件修改的任务 |
| 复杂路由 | 涉及架构变更的任务 |
| Planner 显式调用 | Coordinator 判定需要规划时 |
| 用户请求 | 用户明确要求"制定计划" |

#### 5.3 核心职责

#### 职责 1：任务分解

将高层任务分解为可独立执行的原子子任务。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubTask {
    pub id: String,
    pub description: String,
    pub assigned_agent: AgentType,
    pub target_files: Vec<String>,
    pub expected_output: String,
    pub token_budget: u32,
    pub priority: u8,
    pub estimated_complexity: Complexity,
    pub acceptance_criteria: Vec<String>,
    pub completed: bool,
}
```

#### 职责 2：依赖分析

分析子任务之间的依赖关系，构建 DAG。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskDependency {
    pub from_task: String,
    pub to_task: String,
    pub dep_type: DependencyType,
    pub data_transfer: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DependencyType {
    Strict,
    Data,
    Soft,
}
```

#### 职责 3：Agent 分配

为每个子任务分配合适的 Agent 类型。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentAssignment {
    pub task_id: String,
    pub agent_type: AgentType,
    pub reasoning: String,
    pub required_tools: Vec<String>,
    pub special_instructions: Option<String>,
}
```

#### 职责 4：并行组划分

将无依赖关系的子任务划分为可并行执行的组。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParallelGroup {
    pub group_id: String,
    pub tasks: Vec<SubTask>,
    pub sequence: usize,
    pub estimated_tokens: usize,
    pub estimated_duration_ms: u64,
}
```

#### 职责 5：上下文分配

为每个子任务精确分配所需的上下文信息。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContextAllocation {
    pub task_id: String,
    pub project_context: ProjectContextFragment,
    pub code_snippets: Vec<CodeSnippet>,
    pub impact_summary: Option<String>,
    pub style_reference: Option<String>,
    pub token_budget: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectContextFragment {
    pub relevant_modules: Vec<String>,
    pub relevant_apis: Vec<String>,
    pub relevant_models: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeSnippet {
    pub file_path: String,
    pub line_range: (usize, usize),
    pub content: String,
    pub purpose: String,
}
```

#### 5.4 输出格式

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionPlan {
    pub plan_id: String,
    pub task_description: String,
    pub sub_tasks: Vec<SubTask>,
    pub dependencies: Vec<TaskDependency>,
    pub parallel_groups: Vec<ParallelGroup>,
    pub context_allocations: Vec<ContextAllocation>,
    pub total_estimated_tokens: usize,
    pub total_estimated_duration_ms: u64,
    pub plan_metadata: PlanMetadata,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlanMetadata {
    pub created_at: DateTime<Utc>,
    pub created_by: String,
    pub tokens_used: usize,
    pub planning_duration_ms: u64,
}
```

#### 5.5 输出示例

以"新增用户邮箱登录"为例：

```json
{
  "plan_id": "plan_email_login_20260415_001",
  "task_description": "新增用户邮箱登录功能",
  "sub_tasks": [
    {
      "id": "T1",
      "description": "创建数据库迁移文件，添加 email 和 email_verified 字段",
      "assigned_agent": "Coder",
      "target_files": ["migrations/003_add_email_fields.sql"],
      "required_context": ["migrations/002_add_roles.sql"],
      "estimated_complexity": "medium",
      "estimated_tokens": 2000,
      "priority": 1,
      "acceptance_criteria": ["迁移文件可以正确执行", "新字段有合理的默认值", "迁移可以安全回滚"]
    },
    {
      "id": "T2",
      "description": "修改 User 模型，添加 email 和 email_verified 字段",
      "assigned_agent": "Coder",
      "target_files": ["src/models/user.rs"],
      "required_context": ["T1"],
      "estimated_complexity": "medium",
      "estimated_tokens": 2500,
      "priority": 2,
      "acceptance_criteria": ["User 结构体包含 email: Option<String>", "User 结构体包含 email_verified: bool", "序列化/反序列化正确处理新字段"]
    },
    {
      "id": "T3",
      "description": "修改 user_service 处理 email 字段的创建和更新",
      "assigned_agent": "Coder",
      "target_files": ["src/services/user_service.rs"],
      "required_context": ["T2"],
      "estimated_complexity": "medium",
      "estimated_tokens": 3000,
      "priority": 3,
      "acceptance_criteria": ["create_user 支持可选的 email 参数", "update_user 支持更新 email", "邮箱唯一性校验"]
    },
    {
      "id": "T4",
      "description": "实现邮箱登录认证逻辑（含邮箱验证流程）",
      "assigned_agent": "Coder",
      "target_files": ["src/services/auth_service.rs"],
      "required_context": ["T2", "T3"],
      "estimated_complexity": "complex",
      "estimated_tokens": 4000,
      "priority": 4,
      "acceptance_criteria": ["email_login 函数正确验证邮箱和密码", "支持邮箱验证码发送和验证", "登录失败有明确的错误信息"]
    },
    {
      "id": "T5",
      "description": "添加邮箱登录 API 端点和路由",
      "assigned_agent": "Coder",
      "target_files": ["src/routes/auth.rs"],
      "required_context": ["T4"],
      "estimated_complexity": "medium",
      "estimated_tokens": 3000,
      "priority": 5,
      "acceptance_criteria": ["POST /auth/email-login 端点可用", "POST /auth/email-verify 端点可用", "请求/响应格式符合 API 规范"]
    }
  ],
  "dependencies": [
    { "from_task": "T1", "to_task": "T2", "dep_type": "Strict", "data_transfer": "migration_schema" },
    { "from_task": "T2", "to_task": "T3", "dep_type": "Data", "data_transfer": "User_struct" },
    { "from_task": "T2", "to_task": "T4", "dep_type": "Data", "data_transfer": "User_struct" },
    { "from_task": "T3", "to_task": "T4", "dep_type": "Data", "data_transfer": "user_service_api" },
    { "from_task": "T4", "to_task": "T5", "dep_type": "Data", "data_transfer": "auth_service_api" }
  ],
  "parallel_groups": [
    { "group_id": "G1", "tasks": ["T1"], "sequence": 1, "estimated_tokens": 2000, "estimated_duration_ms": 5000 },
    { "group_id": "G2", "tasks": ["T2"], "sequence": 2, "estimated_tokens": 2500, "estimated_duration_ms": 6000 },
    { "group_id": "G3", "tasks": ["T3"], "sequence": 3, "estimated_tokens": 3000, "estimated_duration_ms": 7000 },
    { "group_id": "G4", "tasks": ["T4"], "sequence": 4, "estimated_tokens": 4000, "estimated_duration_ms": 10000 },
    { "group_id": "G5", "tasks": ["T5"], "sequence": 5, "estimated_tokens": 3000, "estimated_duration_ms": 8000 }
  ],
  "context_allocations": [
    {
      "task_id": "T1",
      "project_context": { "relevant_modules": ["migrations/"], "relevant_apis": [], "relevant_models": ["User"] },
      "code_snippets": [{ "file_path": "migrations/002_add_roles.sql", "line_range": [1, 30], "content": "...", "purpose": "参考现有迁移文件格式" }],
      "impact_summary": "数据库 schema 变更",
      "style_reference": null,
      "token_budget": 3000
    }
  ],
  "total_estimated_tokens": 14500,
  "total_estimated_duration_ms": 36000,
  "plan_metadata": {
    "created_at": "2026-04-15T10:40:00Z",
    "created_by": "Planner",
    "tokens_used": 3500,
    "planning_duration_ms": 4500
  }
}
```

#### 5.6 DAG 可视化

```
     T1: 数据库迁移
         │
         ▼
     T2: User 模型修改
        ╱ ╲
       ╱   ╲
      ▼     ▼
   T3: user_service   T4: auth_service
      修改              实现
       ╲   ╱
        ╲ ╱
         ▼
     T5: API 端点

  执行时间线:
  ─────────────────────────────────────────
  G1: [T1 ████████]
  G2:          [T2 ██████████]
  G3:                    [T3 ████████████]
  G4:                              [T4 ██████████████████]
  G5:                                              [T5 ████████████]
  ─────────────────────────────────────────
  总耗时: ~36s (串行 ~50s, 节省 28%)
```

#### 5.7 Token 预算

| 阶段 | 预算 (tokens) | 说明 |
|------|---------------|------|
| 任务理解 | 500 ~ 1,000 | 理解用户需求和项目上下文 |
| 任务分解 | 1,000 ~ 2,000 | 生成子任务列表 |
| 依赖分析 | 500 ~ 1,000 | 构建依赖 DAG |
| Agent 分配 | 500 ~ 1,000 | 分配 Agent 和工具 |
| 并行组划分 | 500 ~ 1,000 | 优化执行顺序 |
| 上下文分配 | 500 ~ 1,000 | 为每个子任务分配上下文 |
| 输出生成 | 500 ~ 1,000 | 生成 ExecutionPlan JSON |
| **总计** | **4,000 ~ 8,000** | |

#### 5.8 新增：项目记忆读取

Planner 在规划之前会读取项目记忆中的关键信息，辅助生成更精准的执行计划。

```rust
impl Planner {
    /// 从项目记忆加载规划所需信息
    async fn load_planning_context(
        &self,
        memory_dir: &Path,
    ) -> Result<PlanningContext, PlannerError> {
        let mut ctx = PlanningContext::default();

        let overview_path = memory_dir.join("project-overview.md");
        if overview_path.exists() {
            ctx.project_overview = Some(
                tokio::fs::read_to_string(&overview_path).await?
            );
        }

        let conventions_path = memory_dir.join("conventions.md");
        if conventions_path.exists() {
            ctx.conventions = Some(
                tokio::fs::read_to_string(&conventions_path).await?
            );
        }

        let module_map_path = memory_dir.join("module-map.json");
        if module_map_path.exists() {
            let content = tokio::fs::read_to_string(&module_map_path).await?;
            ctx.module_map = Some(serde_json::from_str(&content)?);
        }

        let api_path = memory_dir.join("api-endpoints.json");
        if api_path.exists() {
            let content = tokio::fs::read_to_string(&api_path).await?;
            ctx.api_endpoints = Some(serde_json::from_str(&content)?);
        }

        Ok(ctx)
    }
}

#[derive(Debug, Clone, Default)]
pub struct PlanningContext {
    pub project_overview: Option<String>,
    pub conventions: Option<String>,
    pub module_map: Option<DependencyGraph>,
    pub api_endpoints: Option<ApiEndpoints>,
}
```

> **注意**：项目记忆的完整读写规范详见第 18 章。
