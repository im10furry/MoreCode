# MoreCode — 执行层 Agent（Coder + Reviewer + Tester）

> 执行层负责代码编写、审查和测试，形成 编码→审查→测试 的质量保障流水线。

---

#### 6. Coder Agent（编码执行者）

#### 6.1 角色定位

Coder Agent 是系统的**代码编写与修改执行者**，负责根据 Planner 分配的任务具体编写和修改代码。它是执行层的核心 Agent，所有实际的代码变更都由 Coder 完成。

**核心原则**：
- **只执行不规划**：Coder 不做任务分解和路由决策，只执行分配到的具体编码任务
- **精确修改**：只修改任务要求的代码，不做额外的"顺手"修改
- **交接清晰**：每次执行完毕后输出结构化的交接摘要，便于后续 Agent 接续工作

#### 6.2 核心职责

Coder 的工作流程分为四个步骤：

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ 1.理解任务 │───→│ 2.阅读代码 │───→│ 3.编写代码 │───→│ 4.交接摘要 │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
     │               │               │               │
  解析任务描述    阅读目标文件    执行代码修改    输出变更清单
  理解验收标准    理解现有逻辑    遵循代码风格    说明修改原因
  确认上下文     识别修改点      确保编译通过    标注需要关注
```

#### 6.2.1 预飞检查模式（Pre-flight Review）

**设计动机**：对于功能新增、架构变更等复杂任务，Coder 直接编写代码容易遗漏边界条件、
忽略已有约束、引入隐性 Bug。事后 Reviewer 发现问题再退回修改，浪费 2-3 轮往返 Token。

**核心思路**：Coder 先输出**方案**（不写代码）→ 可行性分析 Agent 审查方案 →
将注意点注入 Coder → Coder 再执行编写。

**适用条件**（满足任一即启用）：
- 任务类型为 `FeatureDevelopment`、`Refactoring`、`Configuration`
- 涉及 3+ 个文件
- 复杂度评估为 Medium 或 Complex
- 涉及数据库 schema、API 接口、认证授权等高风险变更

**预飞检查流程**：

```
┌──────────┐    ┌──────────────┐    ┌──────────────────┐    ┌──────────┐
│ 1.理解任务 │───→│ 2.阅读代码    │───→│ 3.输出方案(不写码)│───→│ 4.预飞检查 │
└──────────┘    └──────────────┘    └──────────────────┘    └──────────┘
                                                                │
                                                    ┌───────────┼───────────┐
                                                    ▼           ▼           ▼
                                              方案可行    方案需调整    方案不可行
                                                │           │           │
                                                ▼           ▼           ▼
                                         注入注意点   退回修改方案   退回Planner
                                                │           │           │
                                                ▼           │           │
                                         ┌──────────┐     │           │
                                         │5.执行编写 │◄────┘           │
                                         └──────────┘                 │
                                                │                     │
                                                ▼                     │
                                         ┌──────────┐                 │
                                         │6.交接摘要 │◄────────────────┘
                                         └──────────┘
```

**方案输出格式**（Coder 在步骤 3 输出）：

```rust
/// Coder 预飞方案（不包含实际代码，仅描述修改计划）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PreFlightPlan {
    /// 修改计划描述（自然语言）
    pub plan_description: String,
    /// 需要修改的文件列表及每个文件的修改类型
    pub file_changes: Vec<PlannedFileChange>,
    /// 预计影响的模块/功能
    pub affected_modules: Vec<String>,
    /// 识别到的潜在风险
    pub identified_risks: Vec<String>,
    /// 需要新增的依赖（如果有）
    pub new_dependencies: Vec<String>,
    /// 数据库迁移需求（如果有）
    pub database_migrations: Option<Vec<String>>,
    /// API 变更（如果有）
    pub api_changes: Option<Vec<ApiChange>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlannedFileChange {
    pub file_path: String,
    pub change_type: ChangeType, // Create | Modify | Delete | Rename
    pub description: String,
    pub estimated_lines_changed: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ChangeType {
    Create,
    Modify,
    Delete,
    Rename { from: String, to: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiChange {
    pub method: String,
    pub path: String,
    pub change_type: String, // "added" | "modified" | "removed"
    pub breaking: bool,
}
```

**可行性分析结果**（Reviewer 在步骤 4 输出）：

```rust
/// 预飞检查结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PreFlightReviewResult {
    /// 审查结论
    pub verdict: PreFlightVerdict,
    /// 方案可行性分析
    pub feasibility: FeasibilityAnalysis,
    /// 需要注入到 Coder 的注意点（Coder 执行时必须遵守）
    pub caveats: Vec<Caveat>,
    /// 建议的修改（如果方案需调整）
    pub suggested_adjustments: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PreFlightVerdict {
    /// 方案可行，可直接执行
    Approved,
    /// 方案需小幅调整后执行
    NeedsAdjustment,
    /// 方案不可行，需退回 Planner 重新规划
    Rejected { reason: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FeasibilityAnalysis {
    /// 正确性评估
    pub correctness: FeasibilityRating,
    /// 完整性评估（是否遗漏边界条件）
    pub completeness: FeasibilityRating,
    /// 兼容性评估（是否破坏现有功能）
    pub compatibility: FeasibilityRating,
    /// 安全性评估
    pub security: FeasibilityRating,
    /// 分析说明
    pub notes: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum FeasibilityRating {
    Good,
    Acceptable,
    Concerning,
    Problematic,
}

/// 注意点（注入到 Coder 的执行上下文）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Caveat {
    /// 注意点类别
    pub category: CaveatCategory,
    /// 优先级
    pub priority: IssueSeverity,
    /// 具体描述（Coder 必须遵守的约束）
    pub description: String,
    /// 相关文件（如果有）
    pub related_files: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CaveatCategory {
    /// 边界条件（如空值、零值、并发）
    EdgeCase,
    /// 向后兼容（如 API 版本、数据格式）
    BackwardCompatibility,
    /// 性能约束（如 N+1 查询、内存泄漏）
    Performance,
    /// 安全约束（如输入验证、权限检查）
    Security,
    /// 代码风格（如命名规范、错误处理模式）
    Convention,
    /// 测试要求（如需要覆盖的场景）
    Testing,
}
```

**Token 消耗对比**：

| 场景 | 无预飞检查 | 有预飞检查 | 节省 |
|------|-----------|-----------|------|
| 一次通过（简单任务） | Coder 8K + Reviewer 5K = 13K | Coder方案 3K + Review 2K + Coder执行 8K = 13K | 0%（持平） |
| 需退回 1 轮 | 13K + Coder重写 6K + Reviewer 5K = 24K | 13K（预飞已拦截问题） | **46%** |
| 需退回 2 轮 | 24K + Coder重写 6K + Reviewer 5K = 35K | 13K | **63%** |
| 引入隐性 Bug（后续修复） | 35K + 后续 Debug 20K = 55K | 13K | **76%** |

**关键收益**：
1. **提高一次完成率**：方案级别的审查比代码级别的审查更容易发现问题
2. **减少退回轮次**：注意点提前注入 Coder，避免"写完再改"的浪费
3. **降低隐性 Bug**：可行性分析覆盖边界条件、兼容性、安全性等维度
4. **长远 Token 节省**：避免后续 Debug/修复的连锁消耗

#### 6.3 输入格式

Coder 接收来自 Planner 的任务分配：

```json
{
  "task_id": "T2",
  "description": "修改 User 模型，添加 email 和 email_verified 字段",
  "assigned_agent": "Coder",
  "target_files": ["src/models/user.rs"],
  "required_context": ["T1"],
  "context": {
    "project_context": {
      "relevant_modules": ["src/models/"],
      "relevant_apis": [],
      "relevant_models": ["User"]
    },
    "code_snippets": [
      {
        "file_path": "src/models/user.rs",
        "line_range": [1, 50],
        "content": "use serde::{Deserialize, Serialize};\nuse chrono::NaiveDateTime;\n\n#[derive(Debug, Clone, Serialize, Deserialize)]\npub struct User {\n    pub id: i64,\n    pub username: String,\n    pub password_hash: String,\n    pub role: String,\n    pub created_at: NaiveDateTime,\n    pub updated_at: NaiveDateTime,\n}",
        "purpose": "当前 User 结构体定义"
      }
    ],
    "style_reference": "PascalCase for structs, snake_case for fields, /// doc comments required",
    "token_budget": 25000  // 由 TokenBudgetAllocator 动态计算
  },
  "acceptance_criteria": [
    "User 结构体包含 email: Option<String>",
    "User 结构体包含 email_verified: bool",
    "序列化/反序列化正确处理新字段"
  ],
  "special_instructions": "保持与现有字段一致的命名风格，添加 doc comments"
}
```

#### 6.4 输出格式

Coder 执行完毕后输出 `AgentExecutionReport`：

> **注意**：此结构体原名为 `AgentHandoff`，已重命名为 `AgentExecutionReport` 以避免与第 11 章的 `AgentHandoff`（交接摘要）混淆。`AgentHandoff` 专用于上级 Agent 向下级 Agent 下发任务时的上下文交接，`AgentExecutionReport` 专用于 Agent 完成任务后的执行结果报告。

```rust
/// Agent 执行报告 — 任务完成后的结果载体
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentExecutionReport {
    /// 任务 ID
    pub task_id: String,
    /// 执行 Agent 类型
    pub agent_type: AgentType,
    /// 执行状态
    pub status: ExecutionStatus,
    /// 修改的文件列表
    pub changed_files: Vec<FileChange>,
    /// 新建的文件列表
    pub new_files: Vec<String>,
    /// 删除的文件列表
    pub deleted_files: Vec<String>,
    /// 执行摘要
    pub summary: String,
    /// 给下一个 Agent 的备注
    pub notes_for_next_agent: Vec<String>,
    /// 验收检查结果
    pub acceptance_check: Vec<AcceptanceCheck>,
    /// 消耗的 Token 数
    pub tokens_used: u32,
    /// 执行耗时（毫秒）
    pub duration_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileChange {
    pub file_path: String,
    pub change_type: ChangeType,
    pub lines_added: usize,
    pub lines_removed: usize,
    pub diff_summary: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ExecutionStatus {
    Completed,
    PartialSuccess { reason: String },
    Failed { error: String },
    Cancelled,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AcceptanceCheck {
    pub criterion: String,
    pub passed: bool,
    pub evidence: String,
}
```

#### 6.5 输出示例

```json
{
  "task_id": "T2",
  "agent_type": "Coder",
  "status": "Completed",
  "changed_files": [
    {
      "file_path": "src/models/user.rs",
      "change_type": "Modification",
      "lines_added": 8,
      "lines_removed": 0,
      "diff_summary": "添加 email: Option<String> 和 email_verified: bool 字段，添加 doc comments"
    }
  ],
  "new_files": [],
  "deleted_files": [],
  "summary": "在 User 结构体中添加了 email 和 email_verified 两个字段。email 使用 Option<String> 类型以兼容现有用户数据，email_verified 默认为 false。所有字段都添加了 doc comments。",
  "notes_for_next_agent": [
    "user_service.rs 中的 create_user 函数需要更新以处理新的 email 参数",
    "auth_service.rs 中的序列化逻辑需要验证新字段的正确序列化"
  ],
  "acceptance_check": [
    { "criterion": "User 结构体包含 email: Option<String>", "passed": true, "evidence": "第 12 行: pub email: Option<String>," },
    { "criterion": "User 结构体包含 email_verified: bool", "passed": true, "evidence": "第 13 行: pub email_verified: bool," },
    { "criterion": "序列化/反序列化正确处理新字段", "passed": true, "evidence": "serde derive 宏已包含，Option<String> 自动处理 null 值" }
  ],
  "tokens_used": 3200,
  "duration_ms": 5500
}
```

#### 6.6 可用工具

| 工具名称 | 功能 | 用途 |
|------|------|------|
| `read_file` | 读取文件内容 | 阅读现有代码 |
| `read_file_partial` | 读取文件部分内容 | 定向阅读关键代码段 |
| `write_file` | 写入/创建文件 | 创建新文件 |
| `edit_file` | 编辑文件部分内容 | 精确修改代码 |
| `search_files` | 按模式搜索文件名 | 查找相关文件 |
| `grep_content` | 正则搜索文件内容 | 查找代码引用 |
| `run_command` | 执行终端命令 | 运行 cargo check、cargo fmt 等 |
| `parse_ast` | 解析代码 AST | 精确理解代码结构 |

#### 6.7 Token 预算

| 阶段 | 预算 (tokens) | 说明 |
|------|---------------|------|
| 理解任务 | 500 ~ 1,000 | 解析任务描述和上下文 |
| 阅读代码 | 1,000 ~ 3,000 | 阅读目标文件和相关文件 |
| 编写代码 | 1,000 ~ 3,000 | 生成代码修改 |
| 验证修改 | 500 ~ 1,000 | 运行 cargo check 验证 |
| 交接摘要 | 500 ~ 1,000 | 生成 AgentExecutionReport |
| **总计** | **3,500 ~ 9,000** | |

#### 6.8 新增：递归并行修改

Coder 在面对多文件修改任务时，可以递归拆分为多个子 Coder 并行修改不同文件。

#### 6.8.1 场景示例

任务："给所有 API 端点添加速率限制中间件"

```
Coder (父)
  │
  ├── MAP: 拆分为多个文件修改任务
  │     │
  │     ├── Sub-Coder-1: src/routes/auth.rs
  │     ├── Sub-Coder-2: src/routes/users.rs
  │     ├── Sub-Coder-3: src/routes/posts.rs
  │     └── Sub-Coder-4: src/routes/admin.rs
  │
  ├── FILTER: 收集所有修改结果
  │     └── 检查是否有编译错误
  │
  └── REDUCE: 一致性检查
        ├── 确保所有端点使用相同的速率限制配置
        ├── 确保错误处理方式一致
        └── 生成统一的交接摘要
```

#### 6.8.2 实现示例

```rust
impl Coder {
    /// 递归并行修改多文件
    async fn recursive_modify(
        &self,
        tasks: Vec<SubTask>,
        style_reference: &str,
        depth: usize,
    ) -> Vec<AgentExecutionReport> {
        if depth >= self.recursive_config.max_depth || tasks.len() <= 1 {
            return futures::future::join_all(
                tasks.into_iter().map(|t| self.execute_task(t))
            ).await;
        }

        // MAP: 为每个文件启动子 Coder
        let mut handles = Vec::new();
        for task in tasks {
            let style = style_reference.to_string();
            let tools = self.tools.clone();
            let handle = tokio::spawn(async move {
                let sub_coder = Coder::with_tools(tools);
                sub_coder.execute_single_task(&task, &style).await
            });
            handles.push(handle);
        }

        let mut results = Vec::new();
        for handle in handles {
            if let Ok(handoff) = handle.await {
                results.push(handoff);
            }
        }

        // FILTER: 只保留成功的结果
        let successful: Vec<_> = results
            .iter()
            .filter(|r| matches!(r.status, ExecutionStatus::Completed))
            .collect();

        // REDUCE: 一致性检查
        self.check_consistency(&successful).await;

        results
    }

    /// 一致性检查
    async fn check_consistency(&self, results: &[&AgentExecutionReport]) {
        // 检查所有修改是否使用相同的代码风格
        // 检查是否有命名冲突
        // 检查是否有遗漏的文件
    }
}
```

> **注意**：递归编排的通用模式详见第 17 章。

#### 6.9 新增：项目记忆更新

Coder 执行完毕后，会更新项目记忆中的相关文件，保持记忆的时效性。

```rust
impl Coder {
    /// 更新项目记忆
    async fn update_memory(
        &self,
        memory_dir: &Path,
        handoff: &AgentExecutionReport,
    ) -> Result<(), CoderError> {
        // 1. 更新变更历史
        self.append_change_history(memory_dir, handoff).await?;

        // 2. 更新模块映射（如果有新增/删除文件）
        if !handoff.new_files.is_empty() || !handoff.deleted_files.is_empty() {
            self.update_module_map(memory_dir, handoff).await?;
        }

        // 3. 更新 API 端点（如果有 API 变更）
        if self.has_api_changes(handoff) {
            self.update_api_endpoints(memory_dir, handoff).await?;
        }

        // 4. 更新数据模型（如果有模型变更）
        if self.has_model_changes(handoff) {
            self.update_data_models(memory_dir, handoff).await?;
        }

        Ok(())
    }

    /// 追加变更历史
    async fn append_change_history(
        &self,
        memory_dir: &Path,
        handoff: &AgentExecutionReport,
    ) -> Result<(), CoderError> {
        let history_path = memory_dir.join("change-history.jsonl");
        let entry = serde_json::to_string(&ChangeHistoryEntry {
            timestamp: Utc::now(),
            task_id: handoff.task_id.clone(),
            changed_files: handoff.changed_files.iter()
                .map(|f| f.file_path.clone())
                .collect(),
            new_files: handoff.new_files.clone(),
            deleted_files: handoff.deleted_files.clone(),
            summary: handoff.summary.clone(),
        })?;

        use tokio::io::AsyncWriteExt;
        let mut file = tokio::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&history_path)
            .await?;
        file.write_all(format!("{}\n", entry).as_bytes()).await?;

        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChangeHistoryEntry {
    pub timestamp: DateTime<Utc>,
    pub task_id: String,
    pub changed_files: Vec<String>,
    pub new_files: Vec<String>,
    pub deleted_files: Vec<String>,
    pub summary: String,
}
```

> **注意**：项目记忆的完整读写规范和一致性保证，详见第 18 章。
## MoreCode — Reviewer Agent（代码审查者）

#### 7. Reviewer Agent（代码审查者）

#### 7.1 角色定位

Reviewer Agent 是系统的**代码质量守门人**，负责审查 Coder 的输出，确保代码质量、安全性和风格一致性。它独立于 Coder 运行，提供客观的第三方审查。

**核心特征**：
- **独立审查**：Reviewer 不参与代码编写，保持审查的客观性
- **多维度审查**：覆盖安全性、正确性、性能、风格等多个维度
- **分级反馈**：使用 blocker/warning/suggestion 三级反馈，明确问题严重程度
- **可退回修改**：审查不通过时可以退回 Coder 修改，最多 3 轮

#### 7.2 核心职责

#### 职责 1：获取变更内容

获取 Coder 的所有变更，包括新增、修改和删除的文件。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReviewInput {
    pub handoff: AgentExecutionReport,
    pub diffs: Vec<FileDiff>,
    pub context: ContextAllocation,
    pub conventions: CodeConventions,
    pub risk_areas: RiskAreas,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileDiff {
    pub file_path: String,
    pub unified_diff: String,
    pub old_content: Option<String>,
    pub new_content: Option<String>,
}
```

#### 职责 2：安全审查

检查代码中的安全漏洞和风险。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityReview {
    pub issues: Vec<SecurityIssue>,
    pub rating: SecurityRating,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityIssue {
    pub severity: IssueSeverity,
    pub description: String,
    pub location: String,
    pub suggestion: String,
    pub cwe_id: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum IssueSeverity {
    Blocker,
    Warning,
    Suggestion,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SecurityRating {
    Safe,
    LowRisk,
    MediumRisk,
    HighRisk,
}
```

#### 职责 3：正确性审查

检查代码逻辑是否正确，是否满足验收标准。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CorrectnessReview {
    pub issues: Vec<CorrectnessIssue>,
    pub acceptance_checks: Vec<AcceptanceCheck>,
    pub compilation_check: CompilationCheck,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CorrectnessIssue {
    pub severity: IssueSeverity,
    pub description: String,
    pub location: String,
    pub suggestion: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompilationCheck {
    pub passed: bool,
    pub errors: Vec<String>,
    pub warnings: Vec<String>,
}
```

#### 职责 4：风格一致性

检查代码是否符合项目的编码规范。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StyleReview {
    pub issues: Vec<StyleIssue>,
    pub consistency_score: u8,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StyleIssue {
    pub severity: IssueSeverity,
    pub rule: String,
    pub description: String,
    pub location: String,
    pub suggestion: String,
}
```

#### 职责 5：输出审查报告

汇总所有审查结果，生成最终报告。

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReviewReport {
    pub report_id: String,
    pub task_id: String,
    pub verdict: ReviewVerdict,
    pub issues: Vec<ReviewIssue>,
    pub security_review: SecurityReview,
    pub correctness_review: CorrectnessReview,
    pub style_review: StyleReview,
    pub summary: String,
    pub review_metadata: ReviewMetadata,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ReviewVerdict {
    Passed,
    NeedsChanges,
    Rejected,
    NeedsEscalation,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReviewIssue {
    pub severity: IssueSeverity,
    pub category: String,
    pub description: String,
    pub location: String,
    pub suggestion: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReviewMetadata {
    pub reviewed_at: DateTime<Utc>,
    pub review_duration_ms: u64,
    pub files_reviewed: usize,
    pub tokens_used: usize,
    pub review_round: u8,
}
```

#### 7.3 审查结果处理流程

```
                    Reviewer 输出审查报告
                          │
              ┌───────────┼───────────┐
              │           │           │
              ▼           ▼           ▼
         ┌────────┐  ┌─────────┐  ┌────────┐
         │ Passed │  │ Needs   │  │Rejected│
         │        │  │ Changes │  │        │
         └───┬────┘  └────┬────┘  └───┬────┘
             │            │            │
             ▼            ▼            ▼
        继续执行      退回 Coder    Coordinator
        → Tester     (最多 3 次)    重新评估
             │            │
             │     ┌──────┘
             │     ▼
             │  Coder 修改
             │     │
             │     ▼
             │  Reviewer 重新审查
             │     │
             │  ┌──┴──┐
             │  │     │
             │  ▼     ▼ (超过 3 次)
             │ 通过  Coordinator 介入
             │  │
             └──┘
```

**审查轮次控制**：

```rust
pub struct ReviewCycle {
    pub max_rounds: u8,
    pub current_round: u8,
    pub issue_history: Vec<u8>,
}

impl ReviewCycle {
    pub fn new() -> Self {
        Self {
            max_rounds: 3,
            current_round: 0,
            issue_history: Vec::new(),
        }
    }

    pub fn should_continue(&self, report: &ReviewReport) -> bool {
        match report.verdict {
            ReviewVerdict::Passed => false,
            ReviewVerdict::Rejected => false,
            ReviewVerdict::NeedsChanges => {
                self.current_round < self.max_rounds
            }
        }
    }

    pub fn should_escalate(&self) -> bool {
        self.current_round >= self.max_rounds
    }

    /// 推进到下一轮审查
    pub fn advance(&mut self) {
        self.current_round += 1;
    }
}
```

#### 7.4 输出示例

```json
{
  "report_id": "review_T2_20260415_001",
  "task_id": "T2",
  "verdict": "Passed",
  "issues": [
    {
      "severity": "Suggestion",
      "category": "Style",
      "description": "建议为 email 字段添加邮箱格式验证的 doc comment",
      "location": "src/models/user.rs:12",
      "suggestion": "/// User's email address. Validated by validator crate."
    }
  ],
  "security_review": {
    "issues": [],
    "rating": "Safe"
  },
  "correctness_review": {
    "issues": [],
    "acceptance_checks": [
      { "criterion": "User 结构体包含 email: Option<String>", "passed": true, "evidence": "Line 12" },
      { "criterion": "User 结构体包含 email_verified: bool", "passed": true, "evidence": "Line 13" },
      { "criterion": "序列化/反序列化正确处理新字段", "passed": true, "evidence": "serde derive + Option type" }
    ],
    "compilation_check": { "passed": true, "errors": [], "warnings": [] }
  },
  "style_review": {
    "issues": [
      {
        "severity": "Suggestion",
        "rule": "doc_comments",
        "description": "email 字段缺少详细的 doc comment",
        "location": "src/models/user.rs:12",
        "suggestion": "添加描述邮箱用途和验证规则的注释"
      }
    ],
    "consistency_score": 92
  },
  "summary": "代码变更质量良好，字段定义正确，序列化处理得当。仅有 1 个风格建议，不阻塞继续执行。",
  "review_metadata": {
    "reviewed_at": "2026-04-15T10:45:00Z",
    "review_duration_ms": 3200,
    "files_reviewed": 1,
    "tokens_used": 2800,
    "review_round": 1
  }
}
```

#### 7.5 Token 预算

| 阶段 | 预算 (tokens) | 说明 |
|------|---------------|------|
| 获取变更内容 | 500 ~ 1,500 | 读取 diff 和上下文 |
| 安全审查 | 1,000 ~ 2,000 | 检查安全漏洞 |
| 正确性审查 | 1,000 ~ 2,000 | 检查逻辑正确性 |
| 风格一致性 | 500 ~ 1,000 | 检查代码风格 |
| 生成报告 | 500 ~ 1,000 | 生成 ReviewReport |
| **总计** | **3,500 ~ 7,500** | |

#### 7.6 🆕 新增：递归并行审查

Reviewer 在面对多文件变更时，可以递归拆分为多个子 Reviewer 并行审查不同文件。

```rust
impl Reviewer {
    /// 递归并行审查
    async fn recursive_review(
        &self,
        diffs: Vec<FileDiff>,
        conventions: &CodeConventions,
        depth: usize,
    ) -> ReviewReport {
        if depth >= self.recursive_config.max_depth || diffs.len() <= 2 {
            return self.direct_review(diffs, conventions).await;
        }

        // MAP: 为每个文件（或文件组）启动子 Reviewer
        let chunks = self.chunk_diffs(diffs, self.recursive_config.max_parallel);
        let mut handles = Vec::new();

        for chunk in chunks {
            let conv = conventions.clone();
            let tools = self.tools.clone();
            let handle = tokio::spawn(async move {
                let sub_reviewer = Reviewer::with_tools(tools);
                sub_reviewer.review_chunk(chunk, &conv).await
            });
            handles.push(handle);
        }

        let mut sub_reports = Vec::new();
        for handle in handles {
            if let Ok(report) = handle.await {
                sub_reports.push(report);
            }
        }

        // FILTER: 保留所有级别的问题（Blocker、Warning、Suggestion）
        let all_issues: Vec<ReviewIssue> = sub_reports
            .iter()
            .flat_map(|r| r.issues.clone())
            .collect();

        // REDUCE: 聚合为最终报告
        self.aggregate_reviews(sub_reports, all_issues)
    }

    fn chunk_diffs(&self, diffs: Vec<FileDiff>, max_chunks: usize) -> Vec<Vec<FileDiff>> {
        let chunk_size = (diffs.len() + max_chunks - 1) / max_chunks;
        diffs.chunks(chunk_size).map(|c| c.to_vec()).collect()
    }
}
```

> **注意**：递归编排的通用模式详见第 17 章。

#### 7.7 🆕 新增：`/deepreview` 深度审查模式

用户可以通过 `/deepreview` 命令开启深度审查模式，AI 自动进行多轮审查直到代码质量达标。默认 7×24 小时开启。

**命令格式**：

| 命令 | 说明 |
|------|------|
| `/deepreview on` | 开启深度审查（默认状态） |
| `/deepreview off` | 关闭深度审查，退回单轮审查 |
| `/deepreview status` | 查看当前深度审查状态和配置 |
| `/deepreview config` | 自定义深度审查参数 |

**开启时提示**：

```
⚠️ 深度审查已开启。AI 将自动进行多轮审查直到代码质量达标。
这可能造成大量 Token 消耗（预计增加 2-5 倍审查成本）。
使用 /deepreview off 可随时关闭。
```

**核心设计**：

```rust
/// 深度审查配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeepReviewConfig {
    /// 是否启用
    pub enabled: bool,
    /// 最大审查轮次（默认 5）
    pub max_rounds: u8,
    /// 通过标准：Blocker=0 且 Warning ≤ 阈值（默认 2）
    pub pass_criteria: PassCriteria,
    /// 每轮审查后是否自动修复（默认 true）
    pub auto_fix: bool,
    /// 单次深度审查 Token 预算上限（默认 50,000）
    /// 注意：此为单个 Agent 的 Token 上限，与全局 max_token_budget（200,000）不同
    pub max_tokens_per_review: u32,
    /// 审查维度配置
    pub dimensions: Vec<ReviewDimensionConfig>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PassCriteria {
    /// Blocker 数量必须为 0
    pub max_blockers: u8,         // 默认 0
    /// Warning 数量上限
    pub max_warnings: u8,         // 默认 2
    /// 最低一致性评分（0-100）
    pub min_consistency_score: u8, // 默认 85
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReviewDimensionConfig {
    /// 审查维度名称
    pub name: String,
    /// 是否启用
    pub enabled: bool,
    /// 权重（用于一致性评分计算）
    pub weight: f32,
}

impl Default for DeepReviewConfig {
    fn default() -> Self {
        Self {
            enabled: true,  // 默认 7×24 开启
            max_rounds: 5,
            pass_criteria: PassCriteria {
                max_blockers: 0,
                max_warnings: 2,
                min_consistency_score: 85,
            },
            auto_fix: true,
            max_tokens_per_review: 50_000,
            dimensions: vec![
                ReviewDimensionConfig { name: "security".into(), enabled: true, weight: 0.30 },
                ReviewDimensionConfig { name: "correctness".into(), enabled: true, weight: 0.30 },
                ReviewDimensionConfig { name: "style".into(), enabled: true, weight: 0.15 },
                ReviewDimensionConfig { name: "consistency".into(), enabled: true, weight: 0.15 },
                ReviewDimensionConfig { name: "performance".into(), enabled: true, weight: 0.10 },
            ],
        }
    }
}
```

**深度审查流程**：

```
用户提交代码变更
       │
       ▼
  ┌─────────────────────────────────────────┐
  │         第 1 轮：标准审查                  │
  │  安全 + 正确性 + 风格 + 一致性 + 性能      │
  └─────────────┬───────────────────────────┘
                │
                ▼
        ┌──────────────┐
        │  是否通过？   │ ← Blocker=0 && Warning≤2 && 一致性≥85
        └──┬───────┬───┘
           │       │
        通过│       │未通过
           │       │
           ▼       ▼
        返回     ┌─────────────────────────┐
        通过    │  第 2 轮：针对性审查        │
                │  只审查上轮发现问题的维度    │
                │  + 自动修复建议             │
                └────────┬────────────────┘
                         │
                         ▼
                  ┌──────────────┐
                  │  是否通过？   │
                  └──┬───────┬───┘
                     │       │
                  通过│       │未通过
                     │       │
                     ▼       ▼
                  返回   ┌──────────────┐
                  通过   │ 第 3-5 轮...  │ ← 递归直到通过或达到上限
                         └──────┬───────┘
                                │
                                ▼
                         ┌──────────────┐
                         │ 达到上限？    │
                         └──┬───────┬───┘
                            │       │
                         是 │       │ 否
                            ▼       ▼
                     生成升级报告  继续审查
                     (标记风险点)
```

**实现代码**：

```rust
impl Reviewer {
    /// 深度审查入口
    pub async fn deep_review(
        &self,
        diffs: Vec<FileDiff>,
        conventions: &CodeConventions,
        config: &DeepReviewConfig,
    ) -> DeepReviewResult {
        if !config.enabled {
            // 未开启深度审查，执行单轮标准审查
            let report = self.direct_review(diffs, conventions).await;
            return DeepReviewResult {
                passed: self.check_pass_criteria(&report, &config.pass_criteria),
                final_report: report,
                rounds: 1,
                total_tokens_used: report.review_metadata.tokens_used,
                fix_history: vec![],
            };
        }

        let mut round = 0;
        let mut total_tokens: u32 = 0;
        let mut fix_history: Vec<FixRecord> = vec![];
        let mut current_diffs = diffs.clone();
        let mut last_report = None;

        loop {
            round += 1;
            if round > config.max_rounds {
                break;
            }

            // 检查 Token 预算
            if total_tokens >= config.max_tokens_per_review {
                tracing::warn!(
                    round, total_tokens,
                    "深度审查达到 Token 预算上限，终止审查"
                );
                break;
            }

            // 执行审查（第 1 轮全维度，后续轮只审查有问题维度）
            let report = if round == 1 {
                self.direct_review(current_diffs.clone(), conventions).await
            } else {
                self.focused_review(
                    current_diffs.clone(),
                    conventions,
                    &self.get_failing_dimensions(&last_report.as_ref().unwrap()),
                ).await
            };

            total_tokens += report.review_metadata.tokens_used;

            // 检查是否通过
            if self.check_pass_criteria(&report, &config.pass_criteria) {
                return DeepReviewResult {
                    passed: true,
                    final_report: report,
                    rounds: round,
                    total_tokens_used: total_tokens,
                    fix_history: fix_history,
                };
            }

            // 自动修复（如果启用）
            if config.auto_fix {
                let fixes = self.generate_auto_fixes(&report).await;
                if !fixes.is_empty() {
                    let applied = self.apply_fixes(fixes.clone()).await;
                    fix_history.push(FixRecord {
                        round,
                        fixes_applied: applied.len(),
                        fixes_total: fixes.len(),
                    });
                    // 更新 diffs 为修复后的版本
                    current_diffs = self.get_updated_diffs().await;
                }
            }

            last_report = Some(report);
        }

        // 达到上限仍未通过，生成升级报告
        let mut final_report = last_report.unwrap();
        final_report.verdict = ReviewVerdict::NeedsEscalation;
        final_report.summary = format!(
            "深度审查 {} 轮后仍未通过。剩余问题：{} Blocker, {} Warning。建议人工审查。",
            round,
            final_report.issues.iter().filter(|i| i.severity == IssueSeverity::Blocker).count(),
            final_report.issues.iter().filter(|i| i.severity == IssueSeverity::Warning).count(),
        );

        DeepReviewResult {
            passed: false,
            final_report,
            rounds: round,
            total_tokens_used: total_tokens,
            fix_history,
        }
    }

    /// 检查是否通过标准
    fn check_pass_criteria(&self, report: &ReviewReport, criteria: &PassCriteria) -> bool {
        let blockers = report.issues.iter()
            .filter(|i| i.severity == IssueSeverity::Blocker)
            .count() as u8;
        let warnings = report.issues.iter()
            .filter(|i| i.severity == IssueSeverity::Warning)
            .count() as u8;

        blockers <= criteria.max_blockers
            && warnings <= criteria.max_warnings
            && report.style_review.consistency_score >= criteria.min_consistency_score as u32
    }

    /// 获取未通过的审查维度（用于后续轮的针对性审查）
    fn get_failing_dimensions(&self, report: &ReviewReport) -> Vec<String> {
        let mut failing = Vec::new();

        if !report.security_review.issues.is_empty() {
            failing.push("security".into());
        }
        if !report.correctness_review.issues.is_empty() {
            failing.push("correctness".into());
        }
        if report.style_review.consistency_score < 85 {
            failing.push("style".into());
        }

        failing
    }
}

/// 深度审查结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeepReviewResult {
    /// 是否通过审查
    pub passed: bool,
    /// 最终审查报告
    pub final_report: ReviewReport,
    /// 审查轮次
    pub rounds: u8,
    /// 总 Token 消耗
    pub total_tokens_used: u32,
    /// 修复历史
    pub fix_history: Vec<FixRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FixRecord {
    pub round: u8,
    pub fixes_applied: usize,
    pub fixes_total: usize,
}
```

**与 Coordinator 的集成**：

```rust
// Coordinator 在 Reviewer 返回后检查深度审查结果
match review_result {
    DeepReviewResult { passed: true, .. } => {
        // 审查通过，继续执行流程
        self.proceed_to_next_step(task).await;
    }
    DeepReviewResult { passed: false, rounds, total_tokens_used, .. } => {
        // 深度审查未通过
        tracing::warn!(
            rounds, total_tokens_used,
            "深度审查未通过，升级为人工审查"
        );
        self.request_human_review(task, review_result.final_report).await;
    }
}
```

**Token 消耗预估**：

| 场景 | 单轮审查 | 深度审查（3轮） | 深度审查（5轮） |
|------|---------|----------------|----------------|
| 小变更（1-2 文件） | 3.5K-7.5K | 8K-18K | 12K-28K |
| 中变更（3-8 文件） | 7K-15K | 18K-40K | 28K-65K |
| 大变更（8+ 文件） | 15K-30K | 40K-85K | 65K-140K |

> **成本提示**：深度审查模式默认开启，预计增加 2-5 倍审查 Token 消耗。对于预算敏感的场景，建议使用 `/deepreview off` 关闭，或通过 `/deepreview config` 调整 `max_rounds` 和 `max_tokens_per_review`。

#### 7.8 🆕 新增：项目记忆读取

Reviewer 在审查之前会读取项目记忆中的代码约定和风险区域，使审查更精准。

```rust
impl Reviewer {
    async fn load_review_context(
        &self,
        memory_dir: &Path,
    ) -> Result<ReviewContext, ReviewerError> {
        let mut ctx = ReviewContext::default();

        let conventions_path = memory_dir.join("conventions.md");
        if conventions_path.exists() {
            ctx.conventions = Some(
                tokio::fs::read_to_string(&conventions_path).await?
            );
        }

        let risk_path = memory_dir.join("risk-areas.json");
        if risk_path.exists() {
            let content = tokio::fs::read_to_string(&risk_path).await?;
            ctx.risk_areas = Some(serde_json::from_str(&content)?);
        }

        Ok(ctx)
    }
}

#[derive(Debug, Clone, Default)]
pub struct ReviewContext {
    pub conventions: Option<String>,
    pub risk_areas: Option<RiskAreas>,
}
```

> **注意**：项目记忆的完整读写规范详见第 18 章。

---
## MoreCode — Tester Agent（测试生成者）

#### 8. Tester Agent（测试生成者）

#### 8.1 角色定位

Tester Agent 是系统的**质量保障专家**，负责为 Coder 的代码变更生成和执行测试用例，确保代码的正确性和稳定性。它在 Reviewer 通过后运行，是交付前的最后一道质量关卡。

**核心特征**：
- **变更驱动**：只针对本次变更生成测试，不生成全量测试
- **多层测试**：覆盖单元测试、集成测试和回归测试
- **自动执行**：生成测试后自动运行，并报告结果
- **可递归拆分**：可以并行测试不同模块

#### 8.2 核心职责

Tester 的工作流程分为五个步骤：

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ 1.理解变更 │───→│ 2.生成用例 │───→│ 3.编写测试 │───→│ 4.运行测试 │───→│ 5.测试报告 │
└──────────┘    └──────────┘    └──────────┘    └──────────┘    └──────────┘
     │               │               │               │               │
  分析变更内容    识别测试场景    编写测试代码    执行并收集结果    汇总测试数据
  确定测试范围    设计边界条件    遵循测试约定    处理测试失败    标注回归风险
```

#### 步骤 1：理解变更

分析 Coder 的变更内容，确定需要测试的范围。

#### 步骤 2：生成测试用例

识别测试场景，包括正常路径、边界条件和异常情况。

#### 步骤 3：编写测试代码

根据测试用例编写实际的测试代码。

#### 步骤 4：运行测试

执行测试并收集结果。

#### 步骤 5：输出测试报告

汇总测试结果，生成结构化报告。

#### 8.3 输出格式

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestReport {
    pub report_id: String,
    pub task_id: String,
    pub statistics: TestStatistics,
    pub test_cases: Vec<TestCaseResult>,
    pub coverage: TestCoverage,
    pub regression: RegressionReport,
    pub failure_details: Vec<FailureDetail>,
    pub summary: String,
    pub test_metadata: TestMetadata,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestStatistics {
    pub tests_written: usize,
    pub passed: usize,
    pub failed: usize,
    pub skipped: usize,
    pub pass_rate: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestCaseResult {
    pub name: String,
    pub file_path: String,
    pub test_type: TestType,
    pub result: TestResult,
    pub duration_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TestType {
    Unit,
    Integration,
    Regression,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TestResult {
    Passed,
    Failed { reason: String },
    Skipped { reason: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestCoverage {
    pub new_code_line_coverage: f32,
    pub new_code_branch_coverage: f32,
    pub overall_line_coverage: f32,
    pub uncovered_paths: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RegressionReport {
    pub ran: bool,
    pub total_tests: usize,
    pub passed: usize,
    pub failed: usize,
    pub new_failures: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FailureDetail {
    pub test_name: String,
    pub reason: String,
    pub expected: Option<String>,
    pub actual: Option<String>,
    pub stack_trace: Option<String>,
    pub suggestion: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestMetadata {
    pub tested_at: DateTime<Utc>,
    pub test_duration_ms: u64,
    pub test_files_created: Vec<String>,
    pub tokens_used: usize,
}
```

#### 8.4 输出示例

```json
{
  "report_id": "test_T2_20260415_001",
  "task_id": "T2",
  "statistics": {
    "tests_written": 8,
    "passed": 8,
    "failed": 0,
    "skipped": 0,
    "pass_rate": 1.0
  },
  "test_cases": [
    { "name": "test_user_email_field_exists", "file_path": "tests/unit/models/user_test.rs", "test_type": "Unit", "result": "Passed", "duration_ms": 12 },
    { "name": "test_user_email_verified_default_false", "file_path": "tests/unit/models/user_test.rs", "test_type": "Unit", "result": "Passed", "duration_ms": 8 },
    { "name": "test_user_email_optional_serialization", "file_path": "tests/unit/models/user_test.rs", "test_type": "Unit", "result": "Passed", "duration_ms": 15 },
    { "name": "test_user_deserialization_with_email", "file_path": "tests/unit/models/user_test.rs", "test_type": "Unit", "result": "Passed", "duration_ms": 10 },
    { "name": "test_user_deserialization_without_email", "file_path": "tests/unit/models/user_test.rs", "test_type": "Unit", "result": "Passed", "duration_ms": 9 },
    { "name": "test_user_email_none_serializes_to_null", "file_path": "tests/unit/models/user_test.rs", "test_type": "Unit", "result": "Passed", "duration_ms": 11 },
    { "name": "test_user_email_some_serializes_correctly", "file_path": "tests/unit/models/user_test.rs", "test_type": "Unit", "result": "Passed", "duration_ms": 10 },
    { "name": "test_user_model_backward_compatibility", "file_path": "tests/unit/models/user_test.rs", "test_type": "Regression", "result": "Passed", "duration_ms": 14 }
  ],
  "coverage": {
    "new_code_line_coverage": 95.0,
    "new_code_branch_coverage": 87.5,
    "overall_line_coverage": 78.5,
    "uncovered_paths": ["User::email 验证逻辑（尚未实现）"]
  },
  "regression": {
    "ran": true,
    "total_tests": 45,
    "passed": 45,
    "failed": 0,
    "new_failures": []
  },
  "failure_details": [],
  "summary": "所有 8 个测试用例通过，新增代码行覆盖率 95%。回归测试全部通过，未引入新的失败。建议后续为 email 字段添加格式验证测试。",
  "test_metadata": {
    "tested_at": "2026-04-15T10:50:00Z",
    "test_duration_ms": 4200,
    "test_files_created": ["tests/unit/models/user_test.rs"],
    "tokens_used": 5500
  }
}
```

#### 8.5 Token 预算

| 阶段 | 预算 (tokens) | 说明 |
|------|---------------|------|
| 理解变更 | 500 ~ 1,000 | 分析变更内容 |
| 生成测试用例 | 1,000 ~ 2,000 | 设计测试场景 |
| 编写测试代码 | 1,500 ~ 3,000 | 生成测试代码 |
| 运行测试 | 0 ~ 500 | 执行测试（主要是工具调用） |
| 生成报告 | 500 ~ 1,000 | 生成 TestReport |
| **总计** | **3,500 ~ 7,500** | |

#### 8.6 🆕 新增：递归并行测试

Tester 在面对多模块变更时，可以递归拆分为多个子 Tester 并行测试不同模块。

```rust
impl Tester {
    /// 递归并行测试
    async fn recursive_test(
        &self,
        modules: Vec<TestModule>,
        depth: usize,
    ) -> TestReport {
        if depth >= self.recursive_config.max_depth || modules.len() <= 1 {
            return self.direct_test(modules).await;
        }

        // MAP: 为每个模块启动子 Tester
        let mut handles = Vec::new();
        for module in modules {
            let tools = self.tools.clone();
            let handle = tokio::spawn(async move {
                let sub_tester = Tester::with_tools(tools);
                sub_tester.test_module(&module).await
            });
            handles.push(handle);
        }

        let mut sub_reports = Vec::new();
        for handle in handles {
            if let Ok(report) = handle.await {
                sub_reports.push(report);
            }
        }

        // FILTER: 只保留失败用例和覆盖率数据
        let failures: Vec<FailureDetail> = sub_reports
            .iter()
            .flat_map(|r| r.failure_details.clone())
            .collect();

        let coverage = TestCoverage {
            // 按测试用例数加权平均：测试用例越多的模块对整体覆盖率影响越大
            new_code_line_coverage: {
                let total_lines: usize = sub_reports.iter().map(|r| r.coverage.new_code_line_coverage as usize).sum();
                let weighted_sum: f32 = sub_reports.iter()
                    .map(|r| r.coverage.new_code_line_coverage * r.statistics.tests_written as f32)
                    .sum();
                if sub_reports.iter().map(|r| r.statistics.tests_written).sum::<usize>() > 0 {
                    weighted_sum / sub_reports.iter().map(|r| r.statistics.tests_written as f32).sum::<f32>()
                } else {
                    0.0
                }
            },
            new_code_branch_coverage: {
                let weighted_sum: f32 = sub_reports.iter()
                    .map(|r| r.coverage.new_code_branch_coverage * r.statistics.tests_written as f32)
                    .sum();
                if sub_reports.iter().map(|r| r.statistics.tests_written).sum::<usize>() > 0 {
                    weighted_sum / sub_reports.iter().map(|r| r.statistics.tests_written as f32).sum::<f32>()
                } else {
                    0.0
                }
            },
            overall_line_coverage: {
                let weighted_sum: f32 = sub_reports.iter()
                    .map(|r| r.coverage.overall_line_coverage * r.statistics.tests_written as f32)
                    .sum();
                if sub_reports.iter().map(|r| r.statistics.tests_written).sum::<usize>() > 0 {
                    weighted_sum / sub_reports.iter().map(|r| r.statistics.tests_written as f32).sum::<f32>()
                } else {
                    0.0
                }
            },
            uncovered_paths: sub_reports
                .iter()
                .flat_map(|r| r.coverage.uncovered_paths.clone())
                .collect(),
        };

        // REDUCE: 聚合为最终报告
        TestReport {
            report_id: format!("test_aggregated_{}", Utc::now().format("%Y%m%d_%H%M%S")),
            task_id: sub_reports.first()
                .map(|r| r.task_id.clone())
                .unwrap_or_default(),
            statistics: TestStatistics {
                tests_written: sub_reports.iter().map(|r| r.statistics.tests_written).sum(),
                passed: sub_reports.iter().map(|r| r.statistics.passed).sum(),
                failed: sub_reports.iter().map(|r| r.statistics.failed).sum(),
                skipped: sub_reports.iter().map(|r| r.statistics.skipped).sum(),
                pass_rate: {
                    let total_passed = sub_reports.iter().map(|r| r.statistics.passed).sum::<usize>();
                    let total_written = sub_reports.iter().map(|r| r.statistics.tests_written).sum::<usize>();
                    if total_written > 0 {
                        total_passed as f32 / total_written as f32
                    } else {
                        0.0
                    }
                },
            },
            test_cases: sub_reports
                .iter()
                .flat_map(|r| r.test_cases.clone())
                .collect(),
            coverage,
            regression: RegressionReport {
                ran: sub_reports.iter().any(|r| r.regression.ran),
                total_tests: sub_reports.iter().map(|r| r.regression.total_tests).sum(),
                passed: sub_reports.iter().map(|r| r.regression.passed).sum(),
                failed: sub_reports.iter().map(|r| r.regression.failed).sum(),
                new_failures: sub_reports
                    .iter()
                    .flat_map(|r| r.regression.new_failures.clone())
                    .collect(),
            },
            failure_details: failures,
            summary: format!(
                "聚合测试 {} 个模块，共 {} 个用例，通过率 {:.1}%",
                sub_reports.len(),
                sub_reports.iter().map(|r| r.statistics.tests_written).sum::<usize>(),
                {
                    let total_passed = sub_reports.iter().map(|r| r.statistics.passed).sum::<usize>();
                    let total_written = sub_reports.iter().map(|r| r.statistics.tests_written).sum::<usize>();
                    if total_written > 0 {
                        total_passed as f32 / total_written as f32 * 100.0
                    } else {
                        0.0
                    }
                }
            ),
            test_metadata: TestMetadata {
                tested_at: Utc::now(),
                test_duration_ms: sub_reports.iter().map(|r| r.test_metadata.test_duration_ms).max().unwrap_or(0),
                test_files_created: sub_reports
                    .iter()
                    .flat_map(|r| r.test_metadata.test_files_created.clone())
                    .collect(),
                tokens_used: sub_reports.iter().map(|r| r.test_metadata.tokens_used).sum(),
            },
        }
    }
}
```

> **注意**：递归编排的通用模式详见第 17 章。

#### 8.7 🆕 新增：项目记忆读取

Tester 在测试之前会读取项目记忆中的 API 端点和数据模型信息，确保测试覆盖所有端点和数据模型。

```rust
impl Tester {
    /// 加载测试所需的记忆信息
    async fn load_test_context(
        &self,
        memory_dir: &Path,
    ) -> Result<TestContext, TesterError> {
        let mut ctx = TestContext::default();

        // 读取 API 端点列表
        let api_path = memory_dir.join("api-endpoints.json");
        if api_path.exists() {
            let content = tokio::fs::read_to_string(&api_path).await?;
            ctx.api_endpoints = Some(serde_json::from_str(&content)?);
        }

        // 读取数据模型列表
        let models_path = memory_dir.join("data-models.json");
        if models_path.exists() {
            let content = tokio::fs::read_to_string(&models_path).await?;
            ctx.data_models = Some(serde_json::from_str(&content)?);
        }

        // 读取代码约定（用于生成符合风格的测试代码）
        let conventions_path = memory_dir.join("conventions.md");
        if conventions_path.exists() {
            ctx.conventions = Some(
                tokio::fs::read_to_string(&conventions_path).await?
            );
        }

        Ok(ctx)
    }
}

#[derive(Debug, Clone, Default)]
pub struct TestContext {
    pub api_endpoints: Option<ApiEndpoints>,
    pub data_models: Option<DataModels>,
    pub conventions: Option<String>,
}
```

