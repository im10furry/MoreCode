# MoreCode — 专项能力 Agent（Research + DocWriter + Debugger）

> 本章不再把 Research、DocWriter、Debugger 定义为“扩展层”，而是把它们归为按需启用的专项能力 Agent：研究调查、文档编写和调试排错。

---

#### 9. Research Agent（研究者）

#### 9.1 角色定位

Research Agent 是系统中的"信息中枢"，负责在编码决策之前进行充分的技术调研。它不是简单的搜索工具，而是一个具备分析、对比、评估能力的深度调研者。当系统面临技术选型、方案对比、兼容性评估等需要外部信息的场景时，Research Agent 会被激活。

**核心特征：**

| 特征 | 描述 |
|------|------|
| 角色类型 | 信息收集与分析型 |
| 执行模式 | 可并行、可递归 |
| 优先级 | 高（阻塞后续编码流程） |
| 输出形式 | 结构化调研报告（JSON） |
| 可否异步 | 否（调研结果直接影响后续决策） |

#### 9.2 触发条件

Research Agent 在以下三种场景下被触发：

```
🔵 触发条件 1：研究任务
   用户明确要求调研，如"帮我调研一下 Rust 的 ORM 方案"
   → 直接启动 Research Agent

🔵 触发条件 2：复杂任务涉及技术选型
   Planner 在拆解任务时发现需要引入新依赖或新技术
   → Coordinator 启动 Research Agent 进行前置调研

🔵 触发条件 3：Coordinator 判断需要更多信息
   当任务描述模糊或涉及多个可行方案时
   → Coordinator 先启动 Research Agent 收集信息，再进入规划阶段
```

#### 9.3 核心职责

Research Agent 承担四大核心职责：

**① 信息收集**

- 通过 `web_search` 搜索技术文档、博客文章、GitHub 仓库
- 通过 `web_fetch` 获取具体页面内容（官方文档、RFC 规范等）
- 通过 `read_file` 和 `grep` 检查项目现有代码中的相关实现
- 通过 `run_command` 执行版本检查、依赖查询等命令

**② 方案分析**

- 对收集到的信息进行结构化整理
- 提取各方案的核心特性、优劣势
- 评估与项目现有架构的契合度
- 生成对比矩阵

**③ 兼容性评估**

- 检查候选方案与当前技术栈的兼容性
- 评估版本要求、编译目标、依赖冲突风险
- 考虑团队技术储备和学习成本

**④ 输出调研报告**

- 以结构化 JSON 格式输出调研结果
- 包含明确的推荐结论和理由
- 标注不确定因素和风险点
- 为后续 Planner 提供决策依据

#### 9.4 输出示例

以下是一个"Rust ORM 方案选型"的调研报告输出示例：

```json
{
  "research_topic": "Rust ORM 方案选型",
  "research_depth": "deep",
  "timestamp": "2026-04-15T10:30:00Z",
  "context": {
    "project_type": "Web API Backend",
    "rust_edition": "2021",
    "database": "PostgreSQL 15",
    "current_deps": ["tokio", "axum", "serde"]
  },
  "candidates": [
    {
      "name": "SQLx",
      "version": "0.7.x",
      "type": "Async SQL Toolkit (compile-time checked)",
      "pros": [
        "编译时 SQL 检查，类型安全",
        "原生异步支持，与 tokio 生态完美集成",
        "轻量级，无 ORM 抽象层开销",
        "支持 PostgreSQL/MySQL/SQLite",
        "活跃维护，Star 12K+"
      ],
      "cons": [
        "需要数据库连接进行编译时检查",
        "复杂查询需手写 SQL",
        "缺少迁移工具（需配合 sqlx-cli）",
        "关联查询需手动处理"
      ],
      "compatibility": {
        "rust_edition": "2021 ✓",
        "async_runtime": "tokio ✓",
        "database": "PostgreSQL ✓",
        "dependency_conflict": "无 ✓"
      },
      "performance": {
        "overhead": "极低（~2% vs raw libpq）",
        "benchmark_ref": "https://github.com/nickel-org/rust-web-benchmarks",
        "compile_time_impact": "中等（需连接数据库）"
      },
      "community": {
        "github_stars": "12500",
        "last_release": "2025-01-10",
        "crates_io_downloads": "15M+",
        "response_time": "活跃（Issue 平均响应 < 3天）"
      },
      "recommendation": "strong_recommend",
      "recommendation_reason": "与项目现有 tokio+axum 栈完美契合，编译时检查提供最高安全性，性能开销最小"
    },
    {
      "name": "Diesel",
      "version": "2.1.x",
      "type": "ORM (compile-time query builder)",
      "pros": [
        "成熟的 Rust ORM，生态完善",
        "强大的 Schema 管理和迁移工具",
        "类型安全的查询构建器",
        "支持复杂关联和预加载",
        "丰富的文档和教程"
      ],
      "cons": [
        "异步支持仍在开发中（diesel-async 非官方）",
        "宏系统复杂，学习曲线陡峭",
        "编译时间较长",
        "Schema 变更需要重新编译"
      ],
      "compatibility": {
        "rust_edition": "2021 ✓",
        "async_runtime": "tokio ⚠（需 diesel-async，非官方）",
        "database": "PostgreSQL ✓",
        "dependency_conflict": "无 ✓"
      },
      "performance": {
        "overhead": "中等（~8-12% vs raw libpq）",
        "benchmark_ref": "https://github.com/nickel-org/rust-web-benchmarks",
        "compile_time_impact": "高（宏展开开销大）"
      },
      "community": {
        "github_stars": "12000",
        "last_release": "2024-12-20",
        "crates_io_downloads": "20M+",
        "response_time": "活跃（核心团队响应快）"
      },
      "recommendation": "recommend_with_caveats",
      "recommendation_reason": "功能强大但异步支持不够原生，若项目对异步要求高则需谨慎"
    },
    {
      "name": "SeaORM",
      "version": "1.0.x",
      "type": "Async ORM (runtime query builder)",
      "pros": [
        "原生异步支持（基于 sqlx）",
        "动态查询构建，灵活度高",
        "自动生成 Entity（sea-orm-cli）",
        "支持 Active Record 和 Data Mapper 模式",
        "与 Axum 集成良好"
      ],
      "cons": [
        "运行时查询构建，缺少编译时 SQL 检查",
        "抽象层开销比 SQLx 大",
        "API 变动较频繁",
        "复杂查询性能不如手写 SQL"
      ],
      "compatibility": {
        "rust_edition": "2021 ✓",
        "async_runtime": "tokio ✓",
        "database": "PostgreSQL ✓",
        "dependency_conflict": "无 ✓"
      },
      "performance": {
        "overhead": "中等偏高（~10-15% vs raw libpq）",
        "benchmark_ref": "https://github.com/SeaQL/sea-orm-benchmarks",
        "compile_time_impact": "中等"
      },
      "community": {
        "github_stars": "6500",
        "last_release": "2025-01-12",
        "crates_io_downloads": "5M+",
        "response_time": "活跃（商业化支持）"
      },
      "recommendation": "recommend",
      "recommendation_reason": "异步原生支持，开发效率高，适合快速迭代项目"
    }
  ],
  "conclusion": {
    "recommended": "SQLx",
    "reasoning": "综合考虑项目的技术栈（tokio + axum）、性能要求（Web API 后端）和安全性需求（编译时检查），SQLx 是最佳选择。若后续需要更高级的 ORM 功能，可以从 SQLx 平滑迁移到 SeaORM（底层兼容）。",
    "risks": [
      "SQLx 编译时检查需要 CI 环境配置数据库连接",
      "复杂报表查询可能需要手写 SQL"
    ],
    "next_steps": [
      "安装 sqlx-cli 并配置 .env 文件",
      "创建数据库迁移文件",
      "在项目中建立 SQLx 基础设施层"
    ]
  }
}
```

#### 9.5 可用工具

| 工具 | 用途 | 使用场景 |
|------|------|----------|
| `web_search` | 互联网搜索 | 搜索技术方案、文档、基准测试、社区讨论 |
| `web_fetch` | 获取网页内容 | 读取官方文档、RFC 规范、GitHub README |
| `read_file` | 读取本地文件 | 检查项目现有代码、配置文件、依赖声明 |
| `grep` | 代码搜索 | 查找项目中已有的相关实现、依赖引用 |
| `run_command` | 执行命令 | 检查 Rust 版本、cargo 搜索 crate、测试编译 |

#### 9.6 Token 预算

| 调研级别 | Token 预算 | 适用场景 | 预期输出 |
|----------|-----------|----------|----------|
| 快速对比 | 15K - 25K | 2-3 个候选方案的简单对比 | 优劣势列表 + 推荐 |
| 深度调研 | 25K - 45K | 3-5 个候选方案的全面分析 | 完整调研报告 + 兼容性评估 |
| 全面调研 | 35K - 60K | 技术选型 + 社区调研 + 生产案例 | 深度报告 + 风险评估 + 迁移路径 |

> **注意：** Token 预算包含输入（项目上下文 + 搜索结果）和输出（调研报告）。深度调研和全面调研的预算范围有重叠，因为实际消耗取决于搜索结果的信息密度。

#### 9.7 🆕 新增：递归调研编排

Research Agent 不仅是信息收集者，还可以作为"迷你协调者"启动子 Agent 进行递归调研。这种模式在调研主题复杂、信息量大时尤为有效。

#### 递归调研流程

```
                        Research Agent（父）
                              │
                    ① 拆分调研方向
                    ┌────┼────┬────┐
                    ▼    ▼    ▼    ▼
              ┌──────┐┌──────┐┌──────┐┌──────┐
              │子 Agent││子 Agent││子 Agent││子 Agent│
              │ A:性能││ B:社区││ C:兼容││ D:案例│
              │ 基准  ││ 活跃度││ 性   ││      │
              └──┬───┘└──┬───┘└──┬───┘└──┬───┘
                 │       │       │       │
                    ③ 筛选过滤
                    ┌────┼────┬────┐
                    ▼    ▼    ▼    ▼
              [精炼数据点] [精炼数据点] [精炼数据点] [精炼数据点]
                    │       │       │       │
                    └────┼────┴────┘
                         ▼
                    ④ 第二轮深度分析
                    （交叉对比、发现矛盾点）
                         │
                         ▼
                    ⑤ 总结输出
                    （结构化调研报告）
```

#### 详细步骤

**① 拆分调研方向**

以"Rust ORM 选型"为例，Research Agent 将调研主题拆分为 4 个独立方向：

| 方向 | 子 Agent | 搜索焦点 | 关键指标 |
|------|----------|----------|----------|
| 性能基准 | SubAgent-A | benchmark、performance、overhead | 查询延迟、吞吐量、内存占用 |
| 社区活跃度 | SubAgent-B | github stars、issues、releases | Star 数、Issue 响应时间、发布频率 |
| 兼容性 | SubAgent-C | compatibility、integration、postgres | Rust 版本、异步运行时、数据库支持 |
| 生产案例 | SubAgent-D | production、case study、real world | 知名项目使用情况、生产问题报告 |

**② 并行启动子 Agent**

每个子 Agent 在干净的上下文中启动，只注入：
- 调研方向描述和搜索焦点
- 候选方案列表
- 必要的项目上下文（技术栈信息）
- 工具权限（web_search、web_fetch）

子 Agent 之间完全隔离，互不知道其他方向的存在。

**③ 筛选过滤**

每个子 Agent 返回原始搜索结果后，Research Agent 进行筛选：

```
筛选规则：
├── 去除网页噪声（导航栏、广告、侧边栏）
├── 去除重复信息（多个来源的相同内容）
├── 去除过时信息（超过 2 年的版本相关内容）
├── 保留关键数据点（版本号、性能数字、兼容性矩阵）
└── 保留结论性陈述（作者的评价、社区的共识）
```

**④ 第二轮深度分析**

将筛选后的精炼结果注入新的分析 Agent，执行：
- 交叉对比：不同方向的数据是否一致
- 矛盾发现：如"社区说性能好"但"基准测试显示差"
- 置信度评估：哪些结论有充分数据支撑，哪些是推测

**⑤ 总结输出**

生成最终的结构化调研报告（格式见 9.4 节）。

#### Token 消耗对比

| 模式 | Token 消耗 | 分析质量 | 信息覆盖率 |
|------|-----------|----------|-----------|
| 不拆分（单 Agent 直接调研） | ~25K | 中等 | 60-70%（受上下文窗口限制） |
| 递归拆分（4 方向子 Agent） | ~22K | 高 | 85-95%（各方向独立深入） |

> **关键洞察：** 递归拆分不仅没有增加 Token 消耗，反而因为每个子 Agent 的上下文更聚焦、更干净，减少了无关信息的干扰，整体消耗反而更低。同时，分析质量显著提升，因为每个方向都有完整的上下文窗口用于深度分析。

#### 9.8 🆕 新增：项目记忆

Research Agent 的项目记忆分为读取和写入两个方向：

#### 读取记忆

```
Research Agent 启动
        │
        ▼
读取 tech-stack.json
├── 知道当前使用的 Rust 版本
├── 知道已有的依赖和版本
├── 知道数据库类型和版本
├── 知道异步运行时选择
└── 知道框架选择（Axum/Actix/...）
        │
        ▼
读取 agent-notes/research/
├── 检查是否有相同主题的缓存调研结果
├── 如果有 → 评估是否过期（时间戳对比）
│   ├── 未过期 → 直接使用缓存，跳过调研
│   └── 已过期 → 增量更新（只调研变化部分）
└── 如果没有 → 执行完整调研
```

#### 写入记忆

```
调研完成
    │
    ▼
写入 agent-notes/research/{topic-hash}.json
├── 调研主题和关键词
├── 调研时间戳
├── 候选方案和结论
├── 推荐方案和理由
└── 相关链接和引用
    │
    ▼
更新 tech-stack.json（如果确定了技术选型）
├── 添加新依赖信息
├── 记录选型理由
└── 标记决策时间
```

**缓存命中示例：**

```
用户："帮我调研 Rust 的 ORM 方案"
Research Agent：
  → 检查 agent-notes/research/rust-orm-selection.json
  → 发现缓存文件存在，时间戳为 2 天前
  → 评估：SQLx 最新版本未变，结论仍然有效
  → 直接返回缓存结果
  → Token 消耗：~2K（vs 完整调研 ~25K）
```

---
## MoreCode — DocWriter Agent（文档编写者）

#### 10. DocWriter Agent（文档编写者）

#### 10.1 角色定位

DocWriter Agent 是系统中的"文档工程师"，负责将代码变更同步到项目文档中。它确保代码与文档的一致性，是项目可维护性的守护者。

**核心特征：**

| 特征 | 描述 |
|------|------|
| 角色类型 | 文档生成与维护型 |
| 执行模式 | 可异步、低优先级 |
| 优先级 | 最低（不阻塞交付） |
| 输出形式 | Markdown / 文档文件 |
| 可否异步 | 是（可在后台执行） |

#### 10.2 触发条件

```
🔵 触发条件 1：代码变更涉及公共 API
   Coder 修改了公共接口、数据结构、配置项
   → Reviewer 标记需要更新文档
   → Coordinator 异步启动 DocWriter

🔵 触发条件 2：新增功能模块
   Planner 拆解任务时发现需要新增文档章节
   → 在执行计划中标记文档任务
   → Coordinator 在编码完成后异步启动 DocWriter

🔵 触发条件 3：用户明确要求
   用户说"帮我更新一下 README"或"写一下 API 文档"
   → Coordinator 直接启动 DocWriter

🔵 触发条件 4：项目初始化
   新项目创建时，自动生成基础文档结构
   → DocWriter 生成 README、CONTRIBUTING、API 文档骨架
```

#### 10.3 特点：可异步执行，优先级最低

DocWriter 是所有 Agent 中唯一可以完全异步执行的 Agent。这意味着：

```
执行时序示例：

  [Coder 完成] → [Reviewer 通过] → [交付用户]
                                      │
                                 （后台异步）
                                      │
                              [DocWriter 更新文档]
                                      │
                              [文档更新完成通知]
```

**异步执行规则：**

| 规则 | 说明 |
|------|------|
| 不阻塞交付 | 用户无需等待文档更新完成即可使用代码 |
| 失败不回滚 | 文档更新失败不影响已交付的代码 |
| 可重试 | 文档任务失败后可以独立重试 |
| 可跳过 | 在紧急情况下可以跳过文档更新 |

#### 10.4 核心职责

**① 文档同步**

- 分析 Coder 的代码变更，识别需要更新的文档
- 更新 API 文档、README、CHANGELOG
- 确保文档中的代码示例与实际代码一致

**② 文档生成**

- 为新模块生成文档骨架
- 生成 API 参考文档
- 生成配置说明文档

**③ 文档审查**

- 检查文档中的过时信息
- 验证文档中的链接有效性
- 确保文档格式统一

**④ 文档结构维护**

- 维护文档目录结构
- 确保文档间的交叉引用正确
- 生成文档索引

#### 10.5 Token 预算

| 文档类型 | Token 预算 | 适用场景 | 预期输出 |
|----------|-----------|----------|----------|
| API 文档更新 | 5K - 10K | 单个接口的文档更新 | 接口说明 + 参数 + 示例 |
| README 更新 | 8K - 15K | 项目 README 的局部更新 | 修改后的 README 章节 |
| 完整文档生成 | 15K - 30K | 新模块的完整文档 | 模块文档 + API 参考 + 示例 |
| 文档重构 | 20K - 40K | 项目文档结构重组 | 完整的文档体系 |

#### 10.6 🆕 新增：项目记忆

DocWriter 通过读取项目记忆确保文档与项目实际情况一致：

```
DocWriter 启动
      │
      ▼
读取 project-overview.md
├── 了解项目整体架构
├── 了解各模块的职责和关系
├── 了解项目当前状态（开发中/稳定/维护中）
└── 了解文档风格和格式约定
      │
      ▼
读取 conventions.md
├── 文档命名规范
├── 文档目录结构约定
├── 语言偏好（中文/英文/双语）
└── 代码示例风格
      │
      ▼
读取 tech-stack.json
├── 确保文档中的技术栈描述准确
├── 确保版本号与实际一致
└── 确保依赖列表完整
      │
      ▼
执行文档更新
      │
      ▼
写入 agent-notes/docwriter/
├── 记录本次更新的文档列表
├── 记录更新原因和关联的代码变更
└── 记录待人工审核的文档部分
```

**记忆一致性保障：**

| 检查项 | 说明 | 处理方式 |
|--------|------|----------|
| API 签名一致性 | 文档中的函数签名与代码是否匹配 | 自动对比，不一致则标记警告 |
| 版本号一致性 | 文档中的版本号与 Cargo.toml 是否匹配 | 自动对比，不一致则更新 |
| 配置项一致性 | 文档中的配置示例与实际配置是否匹配 | 自动对比，不一致则标记 |
| 架构描述一致性 | 文档中的架构图与实际模块结构是否匹配 | 需要人工确认 |

---
## MoreCode — Debugger Agent（调试者）

#### 11. Debugger Agent（调试者）

#### 11.1 角色定位

Debugger Agent 是系统中的"故障排查专家"，负责诊断和修复代码中的错误。它具备系统化的调试方法论，能够从错误现象追溯到根本原因，并给出精确的修复方案。

**核心特征：**

| 特征 | 描述 |
|------|------|
| 角色类型 | 错误诊断与修复型 |
| 执行模式 | 可并行、可递归 |
| 优先级 | 高（阻塞交付） |
| 输出形式 | 修复报告 + 代码补丁 |
| 可否异步 | 否（修复结果直接影响交付） |

#### 11.2 触发条件

```
🔵 触发条件 1：Tester 报告测试失败
   Tester Agent 执行测试用例后报告失败
   → Coordinator 启动 Debugger 分析失败原因
   → Debugger 输出根因分析和修复方案

🔵 触发条件 2：用户报告运行时错误
   用户反馈程序运行时出现 panic、错误码、异常行为
   → Coordinator 收集错误信息，启动 Debugger
   → Debugger 定位问题并修复

🔵 触发条件 3：Coder 代码无法编译
   Coder Agent 提交的代码编译失败
   → Coordinator 将编译错误传递给 Debugger
   → Debugger 分析编译错误并修复
```

#### 11.3 核心职责

Debugger Agent 遵循系统化的四步调试流程：

**① 错误信息收集**

```
收集维度：
├── 编译错误
│   ├── error[E####]: 错误类型和位置
│   ├── warning[W####]: 警告信息
│   └── help: 编译器建议
├── 运行时错误
│   ├── panic 信息和 backtrace
│   ├── 错误日志（log/error 级别）
│   └── 错误码和错误消息
├── 测试失败
│   ├── 失败的测试用例名称
│   ├── 期望值 vs 实际值
│   ├── 断言位置
│   └── 失败模式（panic/断言失败/超时）
└── 环境信息
    ├── Rust 版本和目标平台
    ├── 依赖版本
    └── 环境变量和配置
```

**② 根因分析**

```
分析方法：
├── 静态分析
│   ├── 追踪错误消息到源码位置
│   ├── 分析类型不匹配的原因
│   ├── 检查所有权和生命周期问题
│   └── 检查宏展开结果
├── 动态分析
│   ├── 在关键位置插入日志
│   ├── 添加断言验证中间状态
│   └── 构建最小复现用例
└── 关联分析
    ├── 检查最近的代码变更
    ├── 检查依赖版本变化
    └── 检查配置变更
```

**③ 修复方案**

```
修复策略（按优先级排序）：
├── 精确修复：只修改导致错误的代码行
├── 重构修复：修复设计层面的问题
├── 替代方案：用不同方式实现相同功能
└── 回退方案：如果修复成本过高，回退到上一个工作版本
```

**④ 输出修复报告**

```json
{
  "bug_report": {
    "bug_id": "BUG-2026-001",
    "severity": "high",
    "category": "runtime_error",
    "error_message": "thread 'main' panicked at 'called `Result::unwrap()` on an `Err` value: DatabaseConnectionError'",
    "source_location": {
      "file": "src/db/pool.rs",
      "line": 45,
      "function": "get_connection"
    }
  },
  "root_cause": {
    "type": "error_handling",
    "description": "数据库连接池在启动时未正确初始化，get_connection() 直接 unwrap 了可能失败的连接获取操作",
    "why": "连接池配置的超时时间过短（100ms），在数据库负载高时无法获取连接",
    "evidence": [
      "src/config.rs:12 - pool_timeout 设置为 100ms",
      "src/db/pool.rs:45 - 使用 unwrap() 而非错误处理",
      "日志显示间歇性连接超时"
    ]
  },
  "fix": {
    "approach": "precise_fix",
    "changes": [
      {
        "file": "src/config.rs",
        "line": 12,
        "before": "pool_timeout: 100",
        "after": "pool_timeout: 5000",
        "reason": "将连接超时从 100ms 增加到 5s"
      },
      {
        "file": "src/db/pool.rs",
        "line": 45,
        "before": "pool.get().unwrap()",
        "after": "pool.get().map_err(|e| AppError::DbConnection(e))?",
        "reason": "用正确的错误处理替代 unwrap"
      }
    ],
    "verification": "运行 cargo test -- --test-threads=1 验证修复"
  }
}
```

#### 11.4 Token 预算

| 调试级别 | Token 预算 | 适用场景 | 预期输出 |
|----------|-----------|----------|----------|
| 编译错误修复 | 5K - 15K | 编译器错误、类型不匹配 | 修复补丁 + 简要说明 |
| 运行时错误修复 | 15K - 30K | panic、逻辑错误、边界条件 | 根因分析 + 修复补丁 |
| 复杂 Bug 调试 | 30K - 50K | 并发问题、内存泄漏、性能退化 | 深度分析报告 + 修复方案 |
| 系统性问题 | 40K - 70K | 架构层面的问题、多模块交互错误 | 完整诊断报告 + 重构方案 |

#### 11.5 🆕 新增：递归 Bug 验证

当 Bug 的根因不明确时，Debugger Agent 可以启动多个子 Debugger 并行验证不同的 Bug 假设：

```
                    Debugger（父）
                         │
              拆分多个 Bug 假设
              ┌────┼────┬────┐
              ▼    ▼    ▼    ▼
        ┌────────┐┌────────┐┌────────┐┌────────┐
        │子Debugger││子Debugger││子Debugger││子Debugger│
        │ 假设 A:  ││ 假设 B:  ││ 假设 C:  ││ 假设 D:  │
        │连接池耗尽││SQL 语法错││类型转换错││并发竞争  │
        └───┬────┘└───┬────┘└───┬────┘└───┬────┘
            │          │          │          │
            ▼          ▼          ▼          ▼
         [验证中]    [排除]     [确认!]     [排除]
            │                     │
            └──────┬──────────────┘
                   ▼
            筛选确认的根因
                   │
                   ▼
            输出精确修复方案
```

**假设生成示例：**

```
原始错误："用户登录偶尔返回 500 错误"

假设 A（连接池耗尽）：
  → 子 Debugger 检查连接池配置和监控数据
  → 结果：排除（连接池使用率峰值仅 30%）

假设 B（SQL 语法错误）：
  → 子 Debugger 检查 SQL 查询和参数绑定
  → 结果：排除（SQL 语法正确，编译时已检查）

假设 C（类型转换错误）：
  → 子 Debugger 检查数据库字段类型和 Rust 类型映射
  → 结果：确认！password_hash 字段在某些数据库中为 TEXT，
         但代码期望 VARCHAR(255)，导致截断后 bcrypt 验证失败

假设 D（并发竞争）：
  → 子 Debugger 检查并发访问模式
  → 结果：排除（使用连接池，无共享状态竞争）

最终结论：假设 C 确认，修复方案为统一字段类型定义
```

#### 11.6 🆕 新增：项目记忆

Debugger Agent 通过读取项目记忆辅助定位问题：

```
Debugger 启动
      │
      ▼
读取 conventions.md
├── 了解项目的错误处理约定
│   ├── 是否使用自定义 Error 类型
│   ├── unwrap 的使用规范
│   └── 错误传播模式（? vs .map_err）
├── 了解编码风格
│   ├── 命名规范（有助于理解变量含义）
│   └── 模块组织方式
└── 了解测试约定
    ├── 测试命名规范
    └── 测试组织方式
      │
      ▼
读取 risk-areas.json
├── 已知的风险区域
│   ├── "src/db/pool.rs - 连接池管理，历史上有超时问题"
│   ├── "src/auth/jwt.rs - JWT 验证，边界条件复杂"
│   └── "src/api/handlers.rs - 请求处理，并发访问频繁"
├── 常见错误模式
│   ├── "项目中 unwrap 使用过多，需优先检查"
│   └── "异步代码中缺少 .await"
└── 历史修复记录
    ├── "BUG-2024-015: 类似的连接池问题，修复方式为增加超时"
    └── "BUG-2024-022: bcrypt 验证失败，修复方式为统一字段长度"
      │
      ▼
利用历史信息加速定位
├── 如果当前错误与历史记录相似 → 直接应用已知修复模式
└── 如果是新问题 → 执行完整调试流程
      │
      ▼
写入 agent-notes/debugger/
├── 记录 Bug 描述和根因
├── 记录修复方案和验证结果
└── 更新 risk-areas.json（如果发现了新的风险区域）
```

---
