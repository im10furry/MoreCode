# MoreCode — Git 并发控制

## 8. Git 并发控制策略

### 8.1 问题：并行 Coder 的 Git 冲突

在复杂任务中，多个 Coder Agent 可能同时修改不同文件。如果每个 Coder 独立执行 `git add` + `git commit`，会导致：

```
并行 Coder 场景（无控制）：
  Coder A: 修改 auth.rs     → git add auth.rs && git commit -m "add auth"     ─┐
  Coder B: 修改 api.rs      → git add api.rs && git commit -m "add api"        ─┼── 并发写入 .git/
  Coder C: 修改 tests.rs    → git add tests.rs && git commit -m "add tests"    ─┘

问题 1: .git/ 目录并发写入 → index.lock 冲突 / 对象数据库损坏
问题 2: 各自独立 commit → 碎片化历史，无逻辑关联
问题 3: 部分 Coder 失败 → 已 commit 的无法整体回滚
问题 4: commit message 各自生成 → 风格不一致、语义割裂
问题 5: Coder A 的 commit 可能包含 Coder B 未完成的半成品（如果 add 了工作区）
```

### 8.2 解决方案：两阶段 + Commit Point

核心思想：**Coder 全程不碰 git，Planner 在执行计划中标记提交点，Pipeline 在提交点处统一串行执行 git 操作。**

```
两阶段模型：

  阶段一：代码修改（并行）
  ┌─────────────────────────────────────────────────────┐
  │  Coder A: 修改 auth.rs     → 写文件 ✅              │
  │  Coder B: 修改 api.rs      → 写文件 ✅              │
  │  Coder C: 修改 tests.rs    → 写文件 ✅              │
  │                                                     │
  │  规则：Coder 只能使用 read_file / write_file /      │
  │        edit_file / search_files / grep_content /    │
  │        run_command(仅限 cargo check/cargo fmt 等)   │
  │  禁止：git add / git commit / git push / git stash  │
  └─────────────────────────────────────────────────────┘
                           │
                           ▼ 所有 Coder 完成
  阶段二：Git 提交（串行）
  ┌─────────────────────────────────────────────────────┐
  │  Pipeline Commit Executor (单线程串行):              │
  │                                                     │
  │  1. git add (expected_files ∩ git status)           │
  │  2. git diff --cached → 生成统一 commit message      │
  │  3. git commit -m "feat(auth): 新增邮箱登录功能"     │
  │                                                     │
  │  特点：                                              │
  │  · 单线程执行，无并发冲突                             │
  │  · 统一生成 commit message，风格一致                  │
  │  · 逻辑分组提交，历史整洁                             │
  │  · 可整体回滚（commit 前的文件变更）                   │
  └─────────────────────────────────────────────────────┘
```

### 8.3 Commit Point 定义

**Commit Point（提交点）** 是 Planner 在执行计划中标记的逻辑提交边界。当一组相关的子任务全部完成后，Pipeline 在此处执行统一的 git 操作。

```rust
/// 提交点 — Planner 在执行计划中标记的 Git 提交边界
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommitPoint {
    /// 提交点 ID
    pub id: String,
    /// 提交点名称（用于生成 commit message）
    pub name: String,
    /// 此提交点包含的任务 ID 列表
    pub task_ids: Vec<String>,
    /// 此提交点允许提交的文件范围（仓库相对路径）
    /// Commit Executor 只能提交该列表与 `git status` 的交集
    pub expected_files: Vec<String>,
    /// 提交类型（影响 commit message 前缀）
    pub commit_type: CommitType,
    /// 提交条件：所有 listed tasks 都成功才提交
    pub condition: CommitCondition,
    /// 提交后是否推送到远程
    pub auto_push: bool,
    /// 执行顺序号（用于 Pipeline 中与 ParallelGroup 交错排序）
    pub sequence: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CommitType {
    /// 新功能: feat(scope): description
    Feature { scope: String },
    /// Bug 修复: fix(scope): description
    BugFix { scope: String },
    /// 重构: refactor(scope): description
    Refactor { scope: String },
    /// 测试: test(scope): description
    Test { scope: String },
    /// 文档: docs(scope): description
    Docs { scope: String },
    /// 杂项: chore: description
    Chore,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CommitCondition {
    /// 所有任务成功才提交
    AllSuccess,
    /// 至少一个任务成功就提交（跳过失败的）
    AnySuccess,
    /// 无论成功失败都提交（记录尝试）
    Always,
}
```

> **范围收敛优化（P1-10）**：`CommitExecutor` 不能根据整个工作区的 `git status` 直接提交，否则会把无关改动、用户本地未提交修改、其他 Commit Point 的半成品一起纳入本次提交。正确做法是只提交 `CommitPoint.expected_files ∩ git status --porcelain` 的交集。

### 8.4 Planner 输出格式扩展

Planner 的 `ExecutionPlan` 新增 `commit_points` 字段：

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionPlan {
    pub plan_id: String,
    pub task_description: String,
    pub sub_tasks: Vec<SubTask>,
    pub dependencies: Vec<TaskDependency>,
    pub parallel_groups: Vec<ParallelGroup>,
    pub commit_points: Vec<CommitPoint>,        // 🆕 提交点列表
    pub context_allocations: Vec<ContextAllocation>,
    pub total_estimated_tokens: usize,
    pub total_estimated_duration_ms: u64,
    pub plan_metadata: PlanMetadata,
}
```

#### 8.4.1 输出示例（含 Commit Point）

以"新增用户邮箱登录"为例，Planner 输出：

```json
{
  "plan_id": "plan_email_login_20260415_001",
  "sub_tasks": [
    { "id": "T1", "description": "创建数据库迁移文件", "assigned_agent": "Coder", ... },
    { "id": "T2", "description": "修改 User 模型", "assigned_agent": "Coder", ... },
    { "id": "T3", "description": "修改 user_service", "assigned_agent": "Coder", ... },
    { "id": "T4", "description": "实现邮箱登录认证逻辑", "assigned_agent": "Coder", ... },
    { "id": "T5", "description": "添加 API 端点", "assigned_agent": "Coder", ... },
    { "id": "T6", "description": "编写单元测试", "assigned_agent": "Tester", ... }
  ],
  "parallel_groups": [
    { "group_id": "G1", "tasks": ["T1"], "sequence": 1 },
    { "group_id": "G2", "tasks": ["T2"], "sequence": 2 },
    { "group_id": "G3", "tasks": ["T3", "T4"], "sequence": 3 },
    { "group_id": "G4", "tasks": ["T5"], "sequence": 4 },
    { "group_id": "G5", "tasks": ["T6"], "sequence": 5 }
  ],
  "commit_points": [
    {
      "id": "CP1",
      "name": "数据库 schema 变更",
      "task_ids": ["T1"],
      "expected_files": ["migrations/003_add_email_fields.sql"],
      "commit_type": { "Feature": { "scope": "db" } },
      "condition": "AllSuccess",
      "auto_push": false
    },
    {
      "id": "CP2",
      "name": "邮箱登录核心功能",
      "task_ids": ["T2", "T3", "T4"],
      "expected_files": [
        "src/models/user.rs",
        "src/services/user_service.rs",
        "src/services/auth_service.rs"
      ],
      "commit_type": { "Feature": { "scope": "auth" } },
      "condition": "AllSuccess",
      "auto_push": false
    },
    {
      "id": "CP3",
      "name": "邮箱登录 API 端点与测试",
      "task_ids": ["T5", "T6"],
      "expected_files": ["src/routes/auth.rs", "tests/auth_test.rs"],
      "commit_type": { "Feature": { "scope": "auth" } },
      "condition": "AllSuccess",
      "auto_push": false
    }
  ]
}
```

#### 8.4.2 DAG 可视化（含 Commit Point）

```
     T1: 数据库迁移
         │
         ▼
     ══ CP1: feat(db): 数据库 schema 变更 ══    ← 提交点 1
         │
         ▼
     T2: User 模型修改
        ╱ ╲
       ╱   ╲
      ▼     ▼
   T3: user_service   T4: auth_service     ← 并行执行
      修改              实现
       ╲   ╱
        ╲ ╱
         ▼
     ══ CP2: feat(auth): 邮箱登录核心功能 ══  ← 提交点 2
         │
         ▼
     T5: API 端点
         │
         ▼
     T6: 单元测试
         │
         ▼
     ══ CP3: feat(auth): API 端点与测试 ══   ← 提交点 3

  执行时间线:
  ─────────────────────────────────────────────────────
  G1: [T1 ████████]
  CP1:            [git commit ████]                   ← 串行
  G2:                     [T2 ██████████]
  G3:                              [T3 ██████]  [T4 ██████████████]  ← T3/T4 并行
  CP2:                                              [git commit ████]  ← 串行
  G4:                                                      [T5 ████████████]
  G5:                                                                    [T6 ██████████]
  CP3:                                                                              [git commit ████]
  ─────────────────────────────────────────────────────
```

### 8.5 Pipeline Commit Executor

Pipeline 在执行计划时，遇到 Commit Point 会暂停并行执行，串行处理 git 操作：

```rust
use std::collections::HashSet;

/// Pipeline 提交执行器 — 单线程串行执行所有 git 操作
pub struct CommitExecutor {
    platform: Arc<PlatformEnvironment>,
    commit_style: CommitStyle,
}

/// Commit 风格配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommitStyle {
    /// 是否使用 Conventional Commits 格式
    pub conventional: bool,
    /// commit message 语言（跟随用户语言）
    pub message_language: String,
    /// 最大单次 commit 文件数（超过则拆分）
    pub max_files_per_commit: usize,
    /// 是否在 commit 前运行 cargo fmt / gofmt
    pub auto_format: bool,
    /// 是否在 commit 前运行 cargo clippy / lint
    pub auto_lint: bool,
}

impl CommitExecutor {
    /// 执行提交点
    pub async fn execute_commit_point(
        &self,
        commit_point: &CommitPoint,
        task_results: &[TaskResult],
        working_dir: &Path,
    ) -> Result<CommitResult, CommitError> {
        // 1. 检查提交条件（使用 HashSet 优化查找性能 O(N+M)）
        let expected_set: HashSet<&str> = commit_point.task_ids
            .iter()
            .map(|s| s.as_str())
            .collect();
        let relevant_results: Vec<_> = task_results
            .iter()
            .filter(|r| expected_set.contains(&r.task_id.as_str()))
            .collect();

        let should_commit = match commit_point.condition {
            CommitCondition::AllSuccess => relevant_results.iter().all(|r| r.success),
            CommitCondition::AnySuccess => relevant_results.iter().any(|r| r.success),
            CommitCondition::Always => true,
        };

        if !should_commit {
            log::info!(
                "提交点 {} 条件不满足，跳过提交",
                commit_point.id
            );
            return Ok(CommitResult::Skipped {
                reason: "提交条件不满足".into(),
            });
        }

        // 2. 收集当前提交点允许提交的变更文件
        let changed_files = self.collect_changed_files(
            working_dir,
            &commit_point.expected_files,
        ).await?;

        if changed_files.is_empty() {
            return Ok(CommitResult::Skipped {
                reason: "无文件变更".into(),
            });
        }

        // 3. 可选：自动格式化
        if self.commit_style.auto_format {
            self.run_auto_format(working_dir).await?;
        }

        // 4. 可选：自动 lint 检查
        if self.commit_style.auto_lint {
            let lint_result = self.run_lint(working_dir).await?;
            if !lint_result.success {
                return Err(CommitError::LintFailed {
                    stderr: lint_result.stderr,
                });
            }
        }

        // 5. 生成 commit message
        let message = self.generate_commit_message(
            commit_point,
            &changed_files,
            &relevant_results,
        ).await?;

        // 6. 执行 git add
        self.git_add(&changed_files, working_dir).await?;

        // 7. 执行 git commit
        let commit_hash = self.git_commit(&message, working_dir).await?;

        // 8. 可选：自动推送
        if commit_point.auto_push {
            self.git_push(working_dir).await?;
        }

        Ok(CommitResult::Committed {
            commit_hash,
            message,
            files_count: changed_files.len(),
            files: changed_files,
        })
    }

    /// 收集"当前提交点允许提交"的变更文件
    ///
    /// **性能优化方向**：`git status --porcelain` 在大仓库（10K+ 文件）中
    /// 可能耗时 200ms-2s。生产环境应考虑：
    /// - 在任务开始时预执行 `git status --porcelain` 并缓存结果
    /// - 使用 `git diff --name-only HEAD` 限制范围
    /// - 或监听 fsnotify 事件增量维护变更文件列表
    async fn collect_changed_files(
        &self,
        working_dir: &Path,
        expected_files: &[String],
    ) -> Result<Vec<String>, CommitError> {
        let expected: HashSet<&str> = expected_files
            .iter()
            .map(|s| s.as_str())
            .collect();

        let output = Command::new("git")
            .args(["status", "--porcelain"])
            .current_dir(working_dir)
            .output()
            .await
            .map_err(|e| CommitError::GitFailed(e.to_string()))?;

        let stdout = String::from_utf8_lossy(&output.stdout);
        let files: Vec<String> = stdout
            .lines()
            .filter(|line| !line.is_empty())
            .map(|line| {
                // git status --porcelain 格式: "XY filename"
                // 处理重命名: "R  old -> new" → 取 new 作为实际路径
                let path_part = &line[3..];
                if let Some(arrow_pos) = path_part.find(" -> ") {
                    path_part[arrow_pos + 4..].trim().to_string()
                } else {
                    path_part.trim().to_string()
                }
            })
            .filter(|path| expected.contains(path.as_str()))
            .collect();

        Ok(files)
    }

    /// 生成 commit message
    async fn generate_commit_message(
        &self,
        commit_point: &CommitPoint,
        changed_files: &[String],
        task_results: &[&TaskResult],
    ) -> Result<String, CommitError> {
        let type_prefix = match &commit_point.commit_type {
            CommitType::Feature { scope } => format!("feat({})", scope),
            CommitType::BugFix { scope } => format!("fix({})", scope),
            CommitType::Refactor { scope } => format!("refactor({})", scope),
            CommitType::Test { scope } => format!("test({})", scope),
            CommitType::Docs { scope } => format!("docs({})", scope),
            CommitType::Chore => "chore".to_string(),
        };

        // 从任务结果中提取关键信息
        let details: Vec<String> = task_results
            .iter()
            .filter_map(|r| r.summary.clone())
            .collect();

        let body = if details.is_empty() {
            commit_point.name.clone()
        } else {
            format!(
                "{}\n\n{}",
                commit_point.name,
                details.join("\n")
            )
        };

        let files_summary = if changed_files.len() <= 5 {
            format!(
                "\n\nFiles changed:\n{}",
                changed_files.iter().map(|f| format!("  - {}", f)).collect::<Vec<_>>().join("\n")
            )
        } else {
            format!(
                "\n\nFiles changed: {} files",
                changed_files.len()
            )
        };

        Ok(format!("{}: {}{}", type_prefix, body, files_summary))
    }

    async fn git_add(&self, files: &[String], working_dir: &Path) -> Result<(), CommitError> {
        // 命令行长度限制保护：超过阈值时改用 --pathspec-from-file
        const MAX_ARG_LENGTH: usize = 128_000; // Linux ARG_MAX 通常为 2MB，留安全余量
        
        let total_arg_len: usize = files.iter().map(|f| f.len() + 1).sum();
        
        if total_arg_len > MAX_ARG_LENGTH {
            // 文件列表过长，使用 --pathspec-from-file 从临时文件读取
            let specs_content = files.join("\n");
            let specs_path = working_dir.join(".git/morecode-pathspec");
            tokio::fs::write(&specs_path, &specs_content).await
                .map_err(|e| CommitError::GitFailed(format!("无法写入 pathspec 文件: {}", e)))?;
            
            let output = Command::new("git")
                .args(["add", "--pathspec-from-file", specs_path.to_str().unwrap()])
                .current_dir(working_dir)
                .output()
                .await
                .map_err(|e| CommitError::GitFailed(e.to_string()))?;

            // 清理临时文件
            let _ = tokio::fs::remove_file(&specs_path).await;
            
            if !output.status.success() {
                return Err(CommitError::GitFailed(
                    String::from_utf8_lossy(&output.stderr).into_owned()
                ));
            }
        } else {
            let output = Command::new("git")
                .arg("add")
                .args(files)
                .current_dir(working_dir)
                .output()
                .await
                .map_err(|e| CommitError::GitFailed(e.to_string()))?;

            if !output.status.success() {
                return Err(CommitError::GitFailed(
                    String::from_utf8_lossy(&output.stderr).into_owned()
                ));
            }
        }
        Ok(())
    }

    async fn git_commit(&self, message: &str, working_dir: &Path) -> Result<String, CommitError> {
        let output = Command::new("git")
            .args(["commit", "-m", message])
            .current_dir(working_dir)
            .output()
            .await
            .map_err(|e| CommitError::GitFailed(e.to_string()))?;

        if !output.status.success() {
            return Err(CommitError::GitFailed(
                String::from_utf8_lossy(&output.stderr).into_owned()
            ));
        }

        // 获取 commit hash
        let hash_output = Command::new("git")
            .args(["rev-parse", "HEAD"])
            .current_dir(working_dir)
            .output()
            .await
            .map_err(|e| CommitError::GitFailed(e.to_string()))?;

        Ok(String::from_utf8_lossy(&hash_output.stdout).trim().to_string())
    }

    async fn git_push(&self, working_dir: &Path) -> Result<(), CommitError> {
        let output = Command::new("git")
            .args(["push"])
            .current_dir(working_dir)
            .output()
            .await
            .map_err(|e| CommitError::GitFailed(e.to_string()))?;

        if !output.status.success() {
            return Err(CommitError::GitFailed(
                String::from_utf8_lossy(&output.stderr).into_owned()
            ));
        }
        Ok(())
    }

    async fn run_auto_format(&self, working_dir: &Path) -> Result<(), CommitError> {
        // 根据项目类型选择格式化工具
        let format_commands = [
            // Rust
            ("Cargo.toml", vec!["cargo", "fmt"]),
            // Go
            ("go.mod", vec!["gofmt", "-w", "."]),
            // Python
            ("pyproject.toml", vec!["ruff", "format", "."]),
        ];

        for (marker, cmd) in &format_commands {
            if working_dir.join(marker).exists() {
                let output = Command::new(cmd[0])
                    .args(&cmd[1..])
                    .current_dir(working_dir)
                    .output()
                    .await
                    .map_err(|e| CommitError::FormatFailed(e.to_string()))?;

                if !output.status.success() {
                    log::warn!("格式化失败: {:?}", cmd);
                }
                break;
            }
        }
        Ok(())
    }

    async fn run_lint(&self, working_dir: &Path) -> Result<LintResult, CommitError> {
        let lint_commands = [
            ("Cargo.toml", vec!["cargo", "clippy", "--", "-D", "warnings"]),
            ("go.mod", vec!["go", "vet", "./..."]),
            ("package.json", vec!["npm", "run", "lint"]),
        ];

        for (marker, cmd) in &lint_commands {
            if working_dir.join(marker).exists() {
                let output = Command::new(cmd[0])
                    .args(&cmd[1..])
                    .current_dir(working_dir)
                    .output()
                    .await
                    .map_err(|e| CommitError::LintFailed(e.to_string()))?;

                return Ok(LintResult {
                    success: output.status.success(),
                    stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
                });
            }
        }

        Ok(LintResult { success: true, stderr: String::new() })
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CommitResult {
    Committed {
        commit_hash: String,
        message: String,
        files_count: usize,
        files: Vec<String>,
    },
    Skipped {
        reason: String,
    },
}

#[derive(Debug)]
pub enum CommitError {
    GitFailed(String),
    LintFailed { stderr: String },
    FormatFailed(String),
    NoChanges,
}
```

**提交范围约束：**

- `expected_files` 由 Planner 预先声明，路径统一使用仓库相对路径
- `git status --porcelain` 只负责提供“当前真的脏了哪些文件”
- Commit Point 的实际提交文件 = `expected_files ∩ 当前脏文件`
- 如果交集为空，应跳过提交，而不是扩大到整个工作区
- `git add` 必须只接收这一交集作为 pathspec，避免误提交用户未授权或不相关文件

### 8.6 Pipeline 执行流程（含 Commit Point）

```rust
/// Pipeline 执行器 — 按照执行计划调度 Agent 和 Commit Point
pub struct PipelineExecutor {
    agent_factory: Arc<AgentFactory>,
    commit_executor: Arc<CommitExecutor>,
    platform: Arc<PlatformEnvironment>,
    working_dir: PathBuf,
}

impl PipelineExecutor {
    /// 执行完整的执行计划
    pub async fn execute_plan(&self, plan: ExecutionPlan) -> PlanResult {
        let mut task_results: HashMap<String, TaskResult> = HashMap::new();
        let mut commit_results: Vec<CommitResult> = Vec::new();

        // 按 sequence 排序执行
        let mut all_steps = self.build_execution_steps(&plan);

        for step in all_steps {
            match step {
                ExecutionStep::ParallelGroup(group) => {
                    // 并行执行一组任务
                    let handles: Vec<_> = group.tasks
                        .iter()
                        .map(|task_id| {
                            let factory = Arc::clone(&self.agent_factory);
                            let task = plan.sub_tasks.iter()
                                .find(|t| t.id == *task_id)
                                .unwrap()
                                .clone();
                            tokio::spawn(async move {
                                // TODO: 从 SubTask.assigned_agent 读取 agent_type，
                                //       当前只支持 Coder 并行执行
                                let params = AgentSpawnParams {
                                    agent_type: AgentType::Coder,
                                    task: task.description.clone(),
                                    parent_context: None,
                                    depth: 0,
                                    token_budget: task.estimated_tokens,
                                };
                                let handle = factory.spawn(params);
                                handle.run().await
                            })
                        })
                        .collect();

                    // 等待所有并行任务完成
                    for (task_id, handle) in group.tasks.iter().zip(handles) {
                        if let Ok(result) = handle.await {
                            task_results.insert(task_id.clone(), result);
                        }
                    }
                }

                ExecutionStep::CommitPoint(cp) => {
                    // 📍 遇到提交点 — 暂停，串行执行 git 操作
                    log::info!("到达提交点 {}: {}", cp.id, cp.name);

                    let results: Vec<TaskResult> = cp.task_ids
                        .iter()
                        .filter_map(|id| task_results.get(id).cloned())
                        .collect();

                    match self.commit_executor
                        .execute_commit_point(&cp, &results, &self.working_dir)
                        .await
                    {
                        Ok(result) => {
                            commit_results.push(result);
                        }
                        Err(e) => {
                            log::error!("提交点 {} 执行失败: {:?}", cp.id, e);
                            // 提交失败不阻塞后续任务，但记录错误
                        }
                    }
                }
            }
        }

        PlanResult {
            task_results,
            commit_results,
        }
    }

    /// 将执行计划和提交点合并为有序步骤列表
    /// 
    /// **性能优化方向**：当前实现使用 `Vec::insert(0, ...)` 导致 O(N²) 平移开销。
    /// 当执行步骤较多时（如 20+ 步），应改为：
    /// 1. 先收集所有步骤到 Vec
    /// 2. 反转 Vec（O(N)）
    /// 3. 一次性构建最终列表
    /// 或使用 VecDeque 的 push_front（均摊 O(1)）
    fn build_execution_steps(&self, plan: &ExecutionPlan) -> Vec<ExecutionStep> {
        let mut steps: Vec<ExecutionStep> = Vec::new();

        // 为每个 parallel_group 查找其后的 commit_point
        for group in &plan.parallel_groups {
            steps.push(ExecutionStep::ParallelGroup(group.clone()));

            // 查找所有任务 ID 都在此 group 中的 commit_point
            for cp in &plan.commit_points {
                let all_in_group = cp.task_ids.iter().all(|tid| {
                    group.tasks.contains(tid)
                });
                if all_in_group {
                    steps.push(ExecutionStep::CommitPoint(cp.clone()));
                }
            }
        }

        // 处理跨组的 commit_point（如 CP2 包含 G3 的 T3 和 G4 的 T4）
        // 对于 all_in_group 为 false 的 CommitPoint，找到其 task_ids 中
        // 最后一个 task 所属的 group，将 CommitPoint 放在该 group 之后
        for cp in &plan.commit_points {
            let all_in_group = plan.parallel_groups.iter().any(|g| {
                cp.task_ids.iter().all(|tid| g.tasks.contains(tid))
            });
            if !all_in_group {
                // 找到包含该 CommitPoint 任意 task_id 的最后一个 group
                let last_group_seq = plan.parallel_groups.iter()
                    .filter(|g| cp.task_ids.iter().any(|tid| g.tasks.contains(tid)))
                    .map(|g| g.sequence)
                    .max()
                    .unwrap_or(0);

                // 在最后一个相关 group 之后插入此 CommitPoint
                let insert_pos = steps.iter().position(|s| match s {
                    ExecutionStep::ParallelGroup(g) => g.sequence == last_group_seq,
                    ExecutionStep::CommitPoint(_) => false,
                }).map(|pos| pos + 1).unwrap_or(steps.len());

                steps.insert(insert_pos, ExecutionStep::CommitPoint(cp.clone()));
            }
        }

        steps
    }
}

enum ExecutionStep {
    ParallelGroup(ParallelGroup),
    CommitPoint(CommitPoint),
}
```

### 8.7 Coder Agent 的 Git 工具限制

Coder Agent 的工具列表中**不包含 git 写操作工具**。`run_command` 工具也会在工具层进行命令过滤：

```rust
use std::path::{Path, PathBuf};

/// Git 命令过滤器 — Coder Agent 的 run_command 工具层拦截
pub struct GitCommandFilter;

#[derive(Debug)]
struct ParsedCommand {
    executable: PathBuf,
    argv: Vec<String>,
}

impl GitCommandFilter {
    /// Coder Agent 禁止执行的 git 子命令
    const FORBIDDEN_GIT_SUBCOMMANDS: &[&str] = &[
        "add",
        "commit",
        "push",
        "pull",
        "merge",
        "rebase",
        "cherry-pick",
        "reset",
        "checkout", // 可能切换分支导致混乱
        "stash",
        "tag",
    ];

    /// 允许 Coder 执行的 git 子命令（只读）
    const ALLOWED_GIT_SUBCOMMANDS: &[&str] = &[
        "status",
        "diff",
        "log",
        "show",
        "blame",
        "branch",
        "remote",
    ];

    /// 检查命令是否被允许
    pub fn check(command: &str, agent_type: &AgentType) -> Result<(), String> {
        // 只有 Coder 和 Tester 需要限制
        if !matches!(agent_type, AgentType::Coder | AgentType::Tester) {
            return Ok(());
        }

        let parsed = Self::parse_command(command)?;

        // 非 git 命令直接放行；git 命令进入只读/写入校验
        if !Self::is_git_executable(&parsed.executable) {
            return Ok(());
        }

        let subcommand = parsed.argv.get(1).map(String::as_str).unwrap_or("");

        if Self::FORBIDDEN_GIT_SUBCOMMANDS.contains(&subcommand) {
            return Err(format!(
                "❌ Coder Agent 不能执行 'git {}'. Git 写操作由 Pipeline Commit Executor 统一管理。\
                 如果你修改了文件，系统会在合适的提交点自动提交。",
                subcommand
            ));
        }

        if Self::is_allowed_readonly_git(&parsed.argv) {
            return Ok(());
        }

        // 其他 git 命令默认禁止
        Err(format!(
            "❌ Coder Agent 不能执行 'git {}'. 只允许只读 git 命令: {}",
            subcommand,
            Self::ALLOWED_GIT_SUBCOMMANDS.join(", ")
        ))
    }

    fn parse_command(command: &str) -> Result<ParsedCommand, String> {
        let trimmed = command.trim();

        if trimmed.is_empty() {
            return Err("❌ 命令不能为空".into());
        }

        if contains_shell_control_operators(trimmed) {
            return Err(
                "❌ run_command 不允许使用 shell 链式操作符（;、&&、||、|、换行）".into()
            );
        }

        let argv = shlex::split(trimmed)
            .ok_or_else(|| format!("❌ 无法按 shell 词法规则解析命令: {}", trimmed))?;

        let program = argv
            .first()
            .ok_or_else(|| "❌ 解析后的命令为空".to_string())?;
        let executable = resolve_executable(program)?;

        Ok(ParsedCommand { executable, argv })
    }

    fn is_allowed_readonly_git(argv: &[String]) -> bool {
        match argv.get(1).map(String::as_str) {
            Some("status" | "diff" | "log" | "show" | "blame") => true,
            Some("branch") => {
                let flags = &argv[2..];
                flags.is_empty()
                    || flags.iter().all(|arg| {
                        matches!(
                            arg.as_str(),
                            "-a" | "-r" | "--all" | "--remotes" | "--list" | "--show-current"
                        )
                    })
            }
            Some("remote") => argv.len() == 3 && argv[2] == "-v",
            _ => false,
        }
    }

    fn is_git_executable(path: &Path) -> bool {
        matches!(
            path.file_name().and_then(|name| name.to_str()),
            Some("git") | Some("git.exe")
        )
    }
}

fn resolve_executable(program: &str) -> Result<PathBuf, String> {
    let candidate = Path::new(program);

    if candidate.components().count() > 1 {
        candidate
            .canonicalize()
            .map_err(|e| format!("无法解析命令路径 '{}': {}", program, e))
    } else {
        which::which(program)
            .map_err(|e| format!("无法在 PATH 中定位命令 '{}': {}", program, e))
    }
}

fn contains_shell_control_operators(command: &str) -> bool {
    let mut chars = command.chars().peekable();
    let mut escaped = false;
    let mut in_single = false;
    let mut in_double = false;
    let mut paren_depth = 0;

    while let Some(ch) = chars.next() {
        if escaped {
            escaped = false;
            continue;
        }

        match ch {
            '\\' if !in_single => escaped = true,
            '\'' if !in_double => in_single = !in_single,
            '"' if !in_single => in_double = !in_double,
            '`' if !in_single && !in_double => return true, // 反引号命令替换
            '$' if !in_single && !in_double && chars.peek() == Some(&'(') => return true, // $() 命令替换
            '(' if !in_single && !in_double => { paren_depth += 1; }
            ')' if !in_single && !in_double => {
                if paren_depth > 0 { paren_depth -= 1; }
            }
            '\n' if !in_single && !in_double => return true,
            ';' if !in_single && !in_double => return true,
            '&' if !in_single && !in_double && chars.peek() == Some(&'&') => return true,
            '|' if !in_single && !in_double => return true,
            _ => {}
        }
    }

    false
}
```

安全要点：

- 不能再用 `starts_with("git ")` 做前缀匹配；`git  commit`、`/usr/bin/git commit`、`git commit && ...` 都会绕过。
- `shlex::split` 负责把命令拆成参数数组，解决多空格和引号问题；shell 控制操作符需要在拆分前显式拒绝。
- 过滤逻辑必须先把可执行文件解析为真实路径或 basename，再判断是否为 `git` 以及对应的只读子命令。

### 8.8 回滚策略

当某个 Commit Point 的提交条件不满足时，系统需要处理已修改的文件：

```rust
impl CommitExecutor {
    /// 处理提交失败后的回滚
    pub async fn handle_rollback(
        &self,
        commit_point: &CommitPoint,
        task_results: &[TaskResult],
        working_dir: &Path,
    ) -> RollbackAction {
        let failed_tasks: Vec<_> = task_results
            .iter()
            .filter(|r| !r.success && commit_point.task_ids.contains(&r.task_id))
            .collect();

        if failed_tasks.is_empty() {
            return RollbackAction::None;
        }

        // 策略 1: 如果部分任务成功部分失败，询问用户
        let succeeded = commit_point.task_ids.len() - failed_tasks.len();
        let total = commit_point.task_ids.len();

        if succeeded > 0 && succeeded < total {
            return RollbackAction::AskUser {
                message: format!(
                    "提交点 '{}' 中 {}/{} 个任务成功。\
                     成功的修改是否保留在工作区？\n\
                     - 保留：文件修改不回滚，等待手动处理\n\
                     - 回滚：git checkout 还原所有修改",
                    commit_point.name, succeeded, total
                ),
                succeeded_files: self.get_succeeded_files(task_results, commit_point),
                failed_files: self.get_failed_files(task_results, commit_point),
            };
        }

        // 策略 2: 全部失败，自动回滚
        RollbackAction::AutoRevert {
            reason: format!(
                "提交点 '{}' 的所有任务均失败，自动回滚文件修改",
                commit_point.name
            ),
        }
    }
}

pub enum RollbackAction {
    /// 无需回滚
    None,
    /// 询问用户决定
    AskUser {
        message: String,
        succeeded_files: Vec<String>,
        failed_files: Vec<String>,
    },
    /// 自动回滚所有修改
    AutoRevert {
        reason: String,
    },
    /// 只回滚失败任务的修改
    PartialRevert {
        files_to_revert: Vec<String>,
    },
}
```

### 8.9 完整流程时序图

```
用户: "新增邮箱登录功能"
  │
  ▼
Coordinator: 理解意图 → 路由到复杂任务流程
  │
  ▼
Explorer: 扫描项目结构，输出技术栈和模块信息
  │
  ▼
ImpactAnalyzer: 分析影响范围，输出风险点
  │
  ▼
Planner: 生成执行计划（含 Commit Point）
  │  输出: sub_tasks + parallel_groups + commit_points
  │
  ▼
Pipeline Executor: 按计划执行
  │
  ├── G1: Coder[T1] → 修改 migration 文件
  │   └── T1 完成 ✅
  │
  ├── 📍 CP1: CommitExecutor
  │   ├── git add migrations/003_add_email_fields.sql
  │   ├── 生成 message: "feat(db): 数据库 schema 变更"
  │   └── git commit → abc123
  │
  ├── G2: Coder[T2] → 修改 User 模型
  │   └── T2 完成 ✅
  │
  ├── G3: Coder[T3] + Coder[T4]  ← 并行！
  │   ├── T3 完成 ✅ (user_service)
  │   └── T4 完成 ✅ (auth_service)
  │
  ├── 📍 CP2: CommitExecutor
  │   ├── git add src/models/user.rs src/services/user_service.rs src/services/auth_service.rs
  │   ├── cargo fmt (自动格式化)
  │   ├── cargo clippy (自动 lint)
  │   ├── 生成 message: "feat(auth): 邮箱登录核心功能"
  │   └── git commit → def456
  │
  ├── G4: Coder[T5] → 添加 API 端点
  │   └── T5 完成 ✅
  │
  ├── G5: Tester[T6] → 编写测试
  │   └── T6 完成 ✅
  │
  └── 📍 CP3: CommitExecutor
      ├── git add src/routes/auth.rs tests/auth_test.rs
      ├── 生成 message: "feat(auth): API 端点与测试"
      └── git commit → ghi789
  │
  ▼
Reviewer: 审查所有变更 (git diff abc123..ghi789)
  │
  ▼
Coordinator: 整合结果，交付用户
```

### 8.10 设计决策

| 决策 | 选择 | 理由 |
|------|------|------|
| 谁负责 git 操作 | Pipeline Commit Executor（独立组件） | 职责单一，Coder 专注编码 |
| Coder 能否读 git | 可以（git log/diff/status） | 需要了解代码历史辅助决策 |
| Coder 能否写 git | 不能（工具层拦截） | 防止并发冲突 |
| 提交粒度 | 由 Planner 标记 Commit Point | 逻辑分组，历史整洁 |
| commit message | 自动生成（Conventional Commits） | 风格一致，语义清晰 |
| 提交前格式化 | 可选（auto_format 配置） | 保证提交代码质量 |
| 提交前 lint | 可选（auto_lint 配置） | 防止不合规代码进入仓库 |
| 部分任务失败 | 询问用户或自动回滚 | 灵活处理，不强制 |
| 自动推送 | 默认关闭（auto_push: false） | 安全优先，用户确认后再推 |
