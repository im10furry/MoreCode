# MoreCode — LLM Provider 接入与 Token 管理

> **定位**：Agent 系统的 LLM 调用层、缓存中间件与成本控制基础设施
> **关联章节**：12-上下文压缩策略、15-Prompt 缓存与模板管理、16-可观测性与 Hook 系统

---

## 14. LLM Provider 接入与 Token 管理

### 14.1 核心思想

Agent 系统需要对接多个 LLM Provider（OpenAI / Anthropic / Google / 国产模型 / 本地模型），统一抽象层屏蔽差异。Token 管理是成本控制的基础；缓存则分为 **Provider 侧 Prompt 前缀缓存** 和 **应用侧语义缓存中间件** 两层。

```
┌──────────────────────────────────────────────────────────────┐
│                       Agent System                            │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌──────────┐       │
│  │ Planner │  │ Coder   │  │ Reviewer│  │ Executor │       │
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬─────┘       │
│       └────────────┼────────────┼────────────┘               │
│                    ▼                                          │
│  ┌─────────────────────────────────────────────────────┐      │
│  │       Semantic Cache Middleware (Optional)           │      │
│  │  Explorer / Research 重复查询命中后可直接返回         │      │
│  └────────┬────────────────────────────────────────────┘      │
│           ▼                                                   │
│  ┌─────────────────────────────────────────────────────┐      │
│  │              LlmProvider Trait                       │      │
│  │  chat_stream() / chat() / cache_capability()        │      │
│  └────────┬──────────┬──────────┬──────────┬────────────┘      │
│           │          │          │          │                   │
│     ┌─────▼──────────▼──────────▼──────────▼──────────┐      │
│     │           OpenAI Compatible Provider             │      │
│     │  (统一协议层，覆盖绝大多数 Provider)               │      │
│     │                                                    │      │
│     │  ┌──────────┐ ┌──────────┐ ┌──────────────────┐  │      │
│     │  │ OpenAI   │ │ DeepSeek │ │ 智谱 GLM          │  │      │
│     │  │ GPT-4o   │ │ V3/R1    │ │ GLM-4/4-Plus     │  │      │
│     │  └──────────┘ └──────────┘ └──────────────────┘  │      │
│     │  ┌──────────┐ ┌──────────┐ ┌──────────────────┐  │      │
│     │  │ 通义千问  │ │ 百川     │ │ Moonshot          │  │      │
│     │  │ Qwen     │ │ Baichuan │ │ Kimi              │  │      │
│     │  └──────────┘ └──────────┘ └──────────────────┘  │      │
│     │  ┌──────────┐ ┌──────────┐ ┌──────────────────┐  │      │
│     │  │ Ollama   │ │ LM Studio│ │ vLLM / TGI       │  │      │
│     │  │ 本地模型  │ │ 本地模型  │ │ 自部署           │  │      │
│     │  └──────────┘ └──────────┘ └──────────────────┘  │      │
│     └──────────────────────────────────────────────────┘      │
│           │                    │                              │
│     ┌─────▼──────────┐  ┌─────▼──────────┐                   │
│     │ Anthropic       │  │ Google Gemini   │                   │
│     │ (feature flag)  │  │ (feature flag)  │                   │
│     │ Claude 系列     │  │ Gemini 系列      │                   │
│     └─────────────────┘  └─────────────────┘                   │
│                                                                │
│  ┌─────────────────────────────────────────────────────┐      │
│  │           Token & Cost Layer                         │      │
│  │  TokenBudgetTree │ CostTracker │ BudgetAlert         │      │
│  └─────────────────────────────────────────────────────┘      │
└──────────────────────────────────────────────────────────────┘
```

**设计原则**：

1. **OpenAI 兼容协议优先**：DeepSeek、智谱、通义、百川、Moonshot、Ollama、LM Studio、vLLM 等均兼容 OpenAI API 格式，用统一的 `OpenAiCompatibleProvider` 覆盖，避免为每个 Provider 写适配层
2. **非兼容 Provider 可选编译**：Anthropic（Messages API 格式不同）、Google Gemini 用 feature flag 单独实现
3. **渐进精确**：事前粗略估算，事后从 API 返回值校准，可选精确计数
4. **树状 Token 预算**：父 Agent 持有总预算，子 Agent 获得独立预算（独立构建上下文窗口），预算按任务分配而非按比例切分
5. **双层缓存**：稳定前缀依赖 Provider Prompt Caching；语义相近的重复查询依赖应用侧语义缓存中间件

---

### 14.2 Provider Trait 抽象

#### 14.2.1 核心 Trait 定义

```rust
use async_trait::async_trait;
use futures::stream::BoxStream;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// LLM Provider 统一抽象
#[async_trait]
pub trait LlmProvider: Send + Sync {
    /// 返回 Provider 标识
    fn provider_id(&self) -> &str;

    /// 返回当前使用的模型信息
    fn model_info(&self) -> &ModelInfo;

    /// 同步聊天请求（非流式）
    async fn chat(&self, request: ChatRequest) -> Result<ChatResponse, LlmError>;

    /// 流式聊天请求
    async fn chat_stream(
        &self,
        request: ChatRequest,
    ) -> Result<BoxStream<Result<StreamEvent, LlmError>>, LlmError>;

    /// 返回该 Provider 的缓存能力
    fn cache_capability(&self) -> CacheCapability;

    /// 列出可用模型
    async fn list_models(&self) -> Result<Vec<ModelInfo>, LlmError>;

    /// 取消正在进行的请求
    async fn cancel_request(&self, request_id: &str) -> Result<(), LlmError>;

    /// 预估 token 数量
    fn estimate_tokens(&self, messages: &[LlmMessage]) -> usize;
}
```

#### 14.2.1.1 可选语义缓存中间件

`LlmProvider` Trait 保持“纯 Provider 抽象”，不把语义缓存硬编码进每个后端；语义缓存放在其上的可选中间件层。这样可以在不污染 Provider 实现的前提下，只为 Explorer / Research 这类高重复、低副作用查询启用缓存。

```rust
/// 应用侧语义缓存配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SemanticCacheConfig {
    /// 是否启用
    pub enabled: bool,
    /// 仅对这些 Agent 启用
    pub enabled_agents: Vec<AgentType>,
    /// 余弦相似度阈值（默认 0.90）
    pub cosine_threshold: f32,
    /// 结果 TTL（秒）
    pub ttl_seconds: u64,
    /// 最大可缓存响应长度；超长响应交给 Prompt 缓存和记忆系统处理
    pub max_response_chars: usize,
    /// 🆕 污染检测：同一 key 连续未命中次数超过此值时触发告警（默认 3）
    pub pollution_miss_threshold: u32,
    /// 🆕 污染检测：缓存命中率低于此值时自动禁用该 namespace（默认 0.30）
    pub min_hit_rate: f32,
    /// 🆕 是否对代码生成类查询完全禁用语义缓存（默认 true）
    pub disable_for_code_generation: bool,
}

impl Default for SemanticCacheConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            enabled_agents: vec![AgentType::Explorer, AgentType::Research],
            cosine_threshold: 0.90,
            ttl_seconds: 3600,
            max_response_chars: 12_000,
            pollution_miss_threshold: 3,
            min_hit_rate: 0.30,
            disable_for_code_generation: true,
        }
    }
}

/// 语义缓存命名空间
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct SemanticCacheNamespace {
    pub agent_type: AgentType,
    pub provider_model: String,
    pub repo_fingerprint: String, // git commit / project hash / memory version
}

/// 可缓存查询
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SemanticQuery {
    pub namespace: SemanticCacheNamespace,
    pub normalized_prompt: String,
}

/// 语义缓存条目
///
/// **内存优化方向**：当前存储完整的 `ChatResponse`，大响应（如长代码生成）
/// 会浪费内存。建议：
/// - 添加基于内存的 LRU 淘汰策略（限制缓存总大小，如 100MB）
/// - 仅缓存响应文本，不缓存 tool_calls 等非文本内容
/// - 设置单条缓存最大大小（如 10KB）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SemanticCacheEntry {
    pub query: SemanticQuery,
    pub response: ChatResponse,
    pub similarity: f32,
    pub created_at: i64,
    pub expires_at: i64,
}

#[async_trait]
pub trait SemanticCacheStore: Send + Sync {
    async fn lookup(
        &self,
        query: &SemanticQuery,
        threshold: f32,
    ) -> anyhow::Result<Option<SemanticCacheEntry>>;

    async fn insert(&self, entry: SemanticCacheEntry) -> anyhow::Result<()>;
}
```

> **适用边界**：语义缓存默认只用于 Explorer / Research 的只读查询，不用于代码生成、测试执行、工具调用编排或任何可能产生副作用的请求。

#### 14.2.2 请求与响应数据结构

```rust
/// 聊天请求
#[derive(Debug, Clone, Serialize)]
pub struct ChatRequest {
    pub model: String,
    pub messages: Vec<ChatMessage>,
    pub temperature: Option<f32>,
    pub max_tokens: Option<u32>,
    pub stop: Option<Vec<String>>,
    pub tools: Option<Vec<ToolDefinition>>,
    pub response_format: Option<ResponseFormat>,
    /// Prompt 缓存控制点（与第 15 章联动）
    pub cache_control: Vec<CacheControlPoint>,
}

/// 聊天消息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatMessage {
    pub role: MessageRole,
    pub content: MessageContent,
    pub name: Option<String>,
    pub cache_control: Option<CacheControlPoint>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum MessageRole {
    System,
    User,
    Assistant,
    Tool,
}

/// 多模态消息内容
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum MessageContent {
    Text(String),
    /// 多部分内容（文本 + 图片 + 音频混合）
    Parts(Vec<ContentPart>),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ContentPart {
    Text { text: String },
    Image {
        source: ImageSource,
        media_type: String,
        detail: ImageDetail,
    },
    Audio {
        data: String,       // base64
        format: AudioFormat,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ImageSource {
    Base64(String),
    Url(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ImageDetail {
    Auto,
    Low,
    High,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AudioFormat {
    Wav,
    Mp3,
    Pcm,
}

/// 聊天响应
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatResponse {
    pub id: String,
    pub model: String,
    pub choices: Vec<ChatChoice>,
    pub usage: TokenUsage,
    pub cached_tokens: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatChoice {
    pub index: usize,
    pub message: ChatMessage,
    pub finish_reason: FinishReason,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum FinishReason {
    Stop,
    Length,
    ToolCalls,
    ContentFilter,
}

/// Token 使用量
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct TokenUsage {
    pub prompt_tokens: u64,
    pub completion_tokens: u64,
    pub total_tokens: u64,
}

/// 流式事件
#[derive(Debug, Clone, Deserialize)]
pub enum StreamEvent {
    /// 内容增量（文本片段）
    Delta { delta: ChatMessage, finish_reason: Option<FinishReason> },
    /// Token 使用量（流结束时发送）
    Usage(TokenUsage),
    /// 错误
    Error(String),
}

/// 流式转发器 — 将 LLM 流式事件转换为 AgentEvent 推送到 EventBus
///
/// **设计**：每个 Agent 持有一个 StreamForwarder，在调用 `chat_stream` 时
/// 通过闭包实时将 StreamEvent 转换为 AgentEvent::LlmStreamDelta 推送到 UI。
pub struct StreamForwarder {
    agent_id: String,
    event_bus: Arc<dyn EventBus>,
    buffer: String,
    tool_call_buffer: String,
}

impl StreamForwarder {
    pub fn new(agent_id: String, event_bus: Arc<dyn EventBus>) -> Self {
        Self {
            agent_id,
            event_bus,
            buffer: String::new(),
            tool_call_buffer: String::new(),
        }
    }

    /// 处理一个流式事件，返回是否应该继续
    pub fn on_event(&mut self, event: &StreamEvent) -> bool {
        match event {
            StreamEvent::Delta { delta, finish_reason } => {
                if let Some(content) = &delta.content {
                    let is_last = finish_reason.is_some();
                    self.event_bus.emit(AgentEvent::LlmStreamDelta {
                        agent_id: self.agent_id.clone(),
                        content: content.clone(),
                        is_last,
                    });
                    self.buffer.push_str(content);
                }
                // 工具调用参数流式推送
                if let Some(tool_calls) = &delta.tool_calls {
                    for tc in tool_calls {
                        if let Some(args) = &tc.function.arguments {
                            self.event_bus.emit(AgentEvent::LlmStreamToolCall {
                                agent_id: self.agent_id.clone(),
                                tool_name: tc.function.name.clone(),
                                arguments_json: args.clone(),
                            });
                        }
                    }
                }
                finish_reason.is_none() // 继续接收
            }
            StreamEvent::Usage(usage) => {
                self.event_bus.emit(AgentEvent::TokenUsage {
                    agent_id: self.agent_id.clone(),
                    input: usage.prompt_tokens,
                    output: usage.completion_tokens,
                    cost_usd: 0.0, // 由上层根据模型定价计算
                });
                true
            }
            StreamEvent::Error(err) => {
                tracing::error!(agent_id = %self.agent_id, error = %err, "LLM 流式错误");
                false
            }
        }
    }

    /// 获取完整累积内容
    pub fn into_content(self) -> String {
        self.buffer
    }
}

/// EventBus trait（由 UI 层实现）
#[async_trait]
pub trait EventBus: Send + Sync {
    /// 发送事件到 UI 层
    fn emit(&self, event: AgentEvent);
}

/// 缓存控制点（与第 15 章 Prompt 缓存策略联动）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheControlPoint {
    pub type_: CacheControlType,
    pub breakpoint: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CacheControlType {
    /// Anthropic 风格：ephemeral
    Ephemeral,
    /// OpenAI 风格：auto / explicit
    OpenAiCache { strategy: OpenAiCacheStrategy },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum OpenAiCacheStrategy {
    Auto,
    Explicit,
}

/// 模型信息
#[derive(Debug, Clone)]
pub struct ModelInfo {
    pub model_id: String,
    pub display_name: String,
    pub max_context_tokens: u32,
    pub max_output_tokens: u32,
    pub supports_vision: bool,
    pub supports_audio: bool,
    pub supports_tools: bool,
    pub supports_streaming: bool,
    pub input_cost_per_million: f64,
    pub output_cost_per_million: f64,
}

/// 工具定义
#[derive(Debug, Clone, Serialize)]
pub struct ToolDefinition {
    pub name: String,
    pub description: String,
    pub parameters: serde_json::Value,
}

/// 响应格式
#[derive(Debug, Clone, Serialize)]
pub enum ResponseFormat {
    Text,
    Json,
    JsonSchema(serde_json::Value),
}

/// LLM 错误类型
#[derive(Debug, thiserror::Error)]
pub enum LlmError {
    #[error("API request failed: {0}")]
    ApiError(String),

    #[error("Rate limited, retry after {retry_after_ms}ms")]
    RateLimited { retry_after_ms: u64 },

    #[error("Context length exceeded: prompt={prompt_tokens}, limit={limit}")]
    ContextOverflow { prompt_tokens: u64, limit: u64 },

    #[error("Model not found: {0}")]
    ModelNotFound(String),

    #[error("Authentication failed for provider '{provider}'")]
    AuthFailed { provider: String },

    #[error("Stream error: {0}")]
    StreamError(String),

    #[error("{0}")]
    Internal(String),
}
```

#### 14.2.3 缓存能力声明

```rust
/// Provider 的 Prompt Caching 能力
#[derive(Debug, Clone)]
pub struct CacheCapability {
    /// 是否支持显式缓存控制
    pub explicit_cache: bool,
    /// 缓存 TTL（秒），None 表示由 Provider 自行管理
    pub cache_ttl: Option<u64>,
    /// 缓存命中的折扣比例（0.0 ~ 1.0）
    pub cache_discount: f64,
    /// 触发缓存的最小前缀 Token 数
    pub min_prefix_tokens: u32,
    /// 最大可缓存 Token 数
    pub max_cacheable_tokens: Option<u32>,
    /// 缓存策略说明
    pub strategy_description: &'static str,
}

impl CacheCapability {
    /// 无缓存能力
    pub fn none() -> Self {
        Self {
            explicit_cache: false,
            cache_ttl: None,
            cache_discount: 0.0,
            min_prefix_tokens: 0,
            max_cacheable_tokens: None,
            strategy_description: "This provider does not support prompt caching",
        }
    }

    /// 根据 Token 数判断是否值得缓存
    pub fn is_worth_caching(&self, token_count: u32) -> bool {
        if !self.explicit_cache {
            return false;
        }
        token_count as u32 >= self.min_prefix_tokens
    }
}
```

#### 14.2.4 语义缓存中间件流程

```rust
pub struct SemanticCacheMiddleware<P> {
    inner: P,
    cache: Arc<dyn SemanticCacheStore>,
    config: SemanticCacheConfig,
    /// 污染检测：各 namespace 的连续未命中计数
    miss_counters: Arc<DashMap<String, u32>>,
    /// 污染检测：各 namespace 的命中/总查询统计
    hit_stats: Arc<DashMap<String, (u64, u64)>>,
}

impl<P: LlmProvider> SemanticCacheMiddleware<P> {
    /// 清理过期的污染检测统计（建议在 repo_fingerprint 变更时调用）
    ///
    /// **内存管理**：`hit_stats` 和 `miss_counters` 随 namespace 增加无限增长。
    /// Daemon 模式运行数天后可能积累数千条目。
    ///
    /// **缓解措施**：
    /// - 添加 TTL 过期机制（建议 1 小时）
    /// - 设置最大容量上限（建议 1000 个 namespace）
    /// - repo_fingerprint 变更时主动清除所有统计
    pub fn cleanup_stale_stats(&self, max_age_secs: u64, max_entries: usize) {
        let now = chrono::Utc::now().timestamp();
        // 清理超过 max_age_secs 的条目
        self.hit_stats.retain(|_, (created_at, _)| {
            now - created_at < max_age_secs as i64
        });
        // 如果仍超过最大容量，按 LRU 策略清理最旧的条目
        if self.hit_stats.len() > max_entries {
            let mut entries: Vec<_> = self.hit_stats.iter()
                .map(|e| (*e.key(), *e.value()))
                .collect();
            entries.sort_by_key(|(_, (_, created))| *created);
            for (key, _) in entries.iter().take(self.hit_stats.len() - max_entries) {
                self.hit_stats.remove(key);
                self.miss_counters.remove(key);
            }
        }
    }

    pub async fn chat_with_cache(
        &self,
        agent_type: AgentType,
        repo_fingerprint: &str,
        request: ChatRequest,
    ) -> Result<ChatResponse, LlmError> {
        let semantic_cache_enabled =
            self.config.enabled && self.config.enabled_agents.contains(&agent_type);
        let request_is_cacheable =
            request.tools.is_none() && request.response_format.is_none();

        if semantic_cache_enabled && request_is_cacheable {
            let query = SemanticQuery {
                namespace: SemanticCacheNamespace {
                    agent_type,
                    provider_model: request.model.clone(),
                    repo_fingerprint: repo_fingerprint.to_string(),
                },
                normalized_prompt: normalize_messages(&request.messages),
            };

            if let Some(hit) = self
                .cache
                .lookup(&query, self.config.cosine_threshold)
                .await
                .map_err(|e| LlmError::Internal(e.to_string()))?
            {
                return Ok(hit.response);
            }

            let response = self.inner.chat(request.clone()).await?;

            // 只缓存无工具调用、纯文本、长度可控的响应
            if is_semantic_cacheable_response(&response, self.config.max_response_chars) {
                let _ = self.cache.insert(SemanticCacheEntry {
                    query,
                    response: response.clone(),
                    similarity: 1.0,
                    created_at: chrono::Utc::now().timestamp(),
                    expires_at: chrono::Utc::now().timestamp() + self.config.ttl_seconds as i64,
                }).await;
            }

            return Ok(response);
        }

        self.inner.chat(request).await
    }
}
```

**命中策略建议：**

- 先走应用侧 exact key / prompt hash 命中，再做 embedding 相似度查找
- 余弦相似度默认阈值设为 `0.90`，但应按 embedding 模型与向量库召回特性校准
- 命名空间至少绑定 `agent_type + provider_model + repo_fingerprint`
- 仓库发生代码变化、分支切换或项目记忆失效时，应整体失效对应 namespace

#### 🆕 P1-6: 缓存污染检测机制

语义缓存可能因代码变更导致"旧答案匹配新问题"，形成缓存污染。新增以下检测与自愈机制：

```rust
impl<P: LlmProvider> SemanticCacheMiddleware<P> {
    /// 检查 namespace 是否因命中率过低被自动禁用
    fn is_namespace_disabled(&self, ns_key: &str) -> bool {
        if let Some((hits, total)) = self.hit_stats.get(ns_key) {
            if *total >= 10 { // 至少 10 次查询后才评估
                let hit_rate = *hits as f64 / *total as f64;
                return hit_rate < self.config.min_hit_rate as f64;
            }
        }
        false
    }

    /// 记录命中/未命中并检查污染告警
    fn record_cache_result(&self, ns_key: &str, hit: bool) {
        // 更新命中率统计
        self.hit_stats.entry(ns_key.to_string())
            .and_modify(|(hits, total)| {
                *total += 1;
                if hit { *hits += 1; }
            })
            .or_insert((if hit { 1 } else { 0 }, 1));

        // 更新连续未命中计数
        if hit {
            self.miss_counters.insert(ns_key.to_string(), 0);
        } else {
            self.miss_counters.entry(ns_key.to_string())
                .and_modify(|count| *count += 1)
                .or_insert(1);

            if let Some(count) = self.miss_counters.get(ns_key) {
                if *count >= self.config.pollution_miss_threshold {
                    tracing::warn!(
                        namespace = ns_key,
                        consecutive_misses = *count,
                        "语义缓存可能已污染：连续多次未命中，建议清除该 namespace"
                    );
                }
            }
        }
    }
}
```

**污染自愈策略：**
1. **被动检测**：连续 3 次未命中 → 告警日志
2. **主动禁用**：命中率 < 30%（至少 10 次查询）→ 自动跳过该 namespace 的缓存查询
3. **代码变更触发**：Git commit 后自动失效对应 `repo_fingerprint` 的全部缓存
4. **代码生成类查询**：默认完全禁用语义缓存（`disable_for_code_generation: true`）

#### 14.2.5 后端实现

```rust
// ============================================================
// OpenAI Compatible Provider — 统一协议层
// 覆盖：OpenAI / DeepSeek / 智谱 GLM / 通义千问 / 百川 / Moonshot
//       / Ollama / LM Studio / vLLM / TGI / 任何 OpenAI 兼容 API
// ============================================================

/// OpenAI 兼容 Provider 的已知配置预设
#[derive(Debug, Clone, serde::Deserialize)]
pub struct CompatibleProviderPreset {
    /// Provider 显示名称
    pub display_name: String,
    /// 默认 API Base URL
    pub default_base_url: &'static str,
    /// 默认模型 ID
    pub default_model: &'static str,
    /// 默认上下文窗口大小
    pub default_context_tokens: u32,
    /// 默认最大输出 Token
    pub default_max_output_tokens: u32,
    /// 定价（输入 / 输出，每百万 Token）
    pub default_pricing: (f64, f64),
    /// 是否支持 Prompt Caching
    pub supports_caching: bool,
}

/// 预设注册表：一行配置即可接入新 Provider
pub fn builtin_presets() -> Vec<(&'static str, CompatibleProviderPreset)> {
    vec![
        ("openai", CompatibleProviderPreset {
            display_name: "OpenAI".into(),
            default_base_url: "https://api.openai.com/v1",
            default_model: "gpt-4o",
            default_context_tokens: 128_000,
            default_max_output_tokens: 16_384,
            default_pricing: (5.0, 15.0),
            supports_caching: true,
        }),
        ("deepseek", CompatibleProviderPreset {
            display_name: "DeepSeek".into(),
            default_base_url: "https://api.deepseek.com/v1",
            default_model: "deepseek-chat",
            default_context_tokens: 64_000,
            default_max_output_tokens: 8_192,
            default_pricing: (0.27, 1.10),  // DeepSeek V3 定价
            supports_caching: false,
        }),
        ("zhipu", CompatibleProviderPreset {
            display_name: "智谱 GLM".into(),
            default_base_url: "https://open.bigmodel.cn/api/paas/v4",
            default_model: "glm-4-plus",
            default_context_tokens: 128_000,
            default_max_output_tokens: 4_096,
            default_pricing: (50.0, 50.0),   // 智谱定价（元/百万Token）
            supports_caching: false,
        }),
        ("qwen", CompatibleProviderPreset {
            display_name: "通义千问".into(),
            default_base_url: "https://dashscope.aliyuncs.com/compatible-mode/v1",
            default_model: "qwen-max",
            default_context_tokens: 128_000,
            default_max_output_tokens: 8_192,
            default_pricing: (20.0, 60.0),   // 通义定价（元/百万Token）
            supports_caching: false,
        }),
        ("moonshot", CompatibleProviderPreset {
            display_name: "Moonshot".into(),
            default_base_url: "https://api.moonshot.cn/v1",
            default_model: "moonshot-v1-128k",
            default_context_tokens: 128_000,
            default_max_output_tokens: 4_096,
            default_pricing: (12.0, 12.0),   // Moonshot 定价（元/百万Token）
            supports_caching: false,
        }),
        ("ollama", CompatibleProviderPreset {
            display_name: "Ollama (本地)".into(),
            default_base_url: "http://localhost:11434/v1",
            default_model: "qwen2.5:32b",
            default_context_tokens: 32_000,
            default_max_output_tokens: 4_096,
            default_pricing: (0.0, 0.0),      // 本地免费
            supports_caching: false,
        }),
        ("lmstudio", CompatibleProviderPreset {
            display_name: "LM Studio (本地)".into(),
            default_base_url: "http://localhost:1234/v1",
            default_model: "local-model",
            default_context_tokens: 32_000,
            default_max_output_tokens: 4_096,
            default_pricing: (0.0, 0.0),
            supports_caching: false,
        }),
    ]
}

pub struct OpenAiCompatibleProvider {
    client: reqwest::Client,
    config: CompatibleProviderConfig,
    model_info: ModelInfo,
    cache_capability: CacheCapability,
}

#[derive(Debug, Clone, serde::Deserialize)]
pub struct CompatibleProviderConfig {
    /// Provider 预设名称（如 "deepseek"、"zhipu"），或 "custom" 自定义
    pub preset: String,
    /// API Key（本地模型可省略）
    pub api_key: Option<String>,
    /// API Base URL（覆盖预设默认值）
    pub base_url: Option<String>,
    /// 使用的模型 ID（覆盖预设默认值）
    pub model: Option<String>,
    /// 上下文窗口大小（覆盖预设默认值）
    pub context_tokens: Option<u32>,
    /// 最大输出 Token（覆盖预设默认值）
    pub max_output_tokens: Option<u32>,
    /// 自定义定价（输入/输出，每百万 Token，覆盖预设默认值）
    pub custom_pricing: Option<(f64, f64)>,
    pub timeout_ms: u64,
    pub max_retries: u32,
}

impl OpenAiCompatibleProvider {
    /// 从预设名称创建 Provider
    pub fn from_preset(preset_name: &str, api_key: Option<String>) -> Result<Self, LlmError> {
        let presets = builtin_presets();
        let preset = presets.iter()
            .find(|(name, _)| *name == preset_name)
            .ok_or_else(|| LlmError::ModelNotFound(format!("Unknown preset: {}", preset_name)))?
            .1;

        let config = CompatibleProviderConfig {
            preset: preset_name.to_string(),
            api_key,
            base_url: None,
            model: None,
            context_tokens: None,
            max_output_tokens: None,
            custom_pricing: None,
            timeout_ms: 60_000,
            max_retries: 3,
        };

        Self::new(config, preset)
    }

    /// 从完整配置创建 Provider（支持自定义覆盖）
    pub fn new(
        config: CompatibleProviderConfig,
        preset: &CompatibleProviderPreset,
    ) -> Result<Self, LlmError> {
        let base_url = config.base_url
            .as_deref()
            .unwrap_or(preset.default_base_url)
            .to_string();
        let model = config.model
            .as_deref()
            .unwrap_or(preset.default_model)
            .to_string();
        let context_tokens = config.context_tokens
            .unwrap_or(preset.default_context_tokens);
        let max_output = config.max_output_tokens
            .unwrap_or(preset.default_max_output_tokens);
        let pricing = config.custom_pricing
            .unwrap_or(preset.default_pricing);

        let cache_capability = if preset.supports_caching {
            CacheCapability {
                explicit_cache: true,
                cache_ttl: Some(300),
                cache_discount: 0.5,
                min_prefix_tokens: 1024,
                max_cacheable_tokens: Some(context_tokens),
                strategy_description: "OpenAI-compatible automatic caching",
            }
        } else {
            CacheCapability::none()
        };

        let model_info = ModelInfo {
            model_id: model.clone(),
            display_name: format!("{} ({})", preset.display_name, model),
            max_context_tokens: context_tokens,
            max_output_tokens: max_output,
            supports_vision: true,
            supports_audio: false,
            supports_tools: true,
            supports_streaming: true,
            input_cost_per_million: pricing.0,
            output_cost_per_million: pricing.1,
        };

        Ok(Self {
            client: reqwest::Client::new(),
            config,
            model_info,
            cache_capability,
        })
    }
}

#[async_trait]
impl LlmProvider for OpenAiCompatibleProvider {
    fn provider_id(&self) -> &str {
        &self.config.preset
    }

    fn model_info(&self) -> &ModelInfo {
        &self.model_info
    }

    async fn chat(&self, request: ChatRequest) -> Result<ChatResponse, LlmError> {
        // 统一 OpenAI 兼容 API 调用
        // POST {base_url}/chat/completions
        // 所有兼容 Provider 使用相同的请求/响应格式
        Err(LlmError::Internal("TODO: OpenAI Compatible API 调用待实现".into()))
    }

    async fn chat_stream(
        &self,
        request: ChatRequest,
    ) -> Result<BoxStream<Result<StreamEvent, LlmError>>, LlmError> {
        // SSE 流式响应（OpenAI 兼容格式）
        Err(LlmError::Internal("TODO: OpenAI Compatible SSE 流待实现".into()))
    }

    fn cache_capability(&self) -> CacheCapability {
        self.cache_capability.clone()
    }

    async fn list_models(&self) -> Result<Vec<ModelInfo>, LlmError> {
        // GET {base_url}/models
        Err(LlmError::Internal("TODO: OpenAI Compatible GET /models 待实现".into()))
    }
}

// ============================================================
// Anthropic Provider — Feature Flag 控制
// ============================================================

#[cfg(feature = "anthropic")]
pub struct AnthropicProvider {
    client: reqwest::Client,
    config: AnthropicConfig,
    model_info: ModelInfo,
    cache_capability: CacheCapability,
}

#[cfg(feature = "anthropic")]
#[derive(Debug, Clone, serde::Deserialize)]
pub struct AnthropicConfig {
    pub api_key: String,
    pub base_url: String,           // 默认 https://api.anthropic.com
    pub default_model: String,
    pub timeout_ms: u64,
    pub max_retries: u32,
    pub anthropic_version: String,  // "2023-06-01"
}

#[cfg(feature = "anthropic")]
impl AnthropicProvider {
    pub fn new(config: AnthropicConfig) -> Result<Self, LlmError> {
        let cache_capability = CacheCapability {
            explicit_cache: true,
            cache_ttl: Some(300),              // 5 分钟
            cache_discount: 0.9,               // 90% 折扣
            min_prefix_tokens: 1024,
            max_cacheable_tokens: Some(200_000),
            strategy_description: "Explicit cache_control breakpoints; 90% discount on cache hits; \
                                   25% surcharge on cache writes",
        };

        let model_info = ModelInfo {
            model_id: config.default_model.clone(),
            display_name: config.default_model.clone(),
            max_context_tokens: 200_000,
            max_output_tokens: 8_192,
            supports_vision: true,
            supports_audio: false,
            supports_tools: true,
            supports_streaming: true,
            input_cost_per_million: 3.0,
            output_cost_per_million: 15.0,
        };

        Ok(Self {
            client: reqwest::Client::new(),
            config,
            model_info,
            cache_capability,
        })
    }
}

#[cfg(feature = "anthropic")]
#[async_trait]
impl LlmProvider for AnthropicProvider {
    fn provider_id(&self) -> &str {
        "anthropic"
    }

    fn model_info(&self) -> &ModelInfo {
        &self.model_info
    }

    async fn chat(&self, request: ChatRequest) -> Result<ChatResponse, LlmError> {
        // 转换 ChatRequest 为 Anthropic Messages API 格式
        // 处理 cache_control → cache_control 字段映射
        Err(LlmError::Internal("TODO: Anthropic Messages API 调用待实现".into()))
    }

    async fn chat_stream(
        &self,
        request: ChatRequest,
    ) -> Result<BoxStream<Result<StreamEvent, LlmError>>, LlmError> {
        // Anthropic SSE 流处理
        Err(LlmError::Internal("TODO: Anthropic SSE 流待实现".into()))
    }

    fn cache_capability(&self) -> CacheCapability {
        self.cache_capability.clone()
    }

    async fn list_models(&self) -> Result<Vec<ModelInfo>, LlmError> {
        Err(LlmError::Internal("TODO: Anthropic 模型列表待实现".into()))
    }
}

// ============================================================
// Mock Provider — 测试用
// ============================================================

pub struct MockProvider {
    model_info: ModelInfo,
    responses: std::sync::Mutex<Vec<ChatResponse>>,
    call_count: std::sync::atomic::AtomicU64,
}

impl MockProvider {
    pub fn new(model_id: &str) -> Self {
        let model_info = ModelInfo {
            model_id: model_id.to_string(),
            display_name: format!("Mock ({})", model_id),
            max_context_tokens: 128_000,
            max_output_tokens: 4_096,
            supports_vision: false,
            supports_audio: false,
            supports_tools: true,
            supports_streaming: true,
            input_cost_per_million: 0.0,
            output_cost_per_million: 0.0,
        };

        Self {
            model_info,
            responses: std::sync::Mutex::new(Vec::new()),
            call_count: std::sync::atomic::AtomicU64::new(0),
        }
    }

    /// 预设响应队列
    pub fn enqueue_response(&self, response: ChatResponse) {
        self.responses.lock().unwrap().push(response);
    }
}

#[async_trait]
impl LlmProvider for MockProvider {
    fn provider_id(&self) -> &str {
        "mock"
    }

    fn model_info(&self) -> &ModelInfo {
        &self.model_info
    }

    async fn chat(&self, _request: ChatRequest) -> Result<ChatResponse, LlmError> {
        self.call_count.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let mut responses = self.responses.lock().unwrap();
        responses.pop().ok_or_else(|| LlmError::Internal("No mock response queued".into()))
    }

    async fn chat_stream(
        &self,
        _request: ChatRequest,
    ) -> Result<BoxStream<Result<StreamEvent, LlmError>>, LlmError> {
        self.call_count.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        // 返回一个包含预设响应的模拟流
        Err(LlmError::Internal("TODO: Mock 流待实现".into()))
    }

    fn cache_capability(&self) -> CacheCapability {
        CacheCapability::none()
    }

    async fn list_models(&self) -> Result<Vec<ModelInfo>, LlmError> {
        Ok(vec![self.model_info.clone()])
    }
}
```

---

### 14.3 Token 计数方案

#### 14.3.1 整体架构

```
┌──────────────────────────────────────────────────┐
│                  TokenCounter                     │
│                                                   │
│  ┌─────────────┐    ┌─────────────────────────┐  │
│  │  estimator   │    │  actual_usage            │  │
│  │  (事前估算)  │    │  (事后校准)              │  │
│  │              │    │  AtomicU64               │  │
│  │  BytesPer4   │    │                          │  │
│  │  CharsPer3   │    │  从 API 响应的           │  │
│  │  Tiktoken    │    │  TokenUsage 更新          │  │
│  │  (riptoken)  │    │                          │  │
│  └──────┬──────┘    └──────────┬──────────────┘  │
│         │                      │                  │
│         ▼                      ▼                  │
│  ┌────────────────────────────────────────────┐  │
│  │  estimate(text) → u64                      │  │
│  │  calibrate(estimated, actual) → f64        │  │
│  │  calibrated_estimate(text) → u64           │  │
│  └────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
```

#### 14.3.2 代码定义

```rust
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

/// Token 估算策略
#[derive(Debug, Clone, Copy)]
pub enum TokenEstimator {
    /// 每 3 个字符约 1 个 Token（英文主导场景）
    CharsPer3,
    /// 每 4 字节约 1 个 Token（UTF-8 友好，默认）
    BytesPer4,
    /// 使用 tiktoken 精确计数
    Tiktoken,
}

impl Default for TokenEstimator {
    fn default() -> Self {
        Self::BytesPer4
    }
}

impl TokenEstimator {
    /// 估算文本的 Token 数
    pub fn estimate(&self, text: &str) -> u64 {
        match self {
            Self::CharsPer3 => {
                let chars = text.chars().count() as u64;
                (chars + 2) / 3
            }
            Self::BytesPer4 => {
                let bytes = text.len() as u64;
                (bytes + 3) / 4
            }
            Self::Tiktoken => {
                #[cfg(feature = "riptoken")]
                {
                    riptoken::count_tokens(text)
                }
                #[cfg(not(feature = "riptoken"))]
                {
                    // 降级为 BytesPer4
                    let bytes = text.len() as u64;
                    (bytes + 3) / 4
                }
            }
        }
    }
}

/// Token 计数器：事前估算 + 事后校准
pub struct TokenCounter {
    estimator: TokenEstimator,
    /// 累计实际使用 Token 数
    actual_usage: AtomicU64,
    /// 估算偏差系数（用于后续校准）
    calibration_factor: AtomicU64, // 存储 (factor * 1000) 作为定点数
    /// 累计校准次数
    calibration_count: AtomicU64,
}

impl TokenCounter {
    pub fn new(estimator: TokenEstimator) -> Self {
        Self {
            estimator,
            actual_usage: AtomicU64::new(0),
            calibration_factor: AtomicU64::new(1000), // 初始 1.0
            calibration_count: AtomicU64::new(0),
        }
    }

    /// 事前估算
    pub fn estimate(&self, text: &str) -> u64 {
        self.estimator.estimate(text)
    }

    /// 估算一组消息的总 Token 数
    pub fn estimate_messages(&self, messages: &[ChatMessage]) -> u64 {
        let mut total = 0u64;
        for msg in messages {
            match &msg.content {
                MessageContent::Text(text) => {
                    total += self.estimate(text);
                }
                MessageContent::Parts(parts) => {
                    for part in parts {
                        if let ContentPart::Text { text, .. } = part {
                            total += self.estimate(text);
                        }
                        // 多模态部分单独计算（见 25.4）
                    }
                }
            }
        }
        // 消息格式开销（role、分隔符等）
        total += messages.len() as u64 * 4;
        total
    }

    /// 事后校准：用 API 返回的实际值修正估算偏差
    ///
    /// **并发安全**：使用 AcqRel 内存序确保校准操作的原子性，
    /// 避免 Relaxed 下的重排序导致校准因子不一致。
    pub fn calibrate(&self, estimated: u64, actual: u64) {
        if estimated > 0 {
            let new_factor = (actual as f64 / estimated as f64 * 1000.0) as u64;
            let count = self.calibration_count.fetch_add(1, Ordering::AcqRel) + 1;

            // 指数移动平均，平滑校准
            let old_factor = self.calibration_factor.load(Ordering::Acquire);
            let alpha = 1.0 / (count as f64 + 1.0);
            let smoothed = (old_factor as f64) * (1.0 - alpha) + (new_factor as f64) * alpha;
            self.calibration_factor.store(smoothed as u64, Ordering::Release);
        }

        self.actual_usage.fetch_add(actual, Ordering::AcqRel);
    }

    /// 使用校准系数进行估算
    pub fn calibrated_estimate(&self, text: &str) -> u64 {
        let raw = self.estimate(text);
        let factor = self.calibration_factor.load(Ordering::Relaxed) as f64 / 1000.0;
        (raw as f64 * factor) as u64
    }

    /// 获取累计实际 Token 使用量
    pub fn actual_usage(&self) -> u64 {
        self.actual_usage.load(Ordering::Relaxed)
    }

    /// 重置计数器
    pub fn reset(&self) {
        self.actual_usage.store(0, Ordering::Relaxed);
        self.calibration_count.store(0, Ordering::Relaxed);
        self.calibration_factor.store(1000, Ordering::Relaxed);
    }
}

/// 共享 Token 计数器
pub type SharedTokenCounter = Arc<TokenCounter>;
```

#### 14.3.3 估算策略选择

| 策略 | 精度 | 性能 | 依赖 | 适用场景 |
|------|------|------|------|----------|
| `CharsPer3` | 低（英文 ~70%） | 最快 | 无 | 纯英文快速估算 |
| `BytesPer4` | 中（中英文 ~75-85%） | 快 | 无 | **默认选择**，UTF-8 友好 |
| `Tiktoken` | 高（~98%） | 中 | `riptoken` crate | 需要精确计数的场景 |

**选择 `BytesPer4` 作为默认的理由**：

- UTF-8 编码下，中文字符占 3 字节，英文占 1 字节，BytesPer4 能较好地平衡两者
- 零外部依赖，编译快
- 事后校准机制弥补精度不足

---

### 14.4 树状 Token 预算模型

#### 14.4.1 核心问题

MoreCode 采用递归编排模式（第 17 章），子 Agent 是**全新独立上下文** + 上级 Agent 下发的任务描述和文件引用。这意味着：

- ❌ **错误模型**：子 Agent 从父 Agent 的 token 预算中"切分"一部分——这没有意义，因为子 Agent 有自己独立的上下文窗口
- ✅ **正确模型**：每个 Agent（无论父子）都有独立的 token 预算，父 Agent 负责**分配预算额度**给子任务，但子 Agent 的实际 token 消耗在自己的上下文窗口内独立计算

```
❌ 错误：预算切分模型

  Coordinator (200K 预算)
  ├── Explorer (切分 30K) ← 错误！Explorer 有自己的 128K 上下文
  ├── Coder (切分 80K)    ← 错误！Coder 有自己的 128K 上下文
  └── Reviewer (切分 40K) ← 错误！


✅ 正确：树状预算分配模型

  Coordinator (200K 上下文窗口, 预算额度 $2.00)
  │
  ├── 分配预算: Explorer 任务 $0.30
  │   └── Explorer (128K 上下文窗口, 独立预算 $0.30)
  │       └── 实际消耗: $0.18 ✓ 在预算内
  │
  ├── 分配预算: Coder 任务 $0.80
  │   └── Coder (128K 上下文窗口, 独立预算 $0.80)
  │       └── 实际消耗: $0.65 ✓ 在预算内
  │
  └── 分配预算: Reviewer 任务 $0.40
      └── Reviewer (128K 上下文窗口, 独立预算 $0.40)
          └── 实际消耗: $0.32 ✓ 在预算内
```

#### 14.4.2 预算 vs 上下文窗口

| 概念 | 含义 | 类比 |
|------|------|------|
| **上下文窗口** | 模型的物理限制（如 128K tokens） | 办公桌大小 |
| **Token 预算** | 本次任务允许花费的 token 费用上限 | 差旅预算 |
| **实际消耗** | 当前 Agent 实际使用的 token 数 | 实际花费 |

- 上下文窗口是**硬限制**（超出会 API 报错）
- Token 预算是**软限制**（超出会告警，但不会阻止执行）
- 子 Agent 有自己的上下文窗口，但预算由父 Agent 分配

#### 14.4.3 代码定义

```rust
use std::sync::Arc;

/// 树状 Token 预算节点
pub struct BudgetNode {
    /// 节点 ID（通常对应 Agent ID）
    node_id: String,
    /// 父节点引用
    parent: Option<WeakBudgetNode>,
    /// 当前节点的预算额度（美元）
    budget_limit: f64,
    /// 当前节点的实际消耗（美元）
    actual_cost: AtomicCost,
    /// 已分配给子节点的预算
    allocated_to_children: AtomicCost,
    /// 子节点
    children: Mutex<Vec<Arc<BudgetNode>>>,
    /// 预算告警回调
    alert_callback: Option<Box<dyn Fn(BudgetEvent) + Send + Sync>>,
}

type AtomicCost = std::sync::atomic::AtomicU64; // 存储 (cost * 1_000_000)
type WeakBudgetNode = std::sync::Weak<BudgetNode>;

/// 预算事件
#[derive(Debug, Clone)]
pub enum BudgetEvent {
    /// 子任务预算分配
    Allocated {
        parent_id: String,
        child_id: String,
        amount: f64,
        remaining: f64,
    },
    /// 预算告警
    Warning {
        node_id: String,
        percent: f64,
        actual: f64,
        limit: f64,
    },
    /// 预算超支
    Exceeded {
        node_id: String,
        actual: f64,
        limit: f64,
    },
}

impl BudgetNode {
    /// 创建根节点（会话级总预算）
    pub fn root(session_id: &str, total_budget: f64) -> Arc<Self> {
        Arc::new(Self {
            node_id: session_id.to_string(),
            parent: None,
            budget_limit: total_budget,
            actual_cost: AtomicCost::new(0),
            allocated_to_children: AtomicCost::new(0),
            children: Mutex::new(Vec::new()),
            alert_callback: None,
        })
    }

    /// 为子任务分配预算
    /// 返回子节点的 Arc 引用，子 Agent 持有该引用独立记账
    ///
    /// **并发安全**：使用 compare_exchange 循环替代 Relaxed + fetch_add，
    /// 消除 check-then-act 的 TOCTOU 竞态。
    pub fn allocate_child(
        self: &Arc<Self>,
        child_id: &str,
        amount: f64,
    ) -> Result<Arc<BudgetNode>, BudgetError> {
        let amount_micros = (amount * 1_000_000.0) as u64;
        let limit_micros = (self.budget_limit * 1_000_000.0) as u64;

        // compare_exchange 循环：原子性地检查并分配预算
        loop {
            let allocated = self.allocated_to_children.load(Ordering::Acquire);
            let actual = self.actual_cost.load(Ordering::Acquire);
            let used = allocated + actual;

            if used + amount_micros > limit_micros {
                return Err(BudgetError::InsufficientBudget {
                    requested: amount,
                    remaining: (limit_micros - used) as f64 / 1_000_000.0,
                });
            }

            // 尝试原子递增 allocated_to_children
            match self.allocated_to_children.compare_exchange_weak(
                allocated,
                allocated + amount_micros,
                Ordering::AcqRel,
                Ordering::Acquire,
            ) {
                Ok(_) => break, // 分配成功
                Err(current) => {
                    // 其他线程已修改，重试
                    continue;
                }
            }
        }

        let child = Arc::new(BudgetNode {
            node_id: child_id.to_string(),
            parent: Some(Arc::downgrade(self)),
            budget_limit: amount,
            actual_cost: AtomicCost::new(0),
            allocated_to_children: AtomicCost::new(0),
            children: Mutex::new(Vec::new()),
            alert_callback: None,
        });

        self.children.lock().unwrap().push(Arc::clone(&child));

        if let Some(ref cb) = self.alert_callback {
            let allocated = self.allocated_to_children.load(Ordering::Relaxed);
            let actual = self.actual_cost.load(Ordering::Relaxed);
            let remaining = (limit_micros - allocated - actual) as f64 / 1_000_000.0;
            cb(BudgetEvent::Allocated {
                parent_id: self.node_id.clone(),
                child_id: child_id.to_string(),
                amount,
                remaining,
            });
        }

        Ok(child)
    }

    /// 记录一次 LLM 调用的成本
    pub fn record_cost(&self, cost: f64) {
        let cost_micros = (cost * 1_000_000.0) as u64;
        let new_total = self.actual_cost.fetch_add(cost_micros, Ordering::Relaxed) + cost_micros;
        let limit_micros = (self.budget_limit * 1_000_000.0) as u64;
        let percent = new_total as f64 / limit_micros as f64 * 100.0;

        // 分级告警
        if let Some(ref cb) = self.alert_callback {
            if percent >= 100.0 {
                cb(BudgetEvent::Exceeded {
                    node_id: self.node_id.clone(),
                    actual: new_total as f64 / 1_000_000.0,
                    limit: self.budget_limit,
                });
            } else if percent >= 80.0 {
                cb(BudgetEvent::Warning {
                    node_id: self.node_id.clone(),
                    percent,
                    actual: new_total as f64 / 1_000_000.0,
                    limit: self.budget_limit,
                });
            }
        }
    }

    /// 获取当前节点的剩余预算
    pub fn remaining_budget(&self) -> f64 {
        let limit_micros = (self.budget_limit * 1_000_000.0) as u64;
        let used = self.actual_cost.load(Ordering::Relaxed);
        ((limit_micros - used).max(0) as f64) / 1_000_000.0
    }

    /// 获取当前节点的可用预算（总额 - 已消耗 - 已分配给子节点）
    pub fn available_budget(&self) -> f64 {
        let limit_micros = (self.budget_limit * 1_000_000.0) as u64;
        let used = self.actual_cost.load(Ordering::Relaxed)
            + self.allocated_to_children.load(Ordering::Relaxed);
        ((limit_micros - used).max(0) as f64) / 1_000_000.0
    }

    /// 获取当前节点的实际消耗
    pub fn actual_cost(&self) -> f64 {
        self.actual_cost.load(Ordering::Relaxed) as f64 / 1_000_000.0
    }

    /// 获取整棵预算树的总消耗（递归汇总）
    pub fn total_tree_cost(&self) -> f64 {
        let mut total = self.actual_cost.load(Ordering::Relaxed) as f64 / 1_000_000.0;
        let children = self.children.lock().unwrap();
        for child in children.iter() {
            total += child.total_tree_cost();
        }
        total
    }
}

#[derive(Debug, thiserror::Error)]
pub enum BudgetError {
    #[error("Insufficient budget: requested ${requested:.4}, remaining ${remaining:.4}")]
    InsufficientBudget { requested: f64, remaining: f64 },
}
```

#### 14.4.4 使用示例

```rust
// 1. 创建会话级总预算
let root = BudgetNode::root("session-001", 5.00); // $5.00 总预算

// 2. Coordinator 为子任务分配预算
let explorer_budget = root.allocate_child("explorer-001", 0.50)?;  // $0.50
let coder_budget = root.allocate_child("coder-001", 2.00)?;        // $2.00
let reviewer_budget = root.allocate_child("reviewer-001", 0.80)?;  // $0.80

// 3. Explorer 在自己的预算内独立运行
explorer_budget.record_cost(0.18);  // 实际消耗 $0.18
assert!(explorer_budget.remaining_budget() > 0.0);  // ✓ 在预算内

// 4. Coder 也可以递归分配给子 Coder
let sub_coder_budget = coder_budget.allocate_child("sub-coder-001", 0.60)?;
sub_coder_budget.record_cost(0.42);

// 5. 查看整棵树的总消耗
let total = root.total_tree_cost();  // $0.18 + $0.42 + ... = 总消耗
println!("Total tree cost: ${:.4} / ${:.4}", total, root.budget_limit);
```

#### 14.4.5 预算分配策略

| Agent 类型 | 预算分配依据 | 典型比例 |
|-----------|-------------|---------|
| **Coordinator** | 会话总预算 | 100%（根节点） |
| **Explorer** | 任务复杂度 × 预估轮次 | 5-15% |
| **Impact Analyzer** | 影响范围 × 文件数量 | 3-8% |
| **Planner** | 任务数量 × 复杂度 | 3-5% |
| **Coder** | 代码量 × 修改复杂度 | 30-50% |
| **Reviewer** | 代码量 × 审查深度 | 10-20% |
| **Tester** | 测试用例数量 | 5-15% |

> **注意**：预算分配是"软约束"。子 Agent 超出分配的预算不会中断执行，但会触发告警。只有会话级总预算超支才会触发 Exceeded 事件。

---

### 14.5 多模态 Token 计算

```
┌────────────────────────────────────────────────────────┐
│              Multimodal Token Calculator                │
│                                                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐             │
│  │  文本    │  │  图像    │  │  音频    │             │
│  │  Text    │  │  Image   │  │  Audio   │             │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘             │
│       │              │              │                   │
│       ▼              ▼              ▼                   │
│  byte/4       按 Provider       统一 STT              │
│  CJK 1.5x-2x  分别计算          转文本后计算           │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │  Provider-specific image token formulas:         │   │
│  │                                                   │   │
│  │  Anthropic:  tokens = ceil(w * h / 750)         │   │
│  │  OpenAI:     low=85, high=170~1105 (detail)     │   │
│  │  Google:     tokens = 258 + (w*h/750)           │   │
│  └─────────────────────────────────────────────────┘   │
└────────────────────────────────────────────────────────┘
```

#### 14.5.1 文本 Token 计算

```rust
/// 文本 Token 估算（考虑 CJK 字符权重）
///
/// **性能优化**：对纯 ASCII 文本使用字节级快速路径（批量处理），
/// 仅在遇到非 ASCII 字符时才逐字符处理。
pub fn estimate_text_tokens(text: &str) -> u64 {
    let bytes = text.as_bytes();
    let mut tokens = 0u64;
    let mut i = 0;

    while i < bytes.len() {
        if bytes[i].is_ascii() {
            // ASCII 快速路径：连续 ASCII 字符按字节批量计算
            let ascii_start = i;
            while i < bytes.len() && bytes[i].is_ascii() {
                i += 1;
            }
            tokens += (i - ascii_start) as u64;
        } else {
            // 非 ASCII：解析为 char 并按类型加权
            let ch = text[i..].chars().next().unwrap();
            i += ch.len_utf8();
            if is_cjk_char(ch) {
                tokens += 6; // CJK: ~1.5 tokens
            } else {
                tokens += 4; // 其他 Unicode: ~1 token
            }
        }
    }

    tokens / 4
}

/// 判断是否为 CJK 字符
fn is_cjk_char(ch: char) -> bool {
    let cp = ch as u32;
    // CJK Unified Ideographs
    (0x4E00..=0x9FFF).contains(&cp)
        // CJK Extension A
        || (0x3400..=0x4DBF).contains(&cp)
        // CJK Extension B
        || (0x20000..=0x2A6DF).contains(&cp)
        // CJK Compatibility Ideographs
        || (0xF900..=0xFAFF).contains(&cp)
        // 全角标点
        || (0xFF01..=0xFF60).contains(&cp)
        // CJK 标点
        || (0x3000..=0x303F).contains(&cp)
        // 平假名、片假名
        || (0x3040..=0x309F).contains(&cp)
        || (0x30A0..=0x30FF).contains(&cp)
}
```

#### 14.5.2 图像 Token 计算

```rust
/// 图像 Token 估算（按 Provider 分别计算）
pub struct ImageTokenEstimator;

impl ImageTokenEstimator {
    /// Anthropic: tokens = ceil(width * height / 750)
    pub fn anthropic(width: u32, height: u32) -> u64 {
        let pixels = width as u64 * height as u64;
        (pixels + 749) / 750
    }

    /// OpenAI: 根据 detail 级别计算
    ///   - Low: 固定 85 tokens
    ///   - High: 85 + 170 * tiles, tile = 512x512
    ///   - Auto: 根据图像大小自动选择
    pub fn openai(width: u32, height: u32, detail: &ImageDetail) -> u64 {
        match detail {
            ImageDetail::Low => 85,
            ImageDetail::High => {
                let short_side = width.min(height) as f64;
                let long_side = width.max(height) as f64;

                // 计算需要多少个 512x512 的 tile
                let scale = 2048.0 / long_side;
                let resized_short = short_side * scale;

                let tiles = if resized_short <= 512.0 {
                    1
                } else {
                    let n = (resized_short / 512.0).ceil() as u64;
                    n
                };

                85 + 170 * tiles
            }
            ImageDetail::Auto => {
                // 小图用 Low，大图用 High
                if width <= 512 && height <= 512 {
                    Self::openai(width, height, &ImageDetail::Low)
                } else {
                    Self::openai(width, height, &ImageDetail::High)
                }
            }
        }
    }

    /// Google Gemini: tokens = 258 + ceil(width * height / 750)
    pub fn google(width: u32, height: u32) -> u64 {
        let pixels = width as u64 * height as u64;
        258 + (pixels + 749) / 750
    }

    /// 根据 Provider 自动选择计算方式
    pub fn estimate(provider_id: &str, width: u32, height: u32, detail: &ImageDetail) -> u64 {
        match provider_id {
            "anthropic" => Self::anthropic(width, height),
            "openai" => Self::openai(width, height, detail),
            "google" => Self::google(width, height),
            _ => {
                // 默认使用 OpenAI 公式
                Self::openai(width, height, detail)
            }
        }
    }
}
```

#### 14.5.3 音频 Token 计算

```rust
/// 音频 Token 估算
/// 音频统一通过 STT（Speech-to-Text）管道转为文本后再计算 Token
pub struct AudioTokenEstimator;

impl AudioTokenEstimator {
    /// 估算音频时长（秒）
    pub fn estimate_duration_seconds(audio_bytes: &[u8], format: &AudioFormat) -> u64 {
        match format {
            AudioFormat::Wav => {
                // WAV: data_size / (sample_rate * channels * bits_per_sample / 8)
                if audio_bytes.len() > 44 {
                    let data_size = audio_bytes.len() - 44;
                    // 假设 16kHz, 16-bit, mono（常见 STT 输入格式）
                    data_size as u64 / (16000 * 2)
                } else {
                    0
                }
            }
            AudioFormat::Mp3 => {
                // MP3: 粗略估算，128kbps → bytes / 16000
                audio_bytes.len() as u64 / 16000
            }
            AudioFormat::Pcm => {
                // PCM: bytes / (sample_rate * bytes_per_sample)
                // 假设 16kHz, 16-bit
                audio_bytes.len() as u64 / (16000 * 2)
            }
        }
    }

    /// 估算音频转文本后的 Token 数
    /// 经验值：英语约 150 词/分钟，中文约 250 字/分钟
    pub fn estimate_transcript_tokens(audio_bytes: &[u8], format: &AudioFormat) -> u64 {
        let duration_secs = Self::estimate_duration_seconds(audio_bytes, format);
        let duration_mins = duration_secs as f64 / 60.0;

        // 混合估算：取英文和中文的平均值
        let words_en = duration_mins * 150.0;
        let chars_zh = duration_mins * 250.0;

        // 英文按 chars/3，中文按 bytes/4（每字 3 bytes）
        let tokens_en = (words_en * 4.5) / 3.0; // 平均词长 4.5 字符
        let tokens_zh = (chars_zh * 3.0) / 4.0;

        ((tokens_en + tokens_zh) / 2.0) as u64
    }
}
```

---

### 14.6 成本追踪

#### 14.6.1 成本追踪器

```rust
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{Duration, Instant};

/// 定价信息
#[derive(Debug, Clone)]
pub struct Pricing {
    pub input_per_million: f64,
    pub output_per_million: f64,
    pub cached_input_per_million: Option<f64>,
    pub cache_write_per_million: Option<f64>,
}

/// 成本追踪器
pub struct CostTracker {
    /// 按 Provider + Model 的定价表
    pricing_table: HashMap<String, Pricing>,
    /// 累计成本（美元）
    total_cost: AtomicU64, // 存储 (cost * 1_000_000) 作为定点数
    /// 按时间窗口的成本记录
    cost_history: Mutex<CostHistory>,
    /// 预算配置
    budget: Mutex<BudgetConfig>,
}

#[derive(Debug, Default)]
struct CostHistory {
    /// 每日成本: date_string → cost_cents
    daily: HashMap<String, u64>,
    /// 每周成本: week_string → cost_cents
    weekly: HashMap<String, u64>,
    /// 每任务成本: task_id → cost_cents
    per_task: HashMap<String, u64>,
}

/// 预算配置
#[derive(Debug, Clone)]
pub struct BudgetConfig {
    /// 每日预算上限（美元），None 表示无限制
    pub daily_limit: Option<f64>,
    /// 每周预算上限（美元）
    pub weekly_limit: Option<f64>,
    /// 每任务预算上限（美元）
    pub per_task_limit: Option<f64>,
    /// 告警回调
    pub alert_callback: Option<Box<dyn Fn(BudgetAlert) + Send + Sync>>,
}

/// 预算告警
#[derive(Debug, Clone)]
pub struct BudgetAlert {
    pub alert_type: BudgetAlertType,
    pub budget_type: BudgetType,
    pub current: f64,
    pub limit: f64,
    pub usage_percent: f64,
    pub timestamp: Instant,
}

#[derive(Debug, Clone)]
pub enum BudgetAlertType {
    /// 达到 50%
    Warning50,
    /// 达到 80%
    Warning80,
    /// 达到 100%
    Exceeded,
}

#[derive(Debug, Clone)]
pub enum BudgetType {
    Daily,
    Weekly,
    PerTask(String),
}

impl CostTracker {
    pub fn new() -> Self {
        let mut pricing_table = HashMap::new();

        // OpenAI GPT-4o 定价
        pricing_table.insert("openai:gpt-4o".to_string(), Pricing {
            input_per_million: 5.0,
            output_per_million: 15.0,
            cached_input_per_million: Some(2.5),   // 50% off
            cache_write_per_million: None,
        });

        // OpenAI GPT-4o-mini 定价
        pricing_table.insert("openai:gpt-4o-mini".to_string(), Pricing {
            input_per_million: 0.15,
            output_per_million: 0.6,
            cached_input_per_million: Some(0.075),
            cache_write_per_million: None,
        });

        // Anthropic Claude 3.5 Sonnet 定价
        pricing_table.insert("anthropic:claude-3-5-sonnet".to_string(), Pricing {
            input_per_million: 3.0,
            output_per_million: 15.0,
            cached_input_per_million: Some(0.3),   // 90% off
            cache_write_per_million: Some(3.75),   // 25% surcharge
        });

        // Google Gemini 1.5 Pro 定价
        pricing_table.insert("google:gemini-1.5-pro".to_string(), Pricing {
            input_per_million: 3.5,
            output_per_million: 10.5,
            cached_input_per_million: Some(0.875), // 75% off
            cache_write_per_million: None,
        });

        Self {
            pricing_table,
            total_cost: AtomicU64::new(0),
            cost_history: Mutex::new(CostHistory::default()),
            budget: Mutex::new(BudgetConfig {
                daily_limit: None,
                weekly_limit: None,
                per_task_limit: None,
                alert_callback: None,
            }),
        }
    }

    /// 注册定价
    pub fn register_pricing(&mut self, key: &str, pricing: Pricing) {
        self.pricing_table.insert(key.to_string(), pricing);
    }

    /// 设置预算配置
    pub fn set_budget(&self, config: BudgetConfig) {
        *self.budget.lock().unwrap() = config;
    }

    /// 记录一次 API 调用的成本
    pub fn record_usage(
        &self,
        provider_model: &str,
        usage: &TokenUsage,
        cached_tokens: Option<u64>,
        task_id: Option<&str>,
    ) -> CostRecord {
        let pricing = self.pricing_table
            .get(provider_model)
            .cloned()
            .unwrap_or(Pricing {
                input_per_million: 0.0,
                output_per_million: 0.0,
                cached_input_per_million: None,
                cache_write_per_million: None,
            });

        let mut input_cost = (usage.prompt_tokens as f64 / 1_000_000.0) * pricing.input_per_million;
        let output_cost = (usage.completion_tokens as f64 / 1_000_000.0) * pricing.output_per_million;

        // 计算缓存节省
        let mut cache_savings = 0.0;
        if let (Some(cached), Some(cached_price)) = (cached_tokens, pricing.cached_input_per_million) {
            let cached_cost = (cached as f64 / 1_000_000.0) * cached_price;
            let uncached_cost = (cached as f64 / 1_000_000.0) * pricing.input_per_million;
            cache_savings = uncached_cost - cached_cost;
            input_cost -= cache_savings;
        }

        let total = input_cost + output_cost;
        let cost_micros = (total * 1_000_000.0) as u64;

        // 更新累计成本
        self.total_cost.fetch_add(cost_micros, Ordering::Relaxed);

        // 更新历史记录
        {
            let mut history = self.cost_history.lock().unwrap();
            let today = chrono::Utc::now().format("%Y-%m-%d").to_string();
            let week = chrono::Utc::now().format("%Y-W%W").to_string();

            *history.daily.entry(today).or_insert(0) += cost_micros;
            *history.weekly.entry(week).or_insert(0) += cost_micros;

            if let Some(tid) = task_id {
                *history.per_task.entry(tid.to_string()).or_insert(0) += cost_micros;
            }
        }

        // 检查预算
        self.check_budget(task_id);

        CostRecord {
            provider_model: provider_model.to_string(),
            prompt_tokens: usage.prompt_tokens,
            completion_tokens: usage.completion_tokens,
            cached_tokens,
            input_cost,
            output_cost,
            cache_savings,
            total_cost: total,
        }
    }

    /// 检查预算告警
    fn check_budget(&self, task_id: Option<&str>) {
        let budget = self.budget.lock().unwrap();
        let history = self.cost_history.lock().unwrap();

        let today = chrono::Utc::now().format("%Y-%m-%d").to_string();
        let week = chrono::Utc::now().format("%Y-W%W").to_string();

        // 检查每日预算
        if let Some(daily_limit) = budget.daily_limit {
            if let Some(&daily_cost) = history.daily.get(&today) {
                let current = daily_cost as f64 / 1_000_000.0;
                let percent = current / daily_limit * 100.0;

                if let Some(ref callback) = budget.alert_callback {
                    if percent >= 100.0 {
                        callback(BudgetAlert {
                            alert_type: BudgetAlertType::Exceeded,
                            budget_type: BudgetType::Daily,
                            current,
                            limit: daily_limit,
                            usage_percent: percent,
                            timestamp: Instant::now(),
                        });
                    } else if percent >= 80.0 {
                        callback(BudgetAlert {
                            alert_type: BudgetAlertType::Warning80,
                            budget_type: BudgetType::Daily,
                            current,
                            limit: daily_limit,
                            usage_percent: percent,
                            timestamp: Instant::now(),
                        });
                    } else if percent >= 50.0 {
                        callback(BudgetAlert {
                            alert_type: BudgetAlertType::Warning50,
                            budget_type: BudgetType::Daily,
                            current,
                            limit: daily_limit,
                            usage_percent: percent,
                            timestamp: Instant::now(),
                        });
                    }
                }
            }
        }

        // 检查每周预算（同理）
        // 检查每任务预算（同理）
    }

    /// 获取总成本
    pub fn total_cost(&self) -> f64 {
        self.total_cost.load(Ordering::Relaxed) as f64 / 1_000_000.0
    }

    /// 获取今日成本
    pub fn today_cost(&self) -> f64 {
        let history = self.cost_history.lock().unwrap();
        let today = chrono::Utc::now().format("%Y-%m-%d").to_string();
        history.daily.get(&today)
            .map(|&c| c as f64 / 1_000_000.0)
            .unwrap_or(0.0)
    }
}

/// 单次调用成本记录
#[derive(Debug, Clone)]
pub struct CostRecord {
    pub provider_model: String,
    pub prompt_tokens: u64,
    pub completion_tokens: u64,
    pub cached_tokens: Option<u64>,
    pub input_cost: f64,
    pub output_cost: f64,
    pub cache_savings: f64,
    pub total_cost: f64,
}
```

#### 14.6.2 核心指标

```
┌──────────────────────────────────────────────────────────┐
│                    核心指标仪表盘                         │
│                                                           │
│  ┌─────────────────┐  ┌──────────────────────────────┐  │
│  │ session.count   │  │ token.usage                  │  │
│  │ 会话总数         │  │ Token 使用总量               │  │
│  │                 │  │ prompt / completion / total   │  │
│  └─────────────────┘  └──────────────────────────────┘  │
│                                                           │
│  ┌─────────────────┐  ┌──────────────────────────────┐  │
│  │ cost.usage      │  │ agent.duration               │  │
│  │ 费用统计         │  │ Agent 执行时长               │  │
│  │ input/output/   │  │ avg / p50 / p95 / p99        │  │
│  │ cache_savings   │  │                              │  │
│  └─────────────────┘  └──────────────────────────────┘  │
│                                                           │
│  ┌─────────────────┐                                     │
│  │ tool.call       │                                     │
│  │ 工具调用统计     │                                     │
│  │ count / success │                                     │
│  │ / error / avg   │                                     │
│  │ latency         │                                     │
│  └─────────────────┘                                     │
└──────────────────────────────────────────────────────────┘
```

| 指标 | 类型 | 说明 |
|------|------|------|
| `session.count` | Counter | 会话总数 |
| `token.usage` | Gauge | Token 使用量（prompt / completion / total） |
| `cost.usage` | Gauge | 费用统计（input / output / cache_savings） |
| `agent.duration` | Histogram | Agent 执行时长（avg / p50 / p95 / p99） |
| `tool.call` | Counter + Histogram | 工具调用次数与延迟 |

---

### 14.7 Prompt Caching 集成

#### 14.7.1 三大 Provider 缓存对比

| 特性 | OpenAI | Anthropic | Google |
|------|--------|-----------|--------|
| **缓存机制** | Automatic | Explicit `cache_control` | Automatic |
| **最小前缀** | 1024 tokens | 1024 tokens | 32,768 tokens |
| **缓存读取折扣** | 50% off | 90% off | 75% off |
| **缓存写入费用** | 无额外费用 | +25% surcharge | 无额外费用 |
| **TTL** | 5~10 分钟（滚动） | 5 分钟 | 1 小时 |
| **最大缓存** | 128K tokens | 200K tokens | 1M tokens |
| **控制粒度** | 自动（无法手动控制） | 消息级 breakpoint | 自动 |
| **适用场景** | 长上下文重复前缀 | 精确控制缓存边界 | 超长上下文 |

#### 14.7.2 CacheCapability 指导 Prompt 分层

```rust
/// Prompt 分层策略（与第 15 章 Prompt 缓存联动）
pub struct PromptLayeringStrategy;

impl PromptLayeringStrategy {
    /// 根据 Provider 的缓存能力，优化 Prompt 的分层结构
    ///
    /// 分层原则：
    /// 1. Layer 0 (System): 系统指令 — 最少变化，优先缓存
    /// 2. Layer 1 (Context): 项目上下文 — 偶尔变化
    /// 3. Layer 2 (Task): 当前任务描述 — 每次任务变化
    /// 4. Layer 3 (History): 对话历史 — 持续增长
    /// 5. Layer 4 (Current): 当前用户输入 — 每轮变化
    pub fn optimize_layers(
        provider: &dyn LlmProvider,
        system_prompt: &str,
        context: &str,
        task: &str,
        history: &[ChatMessage],
        current_input: &str,
    ) -> Vec<ChatMessage> {
        let cache_cap = provider.cache_capability();
        let mut messages = Vec::new();

        // Layer 0: System Prompt
        let mut sys_msg = ChatMessage {
            role: MessageRole::System,
            content: MessageContent::Text(system_prompt.to_string()),
            name: None,
            cache_control: None,
        };

        // 如果 Provider 支持显式缓存，在 System Prompt 后设置缓存断点
        if cache_cap.explicit_cache {
            sys_msg.cache_control = Some(CacheControlPoint {
                type_: CacheControlType::Ephemeral,
                breakpoint: "after_system".to_string(),
            });
        }
        messages.push(sys_msg);

        // Layer 1: Context
        if !context.is_empty() {
            messages.push(ChatMessage {
                role: MessageRole::User,
                content: MessageContent::Text(context.to_string()),
                name: None,
                cache_control: if cache_cap.explicit_cache {
                    Some(CacheControlPoint {
                        type_: CacheControlType::Ephemeral,
                        breakpoint: "after_context".to_string(),
                    })
                } else {
                    None
                },
            });
        }

        // Layer 2: Task
        if !task.is_empty() {
            messages.push(ChatMessage {
                role: MessageRole::User,
                content: MessageContent::Text(task.to_string()),
                name: None,
                cache_control: None, // 任务描述不缓存
            });
        }

        // Layer 3: History
        messages.extend(history.iter().cloned());

        // Layer 4: Current Input
        messages.push(ChatMessage {
            role: MessageRole::User,
            content: MessageContent::Text(current_input.to_string()),
            name: None,
            cache_control: None,
        });

        messages
    }

    /// 估算缓存命中率
    pub fn estimate_cache_hit_rate(
        provider: &dyn LlmProvider,
        total_tokens: u64,
        cached_prefix_tokens: u64,
    ) -> f64 {
        let cap = provider.cache_capability();
        if !cap.explicit_cache {
            return 0.0;
        }

        if cached_prefix_tokens < cap.min_prefix_tokens as u64 {
            return 0.0;
        }

        let cacheable = cached_prefix_tokens.min(
            cap.max_cacheable_tokens.unwrap_or(u32::MAX) as u64
        );
        cacheable as f64 / total_tokens as f64
    }
}
```

#### 14.7.3 缓存策略推荐

```

#### 14.7.4 应用侧语义缓存

Provider Prompt Caching 解决的是“前缀稳定、内容完全相同或高度相同”的场景；应用侧语义缓存解决的是“问题重述了，但意图和答案基本不变”的场景。两者互补，而不是替代关系。

```
┌─────────────────────────────────────────────────────────────┐
│                 双层缓存决策顺序                              │
│                                                             │
│  1. 语义缓存可用?                                            │
│     ├── No  → 继续                                           │
│     └── Yes                                                 │
│          ├── Agent ∈ {Explorer, Research}?                  │
│          ├── 请求只读、无工具调用?                           │
│          ├── repo_fingerprint 未变化?                        │
│          └── 相似度 >= 0.90?                                │
│               └── Yes → 直接返回缓存响应                     │
│                                                             │
│  2. Provider Prompt Caching                                  │
│     ├── 命中前缀缓存 → 降低输入 Token 成本                     │
│     └── 未命中 → 正常请求 Provider                            │
│                                                             │
│  3. 请求完成后                                                │
│     ├── 写回 Prompt 缓存（Provider 侧）                       │
│     └── 满足条件则写回语义缓存（应用侧）                       │
└─────────────────────────────────────────────────────────────┘
```

**最适合启用语义缓存的场景：**

- Explorer 重复扫描相同代码库，问题只是措辞不同
- Research 重复查询同一技术选型、兼容性或版本差异
- Coordinator 在多轮追问后再次请求相同事实型补充材料

**不适合启用语义缓存的场景：**

- Coder / Reviewer / Tester 这类强依赖当前代码状态和局部上下文的任务
- 含工具调用、函数调用、结构化 schema 约束的响应
- 依赖时间、网络状态或外部系统实时结果的查询
┌─────────────────────────────────────────────────────────────┐
│                   缓存策略决策流程                            │
│                                                              │
│  Provider 支持 Prompt Caching?                               │
│       │                                                      │
│       ├── No ──→ 不使用缓存，直接发送完整 Prompt               │
│       │                                                      │
│       └── Yes                                                 │
│            │                                                 │
│            ├── Explicit Cache (Anthropic)                     │
│            │    │                                             │
│            │    ├── System Prompt > 1024 tokens?              │
│            │    │    └── Yes → 在 System 后设 breakpoint      │
│            │    │                                             │
│            │    ├── System + Context > 1024 tokens?           │
│            │    │    └── Yes → 在 Context 后设 breakpoint     │
│            │    │                                             │
│            │    └── 缓存写入成本可接受?                        │
│            │         └── Yes → 启用缓存                       │
│            │         └── No  → 仅读取缓存，不主动写入          │
│            │                                                 │
│            └── Automatic Cache (OpenAI / Google)              │
│                 │                                             │
│                 ├── 确保前缀 >= min_prefix_tokens             │
│                 │                                             │
│                 └── 静态内容放在最前面                          │
│                      （System → Context → Task → History）    │
└─────────────────────────────────────────────────────────────┘
```

---

### 14.8 设计决策

| 决策 | 选择 | 理由 |
|------|------|------|
| Provider 架构 | OpenAI 兼容协议统一层 | DeepSeek/智谱/通义/百川/Moonshot/Ollama 等均兼容 OpenAI API，一个实现覆盖绝大多数 Provider |
| 预设注册表 | `builtin_presets()` + 自定义覆盖 | 一行配置接入新 Provider，同时支持自定义 base_url/model/pricing |
| 非兼容 Provider | Feature flag 单独实现 | Anthropic Messages API 和 Google Gemini API 格式不同，按需编译 |
| Token 估算 | BytesPer4（默认） | UTF-8 友好，中英文都较准确；零外部依赖 |
| 精确计数 | 可选 riptoken（feature flag） | 零默认依赖，按需启用；编译时间可控 |
| **预算模型** | **树状预算分配（BudgetNode）** | **子 Agent 独立构建上下文窗口，预算按任务分配而非按比例切分；父子独立记账** |
| 成本控制 | 预算告警（50%/80%/100%） | 防止意外高额费用；分级告警提供缓冲 |
| 缓存策略 | Provider 自适应 | 不同 Provider 缓存机制差异大，统一抽象无法覆盖 |
| 应用侧语义缓存 | 可选中间件（Explorer / Research 默认启用） | Prompt 缓存只解决稳定前缀；语义缓存可覆盖问题重述和重复扫描场景，但必须受 Agent 类型、repo 指纹和相似度阈值约束 |
| 多模态 Token | 按 Provider 分别计算 | 各 Provider 的图像/音频 Token 计算公式不同 |
| 流式响应 | BoxStream + StreamEvent | 统一流式抽象，支持 Token 用量实时推送 |
| 错误处理 | LlmError enum | 覆盖常见错误场景（限流、上下文溢出、认证失败等） |
| 测试支持 | MockProvider | 预设响应队列，无需真实 API 即可测试 Agent 逻辑 |
| 定价管理 | 预设内置 + 运行时覆盖 | 灵活添加新模型定价，支持自定义 pricing |

---

### 14.9 Provider 感知的工具加载策略

工具定义往往是请求中最大的固定前缀之一，但不同 Provider 对“工具可见性”和“延迟加载”的原生支持差异很大，因此不能把“工具简介 + 应用层懒加载重试”写成统一机制。

#### 14.9.1 官方能力差异

| Provider | 官方能力 | 对 MoreCode 的含义 |
|------|------|------|
| **Anthropic** | 工具定义支持 `defer_loading`；大工具集可配合 tool search 使用；延迟工具会在缓存键计算前从前缀移除 | 优先使用**原生延迟加载**，不需要应用层模拟 |
| **OpenAI** | `tool_choice.allowed_tools` 可限制当前回合允许调用的工具集合，同时保留完整工具清单以最大化 Prompt Caching | 优先使用**全量注册 + 子集放行**，而不是频繁重建 tools 数组 |
| **OpenAI-compatible / 其他 Provider** | 多数只支持标准 `tools` 数组，不支持 `allowed_tools` 或 `defer_loading` | 退回到**静态核心工具**或**应用层补发 schema**，但作为兜底方案 |

> 依据：
> - OpenAI Function Calling 文档建议：为了最大化 prompt caching，保持工具数组不变，并用 `allowed_tools` 指定当前可调用子集。
> - Anthropic Tool Reference / Prompt Caching 文档说明：工具可设置 `defer_loading`；被延迟的工具会在缓存前缀计算前被移除，适合大工具目录。

#### 14.9.2 MoreCode 的统一抽象

```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ToolExposureMode {
    /// 完整工具目录始终随请求发送
    FullCatalog,
    /// 完整工具目录稳定发送，但仅允许一个子集被当前回合调用
    AllowedSubset,
    /// Provider 原生延迟加载（如 Anthropic defer_loading）
    NativeDeferred,
    /// 应用层模拟：缺工具时补发 schema 并重试
    AppLevelReload,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProviderToolLoadingPolicy {
    pub mode: ToolExposureMode,
    pub keep_catalog_stable: bool,
    pub supports_allowed_subset: bool,
    pub supports_native_deferred: bool,
}
```

默认策略：

- `AnthropicProvider` -> `NativeDeferred`
- `OpenAiProvider` / `OpenAiCompatibleProvider` 且支持 `allowed_tools` -> `AllowedSubset`
- 其余 Provider -> `FullCatalog` 或 `AppLevelReload`

#### 14.9.3 推荐执行路径

| 路径 | 发送给模型的内容 | 适用场景 | 优点 | 代价 |
|------|------------------|----------|------|------|
| `NativeDeferred` | 完整工具目录，其中非核心工具标记 `defer_loading=true` | Anthropic + 大工具集 | 原生能力、缓存友好、无需多轮重试 | 依赖 Provider 特性 |
| `AllowedSubset` | 完整工具目录 + 当前回合 `allowed_tools=[核心子集]` | OpenAI / 兼容实现 | 目录稳定、缓存稳定、按回合控权 | 需要 Provider 支持子集放行 |
| `FullCatalog` | 每次发送完整工具目录 | 小工具集、低复杂度场景 | 实现最简单 | 固定 Token 开销最高 |
| `AppLevelReload` | 先发核心工具；缺工具时补发完整 schema 重试 | 无原生能力、低频长尾工具 | 可减少首轮 Token | 多一轮往返，且会破坏前缀稳定性 |

#### 14.9.4 为什么不再把“简介 + 拦截重试”作为默认方案

原始提案有一个隐含前提：模型能“先知道工具名，再在缺 schema 时调用它”。但这并不是所有 Provider 都原生支持的交互模式。

- 如果工具根本不在 `tools` 数组里，模型通常无法按标准函数调用协议直接生成合法调用。
- 即使应用层可以拦截文本意图并补发 schema，也会新增一次模型往返，并降低缓存命中率。
- 对支持原生能力的 Provider 来说，应用层重试只是在重复做本该由平台完成的事。

因此 MoreCode 将它降级为**兼容性 fallback**，不再作为主设计。

#### 14.9.5 最小实现接口

```rust
impl ToolRegistry {
    pub fn build_provider_tools(
        &self,
        provider: &dyn LlmProvider,
        agent_type: AgentType,
    ) -> ProviderToolPayload {
        let policy = provider.tool_loading_policy();
        let core = self.get_core_tools(&agent_type);

        match policy.mode {
            ToolExposureMode::NativeDeferred => {
                ProviderToolPayload::anthropic_deferred(
                    self.all_tools.values().cloned().collect(),
                    core,
                )
            }
            ToolExposureMode::AllowedSubset => {
                ProviderToolPayload::with_allowed_subset(
                    self.all_tools.values().cloned().collect(),
                    core,
                )
            }
            ToolExposureMode::FullCatalog => {
                ProviderToolPayload::full_catalog(
                    self.all_tools.values().cloned().collect()
                )
            }
            ToolExposureMode::AppLevelReload => {
                ProviderToolPayload::core_only(
                    core.iter()
                        .filter_map(|name| self.all_tools.get(name).cloned())
                        .collect()
                )
            }
        }
    }
}
```

#### 14.9.6 落地约束

- **目录稳定优先于首轮极限瘦身**：只要 Provider 支持 `allowed_tools` 或 `defer_loading`，就不要每轮重建工具目录。
- **角色核心工具来自能力矩阵**：Coder / Reviewer / Explorer 的默认子集仍以第 11 章能力矩阵为准。
- **安全策略独立生效**：即使工具在目录中可见，实际能否执行仍由第 13 章权限与沙箱策略决定。
- **缓存章节只负责"如何缓存"**：具体的目录拆分和模板组织放到第 15 章处理。
