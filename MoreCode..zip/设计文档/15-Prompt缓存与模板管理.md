# MoreCode — Prompt 缓存与模板管理

> **定位**：Agent 系统 Prompt 层的缓存策略与模板版本管理基础设施
> **边界**：本章只讨论 Provider 侧 Prompt 前缀缓存；应用侧语义缓存中间件见第 14 章
> **关联章节**：12-上下文压缩策略、14-LLM Provider 与 Token 管理、16-可观测性与 Hook 系统

---

## 15. Prompt 缓存与模板管理

### 15.1 核心思想

系统提示和工具定义占大量 token，但跨请求高度重复。以一次典型的多 Agent 任务为例：

```
┌─────────────────────────────────────────────────────────────────────┐
│                    单次 LLM 调用的 Token 构成                        │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  系统提示 (System Prompt)          ████████████████  ~3,000 tokens  │
│  工具定义 (Tool Definitions)       ██████████████    ~2,500 tokens  │
│  项目上下文 (Project Context)      ██████████        ~2,000 tokens  │
│  任务描述 (Task Description)       ██████            ~1,200 tokens  │
│  对话历史 (Conversation History)   ████████████████  ~3,000 tokens  │
│  当前输入 (Current Input)          ████              ~800 tokens    │
│                                                                     │
│  ─────────────────────────────────────────────────────────────────  │
│  可缓存部分: ~7,500 tokens (62.5%)                                  │
│  不可缓存部分: ~5,000 tokens (37.5%)                                │
│                                                                     │
│  结论: 超过 60% 的 token 在跨请求间高度重复，是缓存的核心目标          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

通过分层缓存和模板管理，将重复 token 的成本降至原始的 10%-50%（取决于 Provider 缓存折扣），同时通过模板版本管理防止意外变更导致缓存失效。

**设计原则**：

1. **分层隔离**：不同变化频率的内容放入不同缓存层，变更影响范围最小化
2. **Provider 感知**：缓存策略与 `CacheCapability` 联动，自动适配不同 Provider 的缓存能力
3. **模板驱动**：Prompt 内容模板化，变量替换与版本管理分离
4. **失效可控**：版本化失效 + 事件驱动失效双保险，避免缓存雪崩

---

### 15.2 五层 Prompt 缓存架构

#### 15.2.1 分层总览

```
┌─────────────────────────────────────────────────────────────────────┐
│                    五层 Prompt 缓存架构                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ L1 全局层 (Global)                                          │   │
│  │   系统提示 + 工具定义 + 全局指令                              │   │
│  │   ~5-8K tokens │ 月更新 │ 最长 TTL │ 所有用户共享            │   │
│  │   cache_control: breakpoint = "after_global"                │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ L2 组织层 (Organization)                                    │   │
│  │   团队约定 + 代码规范 + 组织策略                              │   │
│  │   ~2-3K tokens │ 周更新 │ 长 TTL │ 组织内共享                │   │
│  │   cache_control: breakpoint = "after_org"                   │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ L3 项目层 (Project)                                         │   │
│  │   技术栈 + 项目约定 + 架构决策 + 依赖信息                     │   │
│  │   ~3-5K tokens │ 日更新 │ 中等 TTL │ 项目内共享               │   │
│  │   cache_control: breakpoint = "after_project"               │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ L4 会话层 (Session)                                         │   │
│  │   任务描述 + 执行计划 + 会话状态                              │   │
│  │   ~3-5K tokens │ 每次任务更新 │ 不缓存 │ 单会话               │   │
│  │   cache_control: None                                       │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ L5 轮次层 (Turn)                                            │   │
│  │   当前对话历史 + 用户最新输入                                 │   │
│  │   动态 tokens │ 每轮变化 │ 不缓存 │ 单轮                     │   │
│  │   cache_control: None                                       │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ▲ 缓存价值递减 ──────────────────────────── 变化频率递增 ▲         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

#### 15.2.2 PromptLayers 数据结构

```rust
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use serde::{Deserialize, Serialize};

/// Prompt 缓存层标识
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum PromptLayer {
    /// L1 全局层：系统提示、工具定义，所有用户共享
    Global,
    /// L2 组织层：团队约定、代码规范，组织内共享
    Organization,
    /// L3 项目层：技术栈、项目约定，项目内共享
    Project,
    /// L4 会话层：任务描述、执行计划，不缓存
    Session,
    /// L5 轮次层：对话历史，不缓存
    Turn,
}

impl PromptLayer {
    /// 返回该层的默认 TTL（秒）
    pub fn default_ttl(&self) -> Option<u64> {
        match self {
            Self::Global => Some(3600),       // 1 小时
            Self::Organization => Some(1800),  // 30 分钟
            Self::Project => Some(600),        // 10 分钟
            Self::Session => None,             // 不缓存
            Self::Turn => None,                // 不缓存
        }
    }

    /// 返回该层是否应该设置缓存断点
    pub fn should_cache(&self) -> bool {
        matches!(self, Self::Global | Self::Organization | Self::Project)
    }

    /// 返回缓存断点名称
    pub fn breakpoint_name(&self) -> Option<&'static str> {
        match self {
            Self::Global => Some("after_global"),
            Self::Organization => Some("after_org"),
            Self::Project => Some("after_project"),
            Self::Session | Self::Turn => None,
        }
    }

    /// 返回预估 Token 数范围
    pub fn estimated_tokens(&self) -> (u32, u32) {
        match self {
            Self::Global => (5000, 8000),
            Self::Organization => (2000, 3000),
            Self::Project => (3000, 5000),
            Self::Session => (3000, 5000),
            Self::Turn => (500, 8000),  // 高度动态
        }
    }
}

/// 单层 Prompt 内容及其版本信息
#[derive(Debug, Clone)]
pub struct PromptLayerContent {
    /// 所属层
    pub layer: PromptLayer,
    /// 内容文本
    pub content: String,
    /// 版本号（内容变更时自增）
    pub version: u64,
    /// 内容哈希（用于快速比较变更）
    pub content_hash: u64,
    /// 最后更新时间（Unix timestamp）
    pub updated_at: i64,
    /// 该层的变量占位符列表
    pub variables: Vec<String>,
}

/// 五层 Prompt 完整结构
#[derive(Debug, Clone)]
pub struct PromptLayers {
    /// L1 全局层
    pub global: PromptLayerContent,
    /// L2 组织层
    pub organization: Option<PromptLayerContent>,
    /// L3 项目层
    pub project: Option<PromptLayerContent>,
    /// L4 会话层
    pub session: Option<PromptLayerContent>,
    /// L5 轮次层（对话历史）
    pub turn_history: Vec<TurnMessage>,
}

/// 轮次对话消息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TurnMessage {
    pub role: MessageRole,
    pub content: String,
    pub timestamp: i64,
}

/// Prompt 层管理器
pub struct PromptLayerManager {
    /// 各层内容缓存
    layers: Arc<RwLock<PromptLayers>>,
    /// 各层版本号追踪（用于缓存失效判断）
    versions: Arc<RwLock<HashMap<PromptLayer, u64>>>,
    /// 缓存失效异步通知通道（🆕 P2-3: 使用 bounded channel 替代 UnboundedSender，防止内存压力）
    invalidation_tx: tokio::sync::mpsc::Sender<CacheInvalidationEvent>,
    /// 缓存失效监听器列表
    invalidation_listeners: Arc<RwLock<Vec<Arc<dyn Fn(CacheInvalidationEvent) + Send + Sync>>>>,
    /// 文件变更去抖监听句柄
    _watcher: Option<PromptDebouncer>,
}

/// 缓存失效事件
#[derive(Debug, Clone)]
pub struct CacheInvalidationEvent {
    pub layer: PromptLayer,
    pub new_version: u64,
    pub invalidated_at: i64,
}

/// Prompt 模板文件监听去抖器
type PromptDebouncer =
    notify_debouncer_mini::Debouncer<notify_debouncer_mini::notify::RecommendedWatcher>;

impl PromptLayerManager {
    /// 创建新的 Prompt 层管理器
    pub fn new(
        global_content: String,
        org_content: Option<String>,
        project_content: Option<String>,
    ) -> Self {
        let global = PromptLayerContent {
            layer: PromptLayer::Global,
            content: global_content,
            version: 1,
            content_hash: Self::hash_content(&global_content),
            updated_at: chrono::Utc::now().timestamp(),
            variables: Self::extract_variables(&global_content),
        };

        let layers = PromptLayers {
            global,
            organization: org_content.map(|c| PromptLayerContent {
                layer: PromptLayer::Organization,
                content: c,
                version: 1,
                content_hash: Self::hash_content(&c),
                updated_at: chrono::Utc::now().timestamp(),
                variables: Self::extract_variables(&c),
            }),
            project: project_content.map(|c| PromptLayerContent {
                layer: PromptLayer::Project,
                content: c,
                version: 1,
                content_hash: Self::hash_content(&c),
                updated_at: chrono::Utc::now().timestamp(),
                variables: Self::extract_variables(&c),
            }),
            session: None,
            turn_history: Vec::new(),
        };

        let mut versions = HashMap::new();
        versions.insert(PromptLayer::Global, 1);
        if layers.organization.is_some() {
            versions.insert(PromptLayer::Organization, 1);
        }
        if layers.project.is_some() {
            versions.insert(PromptLayer::Project, 1);
        }

        let invalidation_listeners =
            Arc::new(RwLock::new(Vec::<Arc<dyn Fn(CacheInvalidationEvent) + Send + Sync>>::new()));
        let (invalidation_tx, mut invalidation_rx) = tokio::sync::mpsc::unbounded_channel();
        let listeners_for_task = Arc::clone(&invalidation_listeners);

        tokio::spawn(async move {
            while let Some(event) = invalidation_rx.recv().await {
                let callbacks = listeners_for_task.read().await.clone();

                for callback in callbacks {
                    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        callback(event.clone());
                    }));

                    if result.is_err() {
                        tracing::error!(
                            layer = ?event.layer,
                            version = event.new_version,
                            "cache invalidation listener panicked"
                        );
                    }
                }
            }
        });

        Self {
            layers: Arc::new(RwLock::new(layers)),
            versions: Arc::new(RwLock::new(versions)),
            invalidation_tx,
            invalidation_listeners,
            _watcher: None,
        }
    }

    /// 更新指定层的内容，返回是否发生了实际变更
    pub async fn update_layer(
        &self,
        layer: PromptLayer,
        new_content: String,
    ) -> Result<bool, PromptCacheError> {
        let new_hash = Self::hash_content(&new_content);

        let mut layers = self.layers.write().await;
        let target = match layer {
            PromptLayer::Global => Some(&mut layers.global),
            PromptLayer::Organization => layers.organization.as_mut(),
            PromptLayer::Project => layers.project.as_mut(),
            PromptLayer::Session => layers.session.as_mut(),
            PromptLayer::Turn => return Err(PromptCacheError::TurnLayerNotUpdatable),
        };

        if let Some(content) = target {
            if content.content_hash == new_hash {
                return Ok(false); // 内容未变，无需更新
            }

            content.version += 1;
            content.content_hash = new_hash;
            content.content = new_content;
            content.updated_at = chrono::Utc::now().timestamp();
            content.variables = Self::extract_variables(&content.content);

            // 同步更新版本号
            let mut versions = self.versions.write().await;
            if let Some(v) = versions.get_mut(&layer) {
                *v = content.version;
            }

            let new_version = content.version;
            drop(versions);
            drop(layers);

            // 只把失效事件入队，不在版本锁内同步执行监听器逻辑，避免阻塞和重入死锁
            if self.invalidation_tx.send(CacheInvalidationEvent {
                layer,
                new_version,
                invalidated_at: chrono::Utc::now().timestamp(),
            }).is_err() {
                tracing::warn!(layer = ?layer, version = new_version, "cache invalidation dispatcher is closed");
            }

            Ok(true)
        } else {
            Err(PromptCacheError::LayerNotInitialized(layer))
        }
    }

    /// 注册缓存失效监听器
    pub async fn on_invalidation(
        &self,
        listener: impl Fn(CacheInvalidationEvent) + Send + Sync + 'static,
    ) {
        self.invalidation_listeners
            .write()
            .await
            .push(Arc::new(listener));
    }

    /// 获取指定层的当前版本号
    pub async fn get_version(&self, layer: PromptLayer) -> Option<u64> {
        let versions = self.versions.read().await;
        versions.get(&layer).copied()
    }

    /// 构建完整的 Prompt 消息序列（用于发送给 LLM）
    pub async fn build_messages(
        &self,
        provider: &dyn LlmProvider,
        session_content: Option<String>,
        turn_history: Vec<TurnMessage>,
    ) -> Vec<ChatMessage> {
        let layers = self.layers.read().await;
        let cache_cap = provider.cache_capability();
        let mut messages = Vec::new();

        // L1: 全局层 — 始终缓存
        let mut global_msg = ChatMessage {
            role: MessageRole::System,
            content: MessageContent::Text(layers.global.content.clone()),
            name: None,
            cache_control: None,
        };
        if cache_cap.explicit_cache {
            global_msg.cache_control = Some(CacheControlPoint {
                type_: CacheControlType::Ephemeral,
                breakpoint: PromptLayer::Global.breakpoint_name().unwrap().to_string(),
            });
        }
        messages.push(global_msg);

        // L2: 组织层 — 缓存
        if let Some(ref org) = layers.organization {
            let mut org_msg = ChatMessage {
                role: MessageRole::User,
                content: MessageContent::Text(org.content.clone()),
                name: None,
                cache_control: None,
            };
            if cache_cap.explicit_cache {
                org_msg.cache_control = Some(CacheControlPoint {
                    type_: CacheControlType::Ephemeral,
                    breakpoint: PromptLayer::Organization
                        .breakpoint_name()
                        .unwrap()
                        .to_string(),
                });
            }
            messages.push(org_msg);
        }

        // L3: 项目层 — 缓存
        if let Some(ref proj) = layers.project {
            let mut proj_msg = ChatMessage {
                role: MessageRole::User,
                content: MessageContent::Text(proj.content.clone()),
                name: None,
                cache_control: None,
            };
            if cache_cap.explicit_cache {
                proj_msg.cache_control = Some(CacheControlPoint {
                    type_: CacheControlType::Ephemeral,
                    breakpoint: PromptLayer::Project
                        .breakpoint_name()
                        .unwrap()
                        .to_string(),
                });
            }
            messages.push(proj_msg);
        }

        // L4: 会话层 — 不缓存
        if let Some(session) = session_content {
            messages.push(ChatMessage {
                role: MessageRole::User,
                content: MessageContent::Text(session),
                name: None,
                cache_control: None,
            });
        }

        // L5: 轮次层 — 不缓存
        for turn in &turn_history {
            messages.push(ChatMessage {
                role: turn.role.clone(),
                content: MessageContent::Text(turn.content.clone()),
                name: None,
                cache_control: None,
            });
        }

        messages
    }

    /// 计算内容哈希（使用 xxHash 实现快速比较）
    fn hash_content(content: &str) -> u64 {
        xxhash_rust::xxh3::xxh3_64(content.as_bytes())
    }

    /// 提取模板变量占位符
    fn extract_variables(content: &str) -> Vec<String> {
        let re = regex::Regex::new(r"\{\{(\w+)\}\}").unwrap();
        re.captures_iter(content)
            .map(|cap| cap[1].to_string())
            .collect()
    }
}

#[derive(Debug, thiserror::Error)]
pub enum PromptCacheError {
    #[error("layer {0:?} is not initialized")]
    LayerNotInitialized(PromptLayer),
    #[error("turn layer cannot be updated via update_layer; use append_turn instead")]
    TurnLayerNotUpdatable,
    #[error("template variable {0} not found in context")]
    VariableNotFound(String),
}
```

---

### 15.3 缓存策略

#### 15.3.1 版本化缓存失效

每一层维护独立的版本号，内容变更时版本自增。上层（L1）变更影响最大，需要级联失效：

```
┌─────────────────────────────────────────────────────────────────────┐
│                    版本化缓存失效流程                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  L1 内容变更 (v3 -> v4)                                             │
│       │                                                             │
│       ├── 1. 计算新内容哈希                                          │
│       ├── 2. 哈希不同 -> 版本自增                                    │
│       ├── 3. 通知所有活跃会话：L1 已失效                              │
│       ├── 4. 各会话下次请求时携带新版本号                              │
│       └── 5. Provider 侧缓存自动失效（前缀变化）                      │
│                                                                     │
│  L3 内容变更 (v7 -> v8)                                             │
│       │                                                             │
│       ├── 1. 计算新内容哈希                                          │
│       ├── 2. 哈希不同 -> 版本自增                                    │
│       ├── 3. 仅通知该项目下的活跃会话                                 │
│       └── 4. L1/L2 缓存不受影响（前缀未变）                          │
│                                                                     │
│  关键洞察：                                                          │
│  • L1 变更 -> 所有缓存失效（代价最高，应尽量减少）                     │
│  • L2 变更 -> L1 缓存保留，仅 L2+ 失效                               │
│  • L3 变更 -> L1+L2 缓存保留，仅 L3+ 失效（最常见）                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

```rust
/// 缓存版本追踪器
#[derive(Debug, Clone)]
pub struct CacheVersionTracker {
    /// 各层当前版本号
    layer_versions: HashMap<PromptLayer, u64>,
    /// 各层上次变更时间
    last_changed: HashMap<PromptLayer, i64>,
    /// 异步通知发送端（🆕 P2-3: 使用 bounded channel 替代 UnboundedSender）
    listener_tx: tokio::sync::mpsc::Sender<CacheInvalidationEvent>,
    /// 监听器注册表
    listeners: Arc<RwLock<Vec<Arc<dyn Fn(CacheInvalidationEvent) + Send + Sync>>>>,
}

impl CacheVersionTracker {
    pub fn new() -> Self {
        let listeners =
            Arc::new(RwLock::new(Vec::<Arc<dyn Fn(CacheInvalidationEvent) + Send + Sync>>::new()));
        let (listener_tx, mut listener_rx) = tokio::sync::mpsc::channel(1024); // 🆕 P2-3: bounded channel
        let listeners_for_task = Arc::clone(&listeners);

        tokio::spawn(async move {
            while let Some(event) = listener_rx.recv().await {
                let callbacks = listeners_for_task.read().await.clone();
                for callback in callbacks {
                    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        callback(event.clone());
                    }));

                    if result.is_err() {
                        tracing::error!(
                            layer = ?event.layer,
                            version = event.new_version,
                            "cache invalidation listener panicked"
                        );
                    }
                }
            }
        });

        Self {
            layer_versions: HashMap::new(),
            last_changed: HashMap::new(),
            listener_tx,
            listeners,
        }
    }

    /// 检查指定层是否发生了版本变更
    pub fn has_changed(&self, layer: PromptLayer, known_version: u64) -> bool {
        match self.layer_versions.get(&layer) {
            Some(&current) => current != known_version,
            None => false,
        }
    }

    /// 获取版本变更摘要（用于日志和可观测性）
    pub fn change_summary(&self) -> Vec<(PromptLayer, u64, i64)> {
        self.layer_versions
            .iter()
            .filter_map(|(&layer, &version)| {
                self.last_changed.get(&layer).map(|&ts| (layer, version, ts))
            })
            .collect()
    }

    /// 注册变更监听器
    pub async fn on_change(
        &self,
        listener: impl Fn(CacheInvalidationEvent) + Send + Sync + 'static,
    ) {
        self.listeners.write().await.push(Arc::new(listener));
    }

    /// 将变更事件异步入队
    fn notify_listeners(&self, layer: PromptLayer, new_version: u64) {
        let _ = self.listener_tx.send(CacheInvalidationEvent {
            layer,
            new_version,
            invalidated_at: chrono::Utc::now().timestamp(),
        });
    }

    /// 更新版本后触发失效通知
    pub fn mark_changed(&mut self, layer: PromptLayer) {
        let version = self.layer_versions.entry(layer).or_insert(0);
        *version += 1;
        self.last_changed.insert(layer, chrono::Utc::now().timestamp());
        self.notify_listeners(layer, *version);
    }
}
```

> **实现约束**：缓存失效通知只能“入队”，不能在持有版本锁或 Prompt 层写锁时同步回调监听器。监听器执行由独立异步任务完成；单个监听器 panic 使用 `catch_unwind` 隔离并记录日志，避免把整个缓存管理器拖死。

#### 15.3.2 事件驱动缓存失效

监听模板文件变更，自动触发对应层的缓存失效：

```rust
use notify_debouncer_mini::{
    DebounceEventResult,
    Debouncer,
    new_debouncer,
    notify::{RecommendedWatcher, RecursiveMode, Watcher},
};
use std::path::PathBuf;
use std::time::Duration;

/// 文件变更到 Prompt 层的映射
pub struct FileLayerMapping {
    /// prompts/system/ -> L1 Global
    pub system_dir: PathBuf,
    /// prompts/org/ -> L2 Organization
    pub org_dir: PathBuf,
    /// prompts/project/ -> L3 Project
    pub project_dir: PathBuf,
}

impl FileLayerMapping {
    /// 根据文件路径判断属于哪一层
    pub fn resolve_layer(&self, path: &std::path::Path) -> Option<PromptLayer> {
        if path.starts_with(&self.system_dir) {
            Some(PromptLayer::Global)
        } else if path.starts_with(&self.org_dir) {
            Some(PromptLayer::Organization)
        } else if path.starts_with(&self.project_dir) {
            Some(PromptLayer::Project)
        } else {
            None
        }
    }
}

/// 文件监听配置
pub struct FileWatcherConfig {
    /// debounce 窗口。推荐 100-300ms，默认 200ms。
    pub debounce_window: Duration,
}

impl Default for FileWatcherConfig {
    fn default() -> Self {
        Self {
            debounce_window: Duration::from_millis(200),
        }
    }
}

/// 启动文件监听，自动触发缓存失效
pub fn start_file_watcher(
    mapping: FileLayerMapping,
    manager: Arc<PromptLayerManager>,
) -> Result<Debouncer<RecommendedWatcher>, notify_debouncer_mini::notify::Error> {
    let config = FileWatcherConfig::default();
    let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel::<DebounceEventResult>();

    let mut debouncer = new_debouncer(config.debounce_window, move |result| {
        let _ = tx.send(result);
    })?;

    // 监听三个目录
    debouncer.watcher().watch(&mapping.system_dir, RecursiveMode::Recursive)?;
    debouncer.watcher().watch(&mapping.org_dir, RecursiveMode::Recursive)?;
    debouncer.watcher().watch(&mapping.project_dir, RecursiveMode::Recursive)?;

    // 异步处理去抖后的文件变更事件
    tokio::spawn(async move {
        while let Some(result) = rx.recv().await {
            match result {
                Ok(events) => {
                    for event in events {
                        if let Some(layer) = mapping.resolve_layer(&event.path) {
                            if let Ok(content) = tokio::fs::read_to_string(&event.path).await {
                                if let Ok(true) = manager.update_layer(layer, content).await {
                                    tracing::info!(
                                        layer = ?layer,
                                        path = %event.path.display(),
                                        debounce_ms = config.debounce_window.as_millis(),
                                        "Prompt layer cache invalidated due to debounced file change"
                                    );
                                }
                            } else {
                                tracing::warn!(
                                    layer = ?layer,
                                    path = %event.path.display(),
                                    "Template file removed or unreadable after debounced event"
                                );
                            }
                        }
                    }
                }
                Err(errors) => {
                    tracing::warn!(
                        error_count = errors.len(),
                        "Prompt template watcher produced debouncer errors"
                    );
                }
            }
        }
    });

    Ok(debouncer)
}
```

这里的 `manager.update_layer(...)` 只负责更新内容、递增版本并把 `CacheInvalidationEvent` 推入 channel；真正的监听器执行发生在独立任务中。文件监听层再加一层 `notify-debouncer-mini`，把编辑器在保存时产生的连续 create/modify/rename 事件合并成一次失效更新，避免短时间内重复击穿缓存。

> **Debounce 策略**：模板文件监听默认使用 `200ms` 窗口，推荐范围 `100-300ms`。低于 `100ms` 往往无法有效吸收一次保存产生的事件风暴；高于 `300ms` 会让模板修改后的缓存失效反馈变得明显滞后。

> **依赖选型**：文件监听仍以 `notify` 为底层事件源，但在 Prompt 缓存场景中统一通过 `notify-debouncer-mini` 暴露去抖后的事件流，避免把单次保存拆成多次无意义的缓存失效。

#### 15.3.3 缓存预热

在高峰期前预填充缓存，避免冷启动延迟：

```rust
/// 缓存预热策略
pub struct CacheWarmupStrategy {
    /// 预热时间窗口（相对于高峰期提前多少秒）
    pub warmup_ahead_seconds: u64,
    /// 需要预热的层
    pub layers_to_warmup: Vec<PromptLayer>,
    /// 预热时使用的 Provider 列表
    pub providers: Vec<Arc<dyn LlmProvider>>,
}

impl CacheWarmupStrategy {
    /// 执行缓存预热
    pub async fn warmup(
        &self,
        manager: &PromptLayerManager,
    ) -> Vec<WarmupResult> {
        let mut results = Vec::new();

        for provider in &self.providers {
            let cache_cap = provider.cache_capability();
            if !cache_cap.explicit_cache {
                results.push(WarmupResult {
                    provider_id: provider.provider_id().to_string(),
                    layer: PromptLayer::Global,
                    status: WarmupStatus::Skipped("no explicit cache support".into()),
                });
                continue;
            }

            // 构建最小预热请求（仅包含可缓存层）
            let messages = manager
                .build_messages(provider.as_ref(), None, Vec::new())
                .await;

            // 发送一个最小请求以触发 Provider 侧缓存写入
            match provider.chat(ChatRequest {
                model: provider.model_info().model_id.clone(),
                messages: messages.clone(),
                temperature: Some(0.0),
                max_tokens: Some(1), // 最小 token 消耗
                stop: None,
                tools: None,
                response_format: None,
                cache_control: Vec::new(),
            }).await {
                Ok(_) => {
                    results.push(WarmupResult {
                        provider_id: provider.provider_id().to_string(),
                        layer: PromptLayer::Global,
                        status: WarmupStatus::Success,
                    });
                }
                Err(e) => {
                    results.push(WarmupResult {
                        provider_id: provider.provider_id().to_string(),
                        layer: PromptLayer::Global,
                        status: WarmupStatus::Failed(e.to_string()),
                    });
                }
            }
        }

        results
    }
}

#[derive(Debug)]
pub struct WarmupResult {
    pub provider_id: String,
    pub layer: PromptLayer,
    pub status: WarmupStatus,
}

#[derive(Debug)]
pub enum WarmupStatus {
    Success,
    Skipped(String),
    Failed(String),
}
```

---

### 15.4 Provider 缓存能力适配

#### 15.4.1 与 LlmProvider 的 CacheCapability 联动

第 14 章定义了 `CacheCapability` 结构，本章的缓存策略直接依赖该能力声明：

```rust
/// 根据 Provider 缓存能力决定是否在指定层设置缓存断点
pub fn should_set_cache_breakpoint(
    cache_cap: &CacheCapability,
    layer: PromptLayer,
    layer_token_count: u32,
) -> bool {
    // Provider 不支持显式缓存
    if !cache_cap.explicit_cache {
        return false;
    }

    // 该层本身不应缓存
    if !layer.should_cache() {
        return false;
    }

    // Token 数未达到最小前缀要求
    if layer_token_count < cache_cap.min_prefix_tokens {
        return false;
    }

    // 超过最大可缓存 Token 数
    if let Some(max) = cache_cap.max_cacheable_tokens {
        if layer_token_count > max {
            return false;
        }
    }

    true
}

/// 计算缓存命中时的成本节省
pub fn calculate_cache_savings(
    cache_cap: &CacheCapability,
    cached_tokens: u32,
    input_price_per_1k: f64,
) -> f64 {
    let discount = cache_cap.cache_discount;
    let full_cost = (cached_tokens as f64 / 1000.0) * input_price_per_1k;
    let cached_cost = full_cost * (1.0 - discount);

    // 如果有缓存写入附加费（如 Anthropic +25%）
    let write_surcharge = if discount > 0.5 {
        full_cost * 0.25 // 估算写入附加费
    } else {
        0.0
    };

    full_cost - cached_cost - write_surcharge
}
```

#### 15.4.2 三大 Provider 缓存对比

| 特性 | OpenAI | Anthropic | Google Gemini |
|------|--------|-----------|---------------|
| **缓存机制** | Automatic | Explicit `cache_control` | Automatic |
| **最小前缀** | 1024 tokens | 1024 tokens | 32,768 tokens |
| **缓存读取折扣** | 50% off | 90% off | 75% off |
| **缓存写入费用** | 无额外费用 | +25% surcharge | 无额外费用 |
| **TTL** | 5~10 分钟（滚动） | 5 分钟 | 1 小时 |
| **最大缓存** | 128K tokens | 200K tokens | 1M tokens |
| **控制粒度** | 自动（无法手动控制） | 消息级 breakpoint | 自动 |
| **L1 适配** | 自动命中，无需断点 | 在 L1 末尾设 breakpoint | 自动命中 |
| **L2 适配** | 自动命中 | 在 L2 末尾设 breakpoint | 需 32K+ 前缀 |
| **L3 适配** | 自动命中 | 在 L3 末尾设 breakpoint | 需 32K+ 前缀 |
| **推荐策略** | 简单场景首选 | 精细控制首选 | 超长上下文首选 |

#### 15.4.3 缓存决策流程图

```
┌─────────────────────────────────────────────────────────────────────┐
│                    缓存决策流程                                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  收到 LLM 请求                                                      │
│       │                                                             │
│       ▼                                                             │
│  获取 Provider 的 CacheCapability                                   │
│       │                                                             │
│       ├── explicit_cache = false                                    │
│       │       │                                                     │
│       │       ▼                                                     │
│       │   不设置任何 cache_control                                   │
│       │   依赖 Provider 自动缓存（OpenAI / Gemini）                   │
│       │       │                                                     │
│       │       ▼                                                     │
│       │   确保 L1+L2+L3 内容作为消息前缀排列                         │
│       │   （自动缓存依赖前缀匹配）                                    │
│       │                                                             │
│       ├── explicit_cache = true (Anthropic)                         │
│       │       │                                                     │
│       │       ▼                                                     │
│       │   检查各层 Token 数 >= min_prefix_tokens                     │
│       │       │                                                     │
│       │       ├── L1 >= 1024? ── Yes ──▶ 在 L1 末尾设 breakpoint    │
│       │       │                                                     │
│       │       ├── L1+L2 >= 1024? ── Yes ──▶ 在 L2 末尾设 breakpoint │
│       │       │                                                     │
│       │       └── L1+L2+L3 >= 1024? ── Yes ─▶ 在 L3 末尾设 breakpoint│
│       │                                                             │
│       └── min_prefix_tokens = 32768 (Gemini)                       │
│               │                                                     │
│               ▼                                                     │
│           检查 L1+L2+L3 总 Token 数                                  │
│               │                                                     │
│               ├── >= 32K ──▶ 正常缓存，前缀自动命中                  │
│               │                                                     │
│               └── < 32K  ──▶ 考虑合并层或放弃缓存                    │
│                           （Gemini 对短 Prompt 缓存不友好）           │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

### 15.5 Prompt 模板管理

#### 15.5.1 模板目录结构

```
prompts/
├── system/                          # L1 全局层 — Agent 系统提示
│   ├── coordinator.md               #   Coordinator 系统提示
│   ├── explorer.md                  #   Explorer 系统提示
│   ├── impact-analyzer.md           #   ImpactAnalyzer 系统提示
│   ├── planner.md                   #   Planner 系统提示
│   ├── coder.md                     #   Coder 系统提示
│   ├── reviewer.md                  #   Reviewer 系统提示
│   ├── tester.md                    #   Tester 系统提示
│   ├── debugger.md                  #   Debugger 系统提示
│   ├── research.md                  #   Research 系统提示
│   ├── doc-writer.md                #   DocWriter 系统提示
│   ├── compressor.md                #   上下文压缩助手提示
│   └── large-file-guide.md          #   大文件读取指南（注入到各 Agent）
│
├── tools/                           # L1 全局层 — 工具描述
│   ├── file_operations.json         #   文件读写工具定义
│   ├── search.json                  #   代码搜索工具定义
│   ├── terminal.json                #   终端执行工具定义
│   └── browser.json                 #   浏览器操作工具定义
│
├── org/                             # L2 组织层 — 团队约定
│   ├── coding_standards.md          #   代码规范
│   ├── commit_conventions.md        #   提交信息规范
│   └── review_checklist.md          #   代码审查清单
│
├── project/                         # L3 项目层 — 项目上下文
│   ├── tech_stack.md                #   技术栈描述
│   ├── architecture.md              #   架构决策记录
│   ├── dependencies.md              #   关键依赖说明
│   └── conventions.md               #   项目特有约定
│
└── prompts.lock                     # 模板版本锁文件
```

> **完整提示词内容见第 24 章《Agent 系统提示词定义》**

#### 15.5.2 PromptTemplate 数据结构

```rust
/// Prompt 模板定义
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PromptTemplate {
    /// 模板唯一标识
    pub id: String,
    /// 所属层
    pub layer: PromptLayer,
    /// 模板文件路径（相对于 prompts/ 目录）
    pub file_path: String,
    /// 模板内容（原始，含变量占位符）
    pub raw_content: String,
    /// 提取的变量列表
    pub variables: Vec<TemplateVariable>,
    /// 当前版本
    pub version: u64,
    /// 内容哈希
    pub content_hash: u64,
    /// 最后更新时间
    pub updated_at: i64,
}

/// 模板变量定义
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemplateVariable {
    /// 变量名（不含 {{ }}）
    pub name: String,
    /// 是否必填
    pub required: bool,
    /// 默认值
    pub default_value: Option<String>,
    /// 变量描述
    pub description: String,
}

/// 模板渲染引擎
pub struct TemplateRenderer {
    /// 变量正则: {{variable_name}}
    variable_regex: regex::Regex,
}

impl TemplateRenderer {
    pub fn new() -> Self {
        Self {
            variable_regex: regex::Regex::new(r"\{\{(\w+)\}\}").unwrap(),
        }
    }

    /// 渲染模板：将变量占位符替换为实际值
    pub fn render(
        &self,
        template: &str,
        context: &HashMap<String, String>,
    ) -> Result<String, PromptCacheError> {
        let mut result = template.to_string();

        for capture in self.variable_regex.find_iter(template) {
            let full_match = capture.as_str();
            let var_name = &capture.as_str()[2..capture.as_str().len() - 2]; // 去掉 {{ }}

            match context.get(var_name) {
                Some(value) => {
                    result = result.replace(full_match, value);
                }
                None => {
                    return Err(PromptCacheError::VariableNotFound(var_name.to_string()));
                }
            }
        }

        Ok(result)
    }

    /// 验证模板所需变量是否都在 context 中提供
    pub fn validate_context(
        &self,
        template: &PromptTemplate,
        context: &HashMap<String, String>,
    ) -> Vec<String> {
        template
            .variables
            .iter()
            .filter(|var| var.required && !context.contains_key(&var.name))
            .map(|var| var.name.clone())
            .collect()
    }
}

/// 模板管理器
pub struct TemplateManager {
    /// 模板根目录
    root_dir: PathBuf,
    /// 已加载的模板
    templates: Arc<RwLock<HashMap<String, PromptTemplate>>>,
    /// 渲染引擎
    renderer: TemplateRenderer,
}

impl TemplateManager {
    /// 从文件系统加载所有模板
    pub async fn load_all(&self) -> Result<(), PromptCacheError> {
        let mut templates = self.templates.write().await;

        // 加载 system/ 目录
        self.load_templates_from_dir(&self.root_dir.join("system"), &mut templates)
            .await?;

        // 加载 tools/ 目录
        self.load_templates_from_dir(&self.root_dir.join("tools"), &mut templates)
            .await?;

        // 加载 org/ 目录
        self.load_templates_from_dir(&self.root_dir.join("org"), &mut templates)
            .await?;

        // 加载 project/ 目录
        self.load_templates_from_dir(&self.root_dir.join("project"), &mut templates)
            .await?;

        tracing::info!(count = templates.len(), "All prompt templates loaded");
        Ok(())
    }

    /// 渲染指定模板
    pub async fn render_template(
        &self,
        template_id: &str,
        context: &HashMap<String, String>,
    ) -> Result<String, PromptCacheError> {
        let templates = self.templates.read().await;
        let template = templates
            .get(template_id)
            .ok_or_else(|| PromptCacheError::VariableNotFound(format!(
                "template '{}' not found",
                template_id
            )))?;

        self.renderer.render(&template.raw_content, context)
    }

    async fn load_templates_from_dir(
        &self,
        dir: &PathBuf,
        templates: &mut HashMap<String, PromptTemplate>,
    ) -> Result<(), PromptCacheError> {
        if !dir.exists() {
            return Ok(());
        }

        let mut entries = tokio::fs::read_dir(dir).await?;
        while let Some(entry) = entries.next_entry().await? {
            let path = entry.path();
            if path.is_file() {
                let content = tokio::fs::read_to_string(&path).await?;
                let id = path.file_stem().unwrap().to_string_lossy().to_string();

                let variables = self.extract_variable_definitions(&content);

                templates.insert(
                    id.clone(),
                    PromptTemplate {
                        id,
                        layer: self.path_to_layer(&path),
                        file_path: path
                            .strip_prefix(&self.root_dir)
                            .unwrap()
                            .to_string_lossy()
                            .to_string(),
                        raw_content: content,
                        variables,
                        version: 1,
                        content_hash: 0,
                        updated_at: chrono::Utc::now().timestamp(),
                    },
                );
            }
        }
        Ok(())
    }

    fn extract_variable_definitions(&self, content: &str) -> Vec<TemplateVariable> {
        let re = regex::Regex::new(r"\{\{(\w+)\}\}").unwrap();
        let mut vars: Vec<TemplateVariable> = Vec::new();
        let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();

        for cap in re.captures_iter(content) {
            let name = cap[1].to_string();
            if seen.insert(name.clone()) {
                vars.push(TemplateVariable {
                    name,
                    required: true,
                    default_value: None,
                    description: format!("Template variable: {{{}}}", &cap[0]),
                });
            }
        }
        vars
    }

    fn path_to_layer(&self, path: &std::path::Path) -> PromptLayer {
        let path_str = path.to_string_lossy();
        if path_str.contains("/system/") || path_str.contains("/tools/") {
            PromptLayer::Global
        } else if path_str.contains("/org/") {
            PromptLayer::Organization
        } else if path_str.contains("/project/") {
            PromptLayer::Project
        } else {
            PromptLayer::Session
        }
    }
}
```

#### 15.5.3 变量替换示例

```rust
/// 项目上下文变量集合
pub fn build_project_context(
    project_name: &str,
    tech_stack: &str,
    framework: &str,
    language: &str,
) -> HashMap<String, String> {
    let mut ctx = HashMap::new();
    ctx.insert("project_name".into(), project_name.into());
    ctx.insert("tech_stack".into(), tech_stack.into());
    ctx.insert("framework".into(), framework.into());
    ctx.insert("language".into(), language.into());
    ctx.insert("current_date".into(), chrono::Utc::now().format("%Y-%m-%d").to_string());
    ctx
}

// 使用示例
#[tokio::main]
async fn example() {
    let renderer = TemplateRenderer::new();
    let template_content = r#"
You are a senior {{language}} developer working on {{project_name}}.

Tech Stack: {{tech_stack}}
Framework: {{framework}}

Follow the project conventions and coding standards.
"#.to_string();

    let context = build_project_context(
        "MoreCode",
        "Rust + TypeScript + PostgreSQL",
        "Tauri v2",
        "Rust",
    );

    let rendered = renderer.render(&template_content, &context).unwrap();
    // rendered 包含实际项目信息，无 {{ }} 占位符残留
}
```

#### 15.5.4 prompts.lock 锁文件

```rust
/// prompts.lock — 模板版本锁定文件
///
/// 格式: TOML
/// 作用: 记录每个模板的精确版本和哈希，防止意外变更导致缓存大面积失效
///
/// [template.planner]
/// version = 3
/// content_hash = 1234567890
/// file_path = "system/planner.md"
/// updated_at = 1714000000
///
/// [template.coder]
/// version = 5
/// content_hash = 9876543210
/// file_path = "system/coder.md"
/// updated_at = 1714100000

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PromptsLock {
    /// 锁文件版本号（锁文件格式本身的版本）
    pub lock_version: u32,
    /// 生成时间
    pub generated_at: i64,
    /// 各模板的锁定信息
    pub templates: HashMap<String, TemplateLockEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemplateLockEntry {
    /// 模板版本号
    pub version: u64,
    /// 内容哈希
    pub content_hash: u64,
    /// 文件路径
    pub file_path: String,
    /// 最后更新时间
    pub updated_at: i64,
}

impl PromptsLock {
    /// 从当前模板状态生成锁文件
    pub async fn generate(manager: &TemplateManager) -> Self {
        let templates = manager.templates.read().await;
        let mut lock_entries = HashMap::new();

        for (id, template) in templates.iter() {
            lock_entries.insert(
                id.clone(),
                TemplateLockEntry {
                    version: template.version,
                    content_hash: template.content_hash,
                    file_path: template.file_path.clone(),
                    updated_at: template.updated_at,
                },
            );
        }

        Self {
            lock_version: 1,
            generated_at: chrono::Utc::now().timestamp(),
            templates: lock_entries,
        }
    }

    /// 验证当前模板状态是否与锁文件一致
    pub async fn verify(
        &self,
        manager: &TemplateManager,
    ) -> Vec<LockMismatch> {
        let templates = manager.templates.read().await;
        let mut mismatches = Vec::new();

        for (id, locked) in &self.templates {
            match templates.get(id) {
                Some(current) => {
                    if current.content_hash != locked.content_hash {
                        mismatches.push(LockMismatch {
                            template_id: id.clone(),
                            expected_hash: locked.content_hash,
                            actual_hash: current.content_hash,
                            expected_version: locked.version,
                            actual_version: current.version,
                        });
                    }
                }
                None => {
                    mismatches.push(LockMismatch {
                        template_id: id.clone(),
                        expected_hash: locked.content_hash,
                        actual_hash: 0,
                        expected_version: locked.version,
                        actual_version: 0,
                    });
                }
            }
        }

        mismatches
    }
}

#[derive(Debug)]
pub struct LockMismatch {
    pub template_id: String,
    pub expected_hash: u64,
    pub actual_hash: u64,
    pub expected_version: u64,
    pub actual_version: u64,
}
```

---

### 15.6 设计决策

| 决策 | 选择 | 理由 |
|------|------|------|
| **缓存层数** | 五层（L1-L5） | 比二层（缓存/不缓存）更精细，可缓存 60%+ 的 token，实测节省 50-67% 成本。三层太少无法区分组织与项目变更频率差异 |
| **缓存失效策略** | 版本化 + 事件驱动双机制 | 版本化提供精确的变更检测，事件驱动提供实时响应。两者互补避免缓存不一致 |
| **模板格式** | Markdown + JSON | 系统提示用 Markdown（人类可读、支持注释），工具定义用 JSON（机器可解析、与 Provider API 兼容） |
| **变量语法** | `{{variable_name}}` | 与 Mustache/Handlebars 一致，开发者熟悉；双花括号不易与正常文本冲突 |
| **版本管理** | prompts.lock 锁文件 | 类似 Cargo.lock 的设计理念，防止模板意外变更导致缓存大面积失效；CI/CD 中可验证一致性 |
| **缓存预热** | 高峰期前主动触发 | Provider 侧缓存有冷启动延迟（首次写入需额外费用），预热可确保用户请求直接命中缓存 |
| **文件监听** | `notify-debouncer-mini` + 异步处理 | 基于 `notify` 做 100-300ms debounce，默认 200ms，减少保存时的重复事件和不必要的缓存失效；仅监听 L1-L3 目录，L4/L5 为运行时数据 |
| **失效通知** | channel 异步通知 + `catch_unwind` | 版本更新与监听器执行解耦，避免同步回调重入锁导致死锁；单个监听器 panic 不影响其他监听器 |
| **哈希算法** | `xxhash-rust` (`xxh3`) | 速度足够快，且输出在跨进程/跨版本场景下更稳定，适合模板内容比较；无需加密级哈希 |
| **Provider 适配** | CacheCapability 联动 | 复用第 14 章的能力声明，避免重复定义；缓存策略自动适配不同 Provider |
| **L4/L5 不缓存** | 明确不设置缓存断点 | 会话和轮次内容变化频率太高，缓存命中率极低，设置断点反而增加写入开销 |

---

### 15.7 工具定义缓存与延迟加载协同

工具定义既是高价值缓存对象，也是最容易被“动态改动”破坏缓存命中的部分。本节补充一条原则：**优先保持工具目录前缀稳定，再决定哪些工具当前可见、可调用或延迟加载。**

#### 15.7.1 官方行为约束

| Provider | 官方行为 | 对缓存的影响 |
|------|------|------|
| **Anthropic** | Prompt caching 按 `tools -> system -> messages` 顺序计算前缀；工具定义变化会使该前缀后的缓存失效；`defer_loading` 工具会在缓存键计算前被移除 | 非核心工具适合放入 deferred catalog，避免污染缓存前缀 |
| **OpenAI** | 官方建议保持工具数组不变，并使用 `allowed_tools` 指定当前可调用子集，以最大化 prompt caching | 更适合“稳定目录 + 动态放行”，不适合每轮裁剪工具数组 |
| **其他 Provider** | 多数只把 `tools` 当普通请求字段处理 | 只能依赖 MoreCode 自己维持 JSON 稳定排序与版本控制 |

#### 15.7.2 模板目录扩展

在现有 `prompts/tools/` 基础上，增加工具可见性分层：

```text
prompts/
├── system/
├── tools/
│   ├── catalog/
│   │   ├── core.json          # 高频工具，默认进入稳定前缀
│   │   ├── extended.json      # 扩展工具，默认保留在目录中
│   │   └── deferred.json      # 仅 Anthropic/支持 defer_loading 的 Provider 使用
│   ├── briefs.md              # 所有工具的一句话简介（可选）
│   └── allowed-subsets/
│       ├── coder.json
│       ├── reviewer.json
│       └── explorer.json
├── org/
├── project/
└── prompts.lock
```

这里的关键不是把工具“拆得越细越好”，而是让**稳定层**和**动态层**分离：

- `catalog/*.json`：尽量稳定，版本低频变化，适合缓存。
- `allowed-subsets/*.json`：体积很小，可放在会话层或轮次层动态生成。
- `briefs.md`：只在缺少原生工具发现能力的 Provider 上启用。

#### 15.7.3 MoreCode 的缓存规则

| 规则 | 原因 |
|------|------|
| 工具 JSON 必须稳定排序 | 避免无意义字段顺序变化导致缓存失效 |
| 工具 schema 版本仅在参数变化时递增 | 描述文案微调不应频繁击穿缓存 |
| 角色子集与工具目录分离存储 | 子集变化比 schema 变化频繁得多 |
| 能用 `allowed_tools` / `defer_loading` 时，不重建 tools 数组 | 保持高价值前缀稳定 |
| 应用层懒加载补发 schema 时，不进入共享缓存层 | 它是低频 fallback，不值得污染全局缓存 |

#### 15.7.4 Prompt 组装建议

```text
L1 Global
  -> System Prompt
  -> Stable Tool Catalog

L2/L3
  -> 组织/项目约束

L4 Session
  -> Agent 角色
  -> allowed_tools / deferred tool policy

L5 Turn
  -> 当前输入 / 对话历史 / fallback reload 提示
```

这意味着：

- **Anthropic**：`Stable Tool Catalog` 中的长尾工具可以标记 `defer_loading`，既保留目录完整性，又不进入缓存前缀。
- **OpenAI**：`Stable Tool Catalog` 尽量固定；按回合切换 `allowed_tools`，而不是裁剪工具 JSON。
- **Fallback Provider**：只有在无原生能力时，才把“补发 schema 并重试”的提示放进 L5。

#### 15.7.5 设计结论

`25-新功能.md` 最初提出的“工具简介 + 懒加载”思路没有被废弃，但已被重构为更稳妥的两层策略：

1. **Provider 原生能力优先**：Anthropic 用 `defer_loading`，OpenAI 用 `allowed_tools`。
2. **缓存前缀稳定优先**：只要能稳定目录，就不要每轮重建工具数组。
3. **应用层补发 schema 作为兜底**：仅在 Provider 缺少原生支持时使用。
