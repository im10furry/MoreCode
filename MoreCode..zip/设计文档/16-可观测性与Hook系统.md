# MoreCode — 可观测性与 Hook 系统

## 16. 可观测性与 Hook 系统

### 16.1 核心思想

Agent 系统的执行链路复杂（多 Agent 并行、递归编排、工具调用），需要结构化的可观测性来调试、监控和优化。与传统的 Web 服务不同，Agent 系统的请求不是"进-出"模型，而是"规划-执行-反思-重试"的循环模型，一次用户请求可能触发数十次 LLM 调用、工具调用和上下文压缩。

```
┌─────────────────────────────────────────────────────────────────────┐
│               传统 Web 服务 vs Agent 系统 — 可观测性挑战对比           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  传统 Web 服务：                                                     │
│  ┌──────┐    ┌──────┐    ┌──────┐    ┌──────┐                      │
│  │Request│───>│Handler│───>│ Query│───>│Response│                   │
│  └──────┘    └──────┘    └──────┘    └──────┘                      │
│  单链路，一次追踪即可覆盖全部                                        │
│                                                                     │
│  Agent 系统：                                                        │
│  ┌──────┐    ┌────────┐    ┌──────┐    ┌──────┐                    │
│  │User  │───>│Planner │───>│Coder │───>│Tester│                    │
│  │Query │    │Agent   │    │Agent │    │Agent │                    │
│  └──────┘    └───┬────┘    └──┬───┘    └──┬───┘                    │
│                  │            │            │                         │
│              ┌───▼───┐   ┌───▼───┐   ┌───▼───┐                    │
│              │ LLM   │   │Tool   │   │ LLM   │                    │
│              │ Call  │   │ Calls │   │ Call  │                    │
│              └───────┘   └───────┘   └───────┘                    │
│                  │            │            │                         │
│              ┌───▼────────────▼────────────▼───┐                    │
│              │      Context Compression        │                    │
│              │      Memory Read/Write          │                    │
│              │      Permission Check           │                    │
│              └─────────────────────────────────┘                    │
│                                                                     │
│  多链路并行 + 递归嵌套 + 动态工具调用，追踪复杂度呈指数级增长         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**可观测性系统的设计目标**：

1. **全链路追踪**：从用户输入到最终输出，覆盖每个 Agent、每次 LLM 调用、每次工具执行
2. **成本透明**：实时追踪 Token 消耗和 API 成本，支持预算告警
3. **性能分析**：识别瓶颈 Agent、慢工具调用、上下文膨胀点
4. **调试友好**：支持按 Session 回放完整执行过程
5. **隐私可控**：三级隐私策略，满足不同场景的安全需求
6. **可扩展**：Hook 系统提供扩展点，支持自定义监控逻辑

### 16.2 Agent 专用 Span 类型

参考 AgentTelemetry 的 9 种 Span 类型，MoreCode 定义了一套完整的 Agent 专用 Span 体系。每个 Span 类型对应 Agent 执行生命周期中的一个关键事件，携带结构化的属性数据。

```rust
/// Agent 系统专用 Span 类型定义
///
/// 每个 Span 类型对应 Agent 执行生命周期中的一个关键事件。
/// 所有 Span 均携带 session_id、agent_id、timestamp 三个基础属性。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AgentSpanKind {
    // ── Agent 生命周期 ──────────────────────────────────────────
    /// Agent 执行的完整生命周期
    /// 属性: agent_type, input_tokens, output_tokens, status, error
    Agent,

    // ── LLM 调用 ──────────────────────────────────────────────
    /// 单次 LLM API 调用
    /// 属性: model, provider, input_tokens, output_tokens,
    ///       latency_ms, cost_usd, prompt_hash
    LlmCall,

    // ── 工具调用 ──────────────────────────────────────────────
    /// 单次工具调用（文件读写、Shell 执行、HTTP 请求等）
    /// 属性: tool_name, tool_args, result_status, latency_ms,
    ///       result_size_bytes
    ToolCall,

    // ── 记忆系统 ──────────────────────────────────────────────
    /// 从记忆存储读取
    /// 属性: memory_type(short/long), query_key, hit, latency_ms
    MemoryRead,

    /// 写入记忆存储
    /// 属性: memory_type(short/long), key, size_bytes, ttl
    MemoryWrite,

    // ── 上下文管理 ────────────────────────────────────────────
    /// 上下文压缩事件
    /// 属性: strategy(L1/L2/L3), before_tokens, after_tokens,
    ///       compression_ratio, cost_tokens
    ContextCompress,

    // ── 安全与路由 ────────────────────────────────────────────
    /// 权限检查
    /// 属性: permission_type, resource, decision(allow/deny),
    ///       reason
    PermissionCheck,

    /// Agent 路由决策
    /// 属性: input_summary, selected_agent, confidence,
    ///       candidates_count
    RouteDecision,

    // ── 错误处理 ──────────────────────────────────────────────
    /// 错误事件
    /// 属性: error_type, error_message, source_span,
    ///       recovery_action
    Error,
}

/// Span 上下文 — 携带追踪链路信息
#[derive(Debug, Clone)]
pub struct AgentSpanContext {
    pub trace_id:   String,       // 全局唯一追踪 ID
    pub span_id:    String,       // 当前 Span ID
    pub parent_id:  Option<String>, // 父 Span ID（嵌套调用时）
    pub session_id: String,       // 会话 ID
    pub agent_id:   String,       // 当前 Agent ID
}

/// Span 属性 — 结构化的键值对
pub type SpanAttributes = HashMap<String, SpanValue>;

#[derive(Debug, Clone)]
pub enum SpanValue {
    String(String),
    Int(i64),
    Float(f64),
    Bool(bool),
    // 隐私敏感值 — 根据隐私策略决定是否导出
    Sensitive(String),
}

/// 创建一个带属性的 Span
#[macro_export]
macro_rules! agent_span {
    ($kind:expr, $ctx:expr, $($key:expr => $val:expr),* $(,)?) => {{
        let mut attrs = SpanAttributes::new();
        $(
            attrs.insert($key.to_string(), $val.into());
        )*
        AgentSpan::new($kind, $ctx, attrs)
    }};
}
```

**Span 嵌套关系示例**：

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Span 嵌套关系 — 一次用户请求                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  [AgentSpan: Planner]  ──────────────────────────────────────────   │
│  │                                                                  │
│  ├── [LlmCallSpan: gpt-4o, 1200 tokens]                           │
│  │                                                                  │
│  ├── [RouteDecisionSpan: -> Coder, confidence=0.92]                │
│  │                                                                  │
│  ├── [AgentSpan: Coder]  ──────────────────────────────────────    │
│  │   │                                                              │
│  │   ├── [MemoryReadSpan: short_term, key="project_context"]       │
│  │   │                                                              │
│  │   ├── [LlmCallSpan: claude-3.5, 3400 tokens]                   │
│  │   │                                                              │
│  │   ├── [ToolCallSpan: file_write, path="src/main.rs"]            │
│  │   │                                                              │
│  │   ├── [PermissionCheckSpan: file_write -> ALLOW]                │
│  │   │                                                              │
│  │   ├── [ToolCallSpan: shell_exec, cmd="cargo build"]             │
│  │   │   └── [ErrorSpan: compilation_failed]                       │
│  │   │                                                              │
│  │   ├── [LlmCallSpan: claude-3.5, 2800 tokens]  (重试)           │
│  │   │                                                              │
│  │   └── [ToolCallSpan: shell_exec, cmd="cargo build"]  (成功)     │
│  │                                                                  │
│  ├── [ContextCompressSpan: L1, 85% -> 62%]                         │
│  │                                                                  │
│  └── [AgentSpan: Tester]  ──────────────────────────────────────    │
│      │                                                              │
│      ├── [LlmCallSpan: gpt-4o, 1500 tokens]                       │
│      └── [ToolCallSpan: shell_exec, cmd="cargo test"]              │
│                                                                     │
│  总耗时: 12.4s | 总 Token: 8,900 | 总成本: $0.042                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 16.3 三层可观测性架构

系统采用经典的三层可观测性架构，每一层都可以独立替换，但默认配置使用 Rust 生态的标准工具链。

```
┌─────────────────────────────────────────────────────────────────────┐
│                    三层可观测性架构                                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    展示层 (Visualization)                    │   │
│  │                                                             │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │   │
│  │  │   Langfuse   │  │   Grafana    │  │   Jaeger     │      │   │
│  │  │  (自托管)     │  │  + Prometheus│  │  (备选)      │      │   │
│  │  │              │  │              │  │              │      │   │
│  │  │ - Trace 查看  │  │ - 指标仪表盘 │  │ - Trace 查看  │      │   │
│  │  │ - Prompt 管理 │  │ - 告警规则   │  │ - 依赖拓扑   │      │   │
│  │  │ - 成本分析    │  │ - 趋势分析   │  │ - 性能分析   │      │   │
│  │  │ - Session回放 │  │              │  │              │      │   │
│  │  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │   │
│  └─────────┼─────────────────┼─────────────────┼───────────────┘   │
│            │                 │                 │                     │
│            │  OTLP/gRPC      │  Prometheus     │  OTLP/gRPC         │
│            │                 │  /metrics       │                     │
│  ┌─────────▼─────────────────▼─────────────────▼───────────────┐   │
│  │                    导出层 (Export)                           │   │
│  │                                                             │   │
│  │  ┌──────────────────────────────────────────────────────┐   │   │
│  │  │              tracing-opentelemetry                    │   │   │
│  │  │                                                      │   │   │
│  │  │  - OTLP Exporter  (gRPC → Langfuse/Jaeger)          │   │   │
│  │  │  - Prometheus Exporter  (HTTP → Grafana)             │   │   │
│  │  │  - BatchProcessor  (批量导出，减少网络开销)            │   │   │
│  │  │  - 隐私过滤器  (根据 PrivacyLevel 脱敏)               │   │   │
│  │  └──────────────────────────────────────────────────────┘   │   │
│  └────────────────────────────┬────────────────────────────────┘   │
│                               │                                     │
│                               │  OpenTelemetry API                  │
│  ┌────────────────────────────▼────────────────────────────────┐   │
│  │                    采集层 (Collection)                       │   │
│  │                                                             │   │
│  │  ┌──────────────────────────────────────────────────────┐   │   │
│  │  │                   tracing crate                       │   │   │
│  │  │                                                      │   │   │
│  │  │  #[tracing::instrument]                               │   │   │
│  │  │  async fn execute_agent(...) {                        │   │   │
│  │  │      let span = tracing::info_span!(                  │   │   │
│  │  │          "agent.execute",                              │   │   │
│  │  │          agent_type = %self.agent_type,                │   │   │
│  │  │          session_id = %ctx.session_id,                 │   │   │
│  │  │      );                                                │   │   │
│  │  │      let _guard = span.enter();                        │   │   │
│  │  │      // ... Agent 执行逻辑                             │   │   │
│  │  │  }                                                    │   │   │
│  │  └──────────────────────────────────────────────────────┘   │   │
│  │                                                             │   │
│  │  ┌──────────────────┐  ┌──────────────────┐                │   │
│  │  │ AgentSpan Layer  │  │ Metrics Layer    │                │   │
│  │  │                  │  │                  │                │   │
│  │  │ - agent_span!    │  │ - session.count  │                │   │
│  │  │   宏自动创建     │  │ - token.usage    │                │   │
│  │  │ - 自动关联       │  │ - cost.usage     │                │   │
│  │  │   parent span   │  │ - agent.duration │                │   │
│  │  │ - 属性注入       │  │ - tool.call      │                │   │
│  │  └──────────────────┘  └──────────────────┘                │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**采集层初始化代码**：

> **运行时修复（P1-9）**：`init_observability` 很可能在已有 Tokio 上下文中被调用，例如 CLI 主循环、Daemon 模式或异步测试。此时如果再手动 `tokio::runtime::Runtime::new()`，就容易形成嵌套 runtime，并触发 panic。OpenTelemetry 已提供 `opentelemetry_sdk::runtime::Tokio` 作为运行时适配层，应优先复用它而不是手动新建 runtime。

```rust
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};
use opentelemetry::{global, trace::TracerProvider};
use opentelemetry_otlp::{WithExportConfig, new_exporter};
use opentelemetry_sdk::{
    runtime::Tokio,
    trace::{BatchConfig, RandomIdGenerator, Sampler},
};

/// 初始化可观测性系统
///
/// 根据配置同时启用 tracing 日志、OTel 追踪和 Prometheus 指标。
pub fn init_observability(config: &ObservabilityConfig) -> Result<ObservabilityHandle> {
    // 1. 构建 OTel TracerProvider
    let batch_config = BatchConfig::default()
        .with_max_queue_size(config.export_batch_size)
        .with_scheduled_delay(std::time::Duration::from_millis(config.export_interval_ms));

    // ⚠️ 安全要求：OTLP endpoint 必须使用 HTTPS（wss:// 或 https://）
    // 禁止使用明文 HTTP 传输追踪数据，防止敏感信息泄露
    let exporter = new_exporter()
        .tonic()
        .with_endpoint(&config.otlp_endpoint)
        // 生产环境应启用 TLS：
        // .with_tls_config(tonic::transport::ClientTlsConfig::new().with_native_roots())
        .build()?;

    let provider = TracerProvider::builder()
        .with_batch_exporter(exporter, Tokio)
        .with_config(
            opentelemetry_sdk::trace::Config::default()
                .with_sampler(Sampler::ParentBased(Box::new(Sampler::TraceIdRatioBased(
                    config.sample_rate,
                ))))
                .with_id_generator(RandomIdGenerator::default())
                .with_resource(Resource::new(vec![
                    KeyValue::new("service.name", "morecode-agent"),
                    KeyValue::new("service.version", env!("CARGO_PKG_VERSION")),
                ])),
        )
        .build();

    global::set_tracer_provider(provider.clone());

    // 2. 创建 tracing 层 — 日志 + OTel 追踪
    let otel_layer = tracing_opentelemetry::layer()
        .with_tracer(global::tracer("morecode-agent"))
        .with_filter(PrivacyFilter::new(config.privacy_level));

    let log_layer = tracing_subscriber::fmt::layer()
        .with_target(true)
        .with_thread_ids(true)
        .with_filter(tracing_subscriber::filter::LevelFilter::from(config.log_level));

    tracing_subscriber::registry()
        .with(otel_layer)
        .with(log_layer)
        .init();

    Ok(ObservabilityHandle { provider })
}

/// 隐私过滤器 — 根据隐私级别过滤 Span 属性
struct PrivacyFilter {
    level: PrivacyLevel,
}

impl<S> tracing_subscriber::Layer<S> for PrivacyFilter
where
    S: tracing::Subscriber + for<'span> tracing_subscriber::registry::LookupSpan<'span>,
{
    fn on_event(&self, event: &tracing::Event<'_>, _ctx: Context<'_, S>) {
        // 根据隐私级别过滤事件中的敏感属性
        // NONE: 导出所有数据（含完整 prompt/response）
        // METADATA_ONLY: 移除 prompt/response 内容，保留元数据
        // FULL: 仅导出 Span 名称和基础属性
        let mut visitor = PrivacyVisitor::new(self.level);
        event.record(&mut visitor);
        // 如果事件包含需要过滤的敏感字段，则根据级别决定是否丢弃
        match self.level {
            PrivacyLevel::None => {
                // 保留所有事件，不做过滤
            }
            PrivacyLevel::MetadataOnly => {
                // 过滤掉包含敏感信息的事件属性（如 prompt、response）
                // 仅保留元数据字段（如模型名、Token 数、耗时）
                if visitor.has_sensitive_fields() {
                    // 将敏感字段值替换为 "[REDACTED]"
                    visitor.redact_sensitive();
                }
            }
            PrivacyLevel::Full => {
                // 最严格模式：仅保留标识属性，过滤所有其他内容
                if !visitor.has_identity_only() {
                    // 事件不包含任何标识属性，完全跳过
                    return;
                }
            }
        }
    }
}
```

**实现约束：**

- `opentelemetry_sdk` 需启用 `rt-tokio` 特性，才能使用 `runtime::Tokio`
- `init_observability` 应在应用已有的 Tokio 运行时内初始化，而不是私自创建新的 runtime
- 如果某些极早期启动阶段尚未进入 Tokio 上下文，应把可观测性初始化延后到异步入口完成后执行

```rust
// ✅ 推荐：复用现有 Tokio runtime
let provider = TracerProvider::builder()
    .with_batch_exporter(exporter, Tokio)
    .build();

// ❌ 不推荐：在 init_observability 内部手动 new 一个 runtime
let provider = TracerProvider::builder()
    .with_batch_exporter(exporter, tokio::runtime::Runtime::new()?)
    .build();
```

### 16.4 隐私控制

Agent 系统处理的数据可能包含用户的源代码、配置文件、API 密钥等敏感信息。可观测性系统必须提供细粒度的隐私控制，防止敏感数据通过追踪链路泄露。

```
┌─────────────────────────────────────────────────────────────────────┐
│                    三级隐私策略                                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  PrivacyLevel::NONE                                         │   │
│  │  ─────────────────────                                      │   │
│  │  导出所有数据，包含完整 prompt、response、文件内容            │   │
│  │                                                             │   │
│  │  适用场景: 本地开发、调试模式、安全隔离环境                   │   │
│  │  风险等级: 高 — 敏感数据可能泄露到日志/追踪系统              │   │
│  │                                                             │   │
│  │  导出内容:                                                   │   │
│  │  ✓ model: "gpt-4o"                                         │   │
│  │  ✓ prompt: "请帮我重构这个函数..." (完整内容)                │   │
│  │  ✓ response: "好的，我来重构..." (完整内容)                  │   │
│  │  ✓ tool_args: { "path": "/etc/passwd" } (完整参数)          │   │
│  │  ✓ file_content: "API_KEY=sk-xxx..." (完整文件内容)         │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  PrivacyLevel::METADATA_ONLY  (默认)                         │   │
│  │  ─────────────────────────────────                           │   │
│  │  仅导出元数据：模型名、Token 数、成本、耗时                  │   │
│  │  不导出 prompt/response 内容、文件内容、工具参数              │   │
│  │                                                             │   │
│  │  适用场景: 生产环境、团队协作、云端部署                      │   │
│  │  风险等级: 低 — 不包含任何用户数据内容                       │   │
│  │                                                             │   │
│  │  导出内容:                                                   │   │
│  │  ✓ model: "gpt-4o"                                         │   │
│  │  ✗ prompt: "[REDACTED: 1,234 tokens]"                       │   │
│  │  ✗ response: "[REDACTED: 567 tokens]"                       │   │
│  │  ✓ input_tokens: 1234                                       │   │
│  │  ✓ output_tokens: 567                                       │   │
│  │  ✓ cost_usd: 0.0234                                         │   │
│  │  ✓ latency_ms: 1234                                         │   │
│  │  ✗ tool_args: "[REDACTED]"                                  │   │
│  │  ✗ file_content: "[REDACTED: 4,567 bytes]"                  │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  PrivacyLevel::FULL                                         │   │
│  │  ─────────────────────                                      │   │
│  │  最严格模式：仅导出 Span 名称和基础标识符                    │   │
│  │  不导出任何业务数据，包括 Token 数和成本                     │   │
│  │                                                             │   │
│  │  适用场景: 合规要求严格的金融/医疗场景、第三方审计           │   │
│  │  风险等级: 极低 — 几乎无信息泄露风险                        │   │
│  │                                                             │   │
│  │  导出内容:                                                   │   │
│  │  ✓ span_kind: "llm_call"                                   │   │
│  │  ✓ session_id: "abc-123"                                    │   │
│  │  ✓ agent_id: "coder-001"                                    │   │
│  │  ✗ model: "[REDACTED]"                                     │   │
│  │  ✗ prompt: "[REDACTED]"                                    │   │
│  │  ✗ input_tokens: "[REDACTED]"                               │   │
│  │  ✗ cost_usd: "[REDACTED]"                                  │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

```rust
/// 隐私级别定义
#[derive(Debug, Clone, Copy, Serialize, Deserialize, Default, PartialEq, Eq)]
pub enum PrivacyLevel {
    /// 导出所有数据（含完整 prompt/response）
    /// 仅用于本地开发调试
    None,

    /// 仅导出元数据（模型名、Token 数、成本、耗时）
    /// 默认级别，适用于大多数场景
    #[default]
    MetadataOnly,

    /// 最严格模式，仅导出 Span 标识符
    /// 适用于合规要求严格的场景
    Full,
}

impl PrivacyLevel {
    /// 判断某个属性是否应该被导出
    pub fn should_export(&self, attr_key: &str) -> bool {
        match self {
            PrivacyLevel::None => {
                // 即使在 None 模式下，仍过滤高敏感字段（api_key、password、token、secret）
                !Self::is_highly_sensitive_attr(attr_key)
            }
            PrivacyLevel::MetadataOnly => !Self::is_sensitive_attr(attr_key),
            PrivacyLevel::Full => Self::is_identity_attr(attr_key),
        }
    }

    /// 高敏感属性 — 即使在 NONE 模式下也过滤
    const HIGHLY_SENSITIVE_ATTRS: &[&str] = &[
        "api_key", "api_secret", "password", "access_token",
        "refresh_token", "secret_key", "private_key",
    ];

    /// 敏感属性 — 仅 METADATA_ONLY 和 FULL 模式下过滤
    const SENSITIVE_ATTRS: &[&str] = &[
        "prompt", "response", "file_content", "tool_args",
        "tool_result", "memory_content", "error_message",
    ];

    /// 标识属性 — 所有模式下都导出
    const IDENTITY_ATTRS: &[&str] = &[
        "span_kind", "session_id", "agent_id", "trace_id",
    ];

    fn is_highly_sensitive_attr(key: &str) -> bool {
        Self::HIGHLY_SENSITIVE_ATTRS.iter().any(|s| key.contains(s))
    }

    fn is_sensitive_attr(key: &str) -> bool {
        Self::SENSITIVE_ATTRS.iter().any(|s| key.contains(s))
    }

    fn is_identity_attr(key: &str) -> bool {
        Self::IDENTITY_ATTRS.iter().any(|s| key.contains(s))
    }
}
```

### 16.5 Hook 系统

Hook 系统为 Agent 执行提供扩展点，允许用户在关键事件发生前后注入自定义逻辑。与可观测性系统（只读观察）不同，Hook 系统可以**修改执行行为**——例如拒绝危险工具调用、修改 LLM 参数、注入额外上下文。

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Hook 系统架构                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Agent 执行流程 + Hook 注入点:                                       │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                                                             │   │
│  │  PreAgent Hook ──────┐                                      │   │
│  │                      │                                      │   │
│  │  ┌───────────────────▼──────────────────┐                   │   │
│  │  │         Agent 执行                   │                   │   │
│  │  │                                      │                   │   │
│  │  │  ┌─ PreTool Hook ────┐              │                   │   │
│  │  │  │                   │              │                   │   │
│  │  │  │  ┌─ Tool 执行 ──┐ │              │                   │   │
│  │  │  │  │              │ │              │                   │   │
│  │  │  │  └── PostTool ──┘ │              │                   │   │
│  │  │  │      Hook         │              │                   │   │
│  │  │  └───────────────────┘              │                   │   │
│  │  │                                      │                   │   │
│  │  └──────────────────────────────────────┘                   │   │
│  │                      │                                      │   │
│  │  PostAgent Hook ─────┘                                      │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  Hook 返回值决定后续行为:                                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                         │
│  │  Allow   │  │   Deny   │  │  Modify  │                         │
│  │  正常执行 │  │  阻止执行 │  │ 修改参数  │                         │
│  │  返回原结果│  │  返回错误 │  │  后继续执行│                         │
│  └──────────┘  └──────────┘  └──────────┘                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

```rust
/// Hook 事件类型
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum HookEvent {
    /// 工具调用前 — 可修改参数或拒绝调用
    PreTool {
        tool_name: String,
        tool_args: serde_json::Value,
        agent_id: String,
    },

    /// 工具调用后 — 可修改结果或记录日志
    PostTool {
        tool_name: String,
        tool_args: serde_json::Value,
        result: HookResult,
        duration_ms: u64,
        agent_id: String,
    },

    /// Agent 执行前 — 可注入额外上下文或修改配置
    PreAgent {
        agent_type: String,
        agent_id: String,
        input: String,
    },

    /// Agent 执行后 — 可修改输出或触发后续动作
    PostAgent {
        agent_type: String,
        agent_id: String,
        output: String,
        duration_ms: u64,
        token_usage: TokenUsage,
    },
}

/// Hook 执行结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum HookAction {
    /// 允许继续执行
    Allow,

    /// 拒绝执行，返回错误
    Deny { reason: String },

    /// 修改数据后继续执行
    Modify {
        /// 修改后的数据（JSON 格式）
        modified_data: serde_json::Value,
    },
}

/// Hook trait — 所有 Hook 必须实现此接口
#[async_trait::async_trait]
pub trait Hook: Send + Sync {
    /// Hook 名称（用于日志和调试）
    fn name(&self) -> &str;

    /// 该 Hook 关注的事件类型
    fn events(&self) -> Vec<HookEventKind>;

    /// 执行 Hook 逻辑
    async fn execute(&self, event: &HookEvent) -> Result<HookAction>;
}

/// Hook 事件类型（用于过滤）
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum HookEventKind {
    PreTool,
    PostTool,
    PreAgent,
    PostAgent,
}

/// Hook 管理器 — 注册、过滤和执行 Hook
pub struct HookManager {
    hooks: Vec<Box<dyn Hook>>,
    config: HookConfig,
    /// 安全关键 Hook 名称集合（由配置文件指定，而非 Hook 自身声明）
    security_critical_hooks: HashSet<String>,
}

impl HookManager {
    pub fn new(config: HookConfig) -> Self {
        Self {
            hooks: Vec::new(),
            security_critical_hooks: HashSet::from([
                "deny-dangerous-shell".into(),
                "token-budget-guard".into(),
            ]),
            config,
        }
    }

    /// 注册一个 Hook
    pub fn register(&mut self, hook: Box<dyn Hook>) {
        tracing::info!(hook_name = hook.name(), "Hook registered");
        self.hooks.push(hook);
    }

    /// 标记某个 Hook 为安全关键
    pub fn mark_security_critical(&mut self, hook_name: &str) {
        self.security_critical_hooks.insert(hook_name.to_string());
    }

    fn is_security_critical(&self, hook_name: &str) -> bool {
        self.security_critical_hooks.contains(hook_name)
    }

    /// 触发所有匹配的 Hook，安全类 Hook 始终执行（两阶段执行）
    pub async fn trigger(&self, event: &HookEvent) -> Result<HookAction> {
        let kind = match event {
            HookEvent::PreTool { .. } => HookEventKind::PreTool,
            HookEvent::PostTool { .. } => HookEventKind::PostTool,
            HookEvent::PreAgent { .. } => HookEventKind::PreAgent,
            HookEvent::PostAgent { .. } => HookEventKind::PostAgent,
        };

        // 阶段 1：安全类 Hook 始终执行（不受前面 Hook 结果影响）
        for hook in &self.hooks {
            if !hook.events().contains(&kind) || !self.is_security_critical(hook.name()) {
                continue;
            }

            let hook_name = hook.name();
            match hook.execute(event).await {
                Ok(HookAction::Deny { reason }) => {
                    tracing::warn!(hook_name, %reason, "安全类 Hook 拒绝执行");
                    return Ok(HookAction::Deny { reason });
                }
                Ok(HookAction::Allow) => {
                    tracing::debug!(hook_name, "安全类 Hook 放行");
                }
                Ok(HookAction::Modify { modified_data }) => {
                    tracing::info!(hook_name, "安全类 Hook 修改执行数据");
                    return Ok(HookAction::Modify { modified_data });
                }
                Err(e) => {
                    // 安全 Hook 失败必须阻断（fail-close）
                    tracing::error!(hook_name, error = %e, "安全类 Hook 执行失败，强制阻断（fail-close）");
                    return Err(e);
                }
            }
        }

        // 阶段 2：非安全类 Hook（允许 fail-open）
        for hook in &self.hooks {
            if !hook.events().contains(&kind) || self.is_security_critical(hook.name()) {
                continue;
            }

            let hook_name = hook.name();
            match hook.execute(event).await {
                Ok(HookAction::Allow) => {
                    tracing::debug!(hook_name, action = "allow", "Hook passed");
                }
                Ok(HookAction::Deny { reason }) => {
                    tracing::warn!(hook_name, %reason, "Hook denied execution");
                    return Ok(HookAction::Deny { reason });
                }
                Ok(HookAction::Modify { modified_data }) => {
                    tracing::info!(hook_name, "Hook modified execution data");
                    return Ok(HookAction::Modify { modified_data });
                }
                Err(e) => {
                    tracing::error!(hook_name, error = %e, "Hook execution failed");
                    if self.config.fail_open {
                        continue;
                    } else {
                        return Err(e);
                    }
                }
            }
        }

        Ok(HookAction::Allow)
    }
}
```

**配置方式** — `.morecode/hooks.toml`：

```toml
# .morecode/hooks.toml
# ⚠️ 安全要求：
# 1. 配置文件权限必须设为 600（仅所有者可读写）
# 2. 生产环境建议启用 HMAC 签名验证
# 3. 安全类 Hook（deny-dangerous-shell 等）始终执行，不受 fail_open 影响
# 4. HookAction::Modify 返回的 JSON 会做 Schema 验证
# Hook 系统配置

[general]
# Hook 执行失败时是否放行（true = fail-open，false = fail-close）
fail_open = true
# Hook 执行超时（毫秒）
timeout_ms = 5000

# ── 内置 Hook ──────────────────────────────────────────────

[[hooks]]
name = "deny-dangerous-shell"
type = "builtin"
events = ["pre_tool"]
# 拒绝执行危险 Shell 命令
config.deny_patterns = [
    "rm -rf /",
    "mkfs",
    "dd if=/dev/zero",
    ":(){ :|:& };:",  # Fork bomb
]

[[hooks]]
name = "token-budget-guard"
type = "builtin"
events = ["pre_agent"]
# Agent 执行前检查 Token 预算
config.max_tokens_per_agent = 50000
config.warn_threshold = 0.8

[[hooks]]
name = "cost-alert"
type = "builtin"
events = ["post_llm"]
# 单次 LLM 调用成本超过阈值时告警
config.max_cost_per_call_usd = 0.10

# ── Shell 命令 Hook ───────────────────────────────────────

[[hooks]]
name = "notify-on-complete"
type = "shell"
events = ["post_agent"]
# Agent 完成后发送桌面通知（直接参数模式，不经过 shell）
command = "notify-send"
args = ["MoreCode", "Agent {{agent_type}} completed in {{duration_ms}}ms"]

[[hooks]]
name = "log-to-file"
type = "shell"
events = ["post_tool"]
# 工具调用后把 JSON 事件写入外部程序，由外部程序负责落盘
command = "/usr/local/bin/morecode-hook-log"
args = ["--output", "/tmp/morecode-tools.log"]
stdin = "json"
```

**Shell 命令 Hook 实现**：

```rust
use std::path::Path;
use std::process::Stdio;
use tokio::io::AsyncWriteExt;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ShellHookStdinMode {
    None,
    Json,
}

/// Shell 命令 Hook — 默认以“直接执行程序 + stdin JSON”方式调用外部扩展
pub struct ShellHook {
    name: String,
    events: Vec<HookEventKind>,
    command: String,
    args: Vec<String>,
    stdin_mode: ShellHookStdinMode,
    timeout: Duration,
}

#[derive(Debug, Serialize)]
struct HookPayload {
    agent_type: String,
    tool_name: String,
    duration_ms: u64,
    result_status: String,
}

#[async_trait::async_trait]
impl Hook for ShellHook {
    fn name(&self) -> &str {
        &self.name
    }

    fn events(&self) -> Vec<HookEventKind> {
        self.events.clone()
    }

    async fn execute(&self, event: &HookEvent) -> Result<HookAction> {
        self.validate_command()?;

        let payload = HookPayload {
            agent_type: self.extract_agent_type(event),
            tool_name: self.extract_tool_name(event),
            duration_ms: self.extract_duration(event),
            result_status: self.extract_result_status(event),
        };

        // 仅允许在“字面参数”模式下做模板替换，避免交给 shell 二次解释
        let rendered_args = self
            .args
            .iter()
            .map(|arg| self.render_literal_arg(arg, &payload))
            .collect::<Result<Vec<_>>>()?;

        let mut child = tokio::process::Command::new(&self.command)
            .args(&rendered_args)
            .stdin(match self.stdin_mode {
                ShellHookStdinMode::None => Stdio::null(),
                ShellHookStdinMode::Json => Stdio::piped(),
            })
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()?;

        if self.stdin_mode == ShellHookStdinMode::Json {
            if let Some(mut stdin) = child.stdin.take() {
                let payload_json = serde_json::to_vec(&payload)?;
                stdin.write_all(&payload_json).await?;
            }
        }

        let output = tokio::time::timeout(self.timeout, child.wait_with_output())
        .await
        .map_err(|_| anyhow::anyhow!("Shell hook '{}' timed out", self.name))?
        .map_err(|e| anyhow::anyhow!("Failed to execute shell hook '{}': {}", self.name, e))?;

        // 根据退出码决定 Hook 行为
        match output.status.code() {
            Some(0) => Ok(HookAction::Allow),
            Some(1) => {
                // 退出码 1 = Deny
                let reason = String::from_utf8_lossy(&output.stderr).to_string();
                Ok(HookAction::Deny { reason })
            }
            Some(2) => {
                // 退出码 2 = Modify（从 stdout 读取修改后的 JSON）
                let modified_data: serde_json::Value =
                    serde_json::from_slice(&output.stdout)?;
                Ok(HookAction::Modify { modified_data })
            }
            _ => Ok(HookAction::Allow),
        }
    }
}

impl ShellHook {
    fn validate_command(&self) -> Result<()> {
        let executable = Path::new(&self.command)
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or(&self.command)
            .to_lowercase();

        // 1. 禁止 shell 包装器
        anyhow::ensure!(
            !matches!(
                executable.as_str(),
                "sh" | "bash" | "zsh" | "cmd" | "cmd.exe" | "powershell" | "pwsh"
            ),
            "ShellHook 默认禁止 shell 包装器；请改用固定可执行文件或 stdin JSON"
        );

        // 2. 可执行文件路径白名单检查
        let command_path = Path::new(&self.command);
        if command_path.components().count() > 1 {
            // 非 PATH 查找的绝对/相对路径，必须在白名单目录内
            let allowed_dirs = [
                PathBuf::from("/usr/local/bin"),
                PathBuf::from("/usr/bin"),
                PathBuf::from("/opt"),
            ];
            let canonical = command_path.canonicalize()
                .map_err(|e| anyhow::anyhow!("无法解析 Hook 可执行文件路径 '{}': {}", self.command, e))?;
            let is_allowed = allowed_dirs.iter().any(|dir| canonical.starts_with(dir));
            anyhow::ensure!(
                is_allowed,
                "ShellHook 可执行文件 '{}' 不在白名单目录内，允许的目录: {:?}",
                self.command,
                allowed_dirs
            );
        }
        // PATH 查找的命令（单文件名）通过 which 验证其位于系统目录

        Ok(())
    }

    fn render_literal_arg(
        &self,
        template: &str,
        payload: &HookPayload,
    ) -> Result<String> {
        let mut rendered = template.to_string();
        rendered = rendered.replace("{{agent_type}}", &payload.agent_type);
        rendered = rendered.replace("{{tool_name}}", &payload.tool_name);
        rendered = rendered.replace("{{duration_ms}}", &payload.duration_ms.to_string());
        rendered = rendered.replace("{{result_status}}", &payload.result_status);

        // 安全检查：渲染后的参数不得包含 shell 控制字符
        // （因为 Command::new().args() 不经过 shell，此检查为防御性措施）
        if rendered.contains(|c: char| matches!(c, ';' | '|' | '&' | '$' | '`' | '\n' | '\r')) {
            anyhow::bail!(
                "Hook 参数渲染结果包含非法字符（可能是 payload 注入）: {:?}",
                rendered
            );
        }

        Ok(rendered)
    }
}
```

说明：

- `Command::new(...).args(...)` 本身不会启动 shell；真正的注入风险出现在 Hook 被配置成 `sh -c`、`bash -lc`、`cmd /C`、`powershell -Command` 这类 shell 包装器时，模板替换后的字符串会再次被 shell 解释。
- 默认策略应是“禁止 shell 包装器 + 固定可执行文件 + stdin JSON 载荷”。这样模板变量只是普通参数或标准输入数据，不会参与 shell 展开。
- 如果兼容性原因必须通过 shell 执行，所有模板变量都必须先做 shell 转义（例如 `shlex::try_quote`），但这只能作为兜底方案，不能替代前述默认策略。

### 16.6 核心指标

系统定义了一组核心指标，用于监控 Agent 系统的健康状态、性能表现和资源消耗。所有指标通过 Prometheus 格式导出，可在 Grafana 中可视化。

```
┌─────────────────────────────────────────────────────────────────────┐
│                    核心指标体系                                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  业务指标 (Business Metrics)                                 │   │
│  │                                                             │   │
│  │  session.count          Counter   会话总数                   │   │
│  │  session.active         Gauge     当前活跃会话数              │   │
│  │  session.duration       Histogram 会话持续时间分布            │   │
│  │                                                             │   │
│  │  ┌─────────────────────────────────────────────────────┐   │   │
│  │  │  session.count{status="success"}           1,234    │   │   │
│  │  │  session.count{status="error"}               56    │   │   │
│  │  │  session.count{status="timeout"}              12    │   │   │
│  │  │  session.active                                8    │   │   │
│  │  └─────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  资源指标 (Resource Metrics)                                 │   │
│  │                                                             │   │
│  │  token.usage            Counter   Token 消耗量               │   │
│  │  token.usage{model="gpt-4o",type="input"}          45,678   │   │
│  │  token.usage{model="gpt-4o",type="output"}          12,345  │   │
│  │  token.usage{model="claude-3.5",type="input"}       23,456  │   │
│  │                                                             │   │
│  │  cost.usage             Counter   API 成本（美元）           │   │
│  │  cost.usage{model="gpt-4o"}                     $1.234     │   │
│  │  cost.usage{model="claude-3.5"}                   $0.567    │   │
│  │  cost.usage{provider="openai"}                    $1.801    │   │
│  │                                                             │   │
│  │  context.window.usage    Gauge     上下文窗口使用率          │   │
│  │  context.window.usage{agent="coder"}               72%      │   │
│  │  context.window.usage{agent="planner"}             45%      │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  性能指标 (Performance Metrics)                              │   │
│  │                                                             │   │
│  │  agent.duration         Histogram Agent 执行耗时             │   │
│  │  agent.duration{agent="coder",p50="2.3s",p99="8.1s"}       │   │
│  │  agent.duration{agent="tester",p50="1.1s",p99="4.5s"}      │   │
│  │                                                             │   │
│  │  tool.call              Counter   工具调用次数               │   │
│  │  tool.call{tool="file_read",status="success"}        234    │   │
│  │  tool.call{tool="shell_exec",status="success"}         89    │   │
│  │  tool.call{tool="shell_exec",status="error"}            5    │   │
│  │                                                             │   │
│  │  llm.call               Counter   LLM 调用次数               │   │
│  │  llm.call{model="gpt-4o",status="success"}            156    │   │
│  │  llm.call{model="gpt-4o",status="rate_limited"}         3    │   │
│  │  llm.call.latency      Histogram LLM 调用延迟              │   │
│  │  llm.call.latency{model="gpt-4o",p50="1.2s",p99="5.6s"}  │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  系统指标 (System Metrics)                                   │   │
│  │                                                             │   │
│  │  context.compress.count Counter   上下文压缩次数             │   │
│  │  context.compress.count{strategy="L1"}               45     │   │
│  │  context.compress.count{strategy="L2"}               12     │   │
│  │  context.compress.count{strategy="L3"}                3     │   │
│  │                                                             │   │
│  │  permission.deny.count Counter   权限拒绝次数               │   │
│  │  permission.deny.count{resource="file_write"}          2    │   │
│  │  permission.deny.count{resource="network"}             0    │   │
│  │                                                             │   │
│  │  hook.execution.count   Counter   Hook 执行次数              │   │
│  │  hook.execution.count{hook="deny-dangerous",action="deny"} │   │
│  │                                                             │   │
│  │  error.count            Counter   错误计数                   │   │
│  │  error.count{type="llm_timeout"}                     5     │   │
│  │  error.count{type="tool_failure"}                    12     │   │
│  │  error.count{type="context_overflow"}                 2     │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

```rust
/// 核心指标定义 — 使用 metrics crate
use metrics::{counter, gauge, histogram, describe_counter, describe_gauge, describe_histogram};

/// 注册所有核心指标的描述信息
pub fn register_metrics() {
    // ── 业务指标 ──
    describe_counter!("session.count", "Total number of sessions");
    describe_gauge!("session.active", "Currently active sessions");
    describe_histogram!("session.duration", "Session duration in seconds");

    // ── 资源指标 ──
    describe_counter!("token.usage", "Token usage by model and type");
    describe_counter!("cost.usage", "API cost in USD by model");
    describe_gauge!("context.window.usage", "Context window usage ratio by agent");

    // ── 性能指标 ──
    describe_histogram!("agent.duration", "Agent execution duration in seconds");
    describe_counter!("tool.call", "Tool call count by tool name and status");
    describe_counter!("llm.call", "LLM call count by model and status");
    describe_histogram!("llm.call.latency", "LLM call latency in seconds");

    // ── 系统指标 ──
    describe_counter!("context.compress.count", "Context compression count by strategy");
    describe_counter!("permission.deny.count", "Permission denial count by resource");
    describe_counter!("hook.execution.count", "Hook execution count by name and action");
    describe_counter!("error.count", "Error count by type");
}

/// 记录一次 LLM 调用的指标
pub fn record_llm_call(model: &str, status: &str, latency: Duration, usage: &TokenUsage) {
    // 标签值长度限制，防止高基数标签导致 Prometheus 内存膨胀
    const MAX_LABEL_LENGTH: usize = 64;
    let model = &model[..model.len().min(MAX_LABEL_LENGTH)];
    let status = &status[..status.len().min(MAX_LABEL_LENGTH)];

    counter!("llm.call", "model" => model.to_string(), "status" => status.to_string()).increment(1);
    histogram!("llm.call.latency", "model" => model.to_string()).record(latency.as_secs_f64());
    counter!("token.usage", "model" => model.to_string(), "type" => "input").increment(usage.input as u64);
    counter!("token.usage", "model" => model.to_string(), "type" => "output").increment(usage.output as u64);
    counter!("cost.usage", "model" => model.to_string()).increment(usage.cost_usd);
}

/// 记录一次工具调用的指标
pub fn record_tool_call(tool_name: &str, status: &str, duration: Duration) {
    const MAX_LABEL_LENGTH: usize = 64;
    let tool_name = &tool_name[..tool_name.len().min(MAX_LABEL_LENGTH)];
    let status = &status[..status.len().min(MAX_LABEL_LENGTH)];

    counter!("tool.call", "tool" => tool_name.to_string(), "status" => status.to_string()).increment(1);
    histogram!("tool.call.duration", "tool" => tool_name.to_string()).record(duration.as_secs_f64());
}
```

### 16.7 设计决策

| 决策 | 选择 | 理由 |
|------|------|------|
| 可观测性框架 | tracing + OpenTelemetry | Rust 生态事实标准；tracing 提供零成本抽象，OTel 提供厂商中立的导出格式；社区成熟度高，与 Langfuse/Grafana/Jaeger 无缝集成 |
| 展示平台 | Langfuse（自托管） | 专为 LLM 应用设计，原生支持 Prompt 管理、Session 回放、成本分析；开源可自托管，数据不出域；相比 Grafana 更适合 Agent 场景 |
| Hook 事件范围 | 4 种事件（PreTool/PostTool/PreAgent/PostAgent） | 覆盖 80% 的扩展需求，保持系统简洁；过多事件类型会增加配置复杂度和调试难度；如需扩展可通过 Shell Hook 实现 |
| 隐私默认级别 | METADATA_ONLY | 平衡调试需求和隐私保护；默认不导出 prompt/response 内容，避免敏感数据泄露；本地开发可切换为 NONE 获取完整信息 |
| Hook 失败策略 | Fail-open（默认） | Hook 是辅助功能，不应阻塞主流程；与权限系统（fail-close）形成互补；可通过配置切换为 fail-close |
| 指标导出格式 | Prometheus | 云原生标准，Grafana 原生支持；与 OTel 追踪系统解耦，可独立部署；支持标签（label）维度分析 |
| Span 采样策略 | ParentBased + TraceIdRatioBased | 默认采样率 100%（Agent 场景请求量不大）；支持按比例采样降低高负载时的开销；ParentBased 确保同一 Trace 内的 Span 要么全采样要么全丢弃 |
| Shell Hook 退出码语义 | 0=Allow, 1=Deny, 2=Modify | 与 Unix 惯例一致（0=成功）；简单直观，无需额外配置文件；Modify 通过 stdout 传递 JSON，符合管道设计哲学 |
