# MoreCode — Daemon模式

## 20. Daemon 模式

### 20.1 设计动机

随着项目规模的增长，MoreCode 需要从"按需响应"模式进化为"持续守护"模式。Daemon 模式让 Agent 系统能够 7×24 小时自主运行，自动发现并修复 Bug、监控代码健康、执行架构优化，成为开发团队的全天候编程伙伴。

**核心需求：**

- **自主 Bug 修复**：持续监控 CI/CD 流水线、错误日志和测试结果，发现 Bug 后自动分类、修复并提交
- **架构演进**：在技术债务积累到阈值时，自动生成架构设计方案并分阶段执行
- **依赖管理**：监控依赖更新，评估兼容性风险，自动执行安全的依赖升级
- **性能守护**：持续监控性能指标，发现退化时自动定位并优化
- **代码质量**：定期扫描代码库，发现异味（Code Smell）和安全漏洞

**三种自主级别：**

| 级别 | 说明 | 适用场景 |
|------|------|----------|
| **SemiAuto**（半自动，默认） | Bug 修复自动执行，部署和架构变更需要人工审批 | 大多数项目 |
| **FullAuto**（全自动） | 所有操作自动执行，仅在遇到无法解决的错误时通知用户 | 信任度高的私有项目 |
| **MonitorOnly**（仅监控） | 只检测和报告问题，不做任何代码修改 | 审计要求严格的项目 |

**启动方式：**

```bash
# 通过 CLI 命令启动
ai-assistant /daemon start

# 通过命令行标志启动
ai-assistant --daemon

# 指定自主级别
ai-assistant --daemon --autonomy full-auto

# 指定配置文件
ai-assistant --daemon --config daemon.toml
```

**Daemon 必须处理的关键挑战：**

1. **错误恢复**：网络中断、API 限流、Agent 执行失败时的自动恢复
2. **上下文窗口管理**：长程运行中 LLM 上下文窗口有限，需要跨会话管理
3. **进度持久化**：崩溃或重启后能从断点恢复
4. **通知机制**：在需要人工介入时及时通知用户
5. **成本控制**：防止长时间运行导致 API 费用失控

### 20.2 Daemon 模式架构总览

```
┌─────────────────────────────────────────────────────────────────────┐
│                          用户 (User)                                │
│                                                                     │
│  ┌──────────┐  ┌──────────────┐  ┌──────────────────────────────┐  │
│  │  CLI     │  │  TUI 面板    │  │  通知渠道                     │  │
│  │ /daemon  │  │  Daemon 状态  │  │  (Terminal/Desktop/Webhook)  │  │
│  └────┬─────┘  └──────┬───────┘  └──────────────┬───────────────┘  │
└───────┼───────────────┼─────────────────────────┼───────────────────┘
        │               │                         ▲
        ▼               │                         │
┌─────────────────────────────────────────────────────────────────────┐
│                      DaemonController                               │
│                     (生命周期管理器)                                   │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                      状态机                                   │  │
│  │                                                              │  │
│  │   ┌───────┐    start    ┌─────────┐    pause    ┌────────┐  │  │
│  │   │ Idle  │──────────▶│ Running │──────────▶│ Paused │  │  │
│  │   └───────┘            └────┬────┘            └───┬────┘  │  │
│  │       ▲                     │                     │       │  │
│  │       │            approval │              resume │       │  │
│  │       │              needed ▼                     │       │  │
│  │       │           ┌──────────────────┐            │       │  │
│  │       │           │ WaitingApproval  │            │       │  │
│  │       │           └────────┬─────────┘            │       │  │
│  │       │                    │                      │       │  │
│  │       │          shutdown  │                      │       │  │
│  │       │                    ▼                      │       │  │
│  │       │           ┌──────────────────┐            │       │  │
│  │       └───────────│  ShuttingDown    │◀───────────┘       │  │
│  │                   └──────────────────┘                    │  │
│  └──────────────────────────────────────────────────────────────┘  │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        TaskQueue (持久化任务队列)                     │
│                                                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│  │ GitHook  │ │LogMonitor│ │  Cron    │ │  User    │ │ DepUpdate│ │
│  │ (CI 失败) │ │(错误日志) │ │(定时检查) │ │(交互请求) │ │(依赖更新) │ │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ │
└───────┼────────────┼────────────┼────────────┼────────────┼───────┘
        └────────────┴─────┬──────┴────────────┴────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    AgentOrchestrator (复用第 7 章路由)               │
│                                                                     │
│              ┌─────────────────────────────┐                        │
│              │       Coordinator          │                        │
│              └──────────────┬──────────────┘                        │
│                             │                                       │
│          ┌──────────────────┼──────────────────┐                    │
│          │                  │                  │                    │
│    ┌─────▼─────┐    ┌──────▼──────┐    ┌─────▼──────┐             │
│    │  Explorer  │    │   Coder    │    │  Reviewer  │             │
│    └───────────┘    └─────────────┘    └────────────┘             │
│                                                                     │
│    ┌───────────┐    ┌─────────────┐    ┌────────────┐             │
│    │  Tester   │    │  Debugger   │    │  Research  │             │
│    └───────────┘    └─────────────┘    └────────────┘             │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      ResultProcessor (结果处理器)                     │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │ 结果验证     │  │ 决策下一步    │  │ 更新项目记忆              │  │
│  │ (测试通过?)  │  │ (重试/提交/   │  │ (.assistant-memory/)      │  │
│  │              │  │  升级/放弃)   │  │                          │  │
│  └──────────────┘  └──────────────┘  └──────────────────────────┘  │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    支撑服务层                                        │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │CheckpointMgr │  │ CostTracker  │  │SessionMgr    │             │
│  │(检查点管理)   │  │(成本追踪)    │  │(会话管理)     │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │Notification  │  │ ConfigWatch  │  │ProjectMemory │             │
│  │(通知服务)     │  │(配置热重载)   │  │(项目记忆)     │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
└─────────────────────────────────────────────────────────────────────┘
```

**核心组件职责：**

| 组件 | 职责 | 对应章节 |
|------|------|----------|
| **DaemonController** | 管理 Daemon 生命周期、状态机转换、主事件循环 | 本章新增 |
| **TaskQueue** | 持久化任务队列，支持优先级、去重、多种任务来源 | 本章新增 |
| **AgentOrchestrator** | 复用现有多 Agent 编排系统执行任务 | 第 7 章 |
| **ResultProcessor** | 处理执行结果，验证、决策下一步行动 | 本章新增 |
| **NotificationService** | 多渠道通知，支持安静时段和摘要模式 | 本章新增 |
| **CheckpointManager** | 定期保存系统状态，支持崩溃恢复 | 本章新增 |
| **CostTracker** | Token 用量和 API 费用追踪，超限告警 | 本章新增 |
| **SessionManager** | 跨会话上下文管理，控制 LLM 上下文窗口 | 本章新增 |
| **ProjectMemory** | 项目知识持久化存储 | 第 18 章 |

### 20.3 配置文件设计

Daemon 模式通过 TOML 配置文件进行精细控制。配置文件支持热重载，运行时修改后无需重启即可生效。

```rust
use chrono::{Duration, NaiveTime};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Daemon 模式主配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DaemonConfig {
    /// 自主级别：半自动（默认）、全自动、仅监控
    pub autonomy_level: AutonomyLevel,

    /// 最大运行时长，None 表示无限制
    pub max_run_duration: Option<Duration>,

    /// 任务来源列表
    pub task_sources: Vec<TaskSource>,

    /// 审批策略
    pub approval_policy: ApprovalPolicy,

    /// 通知配置
    pub notification_config: NotificationConfig,

    /// 资源限制
    pub resource_limits: ResourceLimits,

    /// 检查点配置
    pub checkpoint_config: CheckpointConfig,

    /// 架构设计配置
    pub architecture_config: ArchitectureConfig,
}

/// 自主级别
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum AutonomyLevel {
    /// 半自动：Bug 修复自动执行，部署和架构变更需要审批
    SemiAuto,
    /// 全自动：所有操作自动执行，仅在无法解决时通知
    FullAuto,
    /// 仅监控：只检测和报告问题，不做代码修改
    MonitorOnly,
}

/// 审批策略
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApprovalPolicy {
    /// 部署是否需要审批（默认 true）
    #[serde(default = "default_true")]
    pub deploy_requires_approval: bool,

    /// 架构变更是否需要审批（默认 true）
    #[serde(default = "default_true")]
    pub architecture_requires_approval: bool,

    /// 破坏性变更是否需要审批（默认 true）
    #[serde(default = "default_true")]
    pub breaking_change_requires_approval: bool,

    /// 自动修复的最大 Bug 严重级别（默认 Medium）
    #[serde(default = "default_bug_severity")]
    pub max_auto_fix_severity: BugSeverity,

    /// 审批超时时间（默认 30 分钟），超时自动拒绝
    #[serde(default = "default_approval_timeout")]
    pub approval_timeout: Duration,
}

fn default_true() -> bool { true }
fn default_bug_severity() -> BugSeverity { BugSeverity::Medium }
fn default_approval_timeout() -> Duration { Duration::minutes(30) }

/// Bug 严重级别
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord)]
pub enum BugSeverity {
    Low,
    Medium,
    High,
    Critical,
}

/// 通知配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NotificationConfig {
    /// 通知渠道列表
    pub channels: Vec<NotificationChannel>,

    /// 需要通知的重要事件类型
    pub important_events: Vec<EventType>,

    /// 安静时段（不发送非关键通知）
    pub quiet_hours: Option<(NaiveTime, NaiveTime)>,

    /// 摘要模式：批量发送通知而非实时发送
    #[serde(default)]
    pub digest_mode: bool,
}

/// 通知渠道
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum NotificationChannel {
    /// 终端通知（响铃）
    Terminal { bell: bool },
    /// 桌面操作系统通知
    Desktop { os_notification: bool },
    /// Webhook（Slack / Discord / Teams 等）
    Webhook {
        url: String,
        headers: HashMap<String, String>,
    },
    /// 邮件通知
    Email { smtp_config: SmtpConfig },
}

/// SMTP 配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SmtpConfig {
    pub server: String,
    pub port: u16,
    pub username: String,
    pub password: String,
    pub from: String,
    pub to: Vec<String>,
}

/// 事件类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum EventType {
    TaskCompleted,
    TaskFailed,
    BugFixed,
    ApprovalNeeded,
    CheckpointCreated,
    CostWarning,
    ErrorEscalation,
    ArchitecturePlanReady,
    DependencyUpdated,
    PerformanceDegradation,
}

/// 资源限制
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceLimits {
    /// 最大并发任务数（默认 3）
    #[serde(default = "default_max_concurrent")]
    pub max_concurrent_tasks: usize,

    /// 每小时最大 Token 数（API 速率限制）
    #[serde(default = "default_hourly_tokens")]
    pub max_tokens_per_hour: usize,

    /// 每天最大费用（美元，预算控制）
    #[serde(default = "default_daily_cost")]
    pub max_cost_per_day: f64,

    /// 每小时最大 Git 提交数（防止提交泛滥）
    #[serde(default = "default_commits_per_hour")]
    pub max_git_commits_per_hour: usize,

    /// 任务间冷却时间（默认 30 秒）
    #[serde(default = "default_cooldown")]
    pub cooldown_between_tasks: Duration,
}

fn default_max_concurrent() -> usize { 3 }
fn default_hourly_tokens() -> usize { 500_000 }
fn default_daily_cost() -> f64 { 10.0 }
fn default_commits_per_hour() -> usize { 10 }
fn default_cooldown() -> Duration { Duration::seconds(30) }

/// 检查点配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CheckpointConfig {
    /// 是否启用检查点
    #[serde(default = "default_true")]
    pub enabled: bool,

    /// 自动检查点间隔（默认 5 分钟）
    #[serde(default = "default_checkpoint_interval")]
    pub interval: Duration,

    /// 最大检查点数量（默认 100）
    #[serde(default = "default_max_checkpoints")]
    pub max_checkpoints: usize,

    /// 在危险操作前自动创建检查点
    #[serde(default = "default_true")]
    pub on_error: bool,
}

fn default_checkpoint_interval() -> Duration { Duration::minutes(5) }
fn default_max_checkpoints() -> usize { 100 }

/// 架构设计配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArchitectureConfig {
    /// 是否启用架构设计能力
    #[serde(default = "default_true")]
    pub enabled: bool,

    /// 最大重构范围
    pub max_refactor_scope: RefactorScope,

    /// 大规模变更前是否生成设计文档
    #[serde(default = "default_true")]
    pub require_design_doc: bool,

    /// 执行设计文档前是否需要审查
    #[serde(default)]
    pub design_doc_review: bool,

    /// 失败时是否自动回滚
    #[serde(default = "default_true")]
    pub rollback_on_failure: bool,
}

/// 重构范围
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RefactorScope {
    /// 单模块内重构
    Module,
    /// 跨模块重构
    CrossModule,
    /// 全项目重构
    ProjectWide,
}
```

**配置文件示例（daemon.toml）：**

```toml
[daemon]
autonomy_level = "SemiAuto"
max_run_duration = "24h"

[daemon.approval_policy]
deploy_requires_approval = true
architecture_requires_approval = true
breaking_change_requires_approval = true
max_auto_fix_severity = "Medium"
approval_timeout = "30m"

[daemon.notification_config]
digest_mode = true
quiet_hours = { start = "23:00", end = "08:00" }

[[daemon.notification_config.channels]]
type = "Terminal"
bell = true

[[daemon.notification_config.channels]]
type = "Webhook"
url = "https://hooks.slack.com/services/xxx"
headers = { "Content-Type" = "application/json" }

[daemon.resource_limits]
max_concurrent_tasks = 3
max_tokens_per_hour = 500000
max_cost_per_day = 10.0
max_git_commits_per_hour = 10
cooldown_between_tasks = "30s"

[daemon.checkpoint_config]
enabled = true
interval = "5m"
max_checkpoints = 100
on_error = true

[daemon.architecture_config]
enabled = true
max_refactor_scope = "CrossModule"
require_design_doc = true
design_doc_review = false
rollback_on_failure = true
```

### 20.4 任务来源与优先级

Daemon 模式支持多种任务来源，每种来源对应不同的触发机制和优先级。

```rust
/// 任务来源
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum TaskSource {
    /// Git Hook：CI 失败、测试失败、构建错误
    GitHook { event_type: GitHookEvent },
    /// 日志监控：错误模式匹配
    LogMonitor { pattern: String, log_path: String },
    /// 定时任务：周期性健康检查
    CronSchedule { cron_expr: String, task_type: CronTaskType },
    /// 用户请求：交互式输入
    UserRequest,
    /// 依赖更新：检测到过时依赖
    DependencyUpdate { check_interval: Duration },
    /// 性能监控：慢查询、内存泄漏等
    PerformanceMonitor { metric_type: PerformanceMetric },
}

/// Git Hook 事件类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum GitHookEvent {
    /// CI 流水线失败
    CiFailure,
    /// 单元测试失败
    TestFailure,
    /// 构建错误
    BuildError,
    /// Lint 警告超过阈值
    LintWarningThreshold,
}

/// 定时任务类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum CronTaskType {
    /// 代码健康检查
    HealthCheck,
    /// 依赖安全扫描
    SecurityScan,
    /// 技术债务评估
    TechDebtAssessment,
    /// 性能基准测试
    PerformanceBenchmark,
}

/// 性能指标类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum PerformanceMetric {
    /// API 响应时间
    ResponseTime { threshold_ms: u64 },
    /// 内存使用量
    MemoryUsage { threshold_mb: u64 },
    /// CPU 使用率
    CpuUsage { threshold_percent: f64 },
    /// 数据库查询时间
    QueryTime { threshold_ms: u64 },
}

/// 任务优先级
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum TaskPriority {
    Critical = 0,  // 最高：安全漏洞、生产环境崩溃
    High = 1,      // 高：CI 失败、测试失败
    Medium = 2,    // 中：代码异味、依赖更新
    Low = 3,       // 低：文档更新、格式优化
}

/// Daemon 任务（扩展自基础 TaskDescription）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DaemonTask {
    /// 任务唯一 ID
    pub id: String,

    /// 任务描述
    pub description: String,

    /// 任务优先级
    pub priority: TaskPriority,

    /// 任务来源
    pub source: TaskSource,

    /// 任务类型
    pub task_type: DaemonTaskType,

    /// 创建时间
    pub created_at: chrono::DateTime<chrono::Utc>,

    /// 去重哈希（避免重复任务）
    pub dedup_hash: String,

    /// 最大重试次数
    pub max_retries: u32,

    /// 已重试次数
    pub retry_count: u32,

    /// 关联的上下文信息
    pub context: TaskContext,
}

/// Daemon 任务类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum DaemonTaskType {
    BugFix,
    DependencyUpdate,
    Refactoring,
    SecurityPatch,
    PerformanceOptimization,
    Documentation,
    HealthCheck,
}

/// 任务上下文
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TaskContext {
    /// CI 失败日志（如果有）
    pub ci_log: Option<String>,
    /// 错误堆栈（如果有）
    pub error_stack: Option<String>,
    /// 相关文件列表
    pub related_files: Vec<String>,
    /// 相关提交哈希
    pub related_commits: Vec<String>,
    /// 额外元数据
    pub metadata: HashMap<String, String>,
}
```

**任务优先级映射表：**

| 来源 | 场景 | 优先级 | 说明 |
|------|------|--------|------|
| GitHook | CI 流水线失败 | Critical | 阻塞团队开发 |
| GitHook | 测试失败 | High | 影响代码质量 |
| GitHook | Lint 警告超阈值 | Low | 不影响功能 |
| LogMonitor | 生产环境错误 | Critical | 影响用户 |
| LogMonitor | 警告日志 | Medium | 需要关注 |
| DependencyUpdate | 安全漏洞修复 | Critical | 安全风险 |
| DependencyUpdate | 普通版本更新 | Low | 可延后处理 |
| PerformanceMonitor | 响应时间超阈值 | High | 影响用户体验 |
| CronSchedule | 健康检查 | Low | 例行任务 |
| UserRequest | 任何 | High | 用户主动请求优先 |

**任务去重机制：**

```rust
impl DaemonTask {
    /// 计算任务去重哈希
    pub fn compute_dedup_hash(description: &str, source: &TaskSource) -> String {
        use std::hash::{Hash, Hasher};
        use xxhash_rust::xxh3::Xxh3;

        let mut hasher = Xxh3::new();
        
        // 中文标准化：全角→半角，统一为小写
        let normalized = description
            .chars()
            .map(|c| {
                if c.is_ascii_uppercase() {
                    c.to_ascii_lowercase()
                } else if ('\u{FF01}'..='\u{FF5E}').contains(&c) {
                    // 全角字符转半角
                    char::from_u32(c as u32 - 0xFEE0).unwrap_or(c)
                } else {
                    c
                }
            })
            .collect::<String>();
        
        // 移除多余空白
        let normalized = normalized.split_whitespace().collect::<Vec<_>>().join(" ");

        normalized.hash(&mut hasher);
        source.hash(&mut hasher);
        format!("{:x}", hasher.finish())
    }
}
```

### 20.5 Daemon 生命周期管理

```rust
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::{watch, mpsc};

/// Daemon 控制器
pub struct DaemonController {
    /// 配置
    config: DaemonConfig,

    /// 当前状态
    state: DaemonState,

    /// 持久化任务队列
    task_queue: Arc<TaskQueue>,

    /// Agent 编排器（复用第 7 章路由系统）
    orchestrator: Arc<AgentOrchestrator>,

    /// 检查点管理器
    checkpoint_manager: Arc<CheckpointManager>,

    /// 通知服务
    notification: Arc<NotificationService>,

    /// 成本追踪器
    cost_tracker: Arc<CostTracker>,

    /// 会话管理器
    session_manager: Arc<SessionManager>,

    /// 关闭信号接收端
    shutdown_rx: watch::Receiver<bool>,

    /// 审批请求通道
    approval_tx: mpsc::Sender<ApprovalRequest>,
    approval_rx: mpsc::Receiver<ApprovalRequest>,

    /// 配置文件监视器
    config_watch: Arc<ConfigWatcher>,

    /// 结果处理器
    result_processor: Arc<ResultProcessor>,
}

/// Daemon 状态
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DaemonState {
    /// 空闲：等待启动
    Idle,

    /// 运行中：正在处理任务
    Running {
        started_at: chrono::DateTime<chrono::Utc>,
        tasks_completed: usize,
        tasks_failed: usize,
    },

    /// 暂停：临时停止处理新任务
    Paused {
        reason: String,
        resume_at: Option<chrono::DateTime<chrono::Utc>>,
    },

    /// 等待审批：需要用户确认
    WaitingApproval {
        pending: ApprovalRequest,
        timeout: chrono::DateTime<chrono::Utc>,
    },

    /// 正在关闭
    ShuttingDown,
}

/// 审批请求
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApprovalRequest {
    pub request_id: String,
    pub task_id: String,
    pub task_description: String,
    pub action: ApprovalAction,
    pub reason: String,
    pub risk_level: RiskLevel,
    pub created_at: chrono::DateTime<chrono::Utc>,
    pub proposed_changes: Vec<String>,
}

/// 审批动作
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ApprovalAction {
    Deploy,
    ArchitectureChange,
    BreakingChange,
    LargeRefactoring,
}

/// 风险级别
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RiskLevel {
    Low,
    Medium,
    High,
    Critical,
}

/// 审批响应
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ApprovalResponse {
    Approved,
    Rejected { reason: String },
    Modified { changes: Vec<String> },
    Timeout,
}

impl DaemonController {
    /// 启动 Daemon
    pub async fn start(&mut self) -> Result<(), DaemonError> {
        // 1. 验证配置
        self.validate_config()?;

        // 2. 恢复检查点（如果有）
        if let Some(checkpoint) = self.checkpoint_manager.restore_latest().await? {
            self.restore_from_checkpoint(checkpoint).await?;
        }

        // 3. 初始化任务来源
        self.init_task_sources().await?;

        // 4. 切换状态
        self.state = DaemonState::Running {
            started_at: chrono::Utc::now(),
            tasks_completed: 0,
            tasks_failed: 0,
        };

        // 5. 通知用户
        self.notification.send(Notification {
            event_type: EventType::TaskCompleted,
            title: "Daemon 已启动".to_string(),
            message: format!(
                "自主级别: {:?}, 并发任务数: {}",
                self.config.autonomy_level,
                self.config.resource_limits.max_concurrent_tasks
            ),
            priority: TaskPriority::Low,
        }).await;

        // 6. 进入主循环
        self.run_loop().await;

        Ok(())
    }

    /// 暂停 Daemon
    pub async fn pause(&mut self, reason: &str) {
        self.state = DaemonState::Paused {
            reason: reason.to_string(),
            resume_at: None,
        };
        self.notification.send(Notification {
            event_type: EventType::TaskCompleted,
            title: "Daemon 已暂停".to_string(),
            message: reason.to_string(),
            priority: TaskPriority::Medium,
        }).await;
    }

    /// 恢复 Daemon
    pub async fn resume(&mut self) {
        if matches!(self.state, DaemonState::Paused { .. }) {
            self.state = DaemonState::Running {
                started_at: chrono::Utc::now(),
                tasks_completed: 0,
                tasks_failed: 0,
            };
        }
    }

    /// 优雅关闭
    pub async fn shutdown(&mut self) {
        self.state = DaemonState::ShuttingDown;

        // 1. 完成当前正在执行的任务
        self.orchestrator.drain().await;

        // 2. 创建最终检查点
        self.checkpoint_manager.create_checkpoint(&self.state).await;

        // 3. 通知用户
        self.notification.send(Notification {
            event_type: EventType::TaskCompleted,
            title: "Daemon 已关闭".to_string(),
            message: "所有任务已完成，状态已保存".to_string(),
            priority: TaskPriority::Medium,
        }).await;
    }
}
```

### 20.6 主循环设计

Daemon 的核心是一个基于 `tokio::select!` 的事件驱动主循环，同时监听多个异步事件源。

```rust
impl DaemonController {
    /// 主事件循环
    async fn run_loop(&mut self) {
        // 检查点定时器
        let mut checkpoint_timer =
            tokio::time::interval(self.config.checkpoint_config.interval);

        // 成本检查定时器（独立于 select!，确保定期触发）
        let mut cost_check_interval = tokio::time::interval(Duration::minutes(1));

        loop {
            // 检查是否应该关闭
            if matches!(self.state, DaemonState::ShuttingDown) {
                break;
            }

            tokio::select! {
                // 事件 1：新任务到达
                Some(task) = self.task_queue.next(), if self.is_running() => {
                    self.handle_new_task(task).await;
                }

                // 事件 2：编排器返回任务结果
                result = self.orchestrator.next_result() => {
                    self.handle_task_result(result).await;
                }

                // 事件 3：用户审批响应
                Some(response) = self.approval_rx.recv() => {
                    self.handle_approval_response(response).await;
                }

                // 事件 4：定期检查点
                _ = checkpoint_timer.tick(), if self.config.checkpoint_config.enabled => {
                    self.create_checkpoint().await;
                }

                // 事件 5：关闭信号（Ctrl+C / SIGTERM）
                _ = self.shutdown_rx.changed() => {
                    if *self.shutdown_rx.borrow() {
                        self.graceful_shutdown().await;
                        break;
                    }
                }

                // 事件 6：配置热重载
                _ = self.config_watch.rx.changed() => {
                    self.reload_config().await;
                }

                // 事件 7：审批超时检查
                _ = tokio::time::sleep_until(self.next_approval_timeout()) => {
                    self.handle_approval_timeout().await;
                }

                // 事件 8：成本检查（每分钟，使用 interval 确保定期触发）
                _ = cost_check_interval.tick() => {
                    self.check_cost_limits().await;
                }
            }
        }
    }

    /// 检查 Daemon 是否处于运行状态
    fn is_running(&self) -> bool {
        matches!(self.state, DaemonState::Running { .. })
    }

    /// 处理新任务
    async fn handle_new_task(&mut self, task: DaemonTask) {
        // 1. 检查资源限制
        if !self.cost_tracker.can_afford(&task).await {
            self.task_queue.requeue(task).await;
            return;
        }

        // 2. 检查是否需要审批
        if self.requires_approval(&task) {
            self.request_approval(task).await;
            return;
        }

        // 3. 检查自主级别
        match self.config.autonomy_level {
            AutonomyLevel::MonitorOnly => {
                // 仅监控模式：只报告，不执行
                self.notification.send(Notification {
                    event_type: EventType::TaskFailed,
                    title: "发现潜在问题".to_string(),
                    message: task.description.clone(),
                    priority: task.priority,
                }).await;
            }
            AutonomyLevel::SemiAuto | AutonomyLevel::FullAuto => {
                // 执行任务
                self.execute_task(task).await;
            }
        }
    }

    /// 处理任务结果
    async fn handle_task_result(&mut self, result: TaskResult) {
        match result.status {
            ExecutionStatus::Completed => {
                // 更新统计
                if let DaemonState::Running { tasks_completed, .. } = &mut self.state {
                    *tasks_completed += 1;
                }

                // 通知用户
                self.notification.send(Notification {
                    event_type: EventType::TaskCompleted,
                    title: "任务完成".to_string(),
                    message: format!(
                        "[{}] {} - {}",
                        result.task_id,
                        result.summary,
                        result.changes_made
                    ),
                    priority: TaskPriority::Medium,
                }).await;

                // 更新项目记忆
                self.update_project_memory(&result).await;
            }
            ExecutionStatus::Failed { error: error.clone() } => {
                    // 根据错误类型判断是否可重试（如网络超时、临时不可用等）
                    let retryable = is_recoverable_error(&error);
                    if retryable && result.retry_count < result.max_retries {
                        // 可重试：使用 tokio::spawn 异步延迟后重新入队，
                        // 避免阻塞当前事件循环
                        let backoff = Duration::seconds(
                            1_i64 * 2_i64.pow(result.retry_count)
                        );
                        let task_queue = self.task_queue.clone();
                        let original_task = result.original_task.clone();
                        tokio::spawn(async move {
                            tokio::time::sleep(backoff).await;
                            task_queue.requeue_with_retry(original_task).await;
                        });
                    } else {
                    // 不可重试或超过最大重试次数
                    if let DaemonState::Running { tasks_failed, .. } = &mut self.state {
                        *tasks_failed += 1;
                    }

                    self.notification.send(Notification {
                        event_type: EventType::ErrorEscalation,
                        title: "任务失败".to_string(),
                        message: format!(
                            "[{}] {} - 错误: {}",
                            result.task_id, result.summary, error
                        ),
                        priority: TaskPriority::High,
                    }).await;
                }
            }
        }
    }

    /// 优雅关闭
    async fn graceful_shutdown(&mut self) {
        self.state = DaemonState::ShuttingDown;

        // 停止接收新任务
        self.task_queue.shutdown().await;

        // 等待当前任务完成（最多等待 5 分钟）
        let drain_result = tokio::time::timeout(
            Duration::minutes(5),
            self.orchestrator.drain()
        ).await;

        if drain_result.is_err() {
            tracing::warn!("部分任务未能在关闭超时内完成");
        }

        // 创建最终检查点
        self.checkpoint_manager.create_checkpoint(&self.state).await;

        tracing::info!("Daemon 已优雅关闭");
    }
}
```

### 20.7 Bug 发现与自动修复流程

Bug 发现与修复是 Daemon 模式最核心的功能。系统通过多种渠道发现 Bug，自动分类并决定修复策略。

```
┌─────────────────────────────────────────────────────────────────────┐
│                     Bug 发现与自动修复流程                             │
│                                                                     │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌────────────────┐  │
│  │ CI/CD 失败  │ │ 错误日志    │ │ 测试失败    │ │ 依赖漏洞扫描   │  │
│  └─────┬──────┘ └─────┬──────┘ └─────┬──────┘ └──────┬─────────┘  │
│        └──────────────┴──────────────┴───────────────┘             │
│                              │                                      │
│                              ▼                                      │
│                    ┌──────────────────┐                             │
│                    │   Bug 发现       │                             │
│                    └────────┬─────────┘                             │
│                             │                                       │
│                             ▼                                       │
│                    ┌──────────────────┐                             │
│                    │   Bug 分类       │                             │
│                    │                  │                             │
│                    │ · 严重级别       │                             │
│                    │ · Bug 类型       │                             │
│                    │ · 影响范围       │                             │
│                    └────────┬─────────┘                             │
│                             │                                       │
│                             ▼                                       │
│                    ┌──────────────────┐                             │
│                    │  检查自主级别     │                             │
│                    └────────┬─────────┘                             │
│                             │                                       │
│              ┌──────────────┼──────────────┐                        │
│              │              │              │                        │
│              ▼              ▼              ▼                        │
│     ┌────────────┐ ┌────────────┐ ┌────────────┐                  │
│     │ MonitorOnly│ │  SemiAuto  │ │  FullAuto  │                  │
│     │            │ │            │ │            │                  │
│     │ 仅报告     │ │ 低/中:自动  │ │ 全部自动   │                  │
│     │ 不修复     │ │ 高/危:审批  │ │ 修复       │                  │
│     └────────────┘ └─────┬──────┘ └─────┬──────┘                  │
│                         └──────┬─────────┘                          │
│                                │                                    │
│                                ▼                                    │
│                    ┌──────────────────┐                             │
│                    │   执行修复       │                             │
│                    │                  │                             │
│                    │ · Coder Agent    │                             │
│                    │ · Debugger Agent │                             │
│                    └────────┬─────────┘                             │
│                             │                                       │
│                             ▼                                       │
│                    ┌──────────────────┐                             │
│                    │   验证修复       │                             │
│                    │                  │                             │
│                    │ · 运行测试       │                             │
│                    │ · 检查编译       │                             │
│                    └────────┬─────────┘                             │
│                             │                                       │
│                    ┌────────┴────────┐                              │
│                    │                 │                              │
│                    ▼                 ▼                              │
│              ┌──────────┐     ┌──────────┐                         │
│              │  通过    │     │  失败    │                         │
│              └────┬─────┘     └────┬─────┘                         │
│                   │                │                                │
│                   ▼                ▼                                │
│           ┌──────────────┐  ┌──────────────┐                      │
│           │ Git Commit   │  │ 回滚 + 重试  │                      │
│           │ + 通知       │  │ + 升级       │                      │
│           └──────────────┘  └──────────────┘                      │
└─────────────────────────────────────────────────────────────────────┘
```

**Bug 分类系统：**

```rust
/// Bug 类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum BugType {
    /// 编译错误
    CompileError { error_message: String },
    /// 测试失败
    TestFailure { test_name: String, assertion: String },
    /// 逻辑 Bug
    LogicBug { description: String, evidence: String },
    /// 性能问题
    PerformanceIssue { metric: String, current: f64, threshold: f64 },
    /// 安全漏洞
    SecurityVulnerability { cve_id: Option<String>, severity: BugSeverity },
    /// 依赖问题
    DependencyIssue { package: String, version: String, issue: String },
}

/// Bug 报告
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BugReport {
    pub id: String,
    pub bug_type: BugType,
    pub severity: BugSeverity,
    pub source: TaskSource,
    pub description: String,
    pub evidence: String,
    pub affected_files: Vec<String>,
    pub discovered_at: chrono::DateTime<chrono::Utc>,
    pub auto_fixable: bool,
    pub suggested_fix: Option<String>,
}

/// 修复策略
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum FixStrategy {
    /// 直接修复：简单的编译错误、拼写错误等
    DirectFix {
        files_to_modify: Vec<String>,
        description: String,
    },
    /// 研究后修复：需要先理解代码逻辑
    ResearchThenFix {
        research_scope: Vec<String>,
        analysis_steps: Vec<String>,
    },
    /// 升级给用户：无法自动修复的复杂问题
    EscalateToUser {
        reason: String,
        suggested_actions: Vec<String>,
    },
}
```

**自动修复决策逻辑：**

```rust
impl DaemonController {
    /// 决定 Bug 的修复策略
    fn decide_fix_strategy(&self, bug: &BugReport) -> FixStrategy {
        match &bug.bug_type {
            BugType::CompileError { .. } => {
                // 编译错误通常可以直接修复
                FixStrategy::DirectFix {
                    files_to_modify: bug.affected_files.clone(),
                    description: format!("修复编译错误: {}", bug.description),
                }
            }
            BugType::TestFailure { test_name, .. } => {
                // 测试失败需要先分析
                if bug.affected_files.len() <= 2 {
                    FixStrategy::DirectFix {
                        files_to_modify: bug.affected_files.clone(),
                        description: format!("修复测试失败: {}", test_name),
                    }
                } else {
                    FixStrategy::ResearchThenFix {
                        research_scope: bug.affected_files.clone(),
                        analysis_steps: vec![
                            "分析测试失败的根本原因".to_string(),
                            "检查相关代码的变更历史".to_string(),
                            "评估修复方案的影响范围".to_string(),
                        ],
                    }
                }
            }
            BugType::SecurityVulnerability { severity, .. } => {
                // 安全漏洞需要谨慎处理
                if *severity == BugSeverity::Critical {
                    FixStrategy::DirectFix {
                        files_to_modify: bug.affected_files.clone(),
                        description: format!("紧急修复安全漏洞: {}", bug.description),
                    }
                } else {
                    FixStrategy::ResearchThenFix {
                        research_scope: bug.affected_files.clone(),
                        analysis_steps: vec![
                            "分析漏洞影响范围".to_string(),
                            "评估修复方案的兼容性".to_string(),
                        ],
                    }
                }
            }
            BugType::LogicBug { .. } => {
                // 逻辑 Bug 通常需要深入研究
                FixStrategy::ResearchThenFix {
                    research_scope: bug.affected_files.clone(),
                    analysis_steps: vec![
                        "理解相关业务逻辑".to_string(),
                        "分析 Bug 的触发条件".to_string(),
                        "设计修复方案".to_string(),
                    ],
                }
            }
            BugType::PerformanceIssue { .. } => {
                // 性能问题需要先分析瓶颈
                FixStrategy::ResearchThenFix {
                    research_scope: bug.affected_files.clone(),
                    analysis_steps: vec![
                        "定位性能瓶颈".to_string(),
                        "分析性能退化的原因".to_string(),
                        "设计优化方案".to_string(),
                    ],
                }
            }
            BugType::DependencyIssue { .. } => {
                // 依赖问题通常可以直接升级
                FixStrategy::DirectFix {
                    files_to_modify: vec!["Cargo.toml".to_string()],
                    description: format!("更新依赖: {}", bug.description),
                }
            }
        }
    }

    /// 检查 Bug 是否可以自动修复
    fn can_auto_fix(&self, bug: &BugReport) -> bool {
        match self.config.autonomy_level {
            AutonomyLevel::MonitorOnly => false,
            AutonomyLevel::FullAuto => true,
            AutonomyLevel::SemiAuto => {
                // 半自动模式：只有低于配置阈值的 Bug 可以自动修复
                bug.severity <= self.config.approval_policy.max_auto_fix_severity
            }
        }
    }
}
```

### 20.8 架构设计能力

Daemon 模式不仅能修复 Bug，还具备架构设计能力，可以在检测到技术债务积累或性能退化时，自动生成架构设计方案并分阶段执行。

**架构设计触发条件：**

| 触发条件 | 检测方式 | 阈值示例 |
|----------|----------|----------|
| 技术债务积累 | 定期评估代码复杂度 | 圈复杂度 > 20 的函数超过 10 个 |
| 性能退化 | 性能基准对比 | 响应时间退化 > 30% |
| 规模增长 | 模块文件数监控 | 单模块文件数 > 50 |
| 用户请求 | `/daemon architecture` 命令 | - |
| 依赖冲突 | 依赖图分析 | 循环依赖检测 |

**架构设计流程：**

```
┌─────────────────────────────────────────────────────────────────────┐
│                      架构设计流程                                    │
│                                                                     │
│  ┌──────────────┐                                                   │
│  │ 触发条件检测  │                                                   │
│  └──────┬───────┘                                                   │
│         │                                                           │
│         ▼                                                           │
│  ┌──────────────┐                                                   │
│  │ 分析当前状态  │                                                   │
│  │              │                                                   │
│  │ · Explorer   │                                                   │
│  │ · 代码度量    │                                                   │
│  │ · 依赖图分析  │                                                   │
│  └──────┬───────┘                                                   │
│         │                                                           │
│         ▼                                                           │
│  ┌──────────────┐                                                   │
│  │ 生成设计文档  │                                                   │
│  │              │                                                   │
│  │ 存储位置:     │                                                   │
│  │ .assistant-  │                                                   │
│  │ memory/      │                                                   │
│  │ architecture/│                                                   │
│  └──────┬───────┘                                                   │
│         │                                                           │
│         ▼                                                           │
│  ┌──────────────┐     ┌──────────────┐                             │
│  │ 需要审查?     │──否─▶│ 创建执行计划  │                             │
│  └──────┬───────┘     └──────┬───────┘                             │
│         │是                   │                                     │
│         ▼                     │                                     │
│  ┌──────────────┐             │                                     │
│  │ 等待用户审查  │             │                                     │
│  └──────┬───────┘             │                                     │
│         │已批准               │                                     │
│         └─────────┬───────────┘                                     │
│                   ▼                                                 │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │              分阶段执行                                       │  │
│  │                                                              │  │
│  │  Phase 1 ──▶ Commit ──▶ Phase 2 ──▶ Commit ──▶ ... ──▶ Done │  │
│  │                                                              │  │
│  │  每个阶段:                                                    │  │
│  │  1. 执行代码变更                                              │  │
│  │  2. 运行测试验证                                              │  │
│  │  3. 创建 Git 提交点                                           │  │
│  │  4. 检查是否需要回滚                                          │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                   │                                                 │
│                   ▼                                                 │
│  ┌──────────────┐                                                   │
│  │ 验证成功标准  │                                                   │
│  └──────┬───────┘                                                   │
│         │                                                           │
│    ┌────┴────┐                                                     │
│    │         │                                                     │
│    ▼         ▼                                                     │
│  ┌──────┐ ┌──────┐                                                │
│  │ 通过  │ │ 失败  │                                                │
│  └──────┘ └──┬───┘                                                │
│               │                                                     │
│               ▼                                                     │
│         ┌──────────┐                                                │
│         │ 自动回滚  │                                                │
│         └──────────┘                                                │
└─────────────────────────────────────────────────────────────────────┘
```

```rust
/// 架构设计文档
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArchitectureDesign {
    /// 设计 ID
    pub id: String,

    /// 标题
    pub title: String,

    /// 动机（为什么要做这个变更）
    pub motivation: String,

    /// 当前状态分析
    pub current_state_analysis: String,

    /// 拟议的变更列表
    pub proposed_changes: Vec<ProposedChange>,

    /// 风险评估
    pub risk_assessment: RiskAssessment,

    /// 执行阶段（每个阶段是一个提交点）
    pub execution_phases: Vec<ExecutionPhase>,

    /// 回滚计划
    pub rollback_plan: String,

    /// 成功标准
    pub success_criteria: Vec<String>,

    /// 预估影响
    pub estimated_impact: ImpactEstimate,

    /// 创建时间
    pub created_at: chrono::DateTime<chrono::Utc>,

    /// 审查状态
    pub review_status: ReviewStatus,
}

/// 拟议变更
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProposedChange {
    pub id: String,
    pub description: String,
    pub affected_modules: Vec<String>,
    pub affected_files: Vec<String>,
    pub breaking: bool,
    pub risk_level: RiskLevel,
}

/// 风险评估
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskAssessment {
    pub overall_risk: RiskLevel,
    pub risks: Vec<RiskItem>,
    pub mitigations: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskItem {
    pub description: String,
    pub probability: f64,  // 0.0 - 1.0
    pub impact: RiskLevel,
    pub mitigation: String,
}

/// 执行阶段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionPhase {
    pub phase_number: usize,
    pub title: String,
    pub description: String,
    pub steps: Vec<String>,
    pub files_to_modify: Vec<String>,
    pub tests_to_run: Vec<String>,
    pub commit_message: String,
    pub rollback_commit: Option<String>,  // 回滚到此提交
    pub estimated_duration: Duration,
    pub dependencies: Vec<usize>,  // 依赖的前置阶段
}

/// 影响评估
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImpactEstimate {
    pub files_changed: usize,
    pub modules_affected: usize,
    pub estimated_loc: usize,
    pub breaking_changes: bool,
    pub performance_impact: Option<String>,
    pub test_coverage_change: Option<f64>,
}

/// 审查状态
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ReviewStatus {
    Pending,
    Approved,
    Rejected { reason: String },
    AutoApproved,
}
```

**设计文档存储路径：**

```
.assistant-memory/
└── architecture/
    ├── designs/
    │   ├── 2024-01-15-refactor-auth-module.md
    │   ├── 2024-01-20-introduce-cache-layer.md
    │   └── 2024-02-01-migrate-to-async.md
    └── executed/
        ├── 2024-01-15-refactor-auth-module/
        │   ├── design.json
        │   ├── phase-1-commit.log
        │   ├── phase-2-commit.log
        │   └── result.json
        └── ...
```

### 20.9 Checkpoint 与恢复机制

Checkpoint 机制是 Daemon 模式可靠性的基石。系统定期将运行状态持久化到磁盘，确保在崩溃或重启后能从断点恢复。

```rust
/// 检查点数据
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Checkpoint {
    /// 检查点 ID
    pub id: String,

    /// 创建时间
    pub created_at: std::time::SystemTime,

    /// Daemon 状态快照
    pub daemon_state: DaemonState,

    /// 任务队列快照
    /// 
    /// **存储优化**：完整 task_queue 快照可能很大（含完整任务描述）。
    /// 生产环境应考虑：
    /// - 使用 gzip/zstd 压缩序列化后的 JSON
    /// - 限制快照中保留的任务数量（如最多 100 个待执行任务）
    /// - 仅保留任务 ID 和优先级，完整数据从原始来源恢复
    pub task_queue_snapshot: Vec<DaemonTask>,

    /// 正在执行的任务进度
    pub active_tasks: Vec<TaskProgress>,

    /// Token 使用统计
    pub token_usage: TokenUsageStats,

    /// 累计费用
    pub cost_accumulated: f64,

    /// Agent 上下文摘要
    pub agent_contexts: HashMap<String, ContextSummary>,

    /// 会话历史摘要
    pub session_summaries: Vec<SessionSummary>,
}

/// 任务进度
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskProgress {
    pub task_id: String,
    pub phase: TaskPhase,
    pub started_at: std::time::SystemTime,
    pub steps_completed: Vec<String>,
    pub steps_remaining: Vec<String>,
    pub intermediate_results: HashMap<String, String>,
}

/// 任务执行阶段
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum TaskPhase {
    /// 等待执行
    Pending,
    /// 正在分析
    Analyzing,
    /// 正在修复
    Fixing,
    /// 正在验证
    Verifying,
    /// 正在提交
    Committing,
    /// 已完成
    Completed,
    /// 已失败
    Failed,
}

/// Token 使用统计
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TokenUsageStats {
    pub prompt_tokens: u64,
    pub completion_tokens: u64,
    pub total_tokens: u64,
    pub hourly_tokens: u64,
    pub daily_tokens: u64,
}

/// 上下文摘要（跨会话传递）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContextSummary {
    pub agent_type: String,
    pub task_id: String,
    pub key_findings: Vec<String>,
    pub files_analyzed: Vec<String>,
    pub decisions_made: Vec<String>,
    pub open_questions: Vec<String>,
    pub token_usage: u64,
}

/// 检查点管理器
pub struct CheckpointManager {
    /// 检查点存储目录
    checkpoint_dir: PathBuf,

    /// 配置
    config: CheckpointConfig,

    /// 当前检查点 ID
    current_checkpoint_id: Option<String>,
}

impl CheckpointManager {
    /// 创建检查点
    pub async fn create_checkpoint(
        &self,
        state: &DaemonState,
    ) -> Result<String, DaemonError> {
        let checkpoint = Checkpoint {
            id: uuid::Uuid::new_v4().to_string(),
            created_at: std::time::SystemTime::now(),
            daemon_state: state.clone(),
            // ... 填充其他字段
            task_queue_snapshot: vec![],
            active_tasks: vec![],
            token_usage: TokenUsageStats::default(),
            cost_accumulated: 0.0,
            agent_contexts: HashMap::new(),
            session_summaries: vec![],
        };

        // 序列化并写入文件
        let checkpoint_path = self.checkpoint_dir
            .join(format!("checkpoint-{}.json", checkpoint.id));
        let json = serde_json::to_string_pretty(&checkpoint)?;
        tokio::fs::write(&checkpoint_path, json).await?;

        // 清理旧检查点
        self.cleanup_old_checkpoints().await?;

        Ok(checkpoint.id)
    }

    /// 恢复最近的检查点
    pub async fn restore_latest(
        &self,
    ) -> Result<Option<Checkpoint>, DaemonError> {
        let mut entries: Vec<_> = tokio::fs::read_dir(&self.checkpoint_dir)
            .await?
            .filter_map(|e| e.ok())
            .collect();
        entries.sort_by_key(|e| e.file_name());

        if let Some(entry) = entries.last() {
            let content = tokio::fs::read_to_string(entry.path()).await?;
            let checkpoint: Checkpoint = serde_json::from_str(&content)?;
            Ok(Some(checkpoint))
        } else {
            Ok(None)
        }
    }

    /// 清理旧检查点，保留最近 N 个
    async fn cleanup_old_checkpoints(&self) -> Result<(), DaemonError> {
        let mut entries: Vec<_> = tokio::fs::read_dir(&self.checkpoint_dir)
            .await?
            .filter_map(|e| e.ok())
            .collect();
        entries.sort_by_key(|e| std::cmp::Reverse(e.file_name()));

        for entry in entries.into_iter().skip(self.config.max_checkpoints) {
            tokio::fs::remove_file(entry.path()).await?;
        }
        Ok(())
    }
}
```

### 20.10 上下文窗口跨会话管理

Daemon 模式的核心挑战之一是：LLM 上下文窗口有限，但 Daemon 需要运行数小时甚至数天。解决方案是**基于会话的上下文管理**。

```
┌─────────────────────────────────────────────────────────────────────┐
│                  跨会话上下文管理                                     │
│                                                                     │
│  Session 1                    Session 2                    Session 3│
│  ┌──────────────────┐        ┌──────────────────┐       ┌────────┐ │
│  │ 任务 A: 修复编译  │        │ 任务 B: 修复测试  │       │ 任务 C │ │
│  │ 错误              │        │ 失败              │       │ ...    │ │
│  │                  │        │                  │       │        │ │
│  │ Token: 15K       │        │ Token: 12K       │       │ Token  │ │
│  └────────┬─────────┘        └────────┬─────────┘       └───┬────┘ │
│           │                           │                      │      │
│           ▼                           ▼                      ▼      │
│  ┌──────────────────┐        ┌──────────────────┐       ┌────────┐ │
│  │ SessionSummary   │        │ SessionSummary   │       │Session │ │
│  │ · 修复了 X 文件  │        │ · 修复了 Y 测试  │       │Summary │ │
│  │ · 发现了 Z 问题  │        │ · 避免了 W 陷阱  │       │        │ │
│  └────────┬─────────┘        └────────┬─────────┘       └───┬────┘ │
│           │                           │                      │      │
│           └───────────┬───────────────┴──────────────────────┘      │
│                       │                                              │
│                       ▼                                              │
│           ┌──────────────────────┐                                   │
│           │   ProjectMemory      │                                   │
│           │   (持久化知识库)      │                                   │
│           │                      │                                   │
│           │ · tech-stack.json    │                                   │
│           │ · conventions.json   │                                   │
│           │ · architecture/      │                                   │
│           │ · bug-patterns.json  │                                   │
│           └──────────────────────┘                                   │
└─────────────────────────────────────────────────────────────────────┘
```

```rust
/// 会话管理器
pub struct SessionManager {
    /// 当前活跃会话
    pub current_session: Option<Session>,

    /// 历史会话摘要
    pub session_history: Vec<SessionSummary>,

    /// 最大保留会话数（默认 50）
    pub max_sessions_to_keep: usize,
}

/// 会话
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Session {
    /// 会话 ID
    pub id: String,

    /// 开始时间
    pub started_at: chrono::DateTime<chrono::Utc>,

    /// 关联的任务
    pub task: DaemonTask,

    /// Token 使用统计
    pub token_usage: TokenUsageStats,

    /// 执行结果
    pub result: Option<TaskResult>,
}

/// 会话摘要（跨会话传递的结构化信息）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionSummary {
    /// 会话 ID
    pub session_id: String,

    /// 任务 ID
    pub task_id: String,

    /// 任务描述
    pub task_description: String,

    /// 执行结果
    pub outcome: SessionOutcome,

    /// 关键发现（传递给下一个会话）
    pub key_findings: Vec<String>,

    /// 修改的文件列表
    pub files_modified: Vec<String>,

    /// 遇到的问题和解决方案
    pub lessons_learned: Vec<String>,

    /// Token 消耗
    pub token_used: u64,

    /// 时间戳
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

/// 会话结果
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum SessionOutcome {
    Success,
    Failed { reason: String },
    Partial { completed_steps: usize, total_steps: usize },
    Escalated { reason: String },
}

impl SessionManager {
    /// 开始新会话
    pub fn start_session(&mut self, task: DaemonTask) -> Session {
        let session = Session {
            id: uuid::Uuid::new_v4().to_string(),
            started_at: chrono::Utc::now(),
            task,
            token_usage: TokenUsageStats::default(),
            result: None,
        };
        self.current_session = Some(session.clone());
        session
    }

    /// 结束当前会话，生成摘要
    pub fn end_session(&mut self, result: TaskResult) -> SessionSummary {
        let session = self.current_session.take()
            .expect("No active session");

        let summary = SessionSummary {
            session_id: session.id.clone(),
            task_id: session.task.id.clone(),
            task_description: session.task.description.clone(),
            outcome: match result.status {
                ExecutionStatus::Completed => SessionOutcome::Success,
                ExecutionStatus::Failed { error } => SessionOutcome::Failed {
                    reason: result.error_message.unwrap_or_default(),
                },
            },
            key_findings: result.key_findings,
            files_modified: result.files_modified,
            lessons_learned: result.lessons_learned,
            token_used: session.token_usage.total_tokens,
            timestamp: chrono::Utc::now(),
        };

        self.session_history.push(summary.clone());

        // 清理旧会话
        if self.session_history.len() > self.max_sessions_to_keep {
            self.session_history = self.session_history
                .split_off(self.session_history.len() - self.max_sessions_to_keep);
        }

        summary
    }

    /// 为新会话构建上下文（注入历史摘要）
    pub fn build_context_for_session(&self, task: &DaemonTask) -> String {
        let mut context = String::new();

        // 注入相关的历史会话摘要
        let relevant_summaries: Vec<_> = self.session_history
            .iter()
            .filter(|s| {
                // 选择与当前任务相关的历史会话
                s.files_modified.iter().any(|f| {
                    task.context.related_files.contains(f)
                })
            })
            .take(5)  // 最多注入 5 个相关摘要
            .collect();

        if !relevant_summaries.is_empty() {
            context.push_str("## 相关历史会话\n\n");
            for summary in relevant_summaries {
                context.push_str(&format!(
                    "- [{}] {}: {:?} - 发现: {}\n",
                    summary.task_id,
                    summary.task_description,
                    summary.outcome,
                    summary.key_findings.join("; "),
                ));
            }
        }

        context
    }
}
```

**上下文管理策略总结：**

| 策略 | 说明 | 效果 |
|------|------|------|
| 会话隔离 | 每个任务独立会话，不继承前一会话的完整对话历史 | 避免上下文污染 |
| 结构化摘要 | 会话结束后生成结构化摘要，只传递关键信息 | 节省 80%+ Token |
| 项目记忆 | 持久化知识库提供跨会话的稳定知识基础 | 避免重复分析 |
| 相关性过滤 | 只注入与当前任务相关的历史摘要 | 提高信息密度 |
| Token 预算 | 每个会话有独立的 Token 预算 | 防止单次任务消耗过多 |

### 20.11 成本控制与资源管理

长时间运行的 Daemon 必须严格控制 API 使用成本，防止费用失控。

```rust
/// 成本追踪器
pub struct CostTracker {
    /// 每小时 Token 计数（原子操作，线程安全）
    pub hourly_tokens: AtomicU64,

    /// 每天 Token 计数
    pub daily_tokens: AtomicU64,

    /// 每天累计费用（美分）
    pub daily_cost: AtomicU64,

    /// 每小时 Token 上限
    pub hourly_limit: usize,

    /// 每天 Token 上限
    pub daily_limit: usize,

    /// 每天费用上限（美元）
    pub daily_cost_limit: f64,

    /// 每小时 Git 提交计数
    pub hourly_commits: AtomicU32,

    /// 每小时 Git 提交上限
    pub hourly_commit_limit: usize,

    /// 费用历史记录
    cost_history: Vec<CostRecord>,
}

/// 费用记录
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CostRecord {
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub tokens_used: u64,
    pub cost_usd: f64,
    pub task_id: String,
    pub model: String,
}

impl CostTracker {
    /// 检查是否可以执行任务
    pub async fn can_afford(&self, task: &DaemonTask) -> bool {
        let current_hourly = self.hourly_tokens.load(Ordering::Relaxed);
        let current_daily = self.daily_tokens.load(Ordering::Relaxed);
        let current_cost = self.daily_cost.load(Ordering::Relaxed) as f64 / 100.0;

        // 检查各项限制
        if current_hourly >= self.hourly_limit as u64 {
            tracing::warn!("每小时 Token 限制已达到: {}/{}", current_hourly, self.hourly_limit);
            return false;
        }

        if current_daily >= self.daily_limit as u64 {
            tracing::warn!("每天 Token 限制已达到: {}/{}", current_daily, self.daily_limit);
            return false;
        }

        if current_cost >= self.daily_cost_limit {
            tracing::warn!("每天费用限制已达到: ${:.2}/${:.2}", current_cost, self.daily_cost_limit);
            return false;
        }

        true
    }

    /// 记录 Token 使用
    pub fn record_usage(&self, tokens: u64, cost_usd: f64, task_id: &str, model: &str) {
        self.hourly_tokens.fetch_add(tokens, Ordering::Relaxed);
        self.daily_tokens.fetch_add(tokens, Ordering::Relaxed);
        self.daily_cost.fetch_add((cost_usd * 100.0) as u64, Ordering::Relaxed);
    }

    /// 重置每小时计数（定时调用）
    pub fn reset_hourly(&self) {
        self.hourly_tokens.store(0, Ordering::Relaxed);
        self.hourly_commits.store(0, Ordering::Relaxed);
    }

    /// 重置每天计数（定时调用）
    pub fn reset_daily(&self) {
        self.daily_tokens.store(0, Ordering::Relaxed);
        self.daily_cost.store(0, Ordering::Relaxed);
    }

    /// 获取当前使用率
    pub fn usage_report(&self) -> UsageReport {
        let hourly = self.hourly_tokens.load(Ordering::Relaxed);
        let daily = self.daily_tokens.load(Ordering::Relaxed);
        let cost = self.daily_cost.load(Ordering::Relaxed) as f64 / 100.0;

        UsageReport {
            hourly_tokens: hourly,
            hourly_limit: self.hourly_limit,
            hourly_usage_percent: (hourly as f64 / self.hourly_limit as f64) * 100.0,
            daily_tokens: daily,
            daily_limit: self.daily_limit,
            daily_usage_percent: (daily as f64 / self.daily_limit as f64) * 100.0,
            daily_cost_usd: cost,
            daily_cost_limit: self.daily_cost_limit,
            cost_usage_percent: (cost / self.daily_cost_limit) * 100.0,
        }
    }
}

/// 使用率报告
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UsageReport {
    pub hourly_tokens: u64,
    pub hourly_limit: usize,
    pub hourly_usage_percent: f64,
    pub daily_tokens: u64,
    pub daily_limit: usize,
    pub daily_usage_percent: f64,
    pub daily_cost_usd: f64,
    pub daily_cost_limit: f64,
    pub cost_usage_percent: f64,
}
```

**成本控制策略：**

| 策略 | 触发条件 | 动作 |
|------|----------|------|
| **软限制告警** | 使用率达到 70% | 发送 CostWarning 通知 |
| **硬限制暂停** | 使用率达到 90% | 暂停新任务，等待配额刷新 |
| **自动降级** | 使用率达到 80% | 降低并发数，使用更便宜的模型 |
| **紧急停止** | 费用超过上限 | 立即停止所有任务，通知用户 |

### 20.12 通知系统

通知系统确保用户在需要时能及时收到 Daemon 的状态更新，同时避免过度打扰。

```rust
/// 通知服务
pub struct NotificationService {
    /// 配置的通知渠道
    channels: Vec<NotificationChannel>,

    /// 需要通知的事件类型
    important_events: HashSet<EventType>,

    /// 安静时段
    quiet_hours: Option<(NaiveTime, NaiveTime)>,

    /// 摘要模式
    digest_mode: bool,

    /// 摘要缓冲区
    digest_buffer: Vec<Notification>,

    /// 摘要发送间隔
    digest_interval: Duration,
}

/// 通知
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Notification {
    pub event_type: EventType,
    pub title: String,
    pub message: String,
    pub priority: TaskPriority,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

impl NotificationService {
    /// 发送通知
    pub async fn send(&self, notification: Notification) {
        // 1. 检查是否在安静时段内
        if self.is_in_quiet_hours(&notification) {
            // 非关键通知延迟发送
            if notification.priority != TaskPriority::Critical {
                self.buffer_for_digest(notification).await;
                return;
            }
        }

        // 2. 摘要模式：缓冲非关键通知
        if self.digest_mode && notification.priority != TaskPriority::Critical {
            self.buffer_for_digest(notification).await;
            return;
        }

        // 3. 发送到所有渠道
        for channel in &self.channels {
            self.send_to_channel(channel, &notification).await;
        }
    }

    /// 检查是否在安静时段内
    fn is_in_quiet_hours(&self, notification: &Notification) -> bool {
        if let Some((start, end)) = &self.quiet_hours {
            let now = chrono::Local::now().time();
            // 简单判断：当前时间是否在安静时段内
            if start <= end {
                now >= *start && now <= *end
            } else {
                // 跨午夜的情况（如 23:00 - 08:00）
                now >= *start || now <= *end
            }
        } else {
            false
        }
    }

    /// 发送到特定渠道
    async fn send_to_channel(&self, channel: &NotificationChannel, notification: &Notification) {
        match channel {
            NotificationChannel::Terminal { bell } => {
                if *bell {
                    eprintln!("\x07");  // 终端响铃
                }
                println!("[Daemon] [{}] {}", notification.event_type, notification.title);
                println!("  {}", notification.message);
            }
            NotificationChannel::Desktop { os_notification } => {
                if *os_notification {
                    // 使用 notify-rust 发送桌面通知
                    let _ = notify_rust::Notification::new()
                        .title(&notification.title)
                        .body(&notification.message)
                        .show();
                }
            }
            NotificationChannel::Webhook { url, headers } => {
                // 发送 Webhook 通知
                let client = reqwest::Client::new();
                let payload = serde_json::json!({
                    "event_type": notification.event_type,
                    "title": notification.title,
                    "message": notification.message,
                    "priority": format!("{:?}", notification.priority),
                    "timestamp": notification.timestamp.to_rfc3339(),
                });

                if let Err(e) = client.post(url)
                    .headers(headers.clone().try_into().unwrap_or_default())
                    .json(&payload)
                    .send()
                    .await
                {
                    tracing::error!("Webhook 通知发送失败: {}", e);
                }
            }
            NotificationChannel::Email { smtp_config } => {
                // 发送邮件通知（使用 lettre 库）
                self.send_email(smtp_config, notification).await;
            }
        }
    }

    /// 缓冲通知用于摘要发送
    async fn buffer_for_digest(&self, notification: Notification) {
        // 将通知添加到缓冲区，等待摘要发送
        // 实际实现中需要使用 Mutex 或通道
    }
}
```

**通知策略矩阵：**

| 事件类型 | MonitorOnly | SemiAuto | FullAuto | 安静时段 |
|----------|:-----------:|:--------:|:--------:|:--------:|
| TaskCompleted | 不通知 | 摘要 | 摘要 | 延迟 |
| TaskFailed | 通知 | 通知 | 通知 | 延迟 |
| BugFixed | 通知 | 通知 | 摘要 | 延迟 |
| ApprovalNeeded | - | 立即 | - | 立即 |
| CostWarning | 通知 | 通知 | 通知 | 立即 |
| ErrorEscalation | 通知 | 通知 | 通知 | 立即 |
| ArchitecturePlanReady | 通知 | 立即 | 摘要 | 延迟 |
| CheckpointCreated | 不通知 | 不通知 | 不通知 | 不通知 |

### 20.13 优雅降级与错误恢复

Daemon 模式必须具备强大的错误恢复能力，确保在遇到各种异常情况时能优雅处理。

```
┌─────────────────────────────────────────────────────────────────────┐
│                     错误恢复策略                                     │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                      错误分类                                 │  │
│  │                                                              │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐   │  │
│  │  │  可恢复错误   │  │  可降级错误   │  │   致命错误        │   │  │
│  │  │ Recoverable  │  │  Degradable  │  │   Fatal          │   │  │
│  │  │              │  │              │  │                  │   │  │
│  │  │ · 网络超时    │  │ · API 限流   │  │ · 配置错误       │   │  │
│  │  │ · 临时故障    │  │ · Token 超限 │  │ · 权限不足       │   │  │
│  │  │ · 文件锁定    │  │ · 模型不可用 │  │ · 磁盘空间不足   │   │  │
│  │  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘   │  │
│  └─────────┼─────────────────┼────────────────────┼─────────────┘  │
│            │                 │                    │                 │
│            ▼                 ▼                    ▼                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐         │
│  │ 指数退避重试  │  │ 降级策略     │  │ 通知用户 + 暂停   │         │
│  │              │  │              │  │                  │         │
│  │ retry 1: 2s  │  │ · 切换模型   │  │ · 发送告警       │         │
│  │ retry 2: 4s  │  │ · 降低并发   │  │ · 创建检查点     │         │
│  │ retry 3: 8s  │  │ · 跳过非关键 │  │ · 暂停任务队列   │         │
│  │ max: 3 次    │  │   任务       │  │ · 等待人工介入   │         │
│  └──────────────┘  └──────────────┘  └──────────────────┘         │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                    熔断器 (Circuit Breaker)                   │  │
│  │                                                              │  │
│  │  ┌──────────┐    失败率 > 50%    ┌──────────┐               │  │
│  │  │  Closed  │─────────────────▶│   Open   │               │  │
│  │  │ (正常)   │                   │  (熔断)   │               │  │
│  │  └──────────┘                   └────┬─────┘               │  │
│  │       ▲                              │                      │  │
│  │       │          超时 30s            │                      │  │
│  │       │◀─────────────────────────────┘                      │  │
│  │       │                                                      │  │
│  │  ┌──────────┐                   ┌──────────┐               │  │
│  │  │  Closed  │◀───探测成功──────│Half-Open │               │  │
│  │  └──────────┘                   └──────────┘               │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

```rust
/// 错误级别
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ErrorLevel {
    /// 可恢复：重试即可
    Recoverable,
    /// 可降级：切换到更简单的策略
    Degradable,
    /// 致命：需要人工介入
    Fatal,
}

/// 熔断器
pub struct CircuitBreaker {
    /// 熔断器状态
    state: CircuitState,

    /// 失败计数
    failure_count: usize,

    /// 成功计数（Half-Open 状态下使用）
    success_count: usize,

    /// 触发熔断的失败率阈值
    failure_threshold: f64,

    /// 总请求数
    total_requests: usize,

    /// 熔断恢复超时
    recovery_timeout: Duration,

    /// 上次状态变更时间
    last_state_change: Instant,
}

#[derive(Debug, Clone, PartialEq)]
pub enum CircuitState {
    /// 正常状态
    Closed,
    /// 熔断状态（拒绝请求）
    Open,
    /// 半开状态（允许探测请求）
    HalfOpen,
}

impl CircuitBreaker {
    /// 记录成功
    pub fn record_success(&mut self) {
        self.success_count += 1;
        self.total_requests += 1;

        if self.state == CircuitState::HalfOpen {
            // 半开状态下连续 3 次成功则恢复正常
            if self.success_count >= 3 {
                self.state = CircuitState::Closed;
                self.failure_count = 0;
                self.success_count = 0;
                self.last_state_change = Instant::now();
            }
        }
    }

    /// 记录失败
    pub fn record_failure(&mut self) {
        self.failure_count += 1;
        self.total_requests += 1;

        let failure_rate = self.failure_count as f64 / self.total_requests as f64;

        if failure_rate > self.failure_threshold {
            self.state = CircuitState::Open;
            self.last_state_change = Instant::now();
        }
    }

    /// 检查是否允许请求
    pub fn allow_request(&mut self) -> bool {
        match self.state {
            CircuitState::Closed => true,
            CircuitState::Open => {
                // 检查是否超过恢复超时
                if self.last_state_change.elapsed() > self.recovery_timeout {
                    self.state = CircuitState::HalfOpen;
                    self.success_count = 0;
                    true  // 允许一个探测请求
                } else {
                    false
                }
            }
            CircuitState::HalfOpen => true,
        }
    }
}

/// 错误处理器
pub struct ErrorHandler {
    circuit_breakers: HashMap<String, CircuitBreaker>,
    retry_config: RetryConfig,
}

#[derive(Debug, Clone)]
pub struct RetryConfig {
    pub max_retries: u32,
    pub base_delay: Duration,
    pub max_delay: Duration,
    pub jitter: bool,
}

impl ErrorHandler {
    /// 带重试的执行
    pub async fn with_retry<F, Fut, T>(
        &self,
        name: &str,
        f: F,
    ) -> Result<T, DaemonError>
    where
        F: Fn(u32) -> Fut,
        Fut: std::future::Future<Output = Result<T, DaemonError>>,
    {
        // 检查熔断器
        let breaker = self.circuit_breakers
            .entry(name.to_string())
            .or_insert_with(|| CircuitBreaker::new(0.5, Duration::seconds(30)));

        if !breaker.allow_request() {
            return Err(DaemonError::CircuitOpen(name.to_string()));
        }

        let mut last_error = None;

        for attempt in 0..=self.retry_config.max_retries {
            match f(attempt).await {
                Ok(result) => {
                    breaker.record_success();
                    return Ok(result);
                }
                Err(e) => {
                    breaker.record_failure();
                    last_error = Some(e);

                    if attempt < self.retry_config.max_retries {
                        // 指数退避 + 随机抖动
                        let delay = self.retry_config.base_delay
                            * 2_u32.pow(attempt)
                            .min(self.retry_config.max_delay);

                        let delay = if self.retry_config.jitter {
                            let jitter = rand::thread_rng()
                                .gen_range(0..delay / 2);
                            delay + jitter
                        } else {
                            delay
                        };

                        tracing::warn!(
                            "任务 {} 第 {} 次重试，等待 {:?}",
                            name, attempt + 1, delay
                        );
                        tokio::time::sleep(delay).await;
                    }
                }
            }
        }

        Err(last_error.unwrap())
    }
}
```

### 20.14 与现有系统的集成点

Daemon 模式并非独立系统，而是构建在现有多 Agent 编排架构之上的一种运行能力扩展。

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Daemon 模式集成架构                                │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                    新增组件（本章）                            │  │
│  │                                                              │  │
│  │  ┌─────────────────┐  ┌──────────────┐  ┌────────────────┐  │  │
│  │  │DaemonController │  │  TaskQueue   │  │CheckpointMgr   │  │  │
│  │  └────────┬────────┘  └──────────────┘  └────────────────┘  │  │
│  │           │                                                  │  │
│  │  ┌────────┴────────┐  ┌──────────────┐  ┌────────────────┐  │  │
│  │  │NotificationSvc  │  │ CostTracker  │  │ SessionManager │  │  │
│  │  └─────────────────┘  └──────────────┘  └────────────────┘  │  │
│  └──────────────────────────┬───────────────────────────────────┘  │
│                             │                                      │
│                             │ 调用                                  │
│                             ▼                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                    复用组件（已有章节）                         │  │
│  │                                                              │  │
│  │  ┌─────────────────┐  ┌──────────────┐  ┌────────────────┐  │  │
│  │  │AgentOrchestrator│  │CommitExecutor│  │ProjectMemory  │  │  │
│  │  │  (第 7 章)     │  │  (第 14 章)  │  │  (第 18 章)    │  │  │
│  │  └─────────────────┘  └──────────────┘  └────────────────┘  │  │
│  │                                                              │  │
│  │  ┌─────────────────┐  ┌──────────────┐  ┌────────────────┐  │  │
│  │  │RecursiveOrch.   │  │  Router      │  │  ContextMgr    │  │  │
│  │  │  (第 17 章)     │  │  (第 7 章)  │  │  (第 9 章)    │  │  │
│  │  └─────────────────┘  └──────────────┘  └────────────────┘  │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

**集成关系详细说明：**

| 新增组件 | 复用组件 | 集成方式 | 说明 |
|----------|----------|----------|------|
| DaemonController | AgentOrchestrator | 方法调用 | Daemon 通过 Orchestrator 执行任务，复用路由和编排逻辑 |
| DaemonController | CommitExecutor | 方法调用 | 修复完成后通过 CommitExecutor 提交代码 |
| TaskQueue | Router | 事件驱动 | 任务到达后通过 Router 决定使用哪些 Agent |
| SessionManager | ContextManager | 上下文注入 | 每个会话开始时通过 ContextManager 构建上下文 |
| ResultProcessor | ProjectMemory | 读写 | 任务完成后更新项目记忆 |
| CheckpointManager | ProjectMemory | 读取 | 恢复时从项目记忆加载知识 |
| DaemonController | RecursiveOrchestrator | 方法调用 | 复杂任务使用递归编排拆分 |

**CLI 入口点集成：**

```rust
// 在 CLI 入口处添加 Daemon 模式支持
pub fn main() {
    let cli = Cli::parse();

    if cli.daemon {
        // Daemon 模式：启动长程自主运行
        tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .unwrap()
            .block_on(async {
                let config = DaemonConfig::load(&cli.config_path)?;
                let controller = DaemonController::new(config).await?;
                controller.start().await?;
                Ok::<(), DaemonError>(())
            });
    } else {
        // 正常模式：单次交互
        // ... 现有逻辑
    }
}

// TUI 中集成 Daemon 控制面板
// 用户可以通过 TUI 查看 Daemon 状态、审批请求、查看日志
impl App {
    fn handle_daemon_command(&mut self, command: &str) {
        match command {
            "/daemon start" => { /* 启动 Daemon */ }
            "/daemon stop" => { /* 停止 Daemon */ }
            "/daemon pause" => { /* 暂停 Daemon */ }
            "/daemon resume" => { /* 恢复 Daemon */ }
            "/daemon status" => { /* 查看状态 */ }
            "/daemon config" => { /* 查看配置 */ }
            "/daemon approve <id>" => { /* 审批请求 */ }
            "/daemon reject <id>" => { /* 拒绝请求 */ }
            "/daemon cost" => { /* 查看费用 */ }
            "/daemon logs" => { /* 查看日志 */ }
            _ => {}
        }
    }
}
```

### 20.15 Rust 依赖

Daemon 模式在现有依赖基础上，需要引入以下新的 Crate：

```toml
[dependencies]
# === 已有依赖（保持不变） ===
tokio = { version = "1", features = ["full"] }
serde = { version = "1", features = ["derive"] }
serde_json = "1"
anyhow = "1"
tracing = "0.1"
uuid = { version = "1", features = ["v4"] }

# === Daemon 模式新增依赖 ===

# 异步运行时（扩展 signal 特性用于优雅关闭）
tokio = { version = "1", features = ["full", "signal"] }

# 稳定快速哈希（任务去重、内容指纹）
xxhash-rust = { version = "0.8", features = ["xxh3"] }

# 时间处理（用于安静时段、超时等）
chrono = { version = "0.4", features = ["serde"] }

# 文件系统监视（用于配置文件热重载）
notify = "6"

# 邮件通知（可选功能）
lettre = { version = "0.11", optional = true }

# HTTP 客户端（用于 Webhook 通知）
reqwest = { version = "0.12", features = ["json"] }

# 桌面通知（可选功能）
notify-rust = { version = "4", optional = true }

# 随机数（用于重试抖动）
rand = "0.8"

# TOML 配置解析
toml = "0.8"
```

**依赖分类：**

| 依赖 | 用途 | 是否必须 |
|------|------|:--------:|
| `tokio` (signal) | 处理 SIGTERM/SIGINT 信号实现优雅关闭 | 是 |
| `chrono` | 时间计算（安静时段、超时、定时任务） | 是 |
| `notify` | 监视配置文件变更实现热重载 | 是 |
| `reqwest` | 发送 Webhook 通知 | 是 |
| `rand` | 重试抖动（jitter） | 是 |
| `toml` | 解析 TOML 配置文件 | 是 |
| `lettre` | 发送邮件通知 | 否（可选） |
| `notify-rust` | 桌面操作系统通知 | 否（可选） |

---

> **本章总结**
>
> 第 20 章介绍了长程自主运行系统（Daemon 模式）的完整设计，是整个多 Agent 编排架构从"按需响应"到"持续守护"的关键进化。
>
> - **设计动机**：大型项目需要 7×24 自主运行能力，支持三种自主级别（半自动、全自动、仅监控），通过配置文件灵活控制。
>
> - **架构总览**：DaemonController 作为生命周期管理器，通过事件驱动主循环协调 TaskQueue、AgentOrchestrator、ResultProcessor 等组件，状态机管理 Idle → Running → Paused → WaitingApproval → ShuttingDown 的转换。
>
> - **配置系统**：精细化的 TOML 配置，涵盖审批策略、通知渠道、资源限制、检查点策略和架构设计配置，支持热重载。
>
> - **任务管理**：支持 GitHook、LogMonitor、CronSchedule、UserRequest、DependencyUpdate、PerformanceMonitor 六种任务来源，优先级排序和去重机制。
>
> - **Bug 修复**：自动发现、分类、修复、验证、提交的完整流程，根据自主级别和 Bug 严重程度决定修复策略。
>
> - **架构设计**：自动生成架构设计文档，分阶段执行大规模重构，每个阶段是独立的提交点，失败时自动回滚。
>
> - **可靠性保障**：Checkpoint 机制确保崩溃恢复，会话管理实现跨会话上下文传递，成本追踪防止费用失控，熔断器和重试策略保障系统稳定性。
>
> - **系统集成**：Daemon 模式构建在现有 AgentOrchestrator、CommitExecutor、ProjectMemory 等组件之上，通过 CLI `--daemon` 标志或 `/daemon start` 命令启动。

---
