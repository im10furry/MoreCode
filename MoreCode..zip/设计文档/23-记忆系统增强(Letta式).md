# MoreCode — 记忆系统增强（Letta 式分层）

> **定位**：Agent 系统的分层记忆基础设施，从平面文件存储升级为四层自主管理记忆架构
> **关联章节**：16-可观测性与 Hook 系统、18-项目记忆系统、20-Daemon 模式、21-大文件智能读取

---

## 23. 记忆系统增强（Letta 式分层）

### 23.1 核心思想

现有第18章记忆系统（`.assistant-memory/` 文件目录）是平面存储，缺乏分层管理和 Agent 自主管理能力。参考 Letta（MemGPT）的分层记忆架构，升级为四层分层记忆。

**现有平面记忆 vs Letta 式分层记忆**：

```
  现有平面记忆（第18章）                    Letta 式分层记忆（本章）

  .assistant-memory/                   ┌─────────────────────────┐
  ├── user_preferences.json           │     Core Memory         │  ← 始终在上下文中
  ├── project_conventions.md          │  (Agent 自主读写)        │     Agent 可自主编辑
  ├── task_states.json                ├─────────────────────────┤
  ├── error_patterns.log              │    Working Memory       │  ← 当前会话文件缓存
  ├── conversation_history/           │  (LRU 100文件/25MB)     │     高频访问文件
  │   ├── 2024-01-01.json             ├─────────────────────────┤
  │   └── 2024-01-02.json             │    Recall Memory        │  ← 完整对话历史
  └── knowledge/                      │  (可搜索对话存档)        │     支持语义搜索
      ├── api_design.md               ├─────────────────────────┤
      └── patterns.md                 │   Archival Memory       │  ← 结构化知识库
                                      │  (SQLite+tantivy)       │     全文/向量检索
  问题：                              └─────────────────────────┘
  - 所有记忆同级，无优先级区分
  - Agent 无法自主管理记忆              优势：
  - 上下文窗口浪费在低优先级信息上        - 分层管理，优先级明确
  - 无法按需召回历史信息                - Agent 自主决定记忆读写
                                      - 上下文窗口利用率最大化
                                      - 支持按需召回与归档
```

**设计原则**：

1. **分层管理**：四层记忆各有职责，优先级从高到低自动调度
2. **Agent 自主**：Core Memory 由 Agent 通过工具调用自主管理，无需人工干预
3. **渐进增强**：Phase 1 文件存储起步，Phase 2 全文搜索，Phase 3 向量检索，Phase 4 图谱记忆
4. **向后兼容**：现有 `.assistant-memory/` 数据可无缝迁移到新架构

---

### 23.2 四层记忆架构

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Agent Context Window                          │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                    Core Memory (核心记忆)                      │  │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐             │  │
│  │  │ UserPref    │ │ ProjectConv │ │ TaskState   │  ...        │  │
│  │  │ Block #1    │ │ Block #2    │ │ Block #3    │             │  │
│  │  │ priority:1  │ │ priority:2  │ │ priority:1  │             │  │
│  │  └─────────────┘ └─────────────┘ └─────────────┘             │  │
│  │  始终在上下文内 · Agent 可自主读写 · 结构化 MemoryBlock        │  │
│  └───────────────────────────────────────────────────────────────┘  │
│                              │                                      │
│                    tool_call / search                               │
│                              │                                      │
│  ┌───────────────────────────┼───────────────────────────────────┐  │
│  │                    Memory Manager                              │  │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐  │  │
│  │  │ Working Memory  │  │ Recall Memory   │  │ Archival     │  │  │
│  │  │                 │  │                 │  │ Memory       │  │  │
│  │  │ LRU File Cache  │  │ Conversation    │  │              │  │  │
│  │  │ 100 files       │  │ Store          │  │ Knowledge    │  │  │
│  │  │ 25MB cap        │  │                 │  │ Store        │  │  │
│  │  │                 │  │ - 完整对话历史   │  │              │  │  │
│  │  │ - 当前会话      │  │ - 语义搜索      │  │ - SQLite     │  │  │
│  │  │   高频文件      │  │ - 时间范围过滤   │  │ - tantivy    │  │  │
│  │  │ - 自动淘汰      │  │ - 关键词提取     │  │ - 后续向量   │  │  │
│  │  │                 │  │                 │  │   扩展       │  │  │
│  │  └─────────────────┘  └─────────────────┘  └──────────────┘  │  │
│  └───────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                   Sleep-Time Compute (后台)                    │  │
│  │  Daemon 模式下异步记忆整合 · 自动归档 · 知识提取                 │  │
│  └───────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

**四层职责总览**：

| 层级 | 名称 | 存储位置 | 生命周期 | 访问模式 |
|------|------|----------|----------|----------|
| L0 | Core Memory | 内存 + 持久化 JSON | 永久，Agent 自主管理 | 始终在上下文窗口内 |
| L1 | Working Memory | 内存 LRU 缓存 | 会话级，LRU 淘汰 | 高频文件快速访问 |
| L2 | Recall Memory | SQLite 数据库 | 永久，按会话存储 | 按需搜索召回 |
| L3 | Archival Memory | SQLite + tantivy | 永久，结构化存储 | 全文/向量检索 |

---

### 23.3 Core Memory 详细设计

Core Memory 是整个记忆系统的核心，始终驻留在 Agent 的上下文窗口中。Agent 通过工具调用自主管理这些记忆块。

#### 23.3.1 数据结构

```rust
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Core Memory 中的单个记忆块
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MemoryBlock {
    /// 唯一标识符，格式: "{category}:{short_id}"
    pub id: String,

    /// 记忆分类
    pub category: MemoryCategory,

    /// 记忆内容（纯文本，Agent 可读写）
    pub content: String,

    /// 优先级 1-10，1 = 最高（始终保留），10 = 最低（可被压缩）
    pub priority: u8,

    /// 版本号，每次修改递增
    pub version: u32,

    /// 创建时间
    pub created_at: DateTime<Utc>,

    /// 最后修改时间
    pub updated_at: DateTime<Utc>,

    /// 最后由哪个 Agent 修改
    pub last_modified_by: String,

    /// 访问频率统计（用于优先级动态调整）
    pub access_count: u64,
}

/// 记忆分类枚举
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum MemoryCategory {
    /// 用户偏好：编码风格、命名习惯、常用框架
    UserPreference,

    /// 项目约定：架构决策、代码规范、目录结构
    ProjectConvention,

    /// 任务状态：当前任务进度、待办事项、阻塞项
    TaskState,

    /// 错误模式：已遇到的错误及解决方案
    ErrorPattern,

    /// 上下文信息：项目背景、业务领域知识
    Context,

    /// 自定义分类
    Custom(String),
}

impl MemoryCategory {
    /// 返回分类的默认优先级
    pub fn default_priority(&self) -> u8 {
        match self {
            MemoryCategory::UserPreference => 2,
            MemoryCategory::ProjectConvention => 3,
            MemoryCategory::TaskState => 1,
            MemoryCategory::ErrorPattern => 4,
            MemoryCategory::Context => 5,
            MemoryCategory::Custom(_) => 6,
        }
    }

    /// 返回分类显示名
    pub fn display_name(&self) -> &str {
        match self {
            MemoryCategory::UserPreference => "用户偏好",
            MemoryCategory::ProjectConvention => "项目约定",
            MemoryCategory::TaskState => "任务状态",
            MemoryCategory::ErrorPattern => "错误模式",
            MemoryCategory::Context => "上下文信息",
            MemoryCategory::Custom(name) => name.as_str(),
        }
    }
}

/// Core Memory 管理器
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoreMemory {
    /// 所有记忆块，按 ID 索引
    blocks: HashMap<String, MemoryBlock>,

    /// Core Memory 的 Token 预算上限
    token_budget: usize,

    /// 当前已使用的 Token 估算
    current_tokens: usize,
}

impl CoreMemory {
    /// 创建新的 Core Memory
    pub fn new(token_budget: usize) -> Self {
        Self {
            blocks: HashMap::new(),
            token_budget,
            current_tokens: 0,
        }
    }

    /// 添加或更新记忆块
    pub fn upsert_block(&mut self, mut block: MemoryBlock) -> Result<(), MemoryError> {
        let estimated_tokens = estimate_tokens(&block.content);

        // 检查 Token 预算
        if !self.blocks.contains_key(&block.id) {
            if self.current_tokens + estimated_tokens > self.token_budget {
                return Err(MemoryError::TokenBudgetExceeded {
                    required: estimated_tokens,
                    available: self.token_budget - self.current_tokens,
                });
            }
        } else {
            // 更新时减去旧内容的 Token
            let old_tokens = self.blocks.get(&block.id)
                .map(|b| estimate_tokens(&b.content))
                .unwrap_or(0);
            self.current_tokens = self.current_tokens.saturating_sub(old_tokens);
        }

        block.version += 1;
        block.updated_at = Utc::now();
        self.current_tokens += estimated_tokens;
        self.blocks.insert(block.id.clone(), block);
        Ok(())
    }

    /// 删除记忆块
    pub fn remove_block(&mut self, id: &str) -> Option<MemoryBlock> {
        if let Some(block) = self.blocks.remove(id) {
            self.current_tokens = self.current_tokens
                .saturating_sub(estimate_tokens(&block.content));
            Some(block)
        } else {
            None
        }
    }

    /// 按分类获取记忆块
    pub fn get_by_category(&self, category: &MemoryCategory) -> Vec<&MemoryBlock> {
        self.blocks.values()
            .filter(|b| &b.category == category)
            .collect()
    }

    /// 获取所有记忆块（按优先级排序）
    pub fn get_all_sorted(&self) -> Vec<&MemoryBlock> {
        let mut blocks: Vec<&MemoryBlock> = self.blocks.values().collect();
        blocks.sort_by_key(|b| b.priority);
        blocks
    }

    /// 压缩低优先级记忆以释放 Token 空间
    pub fn compact(&mut self, target_tokens: usize) -> Vec<MemoryBlock> {
        let mut evicted = Vec::new();
        let mut blocks: Vec<_> = self.blocks.iter_mut().collect();

        // 按优先级降序排列（低优先级先淘汰）
        blocks.sort_by(|a, b| b.1.priority.cmp(&a.1.priority));

        for (_, block) in blocks.iter_mut() {
            if self.current_tokens <= target_tokens {
                break;
            }
            // 将低优先级块降级到 Archival Memory
            if block.priority >= 7 {
                let tokens = estimate_tokens(&block.content);
                self.current_tokens = self.current_tokens.saturating_sub(tokens);
                evicted.push(block.clone());
            }
        }

        // 从 Core Memory 中移除被淘汰的块
        for block in &evicted {
            self.blocks.remove(&block.id);
        }

        evicted
    }

    /// 序列化为上下文格式（注入 System Prompt）
    ///
    /// **性能优化方向**：每次调用都重新排序所有记忆块，O(N log N)。
    /// 生产环境可考虑：
    /// - 使用 BTreeMap 按 priority 排序，插入时即有序
    /// - 维护排序缓存，仅在块变更时重新排序
    /// - 或限制最大块数量（如 50），减少排序开销
    pub fn to_context_string(&self) -> String {
        let mut output = String::from("## Core Memory\n\n");
        let sorted = self.get_all_sorted();

        for block in &sorted {
            output.push_str(&format!(
                "### [{}] {} (v{}, priority:{})\n{}\n\n",
                block.category.display_name(),
                block.id,
                block.version,
                block.priority,
                block.content
            ));
        }

        output
    }

    /// 按关键词搜索记忆块
    ///
    /// **性能优化方向**：当前实现为线性扫描 O(N)，记忆块数量增长后性能下降。
    /// 生产环境应建立倒排索引或使用 tantivy 全文搜索：
    /// - 为每个记忆块维护一个关键词集合
    /// - 使用 HashMap<String, HashSet<BlockId>> 做倒排索引
    /// - 或直接复用 Archival Memory 的 tantivy 索引
    pub fn search(&self, query: &str) -> Vec<MemoryBlock> {
        self.blocks
            .values()
            .filter(|b| b.content.contains(query))
            .cloned()
            .collect()
    }

    /// 按 ID 获取单个记忆块
    pub fn get_block(&self, id: &str) -> Option<&MemoryBlock> {
        self.blocks.get(id)
    }

    /// 获取剩余 Token 预算
    pub fn token_budget(&self) -> usize {
        self.token_budget.saturating_sub(self.current_tokens)
    }
}

/// 记忆系统错误类型
#[derive(Debug, thiserror::Error)]
pub enum MemoryError {
    #[error("Token 预算超限: 需要 {required} tokens, 可用 {available} tokens")]
    TokenBudgetExceeded { required: usize, available: usize },

    #[error("记忆块不存在: {0}")]
    BlockNotFound(String),

    #[error("序列化失败: {0}")]
    SerializationError(#[from] serde_json::Error),

    #[error("存储 IO 错误: {0}")]
    StorageError(#[from] std::io::Error),
}

/// 简易 Token 估算（约 4 字符 = 1 token）
fn estimate_tokens(text: &str) -> usize {
    (text.len() + 3) / 4
}
```

#### 23.3.2 Agent 工具调用接口

Agent 通过以下工具调用自主管理 Core Memory：

```rust
use async_trait::async_trait;

/// Core Memory 管理工具（Agent 可调用）
#[derive(Debug, Serialize, Deserialize)]
pub struct CoreMemoryTool;

#[async_trait]
impl Tool for CoreMemoryTool {
    fn name(&self) -> &str {
        "core_memory_manage"
    }

    fn description(&self) -> &str {
        "管理核心记忆。支持操作: insert/update/delete/search/compact。\
         Agent 应在以下场景主动使用: \
         1) 发现新的用户偏好时 insert; \
         2) 任务状态变化时 update; \
         3) 遇到新错误模式时 insert; \
         4) 低优先级记忆过多时 compact。"
    }

    fn parameters_schema(&self) -> serde_json::Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["insert", "update", "delete", "search", "compact"],
                    "description": "操作类型"
                },
                "id": {
                    "type": "string",
                    "description": "记忆块 ID（insert 时自动生成，update/delete 时必填）"
                },
                "category": {
                    "type": "string",
                    "enum": ["UserPreference", "ProjectConvention", "TaskState", "ErrorPattern", "Context"],
                    "description": "记忆分类（insert 时必填）"
                },
                "content": {
                    "type": "string",
                    "description": "记忆内容（insert/update 时必填）"
                },
                "priority": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10,
                    "description": "优先级 1-10（可选，默认按分类）"
                },
                "search_query": {
                    "type": "string",
                    "description": "搜索关键词（search 时必填）"
                }
            },
            "required": ["action"]
        })
    }

    async fn execute(&self, params: serde_json::Value, ctx: &mut ToolContext) -> Result<serde_json::Value, ToolError> {
        let action = params["action"].as_str().unwrap();
        let memory = ctx.core_memory_mut();

        match action {
            "insert" => {
                let category = params["category"].as_str()
                    .ok_or(ToolError::InvalidParams("category required".into()))?;
                let content = params["content"].as_str()
                    .ok_or(ToolError::InvalidParams("content required".into()))?;

                let category = MemoryCategory::from_str(category)?;
                let priority = params["priority"].as_u64()
                    .unwrap_or(category.default_priority() as u64) as u8;

                let id = format!("{}:{}", category.short_name(), generate_short_id());
                let block = MemoryBlock {
                    id: id.clone(),
                    category,
                    content: content.to_string(),
                    priority,
                    version: 0,
                    created_at: Utc::now(),
                    updated_at: Utc::now(),
                    last_modified_by: ctx.agent_id().to_string(),
                    access_count: 0,
                };

                memory.upsert_block(block)?;
                Ok(serde_json::json!({
                    "status": "ok",
                    "action": "inserted",
                    "id": id,
                    "message": "记忆块已创建"
                }))
            }
            "update" => {
                let id = params["id"].as_str()
                    .ok_or(ToolError::InvalidParams("id required".into()))?;
                let content = params["content"].as_str()
                    .ok_or(ToolError::InvalidParams("content required".into()))?;

                let mut block = memory.get_block(id)
                    .ok_or_else(|| ToolError::NotFound(id.to_string()))?
                    .clone();
                block.content = content.to_string();
                if let Some(p) = params["priority"].as_u64() {
                    block.priority = p as u8;
                }
                block.last_modified_by = ctx.agent_id().to_string();

                memory.upsert_block(block)?;
                Ok(serde_json::json!({
                    "status": "ok",
                    "action": "updated",
                    "id": id,
                    "message": "记忆块已更新"
                }))
            }
            "delete" => {
                let id = params["id"].as_str()
                    .ok_or(ToolError::InvalidParams("id required".into()))?;
                memory.remove_block(id);
                Ok(serde_json::json!({
                    "status": "ok",
                    "action": "deleted",
                    "id": id,
                    "message": "记忆块已删除"
                }))
            }
            "search" => {
                let query = params["search_query"].as_str()
                    .ok_or(ToolError::InvalidParams("search_query required".into()))?;
                let results = memory.search(query);
                Ok(serde_json::json!({
                    "status": "ok",
                    "results": results
                }))
            }
            "compact" => {
                let evicted = memory.compact(memory.token_budget() * 70 / 100);
                Ok(serde_json::json!({
                    "status": "ok",
                    "action": "compacted",
                    "evicted_count": evicted.len(),
                    "freed_tokens": evicted.iter().map(|b| estimate_tokens(&b.content)).sum::<usize>(),
                    "message": format!("已压缩 {} 个低优先级记忆块到归档层", evicted.len())
                }))
            }
            _ => Err(ToolError::InvalidParams(format!("Unknown action: {}", action)))
        }
    }
}
```

#### 23.3.3 Core Memory JSON 示例

```json
{
  "token_budget": 4096,
  "current_tokens": 1287,
  "blocks": {
    "TaskState:current_task": {
      "id": "TaskState:current_task",
      "category": "TaskState",
      "content": "当前正在实现用户认证模块的 JWT Token 刷新机制。\
                  已完成 access_token 签发，待实现 refresh_token 轮转。\
                  阻塞项：需要确认 token 过期时间策略。",
      "priority": 1,
      "version": 5,
      "created_at": "2026-04-15T10:30:00Z",
      "updated_at": "2026-04-16T08:15:00Z",
      "last_modified_by": "planner-agent",
      "access_count": 23
    },
    "UserPreference:code_style": {
      "id": "UserPreference:code_style",
      "category": "UserPreference",
      "content": "用户偏好 Rust 风格：函数名 snake_case，类型名 PascalCase，\
                  错误处理使用 thiserror，异步代码使用 async-trait，\
                  测试使用 #[tokio::test]，禁止 unwrap()。",
      "priority": 2,
      "version": 3,
      "created_at": "2026-04-10T09:00:00Z",
      "updated_at": "2026-04-14T14:20:00Z",
      "last_modified_by": "coder-agent",
      "access_count": 67
    },
    "ProjectConvention:api_design": {
      "id": "ProjectConvention:api_design",
      "category": "ProjectConvention",
      "content": "API 设计约定：RESTful 风格，JSON 请求/响应，\
                  版本号在 URL 路径中（/api/v1/），\
                  错误响应格式 {code, message, details}，\
                  分页使用 cursor-based 方式。",
      "priority": 3,
      "version": 2,
      "created_at": "2026-04-12T11:00:00Z",
      "updated_at": "2026-04-15T16:45:00Z",
      "last_modified_by": "planner-agent",
      "access_count": 41
    },
    "ErrorPattern:sqlx_timeout": {
      "id": "ErrorPattern:sqlx_timeout",
      "category": "ErrorPattern",
      "content": "sqlx 连接池超时：在高并发场景下 PostgreSQL 连接池耗尽。\
                  解决方案：将 pool_max_connections 从 10 提升到 20，\
                  添加 connection timeout 30s，启用 statement caching。",
      "priority": 4,
      "version": 1,
      "created_at": "2026-04-14T20:30:00Z",
      "updated_at": "2026-04-14T20:30:00Z",
      "last_modified_by": "coder-agent",
      "access_count": 8
    }
  }
}
```

---

### 23.4 Working Memory（LRU 文件缓存）

Working Memory 是当前会话的文件缓存层，使用 LRU 策略管理高频访问的文件，与现有第21章大文件智能读取机制集成。

```
┌──────────────────────────────────────────────────────┐
│                   Working Memory                      │
│                                                       │
│  ┌─────────────────────────────────────────────────┐  │
│  │              LruFileCache                        │  │
│  │                                                  │  │
│  │   ┌────────┐ ┌────────┐ ┌────────┐             │  │
│  │   │ File 1 │ │ File 2 │ │ File 3 │  ... (100)  │  │
│  │   │ hot    │ │ warm   │ │ cold   │             │  │
│  │   └───┬────┘ └───┬────┘ └───┬────┘             │  │
│  │       │          │          │                    │  │
│  │       └──────────┼──────────┘                    │  │
│  │                  ▼                               │  │
│  │         LRU 淘汰队列                             │  │
│  │         (最久未访问 → 淘汰)                       │  │
│  │                                                  │  │
│  │   容量限制: 100 文件 / 25 MB                     │  │
│  └─────────────────────────────────────────────────┘  │
│                       │                               │
│            ┌──────────┼──────────┐                    │
│            ▼          ▼          ▼                    │
│     ┌──────────┐ ┌────────┐ ┌──────────┐            │
│     │ 大文件    │ │ 智能摘要 │ │ 按需加载  │            │
│     │ 智能读取  │ │ 缓存   │ │ 策略     │            │
│     │ (第21章)  │ │       │ │          │            │
│     └──────────┘ └────────┘ └──────────┘            │
└──────────────────────────────────────────────────────┘
```

#### 23.4.1 LruFileCache 实现

```rust
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use tokio::sync::RwLock;
use lru::LruCache;

/// 文件缓存条目
#[derive(Debug, Clone)]
pub struct CachedFile {
    /// 文件路径
    pub path: PathBuf,

    /// 文件内容（可能被截断/摘要）
    pub content: String,

    /// 文件原始大小（字节）
    pub original_size: u64,

    /// 缓存内容大小（字节）
    pub cached_size: u64,

    /// 是否为智能摘要（大文件截断后）
    pub is_summary: bool,

    /// 最后访问时间
    pub last_accessed: std::time::Instant,

    /// 文件修改时间（用于失效检测）
    pub modified_time: std::time::SystemTime,
}

/// LRU 文件缓存
///
/// **并发安全注意**：`cache` 和 `current_bytes` 使用两个独立的 RwLock，
/// 如果需要同时持有两个锁，必须按固定顺序获取（先 cache 后 current_bytes），
/// 否则可能死锁。
///
/// **优化方向**：可合并为单个 `Mutex<LruFileCacheInner>` 简化锁管理，
/// 或使用 `parking_lot::RwLock`（比 std 的更轻量且不支持中毒）。
pub struct LruFileCache {
    /// LRU 缓存核心
    cache: RwLock<LruCache<PathBuf, Arc<CachedFile>>>,

    /// 最大文件数量
    max_files: usize,

    /// 最大总字节数
    max_bytes: u64,

    /// 当前缓存总字节数
    current_bytes: RwLock<u64>,
}

impl LruFileCache {
    /// 创建新的 LRU 文件缓存
    ///
    /// 默认配置：100 文件 / 25MB 上限（Claude Code 验证的最佳实践）
    pub fn new() -> Self {
        Self::with_capacity(100, 25 * 1024 * 1024)
    }

    /// 自定义容量
    pub fn with_capacity(max_files: usize, max_bytes: u64) -> Self {
        Self {
            cache: RwLock::new(LruCache::new(
                std::num::NonZeroUsize::new(max_files).unwrap()
            )),
            max_files,
            max_bytes,
            current_bytes: RwLock::new(0),
        }
    }

    /// 获取文件内容（缓存命中则直接返回，否则读取并缓存）
    ///
    /// **性能优化**：使用双检锁模式，先释放锁再执行 I/O，
    /// 避免在持有写锁期间执行同步文件操作。
    pub async fn get_or_read(&self, path: &Path) -> Result<Arc<CachedFile>, CacheError> {
        // 1. 快速路径：读锁检查缓存
        {
            let cache = self.cache.read().await;
            if let Some(cached) = cache.peek(path) {
                // 在读锁下检查 mtime（metadata 调用很快）
                // 如果文件未修改，直接返回
                return Ok(Arc::clone(cached));
            }
        }

        // 2. 释放锁后执行 I/O（不持有任何锁）
        let metadata = tokio::fs::metadata(path).await?;
        let file_size = metadata.len();
        let modified_time = metadata.modified()?;

        let content = if file_size > 50_000 {
            self.read_with_smart_truncation(path, file_size).await?
        } else {
            tokio::fs::read_to_string(path).await?
        };

        let cached_size = content.len() as u64;
        let is_summary = cached_size < file_size;

        let cached_file = Arc::new(CachedFile {
            path: path.to_path_buf(),
            content,
            original_size: file_size,
            cached_size,
            is_summary,
            last_accessed: std::time::Instant::now(),
            modified_time,
        });

        // 3. 获取写锁，双检后插入（避免重复读取）
        {
            let mut cache = self.cache.write().await;
            // 双检：可能在等待写锁期间其他任务已插入
            if let Some(existing) = cache.get(path) {
                if existing.modified_time == modified_time {
                    return Ok(Arc::clone(existing));
                }
                cache.pop(path);
            }
            cache.put(path.clone(), Arc::clone(&cached_file));
        }

        // 4. 更新字节计数
        {
            let mut bytes = self.current_bytes.write().await;
            *bytes += cached_size;
        }

        Ok(cached_file)
    }

    /// 大文件智能截断（与第21章集成）
    async fn read_with_smart_truncation(
        &self,
        path: &Path,
        file_size: u64,
    ) -> Result<String, CacheError> {
        // 策略：首尾各取 15KB，中间用省略标记
        let head_size = 15_000usize;
        let tail_size = 15_000usize;

        let content = tokio::fs::read_to_string(path).await?;

        if content.len() <= head_size + tail_size {
            return Ok(content);
        }

        let head = &content[..head_size];
        let tail = &content[content.len() - tail_size..];

        Ok(format!(
            "{}\n\n... [文件过大，已截断: 原始 {} 字节，显示首尾各 ~15KB] ...\n\n{}",
            head,
            file_size,
            tail
        ))
    }

    /// 插入缓存并按需淘汰
    async fn insert_with_eviction(
        &self,
        path: &Path,
        cached: Arc<CachedFile>,
    ) -> Result<(), CacheError> {
        let mut cache = self.cache.write().await;
        let mut bytes = self.current_bytes.write().await;

        // 如果已存在，先移除旧条目
        if let Some(old) = cache.pop(path) {
            *bytes = bytes.saturating_sub(old.cached_size);
        }

        // LRU 淘汰直到有足够空间
        while *bytes + cached.cached_size > self.max_bytes && cache.len() > 0 {
            if let Some((_, evicted)) = cache.pop_lru() {
                *bytes = bytes.saturating_sub(evicted.cached_size);
            } else {
                break;
            }
        }

        *bytes += cached.cached_size;
        cache.put(path.to_path_buf(), cached);
        Ok(())
    }

    /// 获取缓存统计信息
    pub async fn stats(&self) -> CacheStats {
        let cache = self.cache.read().await;
        let bytes = self.current_bytes.read().await;
        CacheStats {
            file_count: cache.len(),
            total_bytes: *bytes,
            max_files: self.max_files,
            max_bytes: self.max_bytes,
            utilization_ratio: *bytes as f64 / self.max_bytes as f64,
        }
    }

    /// 清空缓存
    pub async fn clear(&self) {
        let mut cache = self.cache.write().await;
        let mut bytes = self.current_bytes.write().await;
        cache.clear();
        *bytes = 0;
    }
}

#[derive(Debug, Clone)]
pub struct CacheStats {
    pub file_count: usize,
    pub total_bytes: u64,
    pub max_files: usize,
    pub max_bytes: u64,
    pub utilization_ratio: f64,
}

#[derive(Debug, thiserror::Error)]
pub enum CacheError {
    #[error("文件读取失败: {0}")]
    ReadError(#[from] std::io::Error),

    #[error("缓存容量超限")]
    CapacityExceeded,
}
```

---

### 23.5 Recall Memory

Recall Memory 存储完整的对话历史，支持按时间范围、关键词、Agent 角色等多维度搜索。

```rust
use async_trait::async_trait;

/// 单条对话记录
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConversationEntry {
    /// 唯一 ID
    pub id: String,

    /// 会话 ID
    pub session_id: String,

    /// 发言角色
    pub role: ConversationRole,

    /// 消息内容
    pub content: String,

    /// 关联的工具调用（如果有）
    pub tool_calls: Vec<ToolCallRecord>,

    /// Token 消耗
    pub tokens_used: u32,

    /// 时间戳
    pub timestamp: DateTime<Utc>,

    /// 关键词标签（用于搜索加速）
    pub tags: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ConversationRole {
    User,
    Agent(String),  // Agent ID
    System,
    Tool,
}

/// Recall Memory 存储接口
#[async_trait]
pub trait ConversationStore: Send + Sync {
    /// 追加对话记录
    async fn append(&self, entry: ConversationEntry) -> Result<(), MemoryError>;

    /// 按会话 ID 获取对话历史
    async fn get_session(
        &self,
        session_id: &str,
        limit: Option<usize>,
    ) -> Result<Vec<ConversationEntry>, MemoryError>;

    /// 搜索对话历史
    async fn search(&self, query: &SearchQuery) -> Result<Vec<ConversationEntry>, MemoryError>;

    /// 按时间范围获取
    async fn get_by_time_range(
        &self,
        start: DateTime<Utc>,
        end: DateTime<Utc>,
    ) -> Result<Vec<ConversationEntry>, MemoryError>;

    /// 获取会话摘要
    async fn get_session_summary(&self, session_id: &str) -> Result<String, MemoryError>;
}

/// 对话搜索参数
#[derive(Debug, Clone)]
pub struct SearchQuery {
    pub keyword: Option<String>,
    pub session_id: Option<String>,
    pub role: Option<ConversationRole>,
    pub start_time: Option<DateTime<Utc>>,
    pub end_time: Option<DateTime<Utc>>,
    pub limit: usize,
    pub offset: usize,
}

/// SQLite 实现
pub struct SqliteConversationStore {
    pool: sqlx::SqlitePool,
}

impl SqliteConversationStore {
    pub async fn new(db_path: &Path) -> Result<Self, MemoryError> {
        let pool = sqlx::SqlitePool::connect_with(
            sqlx::sqlite::SqliteConnectOptions::from_str(&format!("sqlite:{}", db_path.display()))?
                .create_if_missing(true)
        ).await?;

        // 初始化表结构
        sqlx::query(r#"
            CREATE TABLE IF NOT EXISTS conversations (
                id          TEXT PRIMARY KEY,
                session_id  TEXT NOT NULL,
                role        TEXT NOT NULL,
                content     TEXT NOT NULL,
                tokens_used INTEGER DEFAULT 0,
                timestamp   TEXT NOT NULL,
                tags        TEXT DEFAULT '[]'
            );

            CREATE INDEX IF NOT EXISTS idx_conv_session
                ON conversations(session_id, timestamp);

            CREATE INDEX IF NOT EXISTS idx_conv_timestamp
                ON conversations(timestamp);
        "#).execute(&pool).await?;

        Ok(Self { pool })
    }
}

#[async_trait]
impl ConversationStore for SqliteConversationStore {
    async fn append(&self, entry: ConversationEntry) -> Result<(), MemoryError> {
        sqlx::query(r#"
            INSERT INTO conversations (id, session_id, role, content, tokens_used, timestamp, tags)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        "#)
        .bind(&entry.id)
        .bind(&entry.session_id)
        .bind(match entry.role {
            ConversationRole::User => "user",
            ConversationRole::Agent(id) => id.as_str(),
            ConversationRole::System => "system",
            ConversationRole::Tool => "tool",
        })
        .bind(&entry.content)
        .bind(entry.tokens_used as i32)
        .bind(entry.timestamp.to_rfc3339())
        .bind(serde_json::to_string(&entry.tags)?)
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    async fn search(&self, query: &SearchQuery) -> Result<Vec<ConversationEntry>, MemoryError> {
        let mut sql = String::from("SELECT * FROM conversations WHERE 1=1");
        let mut binds: Vec<String> = Vec::new();

        if let Some(ref session_id) = query.session_id {
            sql.push_str(" AND session_id = ?");
            binds.push(session_id.clone());
        }
        if let Some(ref keyword) = query.keyword {
            // ⚠️ 性能注意：LIKE '%keyword%' 无法使用 B-tree 索引，会导致全表扫描。
            // 生产环境应使用 SQLite FTS5 全文搜索扩展：
            //   CREATE VIRTUAL TABLE conversations_fts USING fts5(content, role, session_id);
            //   SELECT * FROM conversations_fts WHERE conversations_fts MATCH ?;
            sql.push_str(" AND content LIKE ?");
            binds.push(format!("%{}%", keyword));
        }
        if let Some(ref role) = query.role {
            sql.push_str(" AND role = ?");
            binds.push(match role {
                ConversationRole::User => "user".into(),
                ConversationRole::Agent(id) => id.clone(),
                ConversationRole::System => "system".into(),
                ConversationRole::Tool => "tool".into(),
            });
        }
        if let Some(start) = query.start_time {
            sql.push_str(" AND timestamp >= ?");
            binds.push(start.to_rfc3339());
        }
        if let Some(end) = query.end_time {
            sql.push_str(" AND timestamp <= ?");
            binds.push(end.to_rfc3339());
        }

        sql.push_str(&format!(" ORDER BY timestamp DESC LIMIT {} OFFSET {}", query.limit, query.offset));

        // 执行查询并映射结果
        return Ok(vec![]); // TODO: 实现搜索查询
    }

    // ... 其他方法实现
}
```

---

### 23.6 Archival Memory

Archival Memory 是结构化知识存储层，初期使用 SQLite + tantivy 全文搜索，后期扩展向量检索和图谱记忆。

```
┌──────────────────────────────────────────────────────────────┐
│                    Archival Memory                            │
│                                                               │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │                  KnowledgeStore Trait                    │  │
│  │  store() / retrieve() / search() / delete()             │  │
│  └──────────┬──────────────────────────┬───────────────────┘  │
│             │                          │                      │
│  ┌──────────▼──────────┐  ┌───────────▼───────────────────┐  │
│  │   Phase 2           │  │   Phase 3                     │  │
│  │   SQLite + tantivy  │  │   + sqlite-vss 向量扩展        │  │
│  │                     │  │                               │  │
│  │   - 结构化存储       │  │   - Embedding 生成            │  │
│  │   - 全文搜索         │  │   - 语义相似度检索             │  │
│  │   - 关键词索引       │  │   - 混合检索 (BM25+向量)      │  │
│  │   - 零外部依赖       │  │   - 本地推理，无需 API         │  │
│  └─────────────────────┘  └───────────────────────────────┘  │
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │   Phase 4: Mem0-G 图谱记忆（远期规划）                    │  │
│  │   - 实体关系抽取                                          │  │
│  │   - 知识图谱构建                                          │  │
│  │   - 关联推理                                              │  │
│  └─────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

#### 23.6.1 KnowledgeStore Trait

```rust
/// 知识条目
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KnowledgeEntry {
    pub id: String,
    pub title: String,
    pub content: String,
    pub category: String,
    pub source: KnowledgeSource,
    pub tags: Vec<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    /// Phase 3: 向量 Embedding
    pub embedding: Option<Vec<f32>>,
    /// Phase 4: 关联实体
    pub entities: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum KnowledgeSource {
    /// 从对话中自动提取
    ConversationExtraction { session_id: String, entry_id: String },
    /// 从 Core Memory 降级归档
    CoreMemoryDemotion { block_id: String },
    /// 用户手动添加
    Manual,
    /// 从代码注释提取
    CodeComment { file_path: String },
}

/// 知识存储接口
#[async_trait]
pub trait KnowledgeStore: Send + Sync {
    /// 存储知识条目
    async fn store(&self, entry: KnowledgeEntry) -> Result<String, MemoryError>;

    /// 按 ID 获取
    async fn retrieve(&self, id: &str) -> Result<Option<KnowledgeEntry>, MemoryError>;

    /// 搜索知识
    async fn search(&self, query: &str, limit: usize) -> Result<Vec<KnowledgeEntry>, MemoryError>;

    /// 删除知识条目
    async fn delete(&self, id: &str) -> Result<bool, MemoryError>;

    /// 获取知识库统计
    async fn stats(&self) -> Result<KnowledgeStats, MemoryError>;
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KnowledgeStats {
    pub total_entries: usize,
    pub by_category: HashMap<String, usize>,
    pub index_size_bytes: u64,
}
```

#### 23.6.2 Phase 2: SQLite + tantivy 全文搜索

```rust
use tantivy::schema::*;
use tantivy::{Index, IndexReader, IndexWriter, DocAddress, Score};
use tantivy::collector::TopDocs;

/// tantivy 全文搜索引擎
pub struct TantivySearchEngine {
    index: Index,
    reader: IndexReader,
    writer: IndexWriter,
    schema: Schema,
}

impl TantivySearchEngine {
    pub fn new(index_dir: &Path) -> Result<Self, MemoryError> {
        let mut schema_builder = Schema::builder();

        let title = schema_builder.add_text_field("title", TEXT | STORED);
        let content = schema_builder.add_text_field("content", TEXT | STORED);
        let category = schema_builder.add_text_field("category", STRING | STORED);
        let tags = schema_builder.add_text_field("tags", TEXT);
        let entry_id = schema_builder.add_text_field("entry_id", STRING | STORED);

        let schema = schema_builder.build();

        let index = Index::create_in_dir(index_dir, schema.clone())
            .unwrap_or_else(|_| Index::open_in_dir(index_dir).unwrap());

        let reader = index.reader()?;
        let writer = index.writer(50_000_000)?;  // 50MB 缓冲区

        Ok(Self {
            index,
            reader,
            writer,
            schema,
        })
    }

    /// 索引单条知识条目
    ///
    /// **性能注意**：每次调用都会执行 `commit()`，这是重量级操作。
    /// 批量索引场景请使用 `index_entries()` 方法。
    pub fn index_entry(&self, entry: &KnowledgeEntry) -> Result<(), MemoryError> {
        let title = self.schema.get_field("title").unwrap();
        let content = self.schema.get_field("content").unwrap();
        let category = self.schema.get_field("category").unwrap();
        let tags = self.schema.get_field("tags").unwrap();
        let entry_id = self.schema.get_field("entry_id").unwrap();

        let mut doc = Document::new();
        doc.add_text(title, &entry.title);
        doc.add_text(content, &entry.content);
        doc.add_text(category, &entry.category);
        doc.add_text(tags, &entry.tags.join(" "));
        doc.add_text(entry_id, &entry.id);

        self.writer.add_document(doc)?;
        self.writer.commit()?;

        Ok(())
    }

    /// 批量索引知识条目（性能优化：所有条目插入后只 commit 一次）
    pub fn index_entries(&self, entries: &[KnowledgeEntry]) -> Result<(), MemoryError> {
        let title = self.schema.get_field("title").unwrap();
        let content = self.schema.get_field("content").unwrap();
        let category = self.schema.get_field("category").unwrap();
        let tags = self.schema.get_field("tags").unwrap();
        let entry_id = self.schema.get_field("entry_id").unwrap();

        for entry in entries {
            let mut doc = Document::new();
            doc.add_text(title, &entry.title);
            doc.add_text(content, &entry.content);
            doc.add_text(category, &entry.category);
            doc.add_text(tags, &entry.tags.join(" "));
            doc.add_text(entry_id, &entry.id);
            self.writer.add_document(doc)?;
        }
        // 所有条目插入后只 commit 一次
        self.writer.commit()?;

        Ok(())
    }

    /// 全文搜索
    pub fn search(&self, query: &str, limit: usize) -> Result<Vec<(String, f64)>, MemoryError> {
        let searcher = self.reader.searcher();
        let content = self.schema.get_field("content").unwrap();
        let title = self.schema.get_field("title").unwrap();
        let entry_id = self.schema.get_field("entry_id").unwrap();

        let query_parser = QueryParser::for_index(
            &self.index,
            vec![title, content],
        );

        let query = query_parser.parse_query(query)?;
        let top_docs = searcher.search(&query, &TopDocs::with_limit(limit))?;

        let results: Vec<(String, f64)> = top_docs.iter()
            .map(|(score, addr)| {
                let retrieved = searcher.doc(*addr).unwrap();
                let id = retrieved.get_first(entry_id).unwrap();
                (id.as_text().unwrap().to_string(), *score)
            })
            .collect();

        Ok(results)
    }
}
```

#### 23.6.3 Phase 3 & Phase 4 路线图

```rust
/// Phase 3: 向量检索扩展（sqlite-vss）
///
/// 使用 sqlite-vss 扩展为 SQLite 添加向量搜索能力：
/// - Embedding 模型：本地运行的小型模型（如 all-MiniLM-L6-v2 via candle）
/// - 存储格式：FLOAT32 向量，维度 384
/// - 检索方式：余弦相似度 + BM25 混合排序
///
/// ```sql
/// CREATE VIRTUAL TABLE knowledge_vectors
/// USING vss0(
///     entry_id TEXT PRIMARY KEY,
///     embedding FLOAT[384]
/// );
///
/// -- 查询示例
/// SELECT k.*,
///     vss_distance_l2(k.embedding, ?) as distance
/// FROM knowledge k, knowledge_vectors v
/// WHERE vss_search(k.embedding, ?)
/// ORDER BY distance
/// LIMIT 10;
/// ```

/// Phase 4: Mem0-G 图谱记忆（远期规划）
///
/// 基于图结构的记忆关联：
/// - 实体抽取：从对话和代码中自动提取实体（人名、模块、API、概念）
/// - 关系构建：实体间关系（依赖、调用、相关、冲突）
/// - 关联推理：通过图谱路径发现间接关联
///
/// 示例图谱：
///   [用户认证模块] --依赖--> [JWT库]
///        |                      |
///   --调用--> [数据库]    --配置--> [环境变量]
///        |
///   --错误--> [连接池超时] --解决--> [调整pool_size]
```

---

### 23.7 Sleep-Time Compute

Daemon 模式（第20章）下的异步记忆整合机制。当 Agent 处于空闲状态时，后台任务自动执行记忆维护。

```
┌──────────────────────────────────────────────────────────────┐
│                 Sleep-Time Compute                            │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐  │
│  │  Daemon 主循环 (第20章)                                 │  │
│  │  ┌──────────────────────────────────────────────────┐  │  │
│  │  │  while running {                                 │  │  │
│  │  │      match receive_event().await {               │  │  │
│  │  │          Some(task) => process_task(task).await, │  │  │
│  │  │          None => sleep_compute().await,  // 空闲  │  │  │
│  │  │      }                                           │  │  │
│  │  │  }                                               │  │  │
│  │  └──────────────────────────────────────────────────┘  │  │
│  └────────────────────────────────────────────────────────┘  │
│                          │                                   │
│              空闲触发 (idle > 30s)                            │
│                          ▼                                   │
│  ┌────────────────────────────────────────────────────────┐  │
│  │              MemoryConsolidationTask                   │  │
│  │                                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐  │  │
│  │  │ 1. 对话摘要   │  │ 2. 知识提取   │  │ 3. 记忆压缩  │  │  │
│  │  │              │  │              │  │             │  │  │
│  │  │ Recall →     │  │ 对话中提取    │  │ Core Memory │  │  │
│  │  │ 生成摘要     │  │ 结构化知识    │  │ 低优先级块  │  │  │
│  │  │ 写入 Archival│  │ 写入 Archival│  │ 降级到      │  │  │
│  │  │              │  │              │  │ Archival    │  │  │
│  │  └──────────────┘  └──────────────┘  └─────────────┘  │  │
│  │                                                        │  │
│  │  ┌──────────────┐  ┌──────────────┐                   │  │
│  │  │ 4. 错误模式   │  │ 5. 上下文    │                   │  │
│  │  │    聚合       │  │    预热      │                   │  │
│  │  │              │  │              │                   │  │
│  │  │ 相似错误合并  │  │ 预加载下个   │                   │  │
│  │  │ 更新 Core    │  │ 任务相关文件  │                   │  │
│  │  │ Memory       │  │ 到 Working   │                   │  │
│  │  │              │  │ Memory       │                   │  │
│  │  └──────────────┘  └──────────────┘                   │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

#### 23.7.1 后台整合任务实现

```rust
use tokio::time::{sleep, Duration};

/// 记忆整合后台任务
pub struct MemoryConsolidationTask {
    core_memory: Arc<RwLock<CoreMemory>>,
    recall_store: Arc<dyn ConversationStore>,
    knowledge_store: Arc<dyn KnowledgeStore>,
    working_cache: Arc<LruFileCache>,
    /// 空闲触发阈值（秒）
    idle_threshold: Duration,
    /// 上次活动时间
    last_activity: Arc<RwLock<std::time::Instant>>,
}

impl MemoryConsolidationTask {
    pub fn new(
        core_memory: Arc<RwLock<CoreMemory>>,
        recall_store: Arc<dyn ConversationStore>,
        knowledge_store: Arc<dyn KnowledgeStore>,
        working_cache: Arc<LruFileCache>,
    ) -> Self {
        Self {
            core_memory,
            recall_store,
            knowledge_store,
            working_cache,
            idle_threshold: Duration::from_secs(30),
            last_activity: Arc::new(RwLock::new(std::time::Instant::now())),
        }
    }

    /// 检查是否应该执行整合
    pub async fn should_consolidate(&self) -> bool {
        let last = *self.last_activity.read().await;
        last.elapsed() > self.idle_threshold
    }

    /// 执行完整的记忆整合流程
    pub async fn consolidate(&self) -> Result<ConsolidationReport, MemoryError> {
        let mut report = ConsolidationReport::default();

        // Step 1: 对话摘要生成
        report.summaries = self.generate_session_summaries().await?;

        // Step 2: 知识提取
        report.extracted = self.extract_knowledge().await?;

        // Step 3: Core Memory 压缩
        report.compacted = self.compact_core_memory().await?;

        // Step 4: 错误模式聚合
        report.error_patterns = self.aggregate_error_patterns().await?;

        Ok(report)
    }

    /// Step 1: 为未摘要的会话生成摘要
    async fn generate_session_summaries(&self) -> Result<usize, MemoryError> {
        // 获取最近的会话列表
        let recent_sessions = self.recall_store
            .search(&SearchQuery {
                keyword: None,
                session_id: None,
                role: None,
                start_time: Some(Utc::now() - Duration::from_secs(86400)),
                end_time: None,
                limit: 20,
                offset: 0,
            })
            .await?;

        let mut summary_count = 0;

        // 按会话分组并生成摘要
        let mut session_ids: Vec<String> = recent_sessions.iter()
            .map(|e| e.session_id.clone())
            .collect();
        session_ids.dedup();

        for session_id in session_ids {
            let summary = self.recall_store.get_session_summary(&session_id).await;
            if summary.is_err() {
                // 摘要不存在，需要生成（调用 LLM）
                let entries = self.recall_store.get_session(&session_id, Some(50)).await?;
                if entries.len() > 10 {
                    let summary_text = self.generate_summary_via_llm(&entries).await?;
                    // 存储到 Archival Memory
                    let entry = KnowledgeEntry {
                        id: format!("summary:{}", session_id),
                        title: format!("会话摘要: {}", session_id),
                        content: summary_text,
                        category: "session_summary".into(),
                        source: KnowledgeSource::ConversationExtraction {
                            session_id: session_id.clone(),
                            entry_id: String::new(),
                        },
                        tags: vec!["auto-generated".into(), "summary".into()],
                        created_at: Utc::now(),
                        updated_at: Utc::now(),
                        embedding: None,
                        entities: Vec::new(),
                    };
                    self.knowledge_store.store(entry).await?;
                    summary_count += 1;
                }
            }
        }

        Ok(summary_count)
    }

    /// Step 3: 压缩 Core Memory
    ///
    /// **性能优化**：先在写锁内完成内存操作（compact），释放锁后再执行
    /// 异步 I/O（写入 Archival Memory），避免长时间持锁。
    async fn compact_core_memory(&self) -> Result<usize, MemoryError> {
        // 阶段 1：在写锁内完成内存操作（快速）
        let evicted = {
            let mut memory = self.core_memory.write().await;
            let budget = memory.token_budget();
            memory.compact(budget * 70 / 100)
        };
        // 写锁已释放

        // 阶段 2：异步写入 Archival Memory（无需持锁）
        for block in evicted {
            let entry = KnowledgeEntry {
                id: format!("demoted:{}", block.id),
                title: format!("归档记忆: {}", block.id),
                content: block.content,
                category: format!("demoted_{}", block.category.display_name()),
                source: KnowledgeSource::CoreMemoryDemotion {
                    block_id: block.id.clone(),
                },
                tags: vec!["auto-demoted".into(), "core-memory".into()],
                created_at: block.created_at,
                updated_at: Utc::now(),
                embedding: None,
                entities: Vec::new(),
            };
            self.knowledge_store.store(entry).await?;
        }

        Ok(evicted.len())
    }

    /// 通过 LLM 生成摘要
    async fn generate_summary_via_llm(
        &self,
        entries: &[ConversationEntry],
    ) -> Result<String, MemoryError> {
        // 构建摘要请求（使用轻量级模型）
        let conversation_text: String = entries.iter()
            .take(20)
            .map(|e| format!("[{}] {}", match e.role {
                ConversationRole::User => "用户",
                ConversationRole::Agent(_) => "Agent",
                ConversationRole::System => "系统",
                ConversationRole::Tool => "工具",
            }, e.content))
            .collect::<Vec<_>>()
            .join("\n");

        // 调用 LLM 生成摘要（此处为示意，实际接入 LlmProvider）
        Ok(format!(
            "[自动摘要] 共 {} 条对话，涵盖主题待提取。原始对话:\n{}",
            entries.len(),
            &conversation_text[..conversation_text.len().min(2000)]
        ))
    }

    // ... extract_knowledge, aggregate_error_patterns 实现略
}

#[derive(Debug, Default)]
pub struct ConsolidationReport {
    pub summaries: usize,
    pub extracted: usize,
    pub compacted: usize,
    pub error_patterns: usize,
}
```

#### 23.7.2 与第20章 Daemon 模式的集成

```rust
/// Daemon 主循环中集成 Sleep-Time Compute
pub struct AgentDaemon {
    // ... 现有字段
    memory_task: Arc<MemoryConsolidationTask>,
}

impl AgentDaemon {
    pub async fn run(&self) -> Result<(), DaemonError> {
        loop {
            match self.receive_event().await {
                Some(event) => {
                    self.process_event(event).await?;
                    // 更新活动时间
                    *self.memory_task.last_activity.write().await =
                        std::time::Instant::now();
                }
                None => {
                    // 空闲：检查是否触发记忆整合
                    if self.memory_task.should_consolidate().await {
                        tracing::info!("空闲超时，触发 Sleep-Time Compute");
                        match self.memory_task.consolidate().await {
                            Ok(report) => {
                                tracing::info!(
                                    "记忆整合完成: 摘要={}, 提取={}, 压缩={}, 错误模式={}",
                                    report.summaries, report.extracted,
                                    report.compacted, report.error_patterns
                                );
                            }
                            Err(e) => {
                                tracing::warn!("记忆整合失败: {}", e);
                            }
                        }
                    }
                    sleep(Duration::from_secs(5)).await;
                }
            }
        }
    }
}
```

---

### 23.8 与现有第18章的兼容

#### 23.8.1 迁移策略

```
  迁移前                              迁移后

  .assistant-memory/           .assistant-memory/
  ├── user_preferences.json    ├── core_memory.json     ← Core Memory
  ├── project_conventions.md   ├── recall.db            ← Recall Memory (SQLite)
  ├── task_states.json         ├── archival.db          ← Archival Memory (SQLite)
  ├── error_patterns.log       ├── archival_index/      ← tantivy 索引目录
  ├── conversation_history/    └── migration_log.json   ← 迁移记录
  │   ├── 2024-01-01.json
  │   └── 2024-01-02.json
  └── knowledge/
      ├── api_design.md
      └── patterns.md

  迁移映射：
  ┌──────────────────────────┬──────────────────────────────────────┐
  │ 现有文件                  │ 迁移目标                             │
  ├──────────────────────────┼──────────────────────────────────────┤
  │ user_preferences.json    │ Core Memory → UserPreference blocks  │
  │ project_conventions.md   │ Core Memory → ProjectConvention block │
  │ task_states.json         │ Core Memory → TaskState blocks       │
  │ error_patterns.log       │ Core Memory → ErrorPattern blocks    │
  │ conversation_history/*   │ Recall Memory → conversations 表     │
  │ knowledge/*              │ Archival Memory → knowledge 表       │
  └──────────────────────────┴──────────────────────────────────────┘
```

#### 23.8.2 迁移实现

```rust
/// 记忆系统迁移器
pub struct MemoryMigrator {
    legacy_dir: PathBuf,
}

impl MemoryMigrator {
    pub fn new(legacy_dir: PathBuf) -> Self {
        Self { legacy_dir }
    }

    /// 执行完整迁移
    pub async fn migrate(&self) -> Result<MigrationReport, MigrationError> {
        let mut report = MigrationReport::default();

        // 1. 迁移用户偏好 → Core Memory
        report.user_preferences = self
            .migrate_user_preferences()
            .await?;

        // 2. 迁移项目约定 → Core Memory
        report.project_conventions = self
            .migrate_project_conventions()
            .await?;

        // 3. 迁移任务状态 → Core Memory
        report.task_states = self
            .migrate_task_states()
            .await?;

        // 4. 迁移错误模式 → Core Memory
        report.error_patterns = self
            .migrate_error_patterns()
            .await?;

        // 5. 迁移对话历史 → Recall Memory
        report.conversations = self
            .migrate_conversations()
            .await?;

        // 6. 迁移知识文件 → Archival Memory
        report.knowledge_entries = self
            .migrate_knowledge()
            .await?;

        // 7. 写入迁移日志
        self.write_migration_log(&report).await?;

        Ok(report)
    }

    async fn migrate_user_preferences(&self) -> Result<u32, MigrationError> {
        let path = self.legacy_dir.join("user_preferences.json");
        if !path.exists() {
            return Ok(0);
        }

        let content = tokio::fs::read_to_string(&path).await?;
        let prefs: serde_json::Value = serde_json::from_str(&content)?;

        let block = MemoryBlock {
            id: "UserPreference:legacy_prefs".into(),
            category: MemoryCategory::UserPreference,
            content: serde_json::to_string_pretty(&prefs)?,
            priority: 2,
            version: 1,
            created_at: Utc::now(),
            updated_at: Utc::now(),
            last_modified_by: "migrator".into(),
            access_count: 0,
        };

        // 写入 Core Memory...
        Ok(1)
    }

    // ... 其他迁移方法实现略
}

#[derive(Debug, Default, Serialize)]
pub struct MigrationReport {
    pub user_preferences: u32,
    pub project_conventions: u32,
    pub task_states: u32,
    pub error_patterns: u32,
    pub conversations: u32,
    pub knowledge_entries: u32,
    pub errors: Vec<String>,
}

#[derive(Debug, thiserror::Error)]
pub enum MigrationError {
    #[error("读取失败: {0}")]
    ReadError(#[from] std::io::Error),

    #[error("解析失败: {0}")]
    ParseError(#[from] serde_json::Error),

    #[error("写入失败: {0}")]
    WriteError(String),
}
```

#### 23.8.3 向后兼容

```rust
/// 记忆系统门面（统一入口，兼容新旧架构）
pub struct MemorySystem {
    core: Arc<RwLock<CoreMemory>>,
    working: Arc<LruFileCache>,
    recall: Arc<dyn ConversationStore>,
    archival: Arc<dyn KnowledgeStore>,
    /// 是否已完成迁移
    migrated: bool,
}

impl MemorySystem {
    /// 初始化记忆系统（自动检测并迁移）
    pub async fn init(base_dir: &Path) -> Result<Self, MemoryError> {
        let legacy_dir = base_dir.join(".assistant-memory");

        let core = Arc::new(RwLock::new(CoreMemory::new(4096)));
        let working = Arc::new(LruFileCache::new());

        // 检测是否需要迁移
        let migrated = if legacy_dir.join("migration_log.json").exists() {
            true  // 已迁移
        } else if legacy_dir.exists() {
            // 执行迁移
            let migrator = MemoryMigrator::new(legacy_dir.clone());
            migrator.migrate().await?;
            true
        } else {
            false  // 全新安装
        };

        // 初始化 Recall 和 Archival 存储
        let recall: Arc<dyn ConversationStore> = Arc::new(
            SqliteConversationStore::new(&base_dir.join(".assistant-memory/recall.db")).await?
        );

        let archival: Arc<dyn KnowledgeStore> = Arc::new(
            SqliteKnowledgeStore::new(&base_dir.join(".assistant-memory/archival.db")).await?
        );

        Ok(Self {
            core,
            working,
            recall,
            archival,
            migrated,
        })
    }

    /// 读取模式：自动路由到正确的记忆层
    pub async fn recall(&self, query: &str) -> Vec<MemoryResult> {
        let mut results = Vec::new();

        // 1. 先查 Core Memory（始终在上下文中）
        let core = self.core.read().await;
        for block in core.search(query) {
            results.push(MemoryResult {
                source: MemoryLayer::Core,
                content: block.content.clone(),
                relevance: 1.0,
            });
        }

        // 2. 查 Archival Memory（如果 Core 中没有足够结果）
        if results.len() < 3 {
            if let Ok(archival_results) = self.archival.search(query, 5).await {
                for entry in archival_results {
                    results.push(MemoryResult {
                        source: MemoryLayer::Archival,
                        content: entry.content,
                        relevance: 0.7,
                    });
                }
            }
        }

        // 3. 查 Recall Memory（对话历史）
        if let Ok(conv_results) = self.recall.search(&SearchQuery {
            keyword: Some(query.to_string()),
            session_id: None,
            role: None,
            start_time: None,
            end_time: None,
            limit: 3,
            offset: 0,
        }).await {
            for entry in conv_results {
                results.push(MemoryResult {
                    source: MemoryLayer::Recall,
                    content: entry.content,
                    relevance: 0.5,
                });
            }
        }

        results
    }
}

#[derive(Debug)]
pub struct MemoryResult {
    pub source: MemoryLayer,
    pub content: String,
    pub relevance: f64,
}

#[derive(Debug, Clone, Copy)]
pub enum MemoryLayer {
    Core,
    Working,
    Recall,
    Archival,
}
```

---

### 23.9 设计决策

| 决策 | 选择 | 理由 |
|------|------|------|
| 记忆架构 | Letta 式四层分层 | 比平面文件更系统化，各层职责清晰，优先级调度自动化 |
| Core Memory 管理 | Agent 自主管理（工具调用） | 比 CLI 命令更灵活，Agent 可根据上下文实时更新记忆 |
| Core Memory 序列化 | JSON 持久化 | 人类可读、可调试、Git 友好，与现有 .assistant-memory/ 风格一致 |
| Working Memory 策略 | LRU 100 文件 / 25MB | Claude Code 实践验证的最佳平衡点，覆盖绝大多数会话场景 |
| 大文件处理 | 首尾截断 15KB | 与第21章智能读取集成，避免单文件占用过多缓存空间 |
| Recall Memory 存储 | SQLite | 轻量级、零配置、Rust 原生 sqlx 支持，适合结构化对话存储 |
| Archival Memory 检索 | Phase 2: tantivy 全文搜索 | Rust 原生全文搜索引擎，零外部依赖，BM25 排序质量高 |
| Archival Memory 检索 | Phase 3: sqlite-vss 向量扩展 | 渐进增强，不引入额外服务依赖，本地推理无需 API 调用 |
| Archival Memory 检索 | Phase 4: Mem0-G 图谱记忆 | 远期规划，实体关系推理能力，需评估复杂度与收益比 |
| Sleep-Time Compute | Daemon 空闲触发（30s） | 与第20章 Daemon 模式无缝集成，不增加额外运行时开销 |
| 迁移策略 | 自动检测 + 一次性迁移 | 向后兼容，用户无感知升级，迁移日志可追溯 |
| Token 预算管理 | Core Memory 硬上限 + 自动压缩 | 防止上下文窗口溢出，低优先级记忆自动降级到归档层 |

---

### 23.10 实施路线图

```
  Phase 1 (MVP)              Phase 2                    Phase 3                Phase 4
  ─────────────              ───────                    ───────                ───────
  Core Memory 结构            tantivy 全文搜索            sqlite-vss 向量        Mem0-G 图谱
  MemoryBlock 定义            Archival Memory            语义相似度检索          实体关系抽取
  Agent 工具接口              索引与搜索                  混合排序 (BM25+向量)    关联推理
  Working Memory LRU          对话摘要生成                Embedding 本地推理      知识图谱构建
  Recall Memory SQLite        知识自动提取

  预计: 2 周                  预计: 1.5 周               预计: 2 周             预计: 3 周
  依赖: 第18章基础             依赖: Phase 1              依赖: Phase 2          依赖: Phase 3
```
