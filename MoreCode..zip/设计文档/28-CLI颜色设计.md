# MoreCode — TUI 颜色定义规范

> 基于 Ratatui + Crossterm 构建的终端 UI 颜色系统设计。
> 所有颜色定义遵循终端真彩色（24-bit True Color）标准，同时提供 256 色和 16 色降级方案。

---

## 24.1 颜色设计原则

| 原则 | 说明 |
|------|------|
| **语义化** | 颜色对应含义，而非外观。`Tips` 永远是黄色，无论在哪个组件中 |
| **可访问性** | 前景/背景对比度 ≥ 4.5:1（WCAG AA 标准） |
| **一致性** | 同一语义在所有组件中使用相同颜色 |
| **可配置** | 用户可通过主题文件自定义所有颜色 |
| **降级友好** | 真彩色 → 256 色 → 16 色自动降级 |

---

## 24.2 语义颜色定义

#### 24.2.1 状态颜色（Status Colors）

用于表示系统状态、Agent 状态、任务进度等。

| 语义 | 颜色名 | 真彩色 (Hex) | 256 色 | 16 色 | 使用场景 |
|------|--------|-------------|--------|-------|----------|
| 成功 | `Success` | `#4ADE80` | `#4ade80` (118) | `Green` | 命令执行成功、任务完成、测试通过 |
| 错误 | `Error` | `#F87171` | `#f87171` (203) | `Red` | 命令执行失败、编译错误、Agent 异常 |
| 警告 | `Warning` | `#FBBF24` | `#fbbf24` (220) | `Yellow` | 潜在风险、降级运行、Token 不足 |
| 信息 | `Info` | `#60A5FA` | `#60a5fa` (75) | `Blue` | 系统信息、状态更新、进度提示 |
| 提示 | `Tips` | `#FCD34D` | `#fcd34d` (227) | `Yellow` | Agent 建议、操作提示、使用指南 |
| 调试 | `Debug` | `#A78BFA` | `#a78bfa` (141) | `Magenta` | 调试信息、详细日志、内部状态 |

#### 24.2.2 Agent 颜色（Agent Colors）

每个 Agent 有专属颜色，用于区分不同 Agent 的输出。

| Agent | 颜色名 | 真彩色 (Hex) | 256 色 | 16 色 | 说明 |
|-------|--------|-------------|--------|-------|------|
| Coordinator | `AgentCoordinator` | `#F472B6` | `#f472b6` (211) | `Magenta` | 主协调者 — 粉色，突出核心角色 |
| Explorer | `AgentExplorer` | `#34D399` | `#34d399` (79) | `Green` | 项目探索者 — 翠绿，代表发现 |
| Impact Analyzer | `AgentImpact` | `#FB923C` | `#fb923c` (215) | `Yellow` | 影响分析者 — 橙色，代表警示 |
| Planner | `AgentPlanner` | `#A78BFA` | `#a78bfa` (141) | `Magenta` | 任务规划者 — 紫色，代表策略 |
| Coder | `AgentCoder` | `#60A5FA` | `#60a5fa` (75) | `Blue` | 编码执行者 — 蓝色，代表编码 |
| Reviewer | `AgentReviewer` | `#2DD4BF` | `#2dd4bf` (80) | `Cyan` | 代码审查者 — 青色，代表审查 |
| Tester | `AgentTester` | `#4ADE80` | `#4ade80` (118) | `Green` | 测试生成者 — 绿色，代表通过 |
| Research | `AgentResearch` | `#C084FC` | `#c084fc` (177) | `Magenta` | 研究者 — 淡紫，代表深度 |
| DocWriter | `AgentDocWriter` | `#F9A8D4` | `#f9a8d4` (218) | `Magenta` | 文档编写者 — 浅粉，代表文档 |
| Debugger | `AgentDebugger` | `#F87171` | `#f87171` (203) | `Red` | 调试者 — 红色，代表修复 |

#### 24.2.3 路由级别颜色（Routing Level Colors）

四级路由决策对应的颜色。

| 级别 | 颜色名 | 真彩色 (Hex) | 256 色 | 16 色 | 说明 |
|------|--------|-------------|--------|-------|------|
| 🟢 Simple | `RouteSimple` | `#4ADE80` | `#4ade80` (118) | `Green` | 单 Agent 直接处理 |
| 🟡 Medium | `RouteMedium` | `#FBBF24` | `#fbbf24` (220) | `Yellow` | 认知层 + 执行层 |
| 🔴 Complex | `RouteComplex` | `#F87171` | `#f87171` (203) | `Red` | 全 Agent 协作 |
| 🔵 Research | `RouteResearch` | `#60A5FA` | `#60a5fa` (75) | `Blue` | 研究型任务 |

#### 24.2.4 命令与输出颜色（Command & Output Colors）

| 语义 | 颜色名 | 真彩色 (Hex) | 256 色 | 16 色 | 使用场景 |
|------|--------|-------------|--------|-------|----------|
| 命令执行 | `CommandRun` | `#4ADE80` | `#4ade80` (118) | `Green` | 正在执行的 Shell 命令 |
| 命令输出 | `CommandOutput` | `#93C5FD` | `#93c5fd` (111) | `Blue` | 命令的标准输出 (stdout) |
| 命令错误 | `CommandError` | `#FCA5A5` | `#fca5a5` (210) | `Red` | 命令的错误输出 (stderr) |
| 命令路径 | `CommandPath` | `#86EFAC` | `#86efac` (150) | `Green` | 文件路径、目录路径 |
| 命令参数 | `CommandArg` | `#FDE68A` | `#fde68a` (229) | `Yellow` | 命令参数、选项标志 |
| 命令关键字 | `CommandKeyword` | `#C4B5FD` | `#c4b5fd` (183) | `Magenta` | Shell 关键字 (if/for/while) |

#### 24.2.5 代码语法颜色（Syntax Highlighting Colors）

| 语义 | 颜色名 | 真彩色 (Hex) | 256 色 | 16 色 | 说明 |
|------|--------|-------------|--------|-------|------|
| 关键字 | `SyntaxKeyword` | `#C084FC` | `#c084fc` (177) | `Magenta` | fn, let, pub, struct, impl |
| 字符串 | `SyntaxString` | `#4ADE80` | `#4ade80` (118) | `Green` | "hello", 'a' |
| 数字 | `SyntaxNumber` | `#FBBF24` | `#fbbf24` (220) | `Yellow` | 42, 3.14, 0xFF |
| 类型 | `SyntaxType` | `#60A5FA` | `#60a5fa` (75) | `Blue` | String, Vec, Option, i32 |
| 注释 | `SyntaxComment` | `#6B7280` | `#6b7280` (243) | `DarkGray` | // comment, /* block */ |
| 函数名 | `SyntaxFunction` | `#F472B6` | `#f472b6` (211) | `Magenta` | my_function, new() |
| 宏 | `SyntaxMacro` | `#FB923C` | `#fb923c` (215) | `Yellow` | println!, vec!, derive() |
| 生命周期 | `SyntaxLifetime` | `#2DD4BF` | `#2dd4bf` (80) | `Cyan` | 'a, 'static |
| 属性 | `SyntaxAttribute` | `#FCD34D` | `#fcd34d` (227) | `Yellow` | #[derive], #[cfg] |
| 变量 | `SyntaxVariable` | `#E5E7EB` | `#e5e7eb` (254) | `White` | 普通变量名 |
| 运算符 | `SyntaxOperator` | `#F9A8D4` | `#f9a8d4` (218) | `Magenta` | +, -, ->, =>, :: |
| 分隔符 | `SyntaxPunctuation` | `#9CA3AF` | `#9ca3af` (245) | `DarkGray` | {, }, (, ), [, ], ;, , |

#### 24.2.6 Git 相关颜色（Git Colors）

| 语义 | 颜色名 | 真彩色 (Hex) | 256 色 | 16 色 | 使用场景 |
|------|--------|-------------|--------|-------|----------|
| 新增行 | `GitAdded` | `#4ADE80` | `#4ade80` (118) | `Green` | diff 中新增的行 |
| 删除行 | `GitDeleted` | `#F87171` | `#f87171` (203) | `Red` | diff 中删除的行 |
| 修改行 | `GitModified` | `#FBBF24` | `#fbbf24` (220) | `Yellow` | diff 中修改的行 |
| Commit Hash | `GitHash` | `#FCD34D` | `#fcd34d` (227) | `Yellow` | commit 哈希值 |
| Branch | `GitBranch` | `#C084FC` | `#c084fc` (177) | `Magenta` | 分支名 |
| Tag | `GitTag` | `#60A5FA` | `#60a5fa` (75) | `Blue` | 标签名 |
| Staged | `GitStaged` | `#34D399` | `#34d399` (79) | `Green` | 已暂存的文件 |
| Unstaged | `GitUnstaged` | `#FB923C` | `#fb923c` (215) | `Yellow` | 未暂存的文件 |
| Untracked | `GitUntracked` | `#9CA3AF` | `#9ca3af` (245) | `DarkGray` | 未跟踪的文件 |

#### 24.2.7 UI 组件颜色（UI Component Colors）

| 语义 | 颜色名 | 真彩色 (Hex) | 256 色 | 16 色 | 使用场景 |
|------|--------|-------------|--------|-------|----------|
| 标题栏 | `TitleBar` | `#1E293B` | `#1e293b` (236) | `DarkBlue` | 顶部标题栏背景 |
| 标题文字 | `TitleText` | `#F1F5F9` | `#f1f5f9` (231) | `White` | 标题栏文字 |
| 状态栏 | `StatusBar` | `#1E293B` | `#1e293b` (236) | `DarkBlue` | 底部状态栏背景 |
| 状态文字 | `StatusText` | `#94A3B8` | `#94a3b8` (246) | `Gray` | 状态栏普通文字 |
| 进度条 | `ProgressBar` | `#3B82F6` | `#3b82f6` (33) | `Blue` | 进度条填充 |
| 进度背景 | `ProgressBg` | `#374151` | `#374151` (238) | `DarkGray` | 进度条背景 |
| 边框 | `Border` | `#475569` | `#475569` (240) | `DarkGray` | 面板边框 |
| 边框高亮 | `BorderHighlight` | `#60A5FA` | `#60a5fa` (75) | `Blue` | 活动面板边框 |
| 选中项 | `Selection` | `#1E3A5F` | `#1e3a5f` (24) | `DarkBlue` | 列表选中项背景 |
| 悬停项 | `Hover` | `#334155` | `#334155` (237) | `DarkGray` | 列表悬停项背景 |
| 输入框 | `InputField` | `#0F172A` | `#0f172a` (233) | `Black` | 输入框背景 |
| 输入光标 | `InputCursor` | `#F472B6` | `#f472b6` (211) | `Magenta` | 输入光标 |
| 滚动条 | `ScrollBar` | `#475569` | `#475569` (240) | `DarkGray` | 滚动条 |
| 滚动条滑块 | `ScrollThumb` | `#94A3B8` | `#94a3b8` (246) | `Gray` | 滚动条滑块 |
| 分隔线 | `Separator` | `#334155` | `#334155` (237) | `DarkGray` | 面板分隔线 |

#### 24.2.8 文本样式颜色（Text Style Colors）

| 语义 | 颜色名 | 真彩色 (Hex) | 256 色 | 16 色 | 使用场景 |
|------|--------|-------------|--------|-------|----------|
| 主要文字 | `TextPrimary` | `#F1F5F9` | `#f1f5f9` (231) | `White` | 正文主要内容 |
| 次要文字 | `TextSecondary` | `#94A3B8` | `#94a3b8` (246) | `Gray` | 辅助说明、元数据 |
| 暗淡文字 | `TextMuted` | `#64748B` | `#64748b` (243) | `DarkGray` | 时间戳、行号、不重要的信息 |
| 强调文字 | `TextAccent` | `#60A5FA` | `#60a5fa` (75) | `Blue` | 需要用户注意的关键信息 |
| 链接 | `TextLink` | `#93C5FD` | `#93c5fd` (111) | `Blue` | 可点击的链接/路径 |
| 标签 | `TextTag` | `#FCD34D` | `#fcd34d` (227) | `Yellow` | 标签、徽章 |
| 用户输入 | `TextUserInput` | `#4ADE80` | `#4ade80` (118) | `Green` | 用户输入的文本 |

---

## 24.3 深色/浅色主题

#### 24.3.1 深色主题（默认）

背景色系：

| 用途 | 颜色名 | 真彩色 (Hex) |
|------|--------|-------------|
| 主背景 | `BgPrimary` | `#0F172A` |
| 次背景 | `BgSecondary` | `#1E293B` |
| 面板背景 | `BgPanel` | `#1E293B` |
| 代码背景 | `BgCode` | `#0F172A` |
| 悬浮背景 | `BgHover` | `#334155` |

#### 24.3.2 浅色主题

背景色系：

| 用途 | 颜色名 | 真彩色 (Hex) |
|------|--------|-------------|
| 主背景 | `BgPrimary` | `#FFFFFF` |
| 次背景 | `BgSecondary` | `#F8FAFC` |
| 面板背景 | `BgPanel` | `#F1F5F9` |
| 代码背景 | `BgCode` | `#F8FAFC` |
| 悬浮背景 | `BgHover` | `#E2E8F0` |

浅色主题下，前景色需要相应调暗以保证对比度：

| 语义 | 深色主题 | 浅色主题 |
|------|----------|----------|
| 主要文字 | `#F1F5F9` | `#0F172A` |
| 次要文字 | `#94A3B8` | `#475569` |
| 暗淡文字 | `#64748B` | `#94A3B8` |
| 边框 | `#475569` | `#CBD5E1` |

---

## 24.4 Rust 实现

#### 24.4.1 颜色定义

```rust
use ratatui::style::Color;

/// 语义颜色枚举 — 所有 UI 颜色通过此枚举引用
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SemanticColor {
    // 状态颜色
    Success,
    Error,
    Warning,
    Info,
    Tips,
    Debug,

    // Agent 颜色
    AgentCoordinator,
    AgentExplorer,
    AgentImpact,
    AgentPlanner,
    AgentCoder,
    AgentReviewer,
    AgentTester,
    AgentResearch,
    AgentDocWriter,
    AgentDebugger,

    // 路由级别
    RouteSimple,
    RouteMedium,
    RouteComplex,
    RouteResearch,

    // 命令与输出
    CommandRun,
    CommandOutput,
    CommandError,
    CommandPath,
    CommandArg,
    CommandKeyword,

    // 语法高亮
    SyntaxKeyword,
    SyntaxString,
    SyntaxNumber,
    SyntaxType,
    SyntaxComment,
    SyntaxFunction,
    SyntaxMacro,
    SyntaxLifetime,
    SyntaxAttribute,
    SyntaxVariable,
    SyntaxOperator,
    SyntaxPunctuation,

    // Git
    GitAdded,
    GitDeleted,
    GitModified,
    GitHash,
    GitBranch,
    GitTag,
    GitStaged,
    GitUnstaged,
    GitUntracked,

    // UI 组件
    TitleBar,
    TitleText,
    StatusBar,
    StatusText,
    ProgressBar,
    ProgressBg,
    Border,
    BorderHighlight,
    Selection,
    Hover,
    InputField,
    InputCursor,
    ScrollBar,
    ScrollThumb,
    Separator,

    // 文本样式
    TextPrimary,
    TextSecondary,
    TextMuted,
    TextAccent,
    TextLink,
    TextTag,
    TextUserInput,

    // 背景
    BgPrimary,
    BgSecondary,
    BgPanel,
    BgCode,
    BgHover,
}

/// 主题定义
pub trait Theme {
    /// 获取语义颜色对应的实际颜色
    fn color(&self, semantic: SemanticColor) -> Color;
    /// 是否支持真彩色
    fn supports_truecolor(&self) -> bool;
    /// 主题名称
    fn name(&self) -> &str;
}

/// 深色主题（默认）
pub struct DarkTheme;

impl Theme for DarkTheme {
    fn color(&self, semantic: SemanticColor) -> Color {
        match semantic {
            // 状态颜色
            SemanticColor::Success       => Color::Rgb(74, 222, 128),   // #4ADE80
            SemanticColor::Error         => Color::Rgb(248, 113, 113),  // #F87171
            SemanticColor::Warning       => Color::Rgb(251, 191, 36),   // #FBBF24
            SemanticColor::Info          => Color::Rgb(96, 165, 250),   // #60A5FA
            SemanticColor::Tips          => Color::Rgb(252, 211, 77),   // #FCD34D
            SemanticColor::Debug         => Color::Rgb(167, 139, 250),  // #A78BFA

            // Agent 颜色
            SemanticColor::AgentCoordinator => Color::Rgb(244, 114, 182), // #F472B6
            SemanticColor::AgentExplorer    => Color::Rgb(52, 211, 153),  // #34D399
            SemanticColor::AgentImpact      => Color::Rgb(251, 146, 60),  // #FB923C
            SemanticColor::AgentPlanner     => Color::Rgb(167, 139, 250), // #A78BFA
            SemanticColor::AgentCoder       => Color::Rgb(96, 165, 250),  // #60A5FA
            SemanticColor::AgentReviewer    => Color::Rgb(45, 212, 191),  // #2DD4BF
            SemanticColor::AgentTester      => Color::Rgb(74, 222, 128),  // #4ADE80
            SemanticColor::AgentResearch    => Color::Rgb(192, 132, 252), // #C084FC
            SemanticColor::AgentDocWriter   => Color::Rgb(249, 168, 212), // #F9A8D4
            SemanticColor::AgentDebugger    => Color::Rgb(248, 113, 113), // #F87171

            // 路由级别
            SemanticColor::RouteSimple   => Color::Rgb(74, 222, 128),   // #4ADE80
            SemanticColor::RouteMedium   => Color::Rgb(251, 191, 36),   // #FBBF24
            SemanticColor::RouteComplex  => Color::Rgb(248, 113, 113),  // #F87171
            SemanticColor::RouteResearch => Color::Rgb(96, 165, 250),   // #60A5FA

            // 命令与输出
            SemanticColor::CommandRun     => Color::Rgb(74, 222, 128),   // #4ADE80
            SemanticColor::CommandOutput  => Color::Rgb(147, 197, 253),  // #93C5FD
            SemanticColor::CommandError   => Color::Rgb(252, 165, 165),  // #FCA5A5
            SemanticColor::CommandPath    => Color::Rgb(134, 239, 172),  // #86EFAC
            SemanticColor::CommandArg     => Color::Rgb(253, 230, 138),  // #FDE68A
            SemanticColor::CommandKeyword => Color::Rgb(196, 181, 253),  // #C4B5FD

            // 语法高亮
            SemanticColor::SyntaxKeyword    => Color::Rgb(192, 132, 252), // #C084FC
            SemanticColor::SyntaxString     => Color::Rgb(74, 222, 128),  // #4ADE80
            SemanticColor::SyntaxNumber     => Color::Rgb(251, 191, 36),  // #FBBF24
            SemanticColor::SyntaxType       => Color::Rgb(96, 165, 250),  // #60A5FA
            SemanticColor::SyntaxComment    => Color::Rgb(107, 114, 128), // #6B7280
            SemanticColor::SyntaxFunction   => Color::Rgb(244, 114, 182), // #F472B6
            SemanticColor::SyntaxMacro      => Color::Rgb(251, 146, 60),  // #FB923C
            SemanticColor::SyntaxLifetime   => Color::Rgb(45, 212, 191),  // #2DD4BF
            SemanticColor::SyntaxAttribute  => Color::Rgb(252, 211, 77),  // #FCD34D
            SemanticColor::SyntaxVariable   => Color::Rgb(229, 231, 235), // #E5E7EB
            SemanticColor::SyntaxOperator   => Color::Rgb(249, 168, 212), // #F9A8D4
            SemanticColor::SyntaxPunctuation=> Color::Rgb(156, 163, 175), // #9CA3AF

            // Git
            SemanticColor::GitAdded    => Color::Rgb(74, 222, 128),   // #4ADE80
            SemanticColor::GitDeleted  => Color::Rgb(248, 113, 113),  // #F87171
            SemanticColor::GitModified => Color::Rgb(251, 191, 36),   // #FBBF24
            SemanticColor::GitHash     => Color::Rgb(252, 211, 77),   // #FCD34D
            SemanticColor::GitBranch   => Color::Rgb(192, 132, 252), // #C084FC
            SemanticColor::GitTag      => Color::Rgb(96, 165, 250),   // #60A5FA
            SemanticColor::GitStaged   => Color::Rgb(52, 211, 153),   // #34D399
            SemanticColor::GitUnstaged => Color::Rgb(251, 146, 60),   // #FB923C
            SemanticColor::GitUntracked=> Color::Rgb(156, 163, 175), // #9CA3AF

            // UI 组件
            SemanticColor::TitleBar        => Color::Rgb(30, 41, 59),    // #1E293B
            SemanticColor::TitleText       => Color::Rgb(241, 245, 249), // #F1F5F9
            SemanticColor::StatusBar       => Color::Rgb(30, 41, 59),    // #1E293B
            SemanticColor::StatusText      => Color::Rgb(148, 163, 184), // #94A3B8
            SemanticColor::ProgressBar     => Color::Rgb(59, 130, 246),  // #3B82F6
            SemanticColor::ProgressBg      => Color::Rgb(55, 65, 81),    // #374151
            SemanticColor::Border          => Color::Rgb(71, 85, 105),   // #475569
            SemanticColor::BorderHighlight => Color::Rgb(96, 165, 250),  // #60A5FA
            SemanticColor::Selection       => Color::Rgb(30, 58, 95),    // #1E3A5F
            SemanticColor::Hover           => Color::Rgb(51, 65, 85),    // #334155
            SemanticColor::InputField      => Color::Rgb(15, 23, 42),    // #0F172A
            SemanticColor::InputCursor     => Color::Rgb(244, 114, 182), // #F472B6
            SemanticColor::ScrollBar       => Color::Rgb(71, 85, 105),   // #475569
            SemanticColor::ScrollThumb     => Color::Rgb(148, 163, 184), // #94A3B8
            SemanticColor::Separator       => Color::Rgb(51, 65, 85),    // #334155

            // 文本样式
            SemanticColor::TextPrimary   => Color::Rgb(241, 245, 249), // #F1F5F9
            SemanticColor::TextSecondary => Color::Rgb(148, 163, 184), // #94A3B8
            SemanticColor::TextMuted     => Color::Rgb(100, 116, 139), // #64748B
            SemanticColor::TextAccent    => Color::Rgb(96, 165, 250),  // #60A5FA
            SemanticColor::TextLink      => Color::Rgb(147, 197, 253), // #93C5FD
            SemanticColor::TextTag       => Color::Rgb(252, 211, 77),  // #FCD34D
            SemanticColor::TextUserInput => Color::Rgb(74, 222, 128),  // #4ADE80

            // 背景
            SemanticColor::BgPrimary   => Color::Rgb(15, 23, 42),    // #0F172A
            SemanticColor::BgSecondary => Color::Rgb(30, 41, 59),    // #1E293B
            SemanticColor::BgPanel     => Color::Rgb(30, 41, 59),    // #1E293B
            SemanticColor::BgCode      => Color::Rgb(15, 23, 42),    // #0F172A
            SemanticColor::BgHover     => Color::Rgb(51, 65, 85),    // #334155
        }
    }

    fn supports_truecolor(&self) -> bool { true }
    fn name(&self) -> &str { "dark" }
}
```

#### 24.4.2 颜色自动降级

```rust
/// 根据终端能力自动选择颜色精度
pub struct ColorResolver {
    theme: Box<dyn Theme>,
    color_level: ColorLevel,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColorLevel {
    TrueColor,  // 24-bit (16M colors)
    Color256,   // 8-bit (256 colors)
    Color16,    // 4-bit (16 colors)
    Monochrome, // No color
}

impl ColorResolver {
    pub fn new(theme: Box<dyn Theme>, terminal_info: &TerminalInfo) -> Self {
        let color_level = if terminal_info.true_color {
            ColorLevel::TrueColor
        } else if terminal_info.color_support {
            // 检测是否支持 256 色
            let term = &terminal_info.term;
            if term.contains("256color") || term.contains("xterm-256color") {
                ColorLevel::Color256
            } else {
                ColorLevel::Color16
            }
        } else {
            ColorLevel::Monochrome
        };

        Self { theme, color_level }
    }

    /// 解析语义颜色为终端实际颜色
    pub fn resolve(&self, semantic: SemanticColor) -> Color {
        let true_color = self.theme.color(semantic);
        match self.color_level {
            ColorLevel::TrueColor => true_color,
            ColorLevel::Color256 => self.to_256(true_color),
            ColorLevel::Color16 => self.to_16(semantic),
            ColorLevel::Monochrome => Color::White,
        }
    }

    /// 真彩色 → 256 色近似映射
    fn to_256(&self, color: Color) -> Color {
        match color {
            Color::Rgb(r, g, b) => {
                // 🆕 P2-4: 使用加权欧几里得距离（感知亮度加权），更贴近人眼感知
                // 人眼对绿色最敏感（权重 1.0），红色次之（0.7），蓝色最弱（0.5）
                let (r, g, b) = (r as i32, g as i32, b as i32);
                let mut best_idx = 0;
                let mut best_dist = i32::MAX;

                // 256 色调色板: 0-15 = 标准 16 色, 16-231 = 6x6x6 立方体, 232-255 = 灰度
                for idx in 16..=231 {
                    let cr = (idx - 16) / 36;
                    let cg = ((idx - 16) % 36) / 6;
                    let cb = (idx - 16) % 6;
                    let pr = if cr == 0 { 0 } else { cr * 40 + 55 };
                    let pg = if cg == 0 { 0 } else { cg * 40 + 55 };
                    let pb = if cb == 0 { 0 } else { cb * 40 + 55 };
                    // 加权距离：R×0.7, G×1.0, B×0.5（基于人眼感知灵敏度）
                    let dist = ((r - pr).pow(2) * 7
                        + (g - pg).pow(2) * 10
                        + (b - pb).pow(2) * 5) / 10;
                    if dist < best_dist {
                        best_dist = dist;
                        best_idx = idx;
                    }
                }

                // 也检查灰度范围（使用标准亮度公式 0.299R + 0.587G + 0.114B）
                for idx in 232..=255 {
                    let gray = (idx - 232) * 10 + 8;
                    let luminance = (r as f32 * 0.299 + g as f32 * 0.587 + b as f32 * 0.114) as i32;
                    let dist = (luminance - gray).abs();
                    if dist < best_dist {
                        best_dist = dist;
                        best_idx = idx;
                    }
                }

                Color::Indexed(best_idx)
            }
            other => other,
        }
    }

    /// 语义颜色 → 16 色映射
    fn to_16(&self, semantic: SemanticColor) -> Color {
        match semantic {
            // 状态
            SemanticColor::Success | SemanticColor::CommandRun
            | SemanticColor::GitAdded | SemanticColor::GitStaged
            | SemanticColor::RouteSimple | SemanticColor::TextUserInput
            | SemanticColor::AgentTester => Color::Green,

            SemanticColor::AgentExplorer => Color::Yellow,

            SemanticColor::Error | SemanticColor::CommandError
            | SemanticColor::GitDeleted | SemanticColor::RouteComplex
            | SemanticColor::AgentDebugger => Color::Red,

            SemanticColor::Warning | SemanticColor::Tips
            | SemanticColor::GitModified | SemanticColor::RouteMedium
            | SemanticColor::CommandArg | SemanticColor::SyntaxNumber
            | SemanticColor::SyntaxAttribute | SemanticColor::TextTag
            | SemanticColor::GitHash | SemanticColor::AgentImpact => Color::Yellow,

            SemanticColor::Info | SemanticColor::CommandOutput
            | SemanticColor::RouteResearch | SemanticColor::TextAccent
            | SemanticColor::TextLink | SemanticColor::AgentCoder
            | SemanticColor::SyntaxType | SemanticColor::GitTag
            | SemanticColor::BorderHighlight | SemanticColor::ProgressBar => Color::Blue,

            SemanticColor::Debug | SemanticColor::CommandKeyword
            | SemanticColor::SyntaxKeyword | SemanticColor::SyntaxFunction
            | SemanticColor::SyntaxOperator | SemanticColor::AgentCoordinator
            | SemanticColor::AgentPlanner | SemanticColor::AgentResearch
            | SemanticColor::AgentDocWriter | SemanticColor::InputCursor
            | SemanticColor::SyntaxMacro => Color::Magenta,

            SemanticColor::AgentReviewer | SemanticColor::SyntaxLifetime => Color::Cyan,

            SemanticColor::SyntaxComment | SemanticColor::TextMuted
            | SemanticColor::SyntaxPunctuation | SemanticColor::GitUntracked
            | SemanticColor::Border | SemanticColor::ScrollBar
            | SemanticColor::Separator => Color::DarkGray,

            SemanticColor::TextSecondary | SemanticColor::StatusText
            | SemanticColor::ScrollThumb => Color::Gray,

            SemanticColor::TextPrimary | SemanticColor::TitleText
            | SemanticColor::SyntaxVariable => Color::White,

            SemanticColor::BgPrimary | SemanticColor::BgCode
            | SemanticColor::InputField => Color::Black,

            SemanticColor::BgSecondary | SemanticColor::BgPanel
            | SemanticColor::TitleBar | SemanticColor::StatusBar
            | SemanticColor::ProgressBg | SemanticColor::Selection
            | SemanticColor::BgHover => Color::DarkBlue,

            _ => Color::White,
        }
    }
}
```

#### 24.4.3 使用示例

```rust
use ratatui::style::{Color, Style, Modifier};
use ratatui::text::{Span, Line};

/// 构建带颜色的文本
fn build_colored_text(resolver: &ColorResolver) -> Vec<Line<'static>> {
    vec![
        // Agent 标识
        Line::from(vec![
            Span::styled("● ", Style::default().fg(resolver.resolve(SemanticColor::AgentCoder))),
            Span::styled("Coder", Style::default()
                .fg(resolver.resolve(SemanticColor::AgentCoder))
                .add_modifier(Modifier::BOLD)),
            Span::raw(" "),
            Span::styled("正在修改 user_service.rs", Style::default()
                .fg(resolver.resolve(SemanticColor::TextSecondary))),
        ]),
        // 命令执行
        Line::from(vec![
            Span::styled("  $ ", Style::default()
                .fg(resolver.resolve(SemanticColor::CommandRun))),
            Span::styled("cargo", Style::default()
                .fg(resolver.resolve(SemanticColor::CommandKeyword))),
            Span::raw(" "),
            Span::styled("check", Style::default()
                .fg(resolver.resolve(SemanticColor::CommandArg))),
        ]),
        // 命令输出
        Line::from(vec![
            Span::styled("    Finished ", Style::default()
                .fg(resolver.resolve(SemanticColor::CommandOutput))),
            Span::styled("dev", Style::default()
                .fg(resolver.resolve(SemanticColor::TextAccent))
                .add_modifier(Modifier::BOLD)),
            Span::styled(" target(s) in 2.34s", Style::default()
                .fg(resolver.resolve(SemanticColor::CommandOutput))),
        ]),
        // Git 状态
        Line::from(vec![
            Span::styled("  + ", Style::default()
                .fg(resolver.resolve(SemanticColor::GitAdded))),
            Span::styled("src/services/user_service.rs", Style::default()
                .fg(resolver.resolve(SemanticColor::GitStaged))),
            Span::raw("  "),
            Span::styled("M ", Style::default()
                .fg(resolver.resolve(SemanticColor::GitModified))),
            Span::styled("src/models/user.rs", Style::default()
                .fg(resolver.resolve(SemanticColor::GitUnstaged))),
        ]),
    ]
}
```

---

## 24.5 用户自定义主题

用户可通过 `~/.config/ai-assistant/theme.toml` 自定义颜色：

```toml
# ~/.config/ai-assistant/theme.toml

[theme]
name = "my-dark"
base = "dark"  # 继承 dark 或 light 主题

# 覆盖特定颜色
[theme.colors]
# 状态颜色
success = "#00FF00"        # 自定义成功色
error = "#FF0000"          # 自定义错误色
tips = "#FFFF00"           # 自定义提示色

# Agent 颜色
agent_coder = "#00BFFF"    # 自定义 Coder 颜色
agent_coordinator = "#FF69B4"

# UI 组件
progress_bar = "#FF6B6B"
border_highlight = "#00CED1"

# 语法高亮
syntax_keyword = "#FF79C6"
syntax_string = "#50FA7B"
syntax_comment = "#6272A4"
```

---

## 24.6 颜色速查表

```
┌─────────────────────────────────────────────────────────────────┐
│                        颜色速查表                                │
├──────────┬──────────┬──────────┬──────────┬─────────────────────┤
│  语义     │  颜色     │  Hex     │  用途     │  示例               │
├──────────┼──────────┼──────────┼──────────┼─────────────────────┤
│  成功     │  🟢 绿    │ #4ADE80  │  任务完成  │  ✅ Build passed    │
│  错误     │  🔴 红    │ #F87171  │  执行失败  │  ❌ Compilation     │
│  警告     │  🟡 黄    │ #FBBF24  │  潜在风险  │  ⚠️ Token 85%      │
│  信息     │  🔵 蓝    │ #60A5FA  │  系统信息  │  ℹ️ 3 tasks left   │
│  提示     │  🟡 浅黄  │ #FCD34D  │  操作建议  │  💡 Try --flag     │
│  调试     │  🟣 紫    │ #A78BFA  │  调试信息  │  🔍 State: Idle    │
├──────────┼──────────┼──────────┼──────────┼─────────────────────┤
│  命令     │  🟢 绿    │ #4ADE80  │  Shell   │  $ cargo build     │
│  输出     │  🔵 浅蓝  │ #93C5FD  │  stdout  │  Finished in 2.3s  │
│  错误输出 │  🔴 浅红  │ #FCA5A5  │  stderr  │  error[E0425]      │
│  路径     │  🟢 浅绿  │ #86EFAC  │  文件路径  │  src/main.rs       │
│  参数     │  🟡 浅黄  │ #FDE68A  │  命令参数  │  --release         │
├──────────┼──────────┼──────────┼──────────┼─────────────────────┤
│  Git+    │  🟢 绿    │ #4ADE80  │  新增行   │  + fn new_func()   │
│  Git-    │  🔴 红    │ #F87171  │  删除行   │  - old_line         │
│  Git~    │  🟡 黄    │ #FBBF24  │  修改行   │  ~ modified_line    │
│  Hash    │  🟡 浅黄  │ #FCD34D  │  提交哈希  │  abc1234           │
│  Branch  │  🟣 紫    │ #C084FC  │  分支名   │  feature/auth      │
├──────────┼──────────┼──────────┼──────────┼─────────────────────┤
│  关键字   │  🟣 紫    │ #C084FC  │  fn/let  │  fn main()         │
│  字符串   │  🟢 绿    │ #4ADE80  │  "..."   │  "hello world"     │
│  数字     │  🟡 黄    │ #FBBF24  │  42      │  let x = 42        │
│  类型     │  🔵 蓝    │ #60A5FA  │  String  │  Vec<String>       │
│  注释     │  ⚪ 灰    │ #6B7280  │  // ...  │  // TODO: fix      │
│  函数名   │  🩷 粉    │ #F472B6  │  my_fn   │  fn process()      │
└──────────┴──────────┴──────────┴──────────┴─────────────────────┘
```
