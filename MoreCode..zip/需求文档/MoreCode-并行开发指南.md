# MoreCode Agent — 并行开发指南

> **日期**：2026-04-18
> **总预估工期**：26-38 天
> **开发模式**：多窗口隔离并行开发

---

## 1. 开发环境准备

```bash
# 克隆仓库
git clone <repo-url> morecode-agent && cd morecode-agent

# 安装 Rust 工具链
rustup toolchain install stable
rustup component add clippy rustfmt

# 验证
cargo build
cargo test
cargo clippy -- -D warnings
cargo fmt --check
```

---

## 2. 并行开发批次

### 批次 1（Day 1-2）：基础设施 — 串行

| 窗口 | 任务 | 文件 | 完成标志 |
|------|------|------|----------|
| W1 | P0-1 Cargo Workspace 初始化 | `Cargo.toml`, `rust-toolchain.toml`, `clippy.toml`, 15 个 crate 的 `Cargo.toml` | `cargo build` 成功 |
| W1 | P0-2 CI 配置 | `.github/workflows/ci.yml` | CI 绿色 |

**完成后**：`git commit -m "chore: initialize cargo workspace and CI" && git push`

### 批次 2（Day 3-7）：核心基础层 — 3 窗口并行

| 窗口 | 任务 | Crate | 开发文档 | 依赖 |
|------|------|-------|----------|------|
| W1 | P1-1 mc-core | `crates/mc-core/` | part1 §P1-1 | 无 |
| W2 | P1-2 mc-communication | `crates/mc-communication/` | part1 §P1-2 | mc-core |
| W3 | P1-3 mc-config | `crates/mc-config/` | part1 §P1-3 | mc-core |

**W2/W3 启动条件**：W1 的 `mc-core` 编译通过后（`cargo build -p mc-core`）

**完成后各窗口独立 commit**：
```bash
# W1
git checkout -b feat/mc-core
# ... 编码 ...
cargo test -p mc-core && cargo clippy -p mc-core -- -D warnings
git add crates/mc-core/ && git commit -m "feat(core): implement core types, enums, and traits"
git push origin feat/mc-core

# W2（等 W1 合并后）
git checkout -b feat/mc-communication main
# ... 编码 ...
cargo test -p mc-communication && cargo clippy -p mc-communication -- -D warnings
git add crates/mc-communication/ && git commit -m "feat(comm): implement three-level message system"
git push origin feat/mc-communication

# W3（等 W1 合并后）
git checkout -b feat/mc-config main
# ... 编码 ...
cargo test -p mc-config && cargo clippy -p mc-config -- -D warnings
git add crates/mc-config/ && git commit -m "feat(config): implement multi-level config management"
git push origin feat/mc-config
```

### 批次 3（Day 5-12）：能力支撑层 — 4 窗口并行

| 窗口 | 任务 | Crate | 开发文档 | 依赖 |
|------|------|-------|----------|------|
| W1 | P2-1 mc-llm | `crates/mc-llm/` | part2 §P2-1 | mc-core, mc-config |
| W2 | P2-2 mc-prompt | `crates/mc-prompt/` | part2 §P2-2 | mc-core |
| W3 | P2-3 mc-sandbox | `crates/mc-sandbox/` | part2 §P2-3 | mc-core |
| W4 | P2-4 mc-tool | `crates/mc-tool/` | part2 §P2-4 | mc-core, mc-config, mc-sandbox |

**W4 启动条件**：W3 的 `mc-sandbox` 编译通过

### 批次 4（Day 10-16）：上下文与记忆层 — 2 窗口并行

| 窗口 | 任务 | Crate | 开发文档 | 依赖 |
|------|------|-------|----------|------|
| W1 | P3-1 mc-context | `crates/mc-context/` | part3 §P3-1 | mc-core |
| W2 | P3-2 mc-memory | `crates/mc-memory/` | part3 §P3-2 | mc-core, mc-context |

**W2 启动条件**：W1 的 `mc-context` 编译通过

### 批次 5（Day 13-20）：Agent 实现层 — 4 窗口并行

| 窗口 | 任务 | Crate | 开发文档 | 依赖 |
|------|------|-------|----------|------|
| W1 | P4-1 mc-agent (trait) | `crates/mc-agent/src/lib.rs`, `trait.rs`, `registry.rs` | part4 §P4-1 | mc-llm, mc-tool, mc-context, mc-communication |
| W2 | P4-2 认知层 Agent | `crates/mc-agent/src/explorer.rs`, `impact.rs`, `planner.rs` | part4 §P4-2 | mc-agent(trait) |
| W3 | P4-3 执行层 Agent | `crates/mc-agent/src/coder.rs`, `reviewer.rs`, `tester.rs` | part4 §P4-3 | mc-agent(trait) |
| W4 | P4-4 专项 Agent | `crates/mc-agent/src/research.rs`, `docwriter.rs`, `debugger.rs` | part4 §P4-4 | mc-agent(trait) |

**W2/W3/W4 启动条件**：W1 的 Agent trait 编译通过

### 批次 6（Day 18-22）：编排与递归层 — 2 窗口并行

| 窗口 | 任务 | Crate | 开发文档 | 依赖 |
|------|------|-------|----------|------|
| W1 | P5-1 mc-recursive | `crates/mc-recursive/` | part5 §P5-1 | mc-core, mc-context, mc-agent |
| W2 | P5-2 mc-coordinator | `crates/mc-coordinator/` | part5 §P5-2 | mc-agent, mc-recursive, mc-communication |

**W2 启动条件**：W1 的 `mc-recursive` 编译通过

### 批次 7（Day 20-24）：高级模式层 — 2 窗口并行

| 窗口 | 任务 | Crate | 开发文档 | 依赖 |
|------|------|-------|----------|------|
| W1 | P6-1 mc-daemon | `crates/mc-daemon/` | part5 §P6-1 | mc-coordinator |
| W2 | P6-2 mc-tui | `crates/mc-tui/` | part5 §P6-2 | mc-coordinator |

### 批次 8（Day 23-26）：集成与入口 — 2 窗口并行

| 窗口 | 任务 | Crate | 开发文档 | 依赖 |
|------|------|-------|----------|------|
| W1 | P7-1 mc-cli | `crates/mc-cli/` | part5 §P7-1 | mc-tui, mc-daemon |
| W2 | P7-2 端到端测试 | `tests/e2e/` | part5 §P7-2 | 全部 |

---

## 3. 文件命名规范

每个 crate 的文件放置规则（参考 25-代码目录与文件命名设计.md）：

```
crates/{crate-name}/
├── Cargo.toml              # 依赖声明
└── src/
    ├── lib.rs               # pub mod 声明
    ├── error.rs             # 错误类型（thiserror）
    ├── types.rs             # 核心结构体和枚举
    ├── trait_def.rs         # trait 定义（如果独立）
    ├── impl_core.rs         # 核心实现
    └── {feature}/           # 功能模块目录
        ├── mod.rs
        └── *.rs
```

**命名规则**：
- 文件名：`snake_case.rs`
- 结构体：`PascalCase`
- 枚举：`PascalCase`，变体 `PascalCase`
- 函数/方法：`snake_case`
- 常量：`SCREAMING_SNAKE_CASE`
- 模块：`snake_case`

---

## 4. Git 工作流

### 分支策略

```
main                    # 稳定分支
├── feat/mc-core         # P1-1
├── feat/mc-communication # P1-2
├── feat/mc-config       # P1-3
├── feat/mc-llm          # P2-1
├── feat/mc-prompt       # P2-2
├── feat/mc-sandbox      # P2-3
├── feat/mc-tool         # P2-4
├── feat/mc-context      # P3-1
├── feat/mc-memory       # P3-2
├── feat/mc-agent        # P4-1~P4-4
├── feat/mc-recursive    # P5-1
├── feat/mc-coordinator  # P5-2
├── feat/mc-daemon       # P6-1
├── feat/mc-tui          # P6-2
└── feat/mc-cli          # P7-1
```

### Commit 规范

```
feat({scope}): {description}

# 示例
feat(core): implement AgentType enum with 10 variants
feat(llm): add OpenAI compatible provider with streaming support
fix(sandbox): resolve TOCTOU vulnerability in file read
test(coordinator): add integration tests for routing decisions
refactor(comm): simplify three-level message system
docs(prompt): add PromptLayerManager usage examples
chore: update dependencies
```

### PR 合并检查清单

- [ ] `cargo test --workspace` 全部通过
- [ ] `cargo clippy --workspace -- -D warnings` 无警告
- [ ] `cargo fmt --all -- --check` 格式正确
- [ ] 新增 pub 类型有文档注释
- [ ] 新增功能有对应测试
- [ ] 不破坏现有 API（或明确标注 breaking change）

---

## 5. 开发文档索引

| 文件 | 内容 | 行数 |
|------|------|------|
| `MoreCode-开发需求文档-part1.md` | 开发顺序 + P0 + P1 | 2,632 |
| `MoreCode-开发需求文档-part2.md` | P2 能力支撑层 | 6,262 |
| `MoreCode-开发需求文档-part3.md` | P3 上下文与记忆层 | 3,513 |
| `MoreCode-开发需求文档-part4.md` | P4 Agent 实现层 | 4,525 |
| `MoreCode-开发需求文档-part5.md` | P5/P6/P7 编排+高级+集成 | 3,643 |
| **总计** | | **20,575** |

每个 Part 的每个模块包含：模块概述 → 架构文档引用 → 大模型开发提示词 → 核心类型定义 → 功能需求清单 → 接口契约 → 测试要点。

---

## 6. 架构设计文档索引

开发时需要参考的原始架构文档：

| 文件 | 核心内容 |
|------|----------|
| `00-MoreCode-agent开发选型-总刚.md` | 技术选型决策 |
| `01-架构总览.md` | 架构图、设计原则、实时反馈层 |
| `02-Coordinator.md` | 协调器、路由、通信优化 |
| `03-认知层Agent.md` | Explorer/ImpactAnalyzer/Planner |
| `04-执行层Agent.md` | Coder/Reviewer/Tester + 预飞检查 |
| `05-专项能力Agent.md` | Research/DocWriter/Debugger |
| `06-平台与环境检测.md` | 平台检测、Shell 配置 |
| `07-路由决策机制.md` | 路由规则 |
| `08-Git并发控制.md` | Git 操作安全 |
| `09-上下文管理与通信.md` | 消息分级、上下文池 |
| `11-能力矩阵与代码实现.md` | 核心类型定义（权威） |
| `12-上下文压缩策略.md` | 四层压缩 |
| `13-权限与沙箱安全.md` | Guardian 沙箱 |
| `14-LLM-Provider与Token管理.md` | LLM 抽象层 |
| `15-Prompt缓存与模板管理.md` | Prompt 管理 |
| `16-可观测性与Hook系统.md` | Hook、Span、隐私 |
| `17-递归编排模式.md` | Map-Filter-Reduce |
| `18-项目记忆系统.md` | 记忆管理器 |
| `20-Daemon模式.md` | 7×24 运行 |
| `22-中断与取消机制.md` | 信号处理、超时 |
| `23-记忆系统增强(Letta式).md` | 四层记忆 |
| `24-Agent系统提示词定义.md` | 系统提示词模板 |
| `25-代码目录与文件命名设计.md` | 目录结构（权威） |
| `26-测试体系设计.md` | 测试策略 |
| `28-CLI颜色设计.md` | 颜色体系 |
| `29-用户偏好自动记录学习.md` | 用户偏好 |
