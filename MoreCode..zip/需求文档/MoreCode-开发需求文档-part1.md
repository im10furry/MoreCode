# MoreCode Agent — 开发需求文档 Part 1

> **版本**：v1.0
> **日期**：2026-04-17
> **范围**：开发顺序 + P0 项目基础设施 + P1 核心基础层（mc-core、mc-communication、mc-config）
> **定位**：基于 Rust + Ratatui 构建的多 Agent 编码助手系统，Actor 并发模型 + CSP Channel 通信

---

## 目录

- [第一部分：开发顺序](#第一部分开发顺序)
  - [1.1 依赖关系图](#11-依赖关系图)
  - [1.2 开发阶段总览表](#12-开发阶段总览表)
  - [1.3 详细开发计划](#13-详细开发计划)
  - [1.4 里程碑定义](#14-里程碑定义)
- [第二部分：P0 项目基础设施](#第二部分p0-项目基础设施)
  - [P0-1 Cargo Workspace 初始化](#p0-1-cargo-workspace-初始化)
  - [P0-2 CI 基础配置](#p0-2-ci-基础配置)
- [第三部分：P1 核心基础层](#第三部分p1-核心基础层)
  - [P1-1 mc-core 核心类型与 Trait](#p1-1-mc-core-核心类型与-trait)
  - [P1-2 mc-communication 通信系统](#p1-2-mc-communication-通信系统)
  - [P1-3 mc-config 多级配置管理](#p1-3-mc-config-多级配置管理)

---

# 第一部分：开发顺序

## 1.1 依赖关系图

```
                         mc-cli (bin)
                        /        \
                   mc-tui      mc-daemon
                      |           |
                   mc-coordinator (编排中枢)
                  /    |    \      \
             mc-agent  mc-recursive  mc-communication
               |           |              |
            mc-llm    mc-context      mc-core
               |           |
            mc-prompt  mc-memory
               |
            mc-tool ── mc-sandbox
               |
            mc-config ── mc-core
```

**依赖规则**：
- `mc-core` 零外部依赖（仅 serde），是所有 crate 的基础
- 禁止循环依赖：上层 crate 可依赖下层，下层不可反向依赖
- `mc-communication` 仅依赖 `mc-core`，不依赖任何业务 crate
- `mc-agent` 依赖 `mc-llm`、`mc-tool`、`mc-context`，不依赖 `mc-coordinator`

## 1.2 开发阶段总览表

| 阶段 | 名称 | 包含模块 | 预估工期 | 并发策略 | 核心产出 |
|------|------|----------|----------|----------|----------|
| **P0** | 项目基础设施 | Workspace、CI | 1-2 天 | 串行 | 可编译的空 crate 骨架、CI 流水线 |
| **P1** | 核心基础层 | mc-core、mc-communication、mc-config | 3-5 天 | P1-1/P1-2/P1-3 全部并发 | 核心类型定义、通信通道、配置加载 |
| **P2** | 能力支撑层 | mc-llm、mc-prompt、mc-sandbox、mc-tool | 4-6 天 | P2-1/P2-2/P2-3 并发；P2-4 依赖 P2-1 | LLM 调用、Prompt 模板、沙箱、工具注册 |
| **P3** | 上下文与记忆层 | mc-context、mc-memory | 5-7 天 | P3-1 和 P3-2 并发 | 上下文压缩、项目记忆 |
| **P4** | Agent 实现层 | mc-agent（10 个 Agent） | 5-7 天 | P4-1 到 P4-5 全部并发 | 10 个 Agent 完整实现 |
| **P5** | 编排与递归层 | mc-coordinator、mc-recursive | 3-4 天 | P5-1 和 P5-2 并发 | Coordinator 六步管道、递归编排 |
| **P6** | 高级模式层 | mc-daemon、mc-tui | 3-4 天 | P6-1 和 P6-2 并发 | Daemon 模式、TUI 界面 |
| **P7** | 集成与入口 | mc-cli、端到端测试 | 2-3 天 | P7-1 和 P7-2 并发 | CLI 入口、E2E 测试 |
| **总计** | | | **26-38 天** | | |

## 1.3 详细开发计划

### P0：项目基础设施（1-2 天）

| 任务编号 | 描述 | 依赖 | 预估工期 | 并发标注 |
|----------|------|------|----------|----------|
| P0-1 | Cargo Workspace 初始化：所有 crate 的 Cargo.toml、rust-toolchain.toml、clippy.toml、.gitignore | 无 | 0.5 天 | 串行（首个任务） |
| P0-2 | CI 基础配置：GitHub Actions workflow（cargo test / clippy / fmt） | P0-1 | 0.5 天 | 串行 |

### P1：核心基础层（3-5 天）

| 任务编号 | 描述 | 依赖 | 预估工期 | 并发标注 |
|----------|------|------|----------|----------|
| P1-1 | mc-core：核心类型定义（AgentType、TaskIntent、CoordinatorPhase、ProjectContext 等）、错误类型、ID/时间工具、SemanticColor | P0 | 2 天 | 与 P1-2/P1-3 并发 |
| P1-2 | mc-communication：三级消息（ControlMessage/StateMessage/BroadcastEvent）、CommunicationChannels、ChannelGroup、审批通道、背压监控 | P0 | 1.5 天 | 与 P1-1/P1-3 并发 |
| P1-3 | mc-config：多级配置加载（全局/项目/环境变量）、配置段定义、合并策略、验证、热重载 | P0 | 1.5 天 | 与 P1-1/P1-2 并发 |

### P2：能力支撑层（4-6 天）

| 任务编号 | 描述 | 依赖 | 预估工期 | 并发标注 |
|----------|------|------|----------|----------|
| P2-1 | mc-llm：LlmProvider trait、OpenAI Compatible Provider、Token 计数、成本追踪 | P1-1, P1-3 | 2 天 | 与 P2-2/P2-3 并发 |
| P2-2 | mc-prompt：Prompt 模板加载、变量替换、版本追踪、文件监听 | P1-1, P1-3 | 1.5 天 | 与 P2-1/P2-3 并发 |
| P2-3 | mc-sandbox：Guardian 白名单、路径限制、Landlock/Seccomp 可选 | P1-1 | 1.5 天 | 与 P2-1/P2-2 并发 |
| P2-4 | mc-tool：Tool trait、工具注册表、内置工具（file_read/write/search/terminal/git） | P2-1, P2-3 | 2 天 | 依赖 P2-1 和 P2-3 |

### P3：上下文与记忆层（5-7 天）

| 任务编号 | 描述 | 依赖 | 预估工期 | 并发标注 |
|----------|------|------|----------|----------|
| P3-1 | mc-context：分层上下文池、四层压缩策略（L1-L4）、大文件智能读取 | P1-1, P2-1 | 3 天 | 与 P3-2 并发 |
| P3-2 | mc-memory：Letta 式四层记忆（Core/Recall/Archival/Procedural）、MemoryWriteQueue | P1-1 | 3 天 | 与 P3-1 并发 |

### P4：Agent 实现层（5-7 天）

| 任务编号 | 描述 | 依赖 | 预估工期 | 并发标注 |
|----------|------|------|----------|----------|
| P4-1 | 认知层 Agent：Explorer、ImpactAnalyzer、Planner | P1-1, P1-2, P2-1, P3-1 | 2 天 | 与 P4-2/P4-3/P4-4/P4-5 并发 |
| P4-2 | 执行层 Agent：Coder、Reviewer、Tester | P1-1, P1-2, P2-1, P2-4 | 2 天 | 与 P4-1/P4-3/P4-4/P4-5 并发 |
| P4-3 | 专项 Agent：Research、DocWriter、Debugger | P1-1, P1-2, P2-1, P2-4 | 1.5 天 | 与 P4-1/P4-2/P4-4/P4-5 并发 |
| P4-4 | Agent trait 定义、AgentRegistry、AgentContext、AgentHandoff | P1-1, P1-2 | 1 天 | 与 P4-1/P4-2/P4-3/P4-5 并发 |
| P4-5 | Agent 单元测试与集成测试 | P4-1, P4-2, P4-3, P4-4 | 1.5 天 | 依赖所有 P4 子任务 |

### P5：编排与递归层（3-4 天）

| 任务编号 | 描述 | 依赖 | 预估工期 | 并发标注 |
|----------|------|------|----------|----------|
| P5-1 | mc-coordinator：六步管道、意图识别、路由决策、执行监控、结果整合 | P4-1, P4-2, P4-3, P4-4 | 2 天 | 与 P5-2 并发 |
| P5-2 | mc-recursive：Map-Filter-Reduce 递归编排、Token 预算分配、深度控制 | P4-4, P3-1 | 1.5 天 | 与 P5-1 并发 |

### P6：高级模式层（3-4 天）

| 任务编号 | 描述 | 依赖 | 预估工期 | 并发标注 |
|----------|------|------|----------|----------|
| P6-1 | mc-daemon：7x24 后台运行、graceful shutdown、健康检查、PID 管理 | P5-1, P3-2 | 2 天 | 与 P6-2 并发 |
| P6-2 | mc-tui：Ratatui 终端界面、事件处理、状态渲染、颜色主题 | P5-1, P1-1 | 2 天 | 与 P6-1 并发 |

### P7：集成与入口（2-3 天）

| 任务编号 | 描述 | 依赖 | 预估工期 | 并发标注 |
|----------|------|------|----------|----------|
| P7-1 | mc-cli：命令行参数解析、子命令路由、应用初始化 | P6-1, P6-2 | 1.5 天 | 与 P7-2 并发 |
| P7-2 | 端到端测试：简单任务、并行任务、递归任务、Daemon 生命周期 | P7-1 | 1.5 天 | 依赖 P7-1 |

## 1.4 里程碑定义

| 里程碑 | 完成标志 | 预计时间 | 验收标准 |
|--------|----------|----------|----------|
| **M0: 骨架就绪** | P0 完成 | Day 2 | `cargo build` 通过；所有 15 个 crate 可编译；CI 绿灯 |
| **M1: 核心类型可用** | P1 完成 | Day 7 | mc-core 所有类型定义完整且可序列化；mc-communication 三级消息可发送/接收；mc-config 可加载和验证配置 |
| **M2: 能力层就绪** | P2 完成 | Day 13 | 可通过 OpenAI Compatible Provider 调用 LLM；Prompt 模板可渲染；沙箱可拦截危险命令 |
| **M3: 上下文与记忆** | P3 完成 | Day 20 | 上下文压缩可在 85% 阈值触发；项目记忆可读写和失效检测 |
| **M4: Agent 全集** | P4 完成 | Day 27 | 10 个 Agent 均可通过 MockProvider 完成单 Agent 任务 |
| **M5: 编排可用** | P5 完成 | Day 31 | Coordinator 可完成 Simple/Medium/Complex 三级路由的端到端任务 |
| **M6: 高级模式** | P6 完成 | Day 35 | Daemon 模式可后台运行并处理任务；TUI 可实时展示 Agent 状态 |
| **M7: 发布就绪** | P7 完成 | Day 38 | CLI 可交互式运行；E2E 测试全部通过；可执行二进制可构建 |

---

# 第二部分：P0 项目基础设施

## P0-1 Cargo Workspace 初始化

### 模块概述

初始化 MoreCode Agent 的 Cargo Workspace，建立 15 个 crate 的骨架结构，配置统一的 Rust 工具链、Clippy 规则和代码格式化标准。这是整个项目的地基，所有后续开发均在此基础上展开。

### 架构文档引用

- [00-MoreCode-agent开发选型-总刚.md](00-MoreCode-agent开发选型-总刚.md) -- 技术选型总览
- [25-代码目录与文件命名设计.md](25-代码目录与文件命名设计.md) -- Workspace 布局（§2）、各 Crate 详细目录结构（§3）、Feature Flags（§9.1）

### 大模型开发提示词

```
## 项目背景
MoreCode Agent 是一个基于 Rust + Ratatui 构建的多 Agent 编码助手系统。
采用 Actor 并发模型 + CSP Channel 通信，包含 10 个 Agent（Coordinator、
Explorer、ImpactAnalyzer、Planner、Coder、Reviewer、Tester、Debugger、
Research、DocWriter），使用 Tokio 异步运行时。

## 任务说明
初始化 Cargo Workspace，创建 15 个 crate 的骨架结构，配置工具链和代码规范。
每个 crate 需要完整的 Cargo.toml（含正确的依赖声明和 feature flags）、
src/lib.rs（含 pub mod 导出占位）。

## 架构参考文档
- 00-MoreCode-agent开发选型-总刚.md（技术选型）
- 25-代码目录与文件命名设计.md §2（Workspace 布局）、§3（各 crate 目录结构）、§9.1（Feature Flags）

## 核心要求
1. Workspace 根 Cargo.toml 使用 resolver = "2"，统一外部依赖版本
2. mc-core 零外部依赖（仅 serde），其他 crate 按依赖关系声明
3. rust-toolchain.toml 固定 Rust 1.85（stable）
4. clippy.toml 配置严格的 lint 规则
5. .gitignore 覆盖 Rust 项目常见忽略项 + .assistant-memory/ + target/

## 依赖 crate
- serde = { version = "1.0", features = ["derive"] }
- tokio = { version = "1", features = ["full", "signal"] }
- chrono = { version = "0.4", features = ["serde"] }
- thiserror = "2"
- anyhow = "1"
- tracing = "0.1"

## 代码规范
- 文件命名：snake_case，类型名对应 snake_case.rs
- 错误类型统一 error.rs
- 所有 pub 类型必须 derive(Debug, Clone, Serialize, Deserialize)
- AgentType 等枚举额外 derive Copy, Hash, Eq, PartialEq, Display

## 测试要求
- cargo build --workspace 编译通过
- cargo clippy --workspace 无 warning
- cargo fmt --check --workspace 格式正确
```

### 核心类型定义

#### Workspace 根 Cargo.toml

```toml
[workspace]
resolver = "2"
members = [
    "crates/mc-core",
    "crates/mc-coordinator",
    "crates/mc-agent",
    "crates/mc-communication",
    "crates/mc-llm",
    "crates/mc-context",
    "crates/mc-memory",
    "crates/mc-prompt",
    "crates/mc-tool",
    "crates/mc-config",
    "crates/mc-sandbox",
    "crates/mc-recursive",
    "crates/mc-daemon",
    "crates/mc-tui",
    "crates/mc-cli",
]

[workspace.package]
version = "0.1.0"
edition = "2024"
authors = ["MoreCode Team"]
license = "MIT"
rust-version = "1.85"

[workspace.dependencies]
# 内部 crate
mc-core = { path = "crates/mc-core" }
mc-coordinator = { path = "crates/mc-coordinator" }
mc-agent = { path = "crates/mc-agent" }
mc-communication = { path = "crates/mc-communication" }
mc-llm = { path = "crates/mc-llm" }
mc-context = { path = "crates/mc-context" }
mc-memory = { path = "crates/mc-memory" }
mc-prompt = { path = "crates/mc-prompt" }
mc-tool = { path = "crates/mc-tool" }
mc-config = { path = "crates/mc-config" }
mc-sandbox = { path = "crates/mc-sandbox" }
mc-recursive = { path = "crates/mc-recursive" }
mc-daemon = { path = "crates/mc-daemon" }
mc-tui = { path = "crates/mc-tui" }

# 外部依赖（统一版本）
tokio = { version = "1", features = ["full", "signal"] }
tokio-util = { version = "0.7", features = ["rt"] }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
thiserror = "2"
anyhow = "1"
tracing = "0.1"
tracing-subscriber = { version = "0.3", features = ["env-filter", "json"] }
clap = { version = "4", features = ["derive"] }
toml = "0.8"
reqwest = { version = "0.12", features = ["json", "stream", "rustls-tls"], default-features = false }
sqlx = { version = "0.8", features = ["runtime-tokio", "sqlite"], default-features = false }
tantivy = "0.22"
notify = "6"
xxhash-rust = { version = "0.8", features = ["xxh3"] }
regex = "1"
chrono = { version = "0.4", features = ["serde"] }
uuid = { version = "1", features = ["v4", "serde"] }
ratatui = "0.25"
crossterm = "0.28"
futures = "0.3"
pin-project-lite = "0.2"
```

#### rust-toolchain.toml

```toml
[toolchain]
channel = "1.85.0"
components = ["rustfmt", "clippy", "rust-src"]
targets = [
    "x86_64-unknown-linux-gnu",
    "aarch64-unknown-linux-gnu",
    "x86_64-apple-darwin",
    "aarch64-apple-darwin",
]
profile = "minimal"
```

#### clippy.toml

```toml
# 严格 Clippy 配置
warn-on-all-wildcard-imports = true
allow-unwrap-in-tests = true
cognitive-complexity-threshold = 25
too-many-arguments-threshold = 7
type-complexity-threshold = 500
```

#### .gitignore

```gitignore
# Rust 编译产物
/target/
**/target/

# IDE
.idea/
.vscode/
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db

# 项目记忆（包含用户数据，不提交）
.assistant-memory/

# 环境配置（可能包含敏感信息）
.env
.env.local

# MoreCode 运行时
*.pid
/morecode.log
```

### 功能需求清单

| 编号 | 描述 | 输入 | 输出 | 验收标准 |
|------|------|------|------|----------|
| P0-1-01 | 创建 Workspace 根目录结构 | 无 | 目录树 | 15 个 crate 目录均存在，每个含 Cargo.toml 和 src/lib.rs |
| P0-1-02 | 配置 Workspace 根 Cargo.toml | 依赖版本列表 | Cargo.toml | `cargo metadata` 可正确解析所有 member |
| P0-1-03 | 创建各 crate 的 Cargo.toml | 依赖关系图 | 15 个 Cargo.toml | 每个 crate 仅声明其直接依赖，无多余依赖 |
| P0-1-04 | 配置 Feature Flags | 功能矩阵 | 各 crate Cargo.toml | mc-llm 支持 openai-compat/anthropic/google/mock；mc-sandbox 支持 landlock/seccomp/wasm；mc-cli 支持 tui/daemon |
| P0-1-05 | 创建 src/lib.rs 占位 | 无 | 15 个 lib.rs | 每个 lib.rs 含正确的 pub mod 声明（空模块占位） |
| P0-1-06 | 配置 rust-toolchain.toml | Rust 版本 | rust-toolchain.toml | `rustup show` 输出 1.85.0 |
| P0-1-07 | 配置 Clippy 规则 | lint 规则列表 | clippy.toml | `cargo clippy --workspace` 无 warning |
| P0-1-08 | 配置 rustfmt | 格式化规则 | rustfmt.toml | `cargo fmt --check --workspace` 通过 |
| P0-1-09 | 配置 .gitignore | 忽略规则列表 | .gitignore | target/、.assistant-memory/、*.swp 等被忽略 |
| P0-1-10 | 验证全量编译 | 无 | 编译输出 | `cargo build --workspace` 零 error 零 warning |

### 接口契约

```bash
# 编译验证
cargo build --workspace          # 退出码 0，无 warning
cargo build --workspace --all-features  # 全功能编译通过

# 代码质量
cargo clippy --workspace -- -D warnings  # 零 clippy warning
cargo fmt --check --workspace    # 格式一致

# 最小构建
cargo build -p mc-core -p mc-communication  # 核心库独立编译
```

### 测试要点

1. **编译测试**：`cargo build --workspace` 零 error
2. **依赖隔离测试**：移除任一下层 crate 后，上层 crate 编译失败（验证依赖声明正确性）
3. **Feature Flag 测试**：`cargo build -p mc-llm --no-default-features` 通过；`cargo build -p mc-llm --features anthropic` 通过
4. **Clippy 严格模式**：`cargo clippy --workspace -- -D warnings` 通过
5. **格式化检查**：`cargo fmt --check --workspace` 通过

---

## P0-2 CI 基础配置

### 模块概述

配置 GitHub Actions CI 流水线，在每次 push 和 PR 时自动执行编译、测试、Clippy 检查和格式化检查，确保代码质量。

### 架构文档引用

- [25-代码目录与文件命名设计.md](25-代码目录与文件命名设计.md) -- §9 编译与构建

### 大模型开发提示词

```
## 项目背景
MoreCode Agent 使用 Cargo Workspace 管理 15 个 crate。
需要配置 CI 流水线确保每次提交的代码质量。

## 任务说明
创建 GitHub Actions workflow 文件，包含以下 Job：
1. check: cargo fmt --check + cargo clippy
2. test: cargo test --workspace
3. build: cargo build --release

## 核心要求
1. 使用 Rust 1.85（与 rust-toolchain.toml 一致）
2. 使用 cargo-nextest 加速测试（可选）
3. 缓存 cargo registry 和 build artifacts
4. 在 push 到 main 和 PR 时触发
5. 矩阵测试：stable 和 nightly（clippy 仅 stable）

## 代码规范
- YAML 缩进 2 空格
- Job 名称使用中文描述
- 使用 actions/checkout@v4、actions/cache@v4、dtolnay/rust-toolchain@stable
```

### 功能需求清单

| 编号 | 描述 | 输入 | 输出 | 验收标准 |
|------|------|------|------|----------|
| P0-2-01 | 创建 CI workflow 文件 | 无 | .github/workflows/ci.yml | YAML 语法正确 |
| P0-2-02 | 配置格式化检查 Job | 源代码 | check 结果 | `cargo fmt --check --all` 失败时 CI 标红 |
| P0-2-03 | 配置 Clippy 检查 Job | 源代码 | lint 结果 | `cargo clippy --workspace -- -D warnings` 失败时 CI 标红 |
| P0-2-04 | 配置测试 Job | 测试代码 | 测试结果 | `cargo test --workspace` 失败时 CI 标红 |
| P0-2-05 | 配置构建 Job | 源代码 | 二进制 | `cargo build --release` 成功 |
| P0-2-06 | 配置缓存 | cargo registry | 缓存命中 | CI 运行时间 < 5 分钟（缓存命中时） |
| P0-2-07 | 配置触发条件 | git push/PR | CI 触发 | push 到 main 和 PR 均触发 |

### 测试要点

1. **YAML 语法验证**：workflow 文件可被 GitHub Actions 正确解析
2. **本地模拟**：`act -n` 可列出所有 Job（使用 act 工具本地测试）
3. **触发验证**：创建测试 PR 可触发 CI

---

# 第三部分：P1 核心基础层

## P1-1 mc-core 核心类型与 Trait

### 模块概述

`mc-core` 是整个 MoreCode Agent 系统的基础 crate，定义所有跨 crate 共享的核心类型、枚举、错误类型和工具函数。零业务逻辑，零外部依赖（serde 除外）。它是 15 个 crate 中唯一没有外部依赖的核心 crate。

### 架构文档引用

- [00-MoreCode-agent开发选型-总刚.md](00-MoreCode-agent开发选型-总刚.md) -- 技术选型总览
- [25-代码目录与文件命名设计.md](25-代码目录与文件命名设计.md) -- §3.1 mc-core 目录结构
- [11-能力矩阵与代码实现.md](11-能力矩阵与代码实现.md) -- §11.1-§11.7 核心类型定义
- [28-CLI颜色设计.md](28-CLI颜色设计.md) -- §24.4 SemanticColor 定义

### 大模型开发提示词

```
## 项目背景
MoreCode Agent 是一个基于 Rust + Tokio 构建的多 Agent 编码助手系统。
mc-core 是所有 crate 的基础，定义共享类型。零业务逻辑，零外部依赖（serde 除外）。

## 任务说明
实现 mc-core crate 的所有核心类型定义，包括：
1. 枚举类型：AgentType(10变体)、TaskIntent(8变体)、CoordinatorPhase(9变体)、
   Complexity、RiskLevel、ChangeType、ResultType、IssueSeverity、
   RiskCategory(9变体)、MemoryCategory(6变体)、MessageRole、FinishReason
2. 结构体：TaskDescription、ProjectContext（含 ProjectInfo/ProjectStructure/
   TechStack/ArchitecturePattern/DependencyGraph/CodeConventions/RiskAreas/
   ScanMetadata）、SubTask、ExecutionPlan、ParallelGroup、TaskDependency、
   CommitPoint、ContextAllocation、PlanMetadata
3. 结果类型：TaskResult、AgentExecutionReport、AgentStatus、AgentExecutionStatus
4. 工具类型：TokenUsage、ModelInfo、ToolDefinition
5. UI 类型：SemanticColor(50+变体)、Theme trait、DarkTheme
6. 错误类型：McError enum
7. 工具函数：generate_id()、generate_trace_id()、now_utc()、format_duration()
8. 常量：通道容量（CONTROL=32, STATE=64, DATA_LINK=128, BROADCAST=64, APPROVAL=10）

## 架构参考文档
- 11-能力矩阵与代码实现.md §11.1-§11.7（核心类型定义）
- 25-代码目录与文件命名设计.md §3.1（目录结构）
- 28-CLI颜色设计.md §24.4（SemanticColor 定义）

## 核心要求
1. 所有 pub 类型必须 derive(Debug, Clone, Serialize, Deserialize)
2. AgentType 等枚举额外 derive Copy, Hash, Eq, PartialEq
3. AgentType 实现 Display trait
4. McError 使用 thiserror 派生
5. ID 生成使用 uuid v4
6. 时间工具使用 chrono::Utc
7. SemanticColor 不依赖 ratatui，使用自定义 Color 枚举
8. 通道容量常量使用 pub const usize

## 依赖 crate
- serde = { version = "1.0", features = ["derive"] }
- serde_json = "1.0"
- chrono = { version = "0.4", features = ["serde"] }
- uuid = { version = "1", features = ["v4", "serde"] }
- thiserror = "2"

## 代码规范
- 文件命名：agent.rs、task.rs、message.rs、error.rs、id.rs、token.rs、time.rs、color.rs
- lib.rs 统一 pub mod 导出
- 所有枚举变体附带 doc comment
- 结构体字段附带 doc comment
- 禁止使用 unwrap()（测试代码除外）

## 测试要求
- 所有枚举的 Serialize/Deserialize 往返测试
- AgentType Display 输出正确性测试
- generate_id() 唯一性测试（1000 次无重复）
- McError 各变体的 Error::source() 链测试
- SemanticColor 变体数量 >= 50
- 通道容量常量值正确性测试
```

### 核心类型定义

#### agent.rs -- Agent 类型与状态

```rust
use serde::{Deserialize, Serialize};
use std::fmt;

/// Agent 类型枚举
///
/// 系统包含 10 个 Agent，按能力类型分为三类：
/// - 协调能力：Coordinator
/// - 认知分析能力：Explorer、ImpactAnalyzer、Planner
/// - 执行交付能力：Coder、Reviewer、Tester
/// - 专项能力：Research、DocWriter、Debugger
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum AgentType {
    /// 主协调者：意图理解、路由决策、执行监控、结果整合
    Coordinator,
    /// 项目探索者：项目结构扫描、技术栈识别、架构模式识别
    Explorer,
    /// 影响分析者：改动点识别、依赖链追踪、风险评估
    ImpactAnalyzer,
    /// 任务规划者：任务分解、依赖分析、Agent 分配、并行组划分
    Planner,
    /// 编码执行者：代码编写与修改（可并行 1~N 个实例）
    Coder,
    /// 代码审查者：安全检查、风格一致性检查（可并行 1~N 个实例）
    Reviewer,
    /// 测试生成者：测试用例生成与执行（可并行 1~N 个实例）
    Tester,
    /// 调试排错者：错误诊断与修复（支持递归）
    Debugger,
    /// 研究调查者：外部文档查阅、技术方案调研（支持递归）
    Research,
    /// 文档编写者：文档生成与更新（可异步，优先级最低）
    DocWriter,
}

impl fmt::Display for AgentType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            AgentType::Coordinator => write!(f, "Coordinator"),
            AgentType::Explorer => write!(f, "Explorer"),
            AgentType::ImpactAnalyzer => write!(f, "ImpactAnalyzer"),
            AgentType::Planner => write!(f, "Planner"),
            AgentType::Coder => write!(f, "Coder"),
            AgentType::Reviewer => write!(f, "Reviewer"),
            AgentType::Tester => write!(f, "Tester"),
            AgentType::Debugger => write!(f, "Debugger"),
            AgentType::Research => write!(f, "Research"),
            AgentType::DocWriter => write!(f, "DocWriter"),
        }
    }
}

/// Agent 执行状态
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum AgentExecutionStatus {
    /// 等待中：已创建但尚未开始执行
    Pending,
    /// 执行中：正在处理任务
    Running,
    /// 已完成：任务成功完成
    Completed,
    /// 已失败：任务执行出错
    Failed,
    /// 已取消：收到取消指令
    Cancelled,
}

/// Agent 状态快照（Coordinator 追踪用）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentStatus {
    /// Agent 类型
    pub agent_type: AgentType,
    /// 当前执行状态
    pub status: AgentExecutionStatus,
    /// 分配的任务 ID
    pub task_id: String,
    /// 已消耗的 Token 数量
    pub token_used: u32,
    /// 开始执行时间
    pub started_at: chrono::DateTime<chrono::Utc>,
    /// 递归深度（0 = 顶层 Agent）
    pub recursion_depth: u8,
}
```

#### event.rs -- Agent 执行事件

```rust
use serde::{Deserialize, Serialize};

/// Agent 执行事件（通过 EventBus 推送到 UI 层）
///
/// 权威定义来源：01-架构总览.md §1.2.1 实时反馈层
/// 用于 Coordinator → TUI 的实时状态推送，支持流式输出可视化。
#[derive(Debug, Clone, Serialize)]
pub enum AgentEvent {
    /// Agent 阶段变更
    PhaseChanged {
        agent_id: String,
        agent_type: AgentType,
        from: String,
        to: String,
    },
    /// 工具调用开始/完成
    ToolCall {
        agent_id: String,
        tool_name: String,
        status: ToolCallStatus, // Started | Completed | Failed
        duration_ms: Option<u64>,
    },
    /// 代码变更实时预览
    CodeDiff {
        agent_id: String,
        file_path: String,
        diff: String,
    },
    /// 需要用户确认
    ConfirmRequired {
        agent_id: String,
        prompt: String,
        options: Vec<String>,
    },
    /// Token 消耗更新
    TokenUsage {
        agent_id: String,
        input: u64,
        output: u64,
        cost_usd: f64,
    },
    /// LLM 流式输出（实时推送到 UI）
    LlmStreamDelta {
        agent_id: String,
        /// 流式内容片段（文本或代码）
        content: String,
        /// 是否为最后一个片段
        is_last: bool,
    },
    /// LLM 流式工具调用（实时推送到 UI）
    LlmStreamToolCall {
        agent_id: String,
        tool_name: String,
        arguments_json: String,
    },
}

/// 工具调用状态
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ToolCallStatus {
    Started,
    Completed,
    Failed,
}
```

#### task.rs -- 任务相关类型

```rust
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// 任务意图枚举
///
/// 由 Coordinator 的意图识别模块生成，用于细化任务描述和调整 Agent 行为参数。
/// 与 TaskType（静态分类，用于路由决策）的职责分工：
/// - TaskType：静态分类，值域稳定
/// - TaskIntent：动态意图，值域可扩展
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum TaskIntent {
    /// 新增功能开发
    FeatureAddition,
    /// Bug 修复
    BugFix,
    /// 代码重构
    Refactoring,
    /// 性能优化
    PerformanceOptimization,
    /// 文档更新
    Documentation,
    /// 技术调研
    Research,
    /// 项目初始化
    ProjectInit,
    /// 其他（可扩展自定义意图）
    Other(String),
}

/// 任务复杂度
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Complexity {
    /// 简单：单文件、单 Agent 可完成
    Simple,
    /// 中等：多文件、需要 Planner 规划
    Medium,
    /// 复杂：涉及架构变更、需要多 Agent 协作
    Complex,
    /// 研究：需要外部信息收集
    Research,
}

/// Coordinator 执行阶段（9 阶段管道）
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CoordinatorPhase {
    /// 阶段 1：意图识别
    IntentRecognition,
    /// 阶段 2：复杂度评估
    ComplexityAssessment,
    /// 阶段 3：Agent 选择
    AgentSelection,
    /// 阶段 4：记忆感知路由
    MemoryAwareRouting,
    /// 阶段 5：资源分配
    ResourceAllocation,
    /// 阶段 6：任务分发
    TaskDispatch,
    /// 阶段 7：监控执行
    Monitoring,
    /// 阶段 8：结果聚合
    ResultAggregation,
    /// 阶段 9：交付
    Delivery,
}

/// 变更类型
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ChangeType {
    /// 新增文件
    AddFile,
    /// 修改文件
    ModifyFile,
    /// 删除文件
    DeleteFile,
    /// 新增依赖
    AddDependency,
    /// 修改配置
    ModifyConfig,
    /// 数据库迁移
    DatabaseMigration,
}

/// 结果类型
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ResultType {
    /// 代码变更
    CodeChange,
    /// 分析报告
    AnalysisReport,
    /// 调研报告
    ResearchReport,
    /// 测试结果
    TestResult,
    /// 审查结果
    ReviewResult,
    /// 修复报告
    FixReport,
    /// 文档
    Documentation,
}

/// 问题严重程度
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum IssueSeverity {
    /// 阻塞：必须修复才能继续
    Blocker,
    /// 严重：强烈建议修复
    Critical,
    /// 警告：建议修复
    Warning,
    /// 建议：可选修复
    Suggestion,
    /// 信息：仅提示
    Info,
}

/// 风险类别（9 变体）
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum RiskCategory {
    /// 架构风险：设计缺陷或架构不匹配
    Architecture,
    /// 性能风险：性能瓶颈或资源泄漏
    Performance,
    /// 安全风险：注入、XSS、敏感信息泄露
    Security,
    /// 兼容性风险：版本不兼容或平台差异
    Compatibility,
    /// 数据风险：数据丢失或损坏
    Data,
    /// 依赖风险：外部依赖不可用或版本冲突
    Dependency,
    /// 可维护性风险：代码复杂度过高或文档缺失
    Maintainability,
    /// 测试风险：测试覆盖不足或测试不稳定
    Testing,
    /// 运维风险：部署或监控缺失
    Operations,
}

/// 记忆类别（6 变体）
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MemoryCategory {
    /// 用户偏好：用户的使用习惯和偏好设置
    UserPreference,
    /// 项目约定：项目的编码规范和架构决策
    ProjectConvention,
    /// 任务状态：当前任务的执行进度和状态
    TaskState,
    /// 错误模式：历史错误和解决方案
    ErrorPattern,
    /// 技术知识：技术栈相关的知识和最佳实践
    TechnicalKnowledge,
    /// 决策记录：重要的设计决策及其理由
    DecisionRecord,
}

/// 消息角色（LLM 对话消息）
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MessageRole {
    /// 系统消息（系统提示词）
    System,
    /// 用户消息
    User,
    /// 助手消息（LLM 回复）
    Assistant,
    /// 工具消息（工具调用结果）
    Tool,
}

/// LLM 输出结束原因
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum FinishReason {
    /// 正常完成
    Stop,
    /// 达到最大 Token 限制
    Length,
    /// 内容被安全策略过滤
    ContentFilter,
    /// 工具调用
    ToolCalls,
    /// 未知原因
    Unknown(String),
}

/// 任务描述 -- Coordinator 六步管道的核心数据结构
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskDescription {
    /// 任务 ID（UUID v4）
    pub id: String,
    /// 用户原始输入
    pub user_input: String,
    /// 识别出的任务意图
    pub intent: TaskIntent,
    /// 评估的复杂度
    pub complexity: Complexity,
    /// 受影响的文件列表
    pub affected_files: Vec<String>,
    /// 是否需要新依赖
    pub requires_new_dependency: bool,
    /// 是否涉及架构变更
    pub involves_architecture_change: bool,
    /// 是否需要外部信息调研
    pub needs_external_research: bool,
    /// 是否需要测试
    pub requires_testing: bool,
    /// 用户强制指定的 Agent（如果有）
    pub forced_agents: Option<Vec<AgentType>>,
    /// 任务约束条件
    pub constraints: Vec<String>,
    /// 创建时间
    pub created_at: DateTime<Utc>,
}

/// 项目上下文 -- Explorer 扫描输出的结构化项目知识
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectContext {
    /// 项目基本信息
    pub project_info: ProjectInfo,
    /// 项目结构
    pub structure: ProjectStructure,
    /// 技术栈信息
    pub tech_stack: TechStack,
    /// 架构模式
    pub architecture: ArchitecturePattern,
    /// 依赖关系图
    pub dependency_graph: DependencyGraph,
    /// 编码规范
    pub conventions: CodeConventions,
    /// 风险区域
    pub risk_areas: Vec<RiskArea>,
    /// 扫描元数据
    pub scan_metadata: ScanMetadata,
    /// 项目根目录路径
    pub root_path: String,
}

/// 项目基本信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectInfo {
    /// 项目名称
    pub name: String,
    /// 项目描述
    pub description: String,
    /// 版本号
    pub version: Option<String>,
    /// 主要编程语言
    pub language: String,
    /// 主要框架
    pub framework: Option<String>,
    /// 许可证
    pub license: Option<String>,
    /// 仓库地址
    pub repository_url: Option<String>,
}

/// 项目结构
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectStructure {
    /// 目录树（缩进格式）
    pub directory_tree: String,
    /// 总文件数
    pub total_files: usize,
    /// 总代码行数
    pub total_lines: usize,
    /// 入口文件列表
    pub entry_files: Vec<String>,
    /// 配置文件列表
    pub config_files: Vec<String>,
    /// 主要模块列表
    pub modules: Vec<ModuleInfo>,
}

/// 模块信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleInfo {
    /// 模块路径
    pub path: String,
    /// 模块名称
    pub name: String,
    /// 模块职责描述
    pub description: String,
    /// 导出的公共接口
    pub exports: Vec<String>,
    /// 依赖的其他模块
    pub dependencies: Vec<String>,
    /// 文件数量
    pub file_count: usize,
    /// 代码行数
    pub line_count: usize,
}

/// 技术栈信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TechStack {
    /// 主要编程语言及版本
    pub language_version: String,
    /// Rust Edition（如果是 Rust 项目）
    pub rust_edition: Option<String>,
    /// 主要框架
    pub framework: Option<String>,
    /// 数据库
    pub database: Option<String>,
    /// ORM
    pub orm: Option<String>,
    /// 认证方式
    pub auth: Option<String>,
    /// 构建工具
    pub build_tool: Option<String>,
    /// 包管理器
    pub package_manager: Option<String>,
    /// 所有依赖（名称 -> 版本）
    pub dependencies: HashMap<String, String>,
    /// 开发依赖
    pub dev_dependencies: HashMap<String, String>,
    /// 最后更新时间
    pub updated_at: DateTime<Utc>,
}

/// 架构模式
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArchitecturePattern {
    /// 识别出的架构模式名称（如 MVC、微服务、单体、六边形架构等）
    pub name: String,
    /// 架构模式描述
    pub description: String,
    /// 分层信息
    pub layers: Vec<ArchitectureLayer>,
    /// 关键设计决策
    pub design_decisions: Vec<String>,
}

/// 架构分层
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArchitectureLayer {
    /// 层名称
    pub name: String,
    /// 层职责
    pub responsibility: String,
    /// 层内模块
    pub modules: Vec<String>,
    /// 依赖的层
    pub depends_on: Vec<String>,
}

/// 依赖关系图
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyGraph {
    /// 节点列表（模块/文件路径）
    pub nodes: Vec<String>,
    /// 边列表（(from, to, 关系类型)）
    pub edges: Vec<DependencyEdge>,
    /// 循环依赖列表
    pub circular_dependencies: Vec<Vec<String>>,
}

/// 依赖边
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyEdge {
    /// 源节点
    pub from: String,
    /// 目标节点
    pub to: String,
    /// 依赖类型（imports、calls、implements、uses）
    pub relation_type: String,
    /// 权重（调用频率等）
    pub weight: Option<f32>,
}

/// 编码规范
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeConventions {
    /// 命名规范
    pub naming: NamingConvention,
    /// 错误处理模式
    pub error_handling: ErrorHandlingPattern,
    /// 测试约定
    pub testing: TestingConvention,
    /// 文档约定
    pub documentation: DocumentationConvention,
    /// 自定义规则
    pub custom_rules: Vec<String>,
}

/// 命名规范
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NamingConvention {
    /// 函数命名风格（snake_case / camelCase / PascalCase）
    pub function: String,
    /// 结构体命名风格
    pub struct_: String,
    /// 常量命名风格（SCREAMING_SNAKE_CASE）
    pub constant: String,
    /// 模块命名风格
    pub module: String,
    /// 枚举变体命名风格
    pub enum_variant: String,
    /// 类型参数命名风格
    pub type_parameter: String,
}

/// 错误处理模式
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ErrorHandlingPattern {
    /// 是否使用自定义 Error 类型
    pub custom_error_type: bool,
    /// Error 类型名称
    pub error_type_name: Option<String>,
    /// unwrap 使用策略（never / minimal / allowed_in_tests）
    pub unwrap_policy: String,
    /// 错误传播方式（question_mark / map_err / custom）
    pub propagation: String,
    /// 错误转换 crate（thiserror / anyhow / 自定义）
    pub error_crate: Option<String>,
}

/// 测试约定
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestingConvention {
    /// 测试命名模式
    pub naming_pattern: String,
    /// 测试属性（#[tokio::test] / #[test]）
    pub test_attribute: String,
    /// 测试文件位置
    pub test_file_location: String,
    /// Mock 框架
    pub mock_framework: Option<String>,
    /// 测试覆盖率要求
    pub coverage_threshold: Option<f32>,
}

/// 文档约定
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DocumentationConvention {
    /// 文档语言
    pub language: String,
    /// 文档格式
    pub format: String,
    /// 代码示例风格
    pub code_example_style: String,
    /// API 文档生成工具
    pub api_doc_tool: Option<String>,
}

/// 风险区域
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskArea {
    /// 文件路径
    pub file: String,
    /// 风险描述
    pub description: String,
    /// 风险级别
    pub level: RiskLevel,
    /// 风险类别
    pub category: RiskCategory,
    /// 历史问题记录
    pub historical_issues: Vec<String>,
    /// 最后更新时间
    pub updated_at: DateTime<Utc>,
}

/// 风险级别
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum RiskLevel {
    /// 低风险：可安全修改
    Low,
    /// 中风险：需要谨慎
    Medium,
    /// 高风险：需要详细分析和测试
    High,
    /// 关键风险：修改可能导致系统故障
    Critical,
}

/// 扫描元数据
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScanMetadata {
    /// 扫描时间
    pub scanned_at: DateTime<Utc>,
    /// 扫描的文件数量
    pub files_scanned: usize,
    /// 总代码行数
    pub total_lines: usize,
    /// 扫描耗时（毫秒）
    pub scan_duration_ms: u64,
    /// 记忆版本号
    pub memory_version: u32,
    /// 扫描工具版本
    pub scanner_version: String,
}

/// 子任务 -- Planner 输出的最小执行单元
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubTask {
    /// 子任务 ID（UUID v4）
    pub id: String,
    /// 子任务描述
    pub description: String,
    /// 目标文件列表
    pub target_files: Vec<String>,
    /// 预期输出
    pub expected_output: String,
    /// Token 预算
    pub token_budget: u32,
    /// 优先级（0 = 最高）
    pub priority: u8,
    /// 预估复杂度
    pub estimated_complexity: Complexity,
    /// 验收标准
    pub acceptance_criteria: Vec<String>,
    /// 完成状态
    pub completed: bool,
    /// 分配的 Agent 类型（由 Planner 指定）
    pub assigned_agent: AgentType,
}

/// 执行计划 -- Planner 输出的完整任务执行方案
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionPlan {
    /// 计划 ID（UUID v4）
    pub plan_id: String,
    /// 关联的任务描述
    pub task_description: String,
    /// 并行执行组
    pub parallel_groups: Vec<ParallelGroup>,
    /// 组间依赖关系（组 ID -> 依赖的组 ID 列表）
    pub group_dependencies: HashMap<String, Vec<String>>,
    /// 所有子任务（扁平列表）
    pub sub_tasks: Vec<SubTask>,
    /// 任务依赖关系
    pub dependencies: Vec<TaskDependency>,
    /// Commit Point 列表
    pub commit_points: Vec<CommitPoint>,
    /// 上下文分配方案
    pub context_allocations: Vec<ContextAllocation>,
    /// 预估总 Token 消耗
    pub total_estimated_tokens: usize,
    /// 预估总耗时（毫秒）
    pub total_estimated_duration_ms: u64,
    /// 计划元数据
    pub plan_metadata: PlanMetadata,
    /// 创建时间
    pub created_at: DateTime<Utc>,
}

/// 并行执行组
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParallelGroup {
    /// 组 ID
    pub id: String,
    /// 组名称
    pub name: String,
    /// 组内的子任务（串行执行）
    pub sub_tasks: Vec<SubTask>,
    /// 是否可以与其他组并行
    pub can_parallel: bool,
    /// 依赖的组 ID 列表
    pub depends_on: Vec<String>,
    /// 分配的 Agent 类型
    pub agent_type: AgentType,
}

/// 任务依赖关系
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskDependency {
    /// 上游任务 ID
    pub upstream_task_id: String,
    /// 下游任务 ID
    pub downstream_task_id: String,
    /// 依赖类型（strong = 必须等待，weak = 可选等待）
    pub dependency_type: DependencyType,
    /// 依赖描述
    pub description: String,
}

/// 依赖类型
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum DependencyType {
    /// 强依赖：上游必须完成后下游才能开始
    Strong,
    /// 弱依赖：上游完成后下游可获得更好的上下文
    Weak,
}

/// Commit Point -- Git 并发控制的合并点
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommitPoint {
    /// Commit Point ID
    pub id: String,
    /// Commit Point 名称
    pub name: String,
    /// 需要等待的任务 ID 列表
    pub waiting_tasks: Vec<String>,
    /// 合并到的目标分支
    pub target_branch: String,
    /// 是否已完成
    pub completed: bool,
    /// 合并时间
    pub merged_at: Option<DateTime<Utc>>,
}

/// 上下文分配方案
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContextAllocation {
    /// 子任务 ID
    pub sub_task_id: String,
    /// Agent 类型
    pub agent_type: AgentType,
    /// 分配的 Token 预算
    pub token_budget: u32,
    /// 需要注入的文件列表
    pub required_files: Vec<String>,
    /// 需要注入的项目知识子集
    pub project_knowledge_subset: Vec<String>,
    /// 上下文窗口大小限制
    pub context_window_limit: usize,
}

/// 计划元数据
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlanMetadata {
    /// 计划生成者（Agent 类型）
    pub generated_by: AgentType,
    /// 计划生成时间
    pub generated_at: DateTime<Utc>,
    /// 使用的 LLM 模型
    pub model_used: String,
    /// 计划生成耗时（毫秒）
    pub generation_duration_ms: u64,
    /// 使用的 Token 数量
    pub tokens_used: u32,
    /// 计划版本号
    pub version: u32,
}
```

#### result.rs -- 结果与报告类型

```rust
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// 任务结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskResult {
    /// 结果类型
    pub result_type: ResultType,
    /// 任务是否成功完成
    pub success: bool,
    /// 结果数据（结构化 JSON）
    pub data: serde_json::Value,
    /// 变更的文件列表
    pub changed_files: Vec<String>,
    /// 生成的内容（代码、文档等）
    pub generated_content: Option<String>,
    /// 错误信息（如果失败）
    pub error_message: Option<String>,
}

/// Agent 执行报告（交接摘要）
///
/// Agent 间通过此结构体传递上下文，遵循"摘要通信"原则。
/// 安全要求：写入前必须做 Schema 验证，过滤敏感字段。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentExecutionReport {
    /// 摘要标题
    pub title: String,
    /// 前序 Agent 的关键发现
    pub key_findings: Vec<String>,
    /// 需要后续 Agent 关注的文件列表
    pub relevant_files: Vec<String>,
    /// 前序 Agent 的建议
    pub recommendations: Vec<String>,
    /// 待处理的风险或警告
    pub warnings: Vec<String>,
    /// 前序 Agent 使用的 Token 数量
    pub token_used: u32,
    /// 交接时间戳
    pub timestamp: DateTime<Utc>,
    /// 附加的结构化数据
    pub extra: Option<serde_json::Value>,
}
```

#### token.rs -- Token 与模型类型

```rust
use serde::{Deserialize, Serialize};

/// Token 使用统计
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TokenUsage {
    /// 输入 Token 数量
    pub prompt_tokens: u32,
    /// 输出 Token 数量
    pub completion_tokens: u32,
    /// 总 Token 数量
    pub total_tokens: u32,
    /// 缓存命中的输入 Token 数量
    pub cached_tokens: u32,
    /// 估算成本（美元）
    pub estimated_cost_usd: f64,
}

impl TokenUsage {
    /// 计算总 Token 数
    pub fn total(&self) -> u32 {
        self.prompt_tokens + self.completion_tokens
    }
}

/// 模型信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelInfo {
    /// 模型 ID（如 "gpt-4o"、"claude-3-5-sonnet"）
    pub model_id: String,
    /// 模型显示名称
    pub display_name: String,
    /// Provider 名称
    pub provider_name: String,
    /// 最大上下文窗口（Token 数）
    pub max_context_tokens: u32,
    /// 最大输出 Token 数
    pub max_output_tokens: u32,
    /// 输入价格（每百万 Token，美元）
    pub input_price_per_million: f64,
    /// 输出价格（每百万 Token，美元）
    pub output_price_per_million: f64,
    /// 是否支持流式输出
    pub supports_streaming: bool,
    /// 是否支持函数调用
    pub supports_function_calling: bool,
    /// 是否支持 JSON Mode
    pub supports_json_mode: bool,
    /// 是否支持 Prompt Caching
    pub supports_prompt_caching: bool,
}

/// 工具定义（LLM Function Calling 用）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolDefinition {
    /// 工具名称
    pub name: String,
    /// 工具描述
    pub description: String,
    /// 参数 JSON Schema
    pub parameters: serde_json::Value,
    /// 是否为必需工具
    pub required: bool,
}
```

#### color.rs -- SemanticColor 与 Theme

```rust
use serde::{Deserialize, Serialize};

/// 终端颜色表示
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TerminalColor {
    /// 24-bit 真彩色
    Rgb(u8, u8, u8),
    /// 8-bit 256 色
    Indexed(u8),
    /// 4-bit 16 色
    Named(NamedColor),
}

/// 16 色命名颜色
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum NamedColor {
    Black, Red, Green, Yellow, Blue, Magenta, Cyan, White,
    DarkGray, LightRed, LightGreen, LightYellow, LightBlue,
    LightMagenta, LightCyan, LightGray,
}

/// 语义颜色枚举 -- 所有 UI 颜色通过此枚举引用
///
/// 总计 74 个变体，覆盖状态、Agent、路由、命令、语法高亮、Git、UI 组件、文本样式、背景。
/// 详见 28-CLI颜色设计.md §24.2。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum SemanticColor {
    // ── 状态颜色（6） ──
    Success, Error, Warning, Info, Tips, Debug,
    // ── Agent 颜色（10） ──
    AgentCoordinator, AgentExplorer, AgentImpact, AgentPlanner,
    AgentCoder, AgentReviewer, AgentTester, AgentResearch,
    AgentDocWriter, AgentDebugger,
    // ── 路由级别（4） ──
    RouteSimple, RouteMedium, RouteComplex, RouteResearch,
    // ── 命令与输出（6） ──
    CommandRun, CommandOutput, CommandError, CommandPath,
    CommandArg, CommandKeyword,
    // ── 语法高亮（12） ──
    SyntaxKeyword, SyntaxString, SyntaxNumber, SyntaxType,
    SyntaxComment, SyntaxFunction, SyntaxMacro, SyntaxLifetime,
    SyntaxAttribute, SyntaxVariable, SyntaxOperator, SyntaxPunctuation,
    // ── Git 相关（9） ──
    GitAdded, GitDeleted, GitModified, GitHash, GitBranch,
    GitTag, GitStaged, GitUnstaged, GitUntracked,
    // ── UI 组件（15） ──
    TitleBar, TitleText, StatusBar, StatusText, ProgressBar,
    ProgressBg, Border, BorderHighlight, Selection, Hover,
    InputField, InputCursor, ScrollBar, ScrollThumb, Separator,
    // ── 文本样式（7） ──
    TextPrimary, TextSecondary, TextMuted, TextAccent,
    TextLink, TextTag, TextUserInput,
    // ── 背景色（5） ──
    BgPrimary, BgSecondary, BgPanel, BgCode, BgHover,
}

/// 主题定义 trait
pub trait Theme: Send + Sync {
    /// 获取语义颜色对应的终端颜色
    fn color(&self, semantic: SemanticColor) -> TerminalColor;
    /// 是否支持真彩色
    fn supports_truecolor(&self) -> bool;
    /// 主题名称
    fn name(&self) -> &str;
}

/// 深色主题（默认）
///
/// 基于 28-CLI颜色设计.md §24.3.1 的颜色定义。
/// 所有颜色值遵循终端真彩色（24-bit True Color）标准。
pub struct DarkTheme;

impl Theme for DarkTheme {
    fn color(&self, semantic: SemanticColor) -> TerminalColor {
        match semantic {
            // 状态颜色
            SemanticColor::Success       => TerminalColor::Rgb(74, 222, 128),
            SemanticColor::Error         => TerminalColor::Rgb(248, 113, 113),
            SemanticColor::Warning       => TerminalColor::Rgb(251, 191, 36),
            SemanticColor::Info          => TerminalColor::Rgb(96, 165, 250),
            SemanticColor::Tips          => TerminalColor::Rgb(252, 211, 77),
            SemanticColor::Debug         => TerminalColor::Rgb(167, 139, 250),
            // Agent 颜色
            SemanticColor::AgentCoordinator => TerminalColor::Rgb(244, 114, 182),
            SemanticColor::AgentExplorer    => TerminalColor::Rgb(52, 211, 153),
            SemanticColor::AgentImpact      => TerminalColor::Rgb(251, 146, 60),
            SemanticColor::AgentPlanner     => TerminalColor::Rgb(167, 139, 250),
            SemanticColor::AgentCoder       => TerminalColor::Rgb(96, 165, 250),
            SemanticColor::AgentReviewer    => TerminalColor::Rgb(45, 212, 191),
            SemanticColor::AgentTester      => TerminalColor::Rgb(74, 222, 128),
            SemanticColor::AgentResearch    => TerminalColor::Rgb(192, 132, 252),
            SemanticColor::AgentDocWriter   => TerminalColor::Rgb(249, 168, 212),
            SemanticColor::AgentDebugger    => TerminalColor::Rgb(248, 113, 113),
            // 路由级别
            SemanticColor::RouteSimple   => TerminalColor::Rgb(74, 222, 128),
            SemanticColor::RouteMedium   => TerminalColor::Rgb(251, 191, 36),
            SemanticColor::RouteComplex  => TerminalColor::Rgb(248, 113, 113),
            SemanticColor::RouteResearch => TerminalColor::Rgb(96, 165, 250),
            // 命令与输出
            SemanticColor::CommandRun     => TerminalColor::Rgb(74, 222, 128),
            SemanticColor::CommandOutput  => TerminalColor::Rgb(147, 197, 253),
            SemanticColor::CommandError   => TerminalColor::Rgb(252, 165, 165),
            SemanticColor::CommandPath    => TerminalColor::Rgb(134, 239, 172),
            SemanticColor::CommandArg     => TerminalColor::Rgb(253, 230, 138),
            SemanticColor::CommandKeyword => TerminalColor::Rgb(196, 181, 253),
            // 语法高亮
            SemanticColor::SyntaxKeyword    => TerminalColor::Rgb(192, 132, 252),
            SemanticColor::SyntaxString     => TerminalColor::Rgb(74, 222, 128),
            SemanticColor::SyntaxNumber     => TerminalColor::Rgb(251, 191, 36),
            SemanticColor::SyntaxType       => TerminalColor::Rgb(96, 165, 250),
            SemanticColor::SyntaxComment    => TerminalColor::Rgb(107, 114, 128),
            SemanticColor::SyntaxFunction   => TerminalColor::Rgb(244, 114, 182),
            SemanticColor::SyntaxMacro      => TerminalColor::Rgb(251, 146, 60),
            SemanticColor::SyntaxLifetime   => TerminalColor::Rgb(45, 212, 191),
            SemanticColor::SyntaxAttribute  => TerminalColor::Rgb(252, 211, 77),
            SemanticColor::SyntaxVariable   => TerminalColor::Rgb(229, 231, 235),
            SemanticColor::SyntaxOperator   => TerminalColor::Rgb(249, 168, 212),
            SemanticColor::SyntaxPunctuation=> TerminalColor::Rgb(156, 163, 175),
            // Git
            SemanticColor::GitAdded    => TerminalColor::Rgb(74, 222, 128),
            SemanticColor::GitDeleted  => TerminalColor::Rgb(248, 113, 113),
            SemanticColor::GitModified => TerminalColor::Rgb(251, 191, 36),
            SemanticColor::GitHash     => TerminalColor::Rgb(252, 211, 77),
            SemanticColor::GitBranch   => TerminalColor::Rgb(192, 132, 252),
            SemanticColor::GitTag      => TerminalColor::Rgb(96, 165, 250),
            SemanticColor::GitStaged   => TerminalColor::Rgb(52, 211, 153),
            SemanticColor::GitUnstaged => TerminalColor::Rgb(251, 146, 60),
            SemanticColor::GitUntracked=> TerminalColor::Rgb(156, 163, 175),
            // UI 组件
            SemanticColor::TitleBar        => TerminalColor::Rgb(30, 41, 59),
            SemanticColor::TitleText       => TerminalColor::Rgb(241, 245, 249),
            SemanticColor::StatusBar       => TerminalColor::Rgb(30, 41, 59),
            SemanticColor::StatusText      => TerminalColor::Rgb(148, 163, 184),
            SemanticColor::ProgressBar     => TerminalColor::Rgb(59, 130, 246),
            SemanticColor::ProgressBg      => TerminalColor::Rgb(55, 65, 81),
            SemanticColor::Border          => TerminalColor::Rgb(71, 85, 105),
            SemanticColor::BorderHighlight => TerminalColor::Rgb(96, 165, 250),
            SemanticColor::Selection       => TerminalColor::Rgb(30, 58, 95),
            SemanticColor::Hover           => TerminalColor::Rgb(51, 65, 85),
            SemanticColor::InputField      => TerminalColor::Rgb(15, 23, 42),
            SemanticColor::InputCursor     => TerminalColor::Rgb(244, 114, 182),
            SemanticColor::ScrollBar       => TerminalColor::Rgb(71, 85, 105),
            SemanticColor::ScrollThumb     => TerminalColor::Rgb(148, 163, 184),
            SemanticColor::Separator       => TerminalColor::Rgb(51, 65, 85),
            // 文本样式
            SemanticColor::TextPrimary   => TerminalColor::Rgb(241, 245, 249),
            SemanticColor::TextSecondary => TerminalColor::Rgb(148, 163, 184),
            SemanticColor::TextMuted     => TerminalColor::Rgb(100, 116, 139),
            SemanticColor::TextAccent    => TerminalColor::Rgb(96, 165, 250),
            SemanticColor::TextLink      => TerminalColor::Rgb(147, 197, 253),
            SemanticColor::TextTag       => TerminalColor::Rgb(252, 211, 77),
            SemanticColor::TextUserInput => TerminalColor::Rgb(74, 222, 128),
            // 背景
            SemanticColor::BgPrimary   => TerminalColor::Rgb(15, 23, 42),
            SemanticColor::BgSecondary => TerminalColor::Rgb(30, 41, 59),
            SemanticColor::BgPanel     => TerminalColor::Rgb(30, 41, 59),
            SemanticColor::BgCode      => TerminalColor::Rgb(15, 23, 42),
            SemanticColor::BgHover     => TerminalColor::Rgb(51, 65, 85),
        }
    }

    fn supports_truecolor(&self) -> bool { true }
    fn name(&self) -> &str { "dark" }
}
```

#### error.rs -- 错误类型

```rust
use thiserror::Error;

/// MoreCode 核心错误类型
///
/// 统一所有 crate 的基础错误枚举。各 crate 可通过
/// `impl From<McError> for XxxError` 转换为自身错误类型。
#[derive(Debug, Error)]
pub enum McError {
    // ── 配置错误 ──
    #[error("配置加载失败: {path}: {reason}")]
    ConfigLoadFailed { path: String, reason: String },
    #[error("配置解析失败: {path}: {reason}")]
    ConfigParseFailed { path: String, reason: String },
    #[error("配置验证失败: {field}: {reason}")]
    ConfigValidationFailed { field: String, reason: String },
    // ── 通信错误 ──
    #[error("通道已关闭: {channel}")]
    ChannelClosed { channel: String },
    #[error("发送超时: {channel} (超时 {timeout_ms}ms)")]
    SendTimeout { channel: String, timeout_ms: u64 },
    #[error("广播订阅者落后: {subscriber} (丢失 {skipped} 条消息)")]
    BroadcastLagged { subscriber: String, skipped: u64 },
    // ── Agent 错误 ──
    #[error("Agent 未注册: {agent_type}")]
    AgentNotRegistered { agent_type: String },
    #[error("Agent 执行超时: {agent_type} (超时 {timeout_secs}s)")]
    AgentTimeout { agent_type: String, timeout_secs: u64 },
    #[error("Agent 执行失败: {agent_type}: {reason}")]
    AgentExecutionFailed { agent_type: String, reason: String },
    // ── 任务错误 ──
    #[error("任务未找到: {task_id}")]
    TaskNotFound { task_id: String },
    #[error("Token 预算超限: 已使用 {used}, 预算 {budget}")]
    TokenBudgetExceeded { used: u32, budget: u32 },
    // ── IO 错误 ──
    #[error("文件操作失败: {path}: {reason}")]
    FileOperationFailed { path: String, reason: String },
    // ── 序列化错误 ──
    #[error("JSON 处理失败: {reason}")]
    SerializationFailed { reason: String },
    // ── 外部依赖 ──
    #[error("LLM 调用失败: {provider}: {reason}")]
    LlmError { provider: String, reason: String },
    // ── 内部错误 ──
    #[error("内部错误: {message}")]
    InternalError { message: String },
}
```

#### id.rs -- ID 生成工具

```rust
use uuid::Uuid;

/// 生成唯一 ID（UUID v4，无连字符格式）
#[inline]
pub fn generate_id() -> String {
    Uuid::new_v4().simple().to_string()
}

/// 生成追踪 ID（带前缀的 UUID）
#[inline]
pub fn generate_trace_id(prefix: &str) -> String {
    format!("{}-{}", prefix, Uuid::new_v4().simple())
}
```

#### time.rs -- 时间工具

```rust
use chrono::Utc;

/// 获取当前 UTC 时间
#[inline]
pub fn now_utc() -> chrono::DateTime<chrono::Utc> {
    Utc::now()
}

/// 格式化持续时间（毫秒 -> 人类可读格式）
pub fn format_duration(duration_ms: u64) -> String {
    if duration_ms < 1000 {
        format!("{}ms", duration_ms)
    } else if duration_ms < 60_000 {
        format!("{:.1}s", duration_ms as f64 / 1000.0)
    } else if duration_ms < 3_600_000 {
        let minutes = duration_ms / 60_000;
        let seconds = (duration_ms % 60_000) / 1000;
        format!("{}m {}s", minutes, seconds)
    } else {
        let hours = duration_ms / 3_600_000;
        let minutes = (duration_ms % 3_600_000) / 60_000;
        let seconds = (duration_ms % 60_000) / 1000;
        format!("{}h {}m {}s", hours, minutes, seconds)
    }
}
```

#### constants.rs -- 通道容量常量

```rust
/// A 级：控制消息通道容量
pub const CONTROL_CHANNEL_CAPACITY: usize = 32;
/// B 级：状态消息通道容量
pub const STATE_CHANNEL_CAPACITY: usize = 64;
/// C 级：数据面消息通道容量
pub const DATA_LINK_CHANNEL_CAPACITY: usize = 128;
/// D 级：广播事件通道容量
pub const BROADCAST_CHANNEL_CAPACITY: usize = 64;
/// 审批通道容量
pub const APPROVAL_CHANNEL_CAPACITY: usize = 10;
/// 默认发送超时时间（毫秒）
pub const SEND_TIMEOUT_MS: u64 = 30_000;
/// 背压告警阈值（队列使用率百分比）
pub const BACKPRESSURE_ALERT_THRESHOLD: f64 = 0.8;
```

#### lib.rs -- 模块导出

```rust
//! mc-core -- MoreCode Agent 核心类型与 Trait
//!
//! 零业务逻辑，零外部依赖（serde 除外）。
//! 定义所有跨 crate 共享的基础类型、枚举、错误类型和工具函数。

pub mod agent;
pub mod task;
pub mod result;
pub mod token;
pub mod color;
pub mod error;
pub mod id;
pub mod time;
pub mod constants;

// 重新导出常用类型
pub use agent::{AgentExecutionStatus, AgentStatus, AgentType};
pub use task::*;
pub use result::{AgentExecutionReport, TaskResult};
pub use token::{ModelInfo, TokenUsage, ToolDefinition};
pub use color::{DarkTheme, NamedColor, SemanticColor, TerminalColor, Theme};
pub use error::McError;
pub use id::{generate_id, generate_trace_id};
pub use time::{format_duration, now_utc};
pub use constants::*;
```

#### complexity.rs -- 复杂度评估与路由配置

```rust
/// 复杂度评估配置（可从配置文件加载，支持运行时调整）
/// 权威定义，mc-coordinator 和 mc-config 引用此类型
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComplexityConfig {
    /// LLM 预判复杂度的基础分
    pub llm_complexity_weights: HashMap<Complexity, i32>,
    /// 文件数量分档及对应分数
    pub file_count_tiers: Vec<(usize, usize, i32)>,
    /// 任务类型权重
    pub task_type_weights: HashMap<String, i32>,
    /// 需要项目上下文的加分
    pub needs_context_bonus: i32,
    /// 每个额外技术领域的加分
    pub domain_bonus: i32,
    /// 项目规模分档及对应分数
    pub project_size_tiers: Vec<(usize, usize, i32)>,
    /// 路由阈值
    pub route_thresholds: RouteThresholds,
    /// LLM 预判权重倍率
    pub llm_weight_multiplier: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteThresholds {
    pub simple_max: i32,
    pub medium_max: i32,
}

/// Agent 间交接数据格式选择
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum HandoffFormat {
    /// 结构化 JSON（零 LLM 调用）
    Structured,
    /// 压缩摘要（LLM 生成 ≤200 tokens）
    CompressedSummary,
    /// 直接注入（不生成摘要）
    DirectInjection,
}

/// 整合过程中的中间产物
#[derive(Debug, Clone)]
pub struct IntegrationContext {
    pub project_context: Option<ProjectContext>,
    pub impact_report: Option<ImpactReport>,
    pub research_report: Option<serde_json::Value>,
}
```

#### evaluator.rs -- 复杂度评估器

```rust
use std::collections::HashMap;
use std::path::Path;

/// 复杂度评估器（使用 ComplexityConfig 进行评估）
///
/// 权威定义来源：02-Coordinator.md §复杂度评估
/// 支持从配置文件加载和基于历史数据的自动校准。
pub struct ComplexityEvaluator {
    config: ComplexityConfig,
    calibration_history: Vec<CalibrationRecord>,
}

/// 校准历史记录
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalibrationRecord {
    pub evaluated_score: i32,
    pub actual_needed_more_agents: bool,
    pub actual_tokens_used: u64,
    pub factors: ComplexityFactors,
}

/// 复杂度评估因子
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComplexityFactors {
    pub task_type: String,
    pub file_count: usize,
    pub domain_count: usize,
    pub needs_context: bool,
}

impl ComplexityEvaluator {
    pub fn new(config: ComplexityConfig) -> Self {
        Self {
            config,
            calibration_history: Vec::new(),
        }
    }

    /// 从配置文件加载（支持 TOML/YAML/JSON）
    pub fn from_file(path: &Path) -> Result<Self, CoordinatorError> {
        let content = tokio::fs::read_to_string(path)
            .map_err(|e| CoordinatorError::ConfigLoadFailed(path.to_path_buf(), e.to_string()))?;
        let config: ComplexityConfig = serde_json::from_str(&content)
            .map_err(|e| CoordinatorError::ConfigParseFailed(path.to_path_buf(), e.to_string()))?;
        Ok(Self::new(config))
    }

    /// 基于历史数据校准配置（需至少 20 条记录）
    pub fn calibrate_from_history(&mut self) -> Option<ComplexityConfig> {
        if self.calibration_history.len() < 20 {
            tracing::info!(
                records = self.calibration_history.len(),
                "校准记录不足 20 条，跳过自动校准"
            );
            return None;
        }

        let mut adjusted = self.config.clone();

        // 按任务类型统计低估/高估次数
        let mut type_adjustments: HashMap<String, i32> = HashMap::new();
        for record in &self.calibration_history {
            if record.actual_needed_more_agents {
                let delta = 3i32.min(50 - record.evaluated_score);
                *type_adjustments.entry(record.factors.task_type.clone())
                    .or_insert(0) += delta;
            } else if record.evaluated_score > 30 && record.actual_tokens_used < 5000 {
                let delta = -3i32.max(-(record.evaluated_score - 10));
                *type_adjustments.entry(record.factors.task_type.clone())
                    .or_insert(0) += delta;
            }
        }

        // 应用调整（限制单次调整幅度 +/-10）
        for (type_key, delta) in &type_adjustments {
            let clamped = delta.clamp(-10, 10);
            if let Some(weight) = adjusted.task_type_weights.get_mut(type_key) {
                *weight = (*weight + clamped).max(1);
            }
        }

        // 调整路由阈值：基于实际分布的 33/66 百分位数
        let mut scores: Vec<i32> = self.calibration_history.iter()
            .map(|r| r.evaluated_score)
            .collect();
        scores.sort();
        if scores.len() >= 20 {
            let p33 = scores[scores.len() / 3];
            let p66 = scores[scores.len() * 2 / 3];
            adjusted.route_thresholds.simple_max = p33;
            adjusted.route_thresholds.medium_max = p66;
        }

        tracing::info!(
            adjustments = type_adjustments.len(),
            new_simple_max = adjusted.route_thresholds.simple_max,
            new_medium_max = adjusted.route_thresholds.medium_max,
            "复杂度校准完成"
        );

        Some(adjusted)
    }

    /// 记录校准数据点
    pub fn record_calibration(&mut self, record: CalibrationRecord) {
        self.calibration_history.push(record);
        // 保留最近 200 条记录
        if self.calibration_history.len() > 200 {
            self.calibration_history.drain(..self.calibration_history.len() - 200);
        }
    }
}
```

### 功能需求清单

| 编号 | 描述 | 输入 | 输出 | 验收标准 |
|------|------|------|------|----------|
| P1-1-01 | AgentType 枚举定义 | 无 | AgentType enum | 10 个变体，derive Copy/Clone/Hash/Eq/PartialEq/Serialize/Deserialize/Display |
| P1-1-02 | TaskIntent 枚举定义 | 无 | TaskIntent enum | 8 个变体（含 Other(String)） |
| P1-1-03 | CoordinatorPhase 枚举定义 | 无 | CoordinatorPhase enum | 9 个变体，对应六步管道各阶段 |
| P1-1-04 | Complexity 枚举定义 | 无 | Complexity enum | 4 个变体：Simple/Medium/Complex/Research |
| P1-1-05 | RiskLevel 枚举定义 | 无 | RiskLevel enum | 4 个变体：Low/Medium/High/Critical |
| P1-1-06 | ChangeType 枚举定义 | 无 | ChangeType enum | 6 个变体 |
| P1-1-07 | ResultType 枚举定义 | 无 | ResultType enum | 7 个变体 |
| P1-1-08 | IssueSeverity 枚举定义 | 无 | IssueSeverity enum | 5 个变体 |
| P1-1-09 | RiskCategory 枚举定义 | 无 | RiskCategory enum | 9 个变体 |
| P1-1-10 | MemoryCategory 枚举定义 | 无 | MemoryCategory enum | 6 个变体 |
| P1-1-11 | MessageRole 枚举定义 | 无 | MessageRole enum | 4 个变体 |
| P1-1-12 | FinishReason 枚举定义 | 无 | FinishReason enum | 5 个变体 |
| P1-1-13 | TaskDescription 结构体 | 任务参数 | TaskDescription | 12 个字段完整 |
| P1-1-14 | ProjectContext 结构体 | Explorer 扫描结果 | ProjectContext | 含 9 个子结构 |
| P1-1-15 | SubTask 结构体 | Planner 输出 | SubTask | 11 个字段完整 |
| P1-1-16 | ExecutionPlan 结构体 | Planner 输出 | ExecutionPlan | 含 parallel_groups/sub_tasks/dependencies/commit_points 等 |
| P1-1-17 | TaskResult 结构体 | Agent 执行结果 | TaskResult | 含 result_type/success/data/changed_files |
| P1-1-18 | AgentExecutionReport 结构体 | Agent 交接数据 | AgentExecutionReport | 含 title/key_findings/relevant_files/recommendations/warnings |
| P1-1-19 | AgentStatus 结构体 | Agent 状态快照 | AgentStatus | 含 agent_type/status/task_id/token_used/started_at/recursion_depth |
| P1-1-19a | AgentEvent 枚举定义 | Agent 执行事件 | AgentEvent enum | 7 个变体（PhaseChanged/ToolCall/CodeDiff/ConfirmRequired/TokenUsage/LlmStreamDelta/LlmStreamToolCall） |
| P1-1-19b | ToolCallStatus 枚举定义 | 无 | ToolCallStatus enum | 3 个变体（Started/Completed/Failed） |
| P1-1-20 | TokenUsage 结构体 | Token 统计数据 | TokenUsage | 含 prompt/completion/total/cached/cost |
| P1-1-21 | ModelInfo 结构体 | 模型配置 | ModelInfo | 12 个字段完整 |
| P1-1-22 | ToolDefinition 结构体 | 工具定义 | ToolDefinition | 含 name/description/parameters/required |
| P1-1-23 | SemanticColor 枚举 | 无 | SemanticColor enum | >= 50 个变体 |
| P1-1-24 | Theme trait + DarkTheme | 语义颜色 | TerminalColor | 74 个颜色映射完整 |
| P1-1-25 | McError 错误枚举 | 错误场景 | McError | 覆盖配置/通信/Agent/任务/IO/序列化/LLM/内部错误 |
| P1-1-26 | generate_id() | 无 | String | 32 字符十六进制 UUID，1000 次无重复 |
| P1-1-27 | generate_trace_id() | 前缀字符串 | String | "{prefix}-{uuid}" 格式 |
| P1-1-28 | now_utc() | 无 | DateTime<Utc> | 返回当前 UTC 时间 |
| P1-1-29 | format_duration() | 毫秒数 | String | 四个分支正确格式化 |
| P1-1-30 | 通道容量常量 | 无 | const usize | CONTROL=32, STATE=64, DATA_LINK=128, BROADCAST=64, APPROVAL=10 |

### 接口契约

```rust
// ID 生成
pub fn generate_id() -> String;
pub fn generate_trace_id(prefix: &str) -> String;
// 时间工具
pub fn now_utc() -> chrono::DateTime<chrono::Utc>;
pub fn format_duration(duration_ms: u64) -> String;
// 主题
pub trait Theme: Send + Sync {
    fn color(&self, semantic: SemanticColor) -> TerminalColor;
    fn supports_truecolor(&self) -> bool;
    fn name(&self) -> &str;
}
// 错误转换
impl From<McError> for YourCrateError { ... }
```

### 测试要点

1. **枚举往返测试**：所有枚举的 Serialize -> Deserialize 往返一致性
2. **AgentType Display 测试**：10 个变体的 Display 输出与预期一致
3. **ID 唯一性测试**：generate_id() 1000 次调用无重复
4. **时间格式化测试**：format_duration 覆盖 <1s、1-60s、1-60m、>=1h 四个分支
5. **SemanticColor 变体计数**：assert!(SemanticColor 变体数 >= 50)
6. **DarkTheme 完整性**：所有 SemanticColor 变体在 DarkTheme 中都有映射
7. **McError Display 测试**：各变体的 error message 包含关键信息
8. **常量值测试**：assert_eq!(CONTROL_CHANNEL_CAPACITY, 32) 等
9. **结构体默认值测试**：TokenUsage::default() 各字段为零值
10. **serde_json 兼容性**：所有类型可序列化为 JSON 并反序列化回来

---

## P1-2 mc-communication 通信系统

### 模块概述

`mc-communication` 实现多 Agent 系统的三级消息通信架构。采用分级通信设计：控制平面由 Coordinator 统一路由；数据平面通过 Channel Group 在组内 Agent 之间直传；广播平面独立使用 broadcast channel，面向 UI/日志/遥测等多订阅者。

### 架构文档引用

- [09-上下文管理与通信.md](09-上下文管理与通信.md) -- §9.4 消息类型定义、§10.1-§10.3 通信架构
- [11-能力矩阵与代码实现.md](11-能力矩阵与代码实现.md) -- §11.6 Agent 消息与交接
- [25-代码目录与文件命名设计.md](25-代码目录与文件命名设计.md) -- §3.4 mc-communication 目录结构

### 大模型开发提示词

```
## 项目背景
MoreCode Agent 使用三级消息通信架构：
- A 级 ControlMessage：Coordinator -> Agent（任务分配、取消、审批、协作请求）
- B 级 StateMessage：Agent -> Coordinator + Agent 间直连（进度、完成、失败、交接、流式分块）
- C 级 BroadcastEvent：系统广播（进度快照、系统通知）

## 任务说明
实现 mc-communication crate，包含：
1. 三级消息枚举定义（ControlMessage/StateMessage/BroadcastEvent）
2. CommunicationChannels 结构（所有 channel 的创建和管理）
3. ChannelGroup（按 DAG 边在 Agent 间建立数据面直连）
4. register_agent() 返回 Receiver
5. 审批通道（ApprovalRequest/ApprovalResponse）
6. 背压监控（30s 超时、queue_depth 告警）
7. broadcast 慢订阅者 Lagged 处理

## 架构参考文档
- 09-上下文管理与通信.md §9.4（消息类型定义）
- 11-能力矩阵与代码实现.md §11.6（Agent 消息与交接）
- 25-代码目录与文件命名设计.md §3.4（目录结构）

## 核心要求
1. StateMessage 合并了原 B 级（StateMessage）和 C 级（DataPlaneMessage）
2. 通道容量使用 mc-core 中的常量
3. 所有 send 操作设置 30s 超时
4. queue_depth 超过 80% 容量时触发告警
5. broadcast 慢订阅者收到 Lagged 后记录日志并重拉最新快照
6. ChannelGroup 仅在 DAG 依赖边上建立直连

## 依赖 crate
- mc-core（核心类型、通道容量常量）
- tokio（异步运行时）
- serde / serde_json

## 测试要求
- 消息 Serialize/Deserialize 往返测试
- CommunicationChannels 创建和销毁测试
- register_agent() 返回正确的 Receiver
- ChannelGroup 数据面直连发送/接收测试
- 背压测试：发送方在队列满时正确阻塞
- broadcast Lagged 处理测试
- 审批通道端到端测试
```

### 核心类型定义

#### control/message.rs -- A 级控制消息

```rust
use mc_core::{AgentType, SubTask, AgentExecutionReport};
use serde::{Deserialize, Serialize};

/// A 级：控制消息（Coordinator -> Agent）
///
/// 必须按顺序送达，单消费者，不允许因为旁路订阅者变慢而丢失。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ControlMessage {
    /// 任务分配：Coordinator -> Agent
    TaskAssigned {
        task_id: String,
        agent_type: AgentType,
        task: SubTask,
        context: AgentExecutionReport,
        token_budget: u64,
    },
    /// 取消任务：Coordinator -> Agent
    Cancel {
        task_id: String,
        reason: String,
    },
    /// 需要审批：Agent -> Coordinator
    ApprovalRequired {
        task_id: String,
        agent_type: AgentType,
        reason: String,
        options: Vec<String>,
        recommendation: Option<String>,
    },
    /// 协作请求：Agent -> Agent（经 Coordinator 路由）
    CollaborationRequest {
        from_agent: AgentType,
        to_agent: AgentType,
        request_type: String,
        payload: serde_json::Value,
    },
}
```

#### state/message.rs -- B 级状态+数据消息

```rust
use mc_core::{AgentType, TaskResult, AgentExecutionReport};
use serde::{Deserialize, Serialize};

/// B 级：状态+数据消息（Agent -> Coordinator，以及 Agent 间直连）
///
/// 合并了原 B 级（StateMessage）和 C 级（DataPlaneMessage）。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum StateMessage {
    // ── 原状态消息 ──
    /// 执行进度报告
    Progress {
        task_id: String,
        agent_type: AgentType,
        phase: String,
        progress_percent: u8,
        message: String,
    },
    /// 任务完成（终态消息，不允许丢弃）
    TaskCompleted {
        task_id: String,
        agent_type: AgentType,
        result: TaskResult,
        handoff: AgentExecutionReport,
        token_used: u64,
    },
    /// 任务失败（终态消息，不允许丢弃）
    TaskFailed {
        task_id: String,
        agent_type: AgentType,
        error: String,
        retry_count: u8,
        can_retry: bool,
    },
    // ── 原数据面消息（已合并） ──
    /// Agent 间交接摘要
    Handoff {
        task_id: String,
        from_agent: AgentType,
        to_agent: AgentType,
        handoff: AgentExecutionReport,
    },
    /// 部分结果（Agent 间直连）
    PartialResult {
        task_id: String,
        from_agent: AgentType,
        to_agent: AgentType,
        payload: serde_json::Value,
    },
    /// 流式分块（Agent 间直连）
    StreamChunk {
        task_id: String,
        from_agent: AgentType,
        to_agent: AgentType,
        sequence: u32,
        payload: String,
        is_last: bool,
    },
}
```

#### broadcast/event.rs -- C 级广播事件

```rust
use mc_core::AgentType;
use serde::{Deserialize, Serialize};

/// C 级：广播事件（系统级通知，所有订阅者均可接收）
///
/// 一发多收，允许慢订阅者 lagged。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum BroadcastEvent {
    /// 进度快照
    ProgressSnapshot {
        task_id: String,
        agent_type: AgentType,
        progress_percent: u8,
        summary: String,
    },
    /// 系统通知
    SystemNotification {
        level: String,
        message: String,
    },
}
```

#### approval -- 审批通道类型

```rust
use serde::{Deserialize, Serialize};

/// 审批请求
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApprovalRequest {
    pub request_id: String,
    pub task_id: String,
    pub agent_type: String,
    pub reason: String,
    pub options: Vec<String>,
    pub recommendation: Option<String>,
    pub created_at: chrono::DateTime<chrono::Utc>,
    pub timeout_secs: u64,
}

/// 审批响应
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApprovalResponse {
    pub request_id: String,
    pub choice: String,
    pub approved: bool,
    pub comment: Option<String>,
    pub responded_at: chrono::DateTime<chrono::Utc>,
}
```

#### channels.rs -- 通信通道管理

```rust
use mc_core::{
    AgentType, CONTROL_CHANNEL_CAPACITY, STATE_CHANNEL_CAPACITY,
    DATA_LINK_CHANNEL_CAPACITY, BROADCAST_CHANNEL_CAPACITY,
    APPROVAL_CHANNEL_CAPACITY, SEND_TIMEOUT_MS,
};
use std::collections::HashMap;
use tokio::sync::{mpsc, broadcast};

/// 通信通道集合
pub struct CommunicationChannels {
    control_senders: HashMap<AgentType, mpsc::Sender<ControlMessage>>,
    control_receivers: HashMap<AgentType, mpsc::Receiver<ControlMessage>>,
    state_senders: HashMap<AgentType, mpsc::Sender<StateMessage>>,
    state_receivers: HashMap<AgentType, mpsc::Receiver<StateMessage>>,
    broadcast_sender: broadcast::Sender<BroadcastEvent>,
    broadcast_receiver: broadcast::Receiver<BroadcastEvent>,
    approval_sender: mpsc::Sender<ApprovalRequest>,
    approval_request_receiver: mpsc::Receiver<ApprovalRequest>,
    approval_response_sender: mpsc::Sender<ApprovalResponse>,
    approval_response_receiver: mpsc::Receiver<ApprovalResponse>,
    channel_groups: HashMap<String, ChannelGroup>,
}

impl CommunicationChannels {
    pub fn new() -> Self { /* 初始化所有通道 */ }
    pub fn register_agent(&mut self, agent_type: AgentType)
        -> (mpsc::Receiver<ControlMessage>, mpsc::Sender<StateMessage>) { /* ... */ }
    pub async fn send_control(&self, agent_type: &AgentType, message: ControlMessage)
        -> Result<(), CommunicationError> { /* 30s 超时 */ }
    pub fn take_state_receiver(&mut self, agent_type: &AgentType)
        -> Option<mpsc::Receiver<StateMessage>> { /* ... */ }
    pub fn broadcast(&self, event: BroadcastEvent) { /* 忽略慢订阅者 */ }
    pub fn subscribe_broadcast(&self) -> broadcast::Receiver<BroadcastEvent> { /* ... */ }
    pub fn create_channel_group(&mut self, group_id: &str, edges: &[(AgentType, AgentType)]) { /* ... */ }
    pub fn destroy_channel_group(&mut self, group_id: &str) { /* ... */ }
    pub fn take_approval_request_receiver(&mut self) -> Option<mpsc::Receiver<ApprovalRequest>> { /* ... */ }
    pub fn take_approval_response_receiver(&mut self) -> Option<mpsc::Receiver<ApprovalResponse>> { /* ... */ }
    pub fn approval_sender(&self) -> &mpsc::Sender<ApprovalRequest> { /* ... */ }
    pub fn approval_response_sender(&self) -> &mpsc::Sender<ApprovalResponse> { /* ... */ }
}
```

#### channel_group.rs -- Channel Group

```rust
use mc_core::AgentType;
use std::collections::HashMap;
use tokio::sync::mpsc;

/// Channel Group -- 围绕同一并行工作集建立的临时通信域
pub struct ChannelGroup {
    pub group_id: String,
    pub members: Vec<AgentType>,
    pub data_links: HashMap<(AgentType, AgentType), mpsc::Sender<StateMessage>>,
    data_receivers: HashMap<(AgentType, AgentType), mpsc::Receiver<StateMessage>>,
}

impl ChannelGroup {
    pub fn take_data_receiver(&mut self, from: AgentType, to: AgentType)
        -> Option<mpsc::Receiver<StateMessage>> { /* ... */ }
    pub async fn send_data(&self, from: AgentType, to: AgentType, message: StateMessage)
        -> Result<(), CommunicationError> { /* 30s 超时 */ }
}
```

#### error.rs -- 通信错误

```rust
use thiserror::Error;

#[derive(Debug, Error)]
pub enum CommunicationError {
    #[error("Agent 未注册: {agent_type}")]
    AgentNotRegistered { agent_type: String },
    #[error("通道已关闭: {channel}")]
    ChannelClosed { channel: String },
    #[error("发送超时: {channel} (超时 {timeout_ms}ms)")]
    SendTimeout { channel: String, timeout_ms: u64 },
    #[error("数据面直连不存在: {from} -> {to}")]
    DataLinkNotFound { from: String, to: String },
    #[error("Channel Group 不存在: {group_id}")]
    GroupNotFound { group_id: String },
    #[error("广播订阅者落后: 丢失 {skipped} 条消息")]
    BroadcastLagged { skipped: u64 },
    #[error("背压告警: {channel} 队列深度 {depth}/{capacity}")]
    BackpressureAlert { channel: String, depth: usize, capacity: usize },
}

impl From<mc_core::McError> for CommunicationError { /* ... */ }
```

### 功能需求清单

| 编号 | 描述 | 输入 | 输出 | 验收标准 |
|------|------|------|------|----------|
| P1-2-01 | ControlMessage 枚举定义 | 无 | ControlMessage | 4 个变体 |
| P1-2-02 | StateMessage 枚举定义 | 无 | StateMessage | 6 个变体（含合并的 DataPlaneMessage） |
| P1-2-03 | BroadcastEvent 枚举定义 | 无 | BroadcastEvent | 2 个变体 |
| P1-2-04 | CommunicationChannels 创建 | 无 | CommunicationChannels | new() 创建所有通道，无 panic |
| P1-2-05 | register_agent() 注册 | AgentType | (Receiver, Sender) | 为指定 Agent 创建控制通道和状态通道 |
| P1-2-06 | send_control() 发送控制消息 | AgentType + ControlMessage | Result<()> | 30s 超时 |
| P1-2-07 | take_state_receiver() 获取状态接收端 | AgentType | Option<Receiver> | 正确移出并返回 |
| P1-2-08 | broadcast() 广播事件 | BroadcastEvent | () | 忽略慢订阅者，不 panic |
| P1-2-09 | subscribe_broadcast() 订阅广播 | 无 | broadcast::Receiver | 返回新的订阅者 |
| P1-2-10 | create_channel_group() 创建组 | group_id + edges | ChannelGroup | 仅在 DAG 边上建立直连 |
| P1-2-11 | ChannelGroup.send_data() 数据面发送 | from/to + StateMessage | Result<()> | 30s 超时 |
| P1-2-12 | ApprovalRequest/Response 定义 | 无 | 结构体 | 包含完整字段 |
| P1-2-13 | 审批通道端到端 | ApprovalRequest | ApprovalResponse | 端到端传递 |
| P1-2-14 | 背压监控 | queue_depth | 告警日志 | > 80% 容量触发 warn |
| P1-2-15 | broadcast Lagged 处理 | Lagged 错误 | 日志 + 重拉 | 记录 skipped 数量 |

### 接口契约

```rust
pub fn register_agent(&mut self, agent_type: AgentType)
    -> (mpsc::Receiver<ControlMessage>, mpsc::Sender<StateMessage>);
pub async fn send_control(&self, agent_type: &AgentType, message: ControlMessage)
    -> Result<(), CommunicationError>;
pub fn broadcast(&self, event: BroadcastEvent);
pub fn create_channel_group(&mut self, group_id: &str, edges: &[(AgentType, AgentType)]);
pub async fn send_data(&self, from: AgentType, to: AgentType, message: StateMessage)
    -> Result<(), CommunicationError>;
```

### 测试要点

1. **消息序列化测试**：ControlMessage/StateMessage/BroadcastEvent 的 JSON 往返
2. **通道创建测试**：CommunicationChannels::new() 不 panic
3. **注册测试**：register_agent() 返回正确的 Receiver
4. **发送超时测试**：不消费 Receiver 时 30s 后返回超时错误
5. **背压测试**：持续发送直到队列满，验证发送方阻塞
6. **broadcast Lagged 测试**：订阅者不消费时收到 Lagged
7. **Channel Group 测试**：仅在指定边上建立通道
8. **审批通道测试**：ApprovalRequest -> ApprovalResponse 端到端
9. **错误转换测试**：McError -> CommunicationError 转换正确
10. **并发安全测试**：多线程同时注册/发送/接收不 panic

---

## P1-3 mc-config 多级配置管理

### 模块概述

`mc-config` 实现多级配置管理系统，支持全局配置（`~/.config/morecode/config.toml`）、项目配置（`.morecode/config.toml`）和环境变量覆盖三级优先级。提供 11 个配置段定义、合并策略、验证规则和热重载能力。

### 架构文档引用

- [25-代码目录与文件命名设计.md](25-代码目录与文件命名设计.md) -- §3.10 mc-config 目录结构、§4.3 配置文件目录
- [02-Coordinator.md](02-Coordinator.md) -- CoordinatorConfig 配置段

### 大模型开发提示词

```
## 项目背景
MoreCode Agent 需要多级配置管理系统，支持：
1. 全局配置：~/.config/morecode/config.toml
2. 项目配置：.morecode/config.toml（覆盖全局）
3. 环境变量覆盖：MORECODE_ 前缀（最高优先级）

## 任务说明
实现 mc-config crate，包含：
1. 11 个配置段结构体定义
2. 多级配置加载器（全局 -> 项目 -> 环境变量）
3. 配置合并策略（项目覆盖全局、环境变量覆盖文件）
4. 配置验证（必填字段、值范围、互斥约束）
5. 配置热重载（notify 文件监听）

## 核心要求
1. 所有配置段使用 serde Deserialize，支持 TOML 格式
2. 配置合并使用 Option<T> 语义
3. 环境变量映射：MORECODE_COORDINATOR_MAX_TOKEN_BUDGET -> coordinator.max_token_budget
4. 配置验证在加载后自动执行
5. 热重载使用 notify crate 监听配置文件变更

## 依赖 crate
- mc-core（错误类型、常量）
- serde / serde_json / toml
- notify（文件监听）
- tokio（异步运行时）

## 测试要求
- 各配置段的 TOML 解析测试
- 多级合并测试
- 验证失败测试
- 热重载测试
- 默认值测试
```

### 核心类型定义

#### app.rs -- 应用总配置

```rust
use serde::{Deserialize, Serialize};

/// 应用总配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    #[serde(default)]
    pub app: AppSettings,
    #[serde(default)]
    pub coordinator: CoordinatorConfig,
    #[serde(default)]
    pub agent: AgentConfig,
    #[serde(default)]
    pub provider: ProviderConfig,
    #[serde(default)]
    pub memory: MemoryConfig,
    #[serde(default)]
    pub context: ContextConfig,
    #[serde(default)]
    pub sandbox: SandboxConfig,
    #[serde(default)]
    pub recursive: RecursiveConfig,
    #[serde(default)]
    pub daemon: DaemonConfig,
    #[serde(default)]
    pub tui: TuiConfig,
    #[serde(default)]
    pub cost: CostBudgetConfig,
}

/// 应用基本信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppSettings {
    #[serde(default = "default_app_name")]
    pub name: String,
    #[serde(default)]
    pub version: Option<String>,
    #[serde(default = "default_log_level")]
    pub log_level: String,
    #[serde(default)]
    pub data_dir: Option<String>,
}

fn default_app_name() -> String { "morecode".to_string() }
fn default_log_level() -> String { "info".to_string() }
```

#### coordinator.rs -- 协调器配置

```rust
use serde::{Deserialize, Serialize};

/// 协调器配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoordinatorConfig {
    #[serde(default = "default_max_token_budget")]
    pub max_token_budget: u32,
    #[serde(default = "default_max_recursion_depth")]
    pub max_recursion_depth: u8,
    #[serde(default = "default_agent_timeout_secs")]
    pub agent_timeout_secs: u64,
    #[serde(default = "default_max_retries")]
    pub max_retries: u8,
    #[serde(default = "default_true")]
    pub memory_aware_routing: bool,
    #[serde(default = "default_true")]
    pub recursive_orchestration: bool,
    #[serde(default = "default_memory_stale_days")]
    pub memory_stale_threshold_days: i64,
    #[serde(default = "default_true")]
    pub preflight_check: bool,
    #[serde(default = "default_llm_weight")]
    pub llm_weight_multiplier: f32,
}

fn default_max_token_budget() -> u32 { 200_000 }
fn default_max_recursion_depth() -> u8 { 2 }
fn default_agent_timeout_secs() -> u64 { 300 }
fn default_max_retries() -> u8 { 3 }
fn default_true() -> bool { true }
fn default_memory_stale_days() -> i64 { 7 }
fn default_llm_weight() -> f32 { 1.0 }
```

#### agent.rs -- Agent 通用配置

```rust
use serde::{Deserialize, Serialize};

/// Agent 通用配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentConfig {
    #[serde(default = "default_model")]
    pub default_model: String,
    #[serde(default = "default_temperature")]
    pub temperature: f32,
    #[serde(default = "default_max_output_tokens")]
    pub max_output_tokens: u32,
    #[serde(default = "default_true")]
    pub streaming: bool,
    #[serde(default = "default_tool_timeout")]
    pub tool_timeout_secs: u64,
    #[serde(default = "default_true")]
    pub auto_retry: bool,
}

fn default_model() -> String { "gpt-4o".to_string() }
fn default_temperature() -> f32 { 0.7 }
fn default_max_output_tokens() -> u32 { 4096 }
fn default_tool_timeout() -> u64 { 60 }
```

#### provider.rs -- LLM Provider 配置

```rust
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// LLM Provider 配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProviderConfig {
    #[serde(default = "default_provider")]
    pub default_provider: String,
    #[serde(default)]
    pub providers: HashMap<String, ProviderEntry>,
    #[serde(default)]
    pub semantic_cache_enabled: bool,
    #[serde(default = "default_cache_threshold")]
    pub semantic_cache_threshold: f32,
    #[serde(default)]
    pub precise_token_count: bool,
}

/// 单个 Provider 配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProviderEntry {
    #[serde(default = "default_provider")]
    pub provider_type: String,
    #[serde(default)]
    pub base_url: Option<String>,
    #[serde(default)]
    pub api_key: Option<String>,
    #[serde(default)]
    pub api_key_env: Option<String>,
    #[serde(default)]
    pub default_model: Option<String>,
    #[serde(default)]
    pub headers: HashMap<String, String>,
}

fn default_provider() -> String { "openai-compat".to_string() }
fn default_cache_threshold() -> f32 { 0.90 }
```

#### memory.rs -- 记忆系统配置

```rust
use serde::{Deserialize, Serialize};

/// 记忆系统配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MemoryConfig {
    #[serde(default = "default_memory_dir")]
    pub memory_dir: String,
    #[serde(default = "default_memory_ttl_days")]
    pub ttl_days: i64,
    #[serde(default = "default_core_memory_limit")]
    pub core_memory_limit: usize,
    #[serde(default = "default_working_memory_files")]
    pub working_memory_max_files: usize,
    #[serde(default = "default_working_memory_mb")]
    pub working_memory_max_mb: usize,
    #[serde(default)]
    pub sleep_time_compute: bool,
}

fn default_memory_dir() -> String { ".assistant-memory".to_string() }
fn default_memory_ttl_days() -> i64 { 30 }
fn default_core_memory_limit() -> usize { 100 }
fn default_working_memory_files() -> usize { 100 }
fn default_working_memory_mb() -> usize { 25 }
```

#### context.rs -- 上下文管理配置

```rust
use serde::{Deserialize, Serialize};

/// 上下文管理配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContextConfig {
    #[serde(default = "default_l1_threshold")]
    pub l1_micro_compress_threshold: usize,
    #[serde(default = "default_l2_threshold")]
    pub l2_auto_compress_threshold: f32,
    #[serde(default = "default_l3_threshold")]
    pub l3_memory_compress_threshold: f32,
    #[serde(default = "default_true")]
    pub repo_map_enabled: bool,
    #[serde(default = "default_large_file_threshold")]
    pub large_file_threshold: usize,
}

fn default_l1_threshold() -> usize { 10_000 }
fn default_l2_threshold() -> f32 { 0.85 }
fn default_l3_threshold() -> f32 { 0.90 }
fn default_large_file_threshold() -> usize { 2000 }
```

#### sandbox.rs -- 沙箱配置

```rust
use serde::{Deserialize, Serialize};

/// 沙箱配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SandboxConfig {
    #[serde(default = "default_permission_mode")]
    pub permission_mode: String,
    #[serde(default)]
    pub landlock_enabled: bool,
    #[serde(default)]
    pub seccomp_enabled: bool,
    #[serde(default)]
    pub wasm_enabled: bool,
    #[serde(default)]
    pub command_whitelist: Vec<String>,
    #[serde(default)]
    pub read_only_paths: Vec<String>,
    #[serde(default)]
    pub write_paths: Vec<String>,
}

fn default_permission_mode() -> String { "default".to_string() }
```

#### recursive.rs -- 递归编排配置

```rust
use serde::{Deserialize, Serialize};

/// 递归编排配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecursiveConfig {
    #[serde(default = "default_max_sub_agents")]
    pub max_sub_agents: usize,
    #[serde(default = "default_max_depth")]
    pub max_depth: usize,
    #[serde(default = "default_max_total")]
    pub max_total_sub_agents: usize,
    #[serde(default = "default_sub_agent_timeout")]
    pub sub_agent_timeout_secs: u64,
    #[serde(default = "default_true")]
    pub enabled: bool,
}

fn default_max_sub_agents() -> usize { 5 }
fn default_max_depth() -> usize { 2 }
fn default_max_total() -> usize { 20 }
fn default_sub_agent_timeout() -> u64 { 120 }
```

#### daemon.rs -- Daemon 模式配置

```rust
use serde::{Deserialize, Serialize};

/// Daemon 模式配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DaemonConfig {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default = "default_pid_file")]
    pub pid_file: String,
    #[serde(default = "default_health_interval")]
    pub health_check_interval_secs: u64,
    #[serde(default = "default_update_interval")]
    pub auto_update_check_hours: u64,
    #[serde(default)]
    pub quiet_hours: Option<QuietHours>,
    #[serde(default)]
    pub daily_budget_usd: Option<f64>,
}

/// 安静时段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuietHours {
    pub start_hour: u8,
    pub end_hour: u8,
}

fn default_pid_file() -> String { "/tmp/morecode.pid".to_string() }
fn default_health_interval() -> u64 { 60 }
fn default_update_interval() -> u64 { 24 }
```

#### tui.rs -- TUI 界面配置

```rust
use serde::{Deserialize, Serialize};

/// TUI 界面配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TuiConfig {
    #[serde(default = "default_theme")]
    pub theme: String,
    #[serde(default)]
    pub mouse_support: bool,
    #[serde(default = "default_max_log_lines")]
    pub max_log_lines: usize,
    #[serde(default = "default_refresh_rate")]
    pub refresh_rate_ms: u64,
    #[serde(default)]
    pub custom_theme_path: Option<String>,
}

fn default_theme() -> String { "dark".to_string() }
fn default_max_log_lines() -> usize { 1000 }
fn default_refresh_rate() -> u64 { 100 }
```

#### cost.rs -- 成本预算配置

```rust
use serde::{Deserialize, Serialize};

/// 成本预算配置段
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CostBudgetConfig {
    #[serde(default)]
    pub daily_budget_usd: Option<f64>,
    #[serde(default)]
    pub weekly_budget_usd: Option<f64>,
    #[serde(default)]
    pub monthly_budget_usd: Option<f64>,
    #[serde(default)]
    pub per_task_budget_usd: Option<f64>,
    #[serde(default = "default_over_budget_action")]
    pub over_budget_action: String,
    #[serde(default = "default_cost_log")]
    pub cost_log_path: String,
}

fn default_over_budget_action() -> String { "warn".to_string() }
fn default_cost_log() -> String { ".assistant-memory/cost-log.json".to_string() }
```

#### error.rs -- 配置错误

```rust
use thiserror::Error;

/// 配置系统错误类型
#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("配置加载失败: {path}: {reason}")]
    LoadFailed { path: String, reason: String },
    #[error("配置解析失败: {path}: {reason}")]
    ParseFailed { path: String, reason: String },
    #[error("配置验证失败: {field}: {reason}")]
    ValidationFailed { field: String, reason: String },
    #[error("配置热重载失败: {reason}")]
    HotReloadFailed { reason: String },
    #[error("环境变量解析失败: {var_name}: {reason}")]
    EnvVarParseFailed { var_name: String, reason: String },
}
```

#### loader.rs -- 配置加载器

```rust
use std::path::PathBuf;
use tokio::sync::broadcast;

/// 配置变更事件
#[derive(Debug, Clone)]
pub enum ConfigChangeEvent {
    FileChanged { path: PathBuf, change_type: FileChangeType },
    EnvChanged { var_name: String },
}

#[derive(Debug, Clone)]
pub enum FileChangeType { Created, Modified, Deleted }

/// 配置加载器
pub struct ConfigLoader {
    global_config_dir: PathBuf,
    project_config_dir: PathBuf,
    config_change_tx: broadcast::Sender<ConfigChangeEvent>,
    config_change_rx: broadcast::Receiver<ConfigChangeEvent>,
    current_config: AppConfig,
}

impl ConfigLoader {
    pub fn new(global_config_dir: PathBuf, project_config_dir: PathBuf) -> Self { /* ... */ }

    /// 加载完整配置（全局 + 项目 + 环境变量）
    pub async fn load(&mut self) -> Result<AppConfig, ConfigError> {
        // 1. 加载全局配置
        let global_config = self.load_global_config().await?;
        // 2. 加载项目配置
        let project_config = self.load_project_config().await?;
        // 3. 合并：项目覆盖全局
        let mut merged = Self::merge_configs(global_config, project_config);
        // 4. 应用环境变量覆盖
        Self::apply_env_overrides(&mut merged);
        // 5. 验证
        Self::validate(&merged)?;
        self.current_config = merged.clone();
        Ok(merged)
    }

    fn load_global_config(&self) -> Result<AppConfig, ConfigError> { /* ... */ }
    fn load_project_config(&self) -> Result<AppConfig, ConfigError> { /* ... */ }
    fn merge_configs(global: AppConfig, project: AppConfig) -> AppConfig { /* ... */ }
    fn apply_env_overrides(config: &mut AppConfig) { /* ... */ }
    fn validate(config: &AppConfig) -> Result<(), ConfigError> {
        // 必填字段、值范围、互斥约束
        // 例如：max_token_budget > 0, max_recursion_depth <= 3,
        // temperature 0.0-2.0, bypass + daemon 互斥
    }

    /// 启动配置热重载
    pub async fn start_hot_reload(&self) -> Result<(), ConfigError> { /* ... */ }
    /// 订阅配置变更
    pub fn subscribe(&self) -> broadcast::Receiver<ConfigChangeEvent> { /* ... */ }
    /// 获取当前配置快照
    pub fn current(&self) -> &AppConfig { &self.current_config }
}
```

### 功能需求清单

| 编号 | 描述 | 输入 | 输出 | 验收标准 |
|------|------|------|------|----------|
| P1-3-01 | AppConfig 总配置定义 | 无 | AppConfig | 11 个配置段，均支持 serde |
| P1-3-02 | CoordinatorConfig 定义 | 无 | CoordinatorConfig | 9 个字段，含合理默认值 |
| P1-3-03 | AgentConfig 定义 | 无 | AgentConfig | 6 个字段 |
| P1-3-04 | ProviderConfig 定义 | 无 | ProviderConfig | 含 providers HashMap |
| P1-3-05 | MemoryConfig 定义 | 无 | MemoryConfig | 6 个字段 |
| P1-3-06 | ContextConfig 定义 | 无 | ContextConfig | 5 个字段 |
| P1-3-07 | SandboxConfig 定义 | 无 | SandboxConfig | 7 个字段 |
| P1-3-08 | RecursiveConfig 定义 | 无 | RecursiveConfig | 5 个字段 |
| P1-3-09 | DaemonConfig 定义 | 无 | DaemonConfig | 6 个字段，含 QuietHours |
| P1-3-10 | TuiConfig 定义 | 无 | TuiConfig | 5 个字段 |
| P1-3-11 | CostBudgetConfig 定义 | 无 | CostBudgetConfig | 6 个字段 |
| P1-3-12 | 多级配置加载 | 配置文件路径 | AppConfig | 全局 + 项目 + 环境变量三级合并 |
| P1-3-13 | 配置合并策略 | global + project | AppConfig | 项目 Some 覆盖全局 Some |
| P1-3-14 | 环境变量覆盖 | MORECODE_* 环境变量 | AppConfig | MORECODE_COORDINATOR_MAX_TOKEN_BUDGET 等映射正确 |
| P1-3-15 | 配置验证 | AppConfig | Result<()> | 必填字段、值范围、互斥约束检查 |
| P1-3-16 | 配置热重载 | 文件变更事件 | ConfigChangeEvent | notify 监听 + broadcast 通知 |
| P1-3-17 | ConfigError 定义 | 错误场景 | ConfigError | 5 个变体，使用 thiserror |

### 接口契约

```rust
// 加载配置
pub async fn load(&mut self) -> Result<AppConfig, ConfigError>;
// 热重载
pub async fn start_hot_reload(&self) -> Result<(), ConfigError>;
// 订阅变更
pub fn subscribe(&self) -> broadcast::Receiver<ConfigChangeEvent>;
// 获取当前配置
pub fn current(&self) -> &AppConfig;
```

### 测试要点

1. **TOML 解析测试**：各配置段的 TOML 字符串可正确解析
2. **默认值测试**：空 TOML 解析后所有字段有合理默认值
3. **多级合并测试**：项目配置正确覆盖全局配置
4. **环境变量测试**：MORECODE_COORDINATOR_MAX_TOKEN_BUDGET=100000 正确覆盖
5. **验证失败测试**：max_token_budget=0 返回 ValidationFailed
6. **互斥约束测试**：bypass + daemon.enabled=true 返回 ValidationFailed
7. **热重载测试**：文件变更触发 ConfigChangeEvent
8. **缺失文件测试**：全局/项目配置文件不存在时使用默认值
9. **ConfigError Display 测试**：错误消息包含关键信息
10. **serde_json 兼容性**：AppConfig 可序列化为 JSON
