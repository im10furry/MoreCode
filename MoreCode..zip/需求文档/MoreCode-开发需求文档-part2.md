# MoreCode 开发需求文档 — Part 2：P2 能力支撑层

> **文档版本**：v1.0
> **最后更新**：2026-04-17
> **模块范围**：mc-llm / mc-prompt / mc-sandbox / mc-tool
> **目标行数**：约 2500 行

---

## 目录

- [P2-1 mc-llm — LLM 提供者抽象与 Token 管理](#p2-1-mc-llm--llm-提供者抽象与-token-管理)
- [P2-2 mc-prompt — Prompt 缓存与模板管理](#p2-2-mc-prompt--prompt-缓存与模板管理)
- [P2-3 mc-sandbox — 权限与沙箱安全](#p2-3-mc-sandbox--权限与沙箱安全)
- [P2-4 mc-tool — 工具注册与执行框架](#p2-4-mc-tool--工具注册与执行框架)

---

# P2-1 mc-llm — LLM 提供者抽象与 Token 管理

## 1.1 模块概述

`mc-llm` 是 MoreCode 的核心大模型交互层，负责：

1. **统一 LLM 提供者抽象**：通过 `LlmProvider` trait 屏蔽不同 LLM 服务商（OpenAI、Anthropic、本地模型等）的差异，提供统一的 `chat` / `chat_stream` 接口。
2. **流式事件转发**：`StreamForwarder` 与 `EventBus` trait 实现流式响应的实时分发与背压控制。
3. **语义缓存**：`SemanticCacheMiddleware` 对语义相似的请求进行缓存命中，降低重复调用成本。
4. **Token 计数与成本追踪**：`estimate_text_tokens` 提供快速估算；`BudgetNode` 通过原子操作实现并发安全的预算管理。
5. **OpenAI 兼容实现**：`OpenAiProvider` 作为参考实现，支持 OpenAI Chat Completions API 的完整功能。

### 架构文档引用

| 文档 | 关联章节 |
|------|----------|
| `14-LLM-Provider与Token管理.md` | 全文 — Provider trait 设计、Token 计数策略、成本追踪、语义缓存 |
| `15-Prompt缓存与模板管理.md` | §缓存控制点、§OpenAI 缓存策略 — CacheCapability / CacheControlPoint |

---

## 1.2 大模型开发提示词

```
你是 MoreCode 项目的 mc-llm 模块开发者。请遵循以下规范：

1. 所有 LLM 交互必须通过 LlmProvider trait 进行，禁止直接调用第三方 SDK。
2. 流式响应必须使用 StreamForwarder 进行转发，禁止在 Provider 内部消费流。
3. Token 计数使用 estimate_text_tokens 函数，不依赖外部库。
4. 成本追踪使用 BudgetNode 的 compare_exchange 循环，确保并发安全。
5. 语义缓存的相似度阈值默认 0.95，可通过 SemanticCacheConfig 配置。
6. 所有公开 API 必须支持取消（通过 CancellationToken）。
7. 错误处理使用 LlmError 枚举，禁止 unwrap()。
8. OpenAI 兼容实现必须支持 cache_control 扩展字段。
```

---

## 1.3 核心类型定义

### 1.3.1 LlmProvider trait

```rust
use std::collections::HashMap;
use std::future::Future;
use std::pin::Pin;
use tokio::sync::mpsc;

/// LLM 提供者统一抽象
///
/// 所有 LLM 服务商（OpenAI、Anthropic、本地模型等）必须实现此 trait。
/// 实现者需保证线程安全（Send + Sync）。
pub trait LlmProvider: Send + Sync {
    /// 返回提供者唯一标识符（如 "openai", "anthropic", "local"）
    fn provider_id(&self) -> &str;

    /// 返回当前使用的模型信息
    fn model_info(&self) -> &ModelInfo;

    /// 同步聊天请求（非流式）
    ///
    /// # 错误
    /// - 返回 `LlmError::RateLimited` 当触发速率限制时
    /// - 返回 `LlmError::Timeout` 当请求超时时
    /// - 返回 `LlmError::ContextLengthExceeded` 当输入超过上下文窗口时
    fn chat(
        &self,
        request: ChatRequest,
    ) -> Pin<Box<dyn Future<Output = Result<ChatResponse, LlmError>> + Send + '_>>;

    /// 流式聊天请求
    ///
    /// 通过 mpsc::Receiver 返回流式事件流。
    /// 调用者可通过 CancellationToken 取消请求。
    fn chat_stream(
        &self,
        request: ChatRequest,
        cancel_token: CancellationToken,
    ) -> Pin<Box<dyn Future<Output = Result<mpsc::Receiver<StreamEvent>, LlmError>> + Send + '_>>;

    /// 返回当前提供者的缓存能力
    fn cache_capability(&self) -> CacheCapability;

    /// 列出当前提供者支持的所有模型
    fn list_models(
        &self,
    ) -> Pin<Box<dyn Future<Output = Result<Vec<ModelInfo>, LlmError>> + Send + '_>>;

    /// 取消正在进行的请求
    ///
    /// # 参数
    /// - `request_id`: 请求的唯一标识符
    fn cancel_request(&self, request_id: &str) -> Result<(), LlmError>;

    /// 估算给定文本的 Token 数量
    ///
    /// 提供快速估算，精度要求 ±10%。
    /// 对于精确计数，应使用各提供商的 tokenizer API。
    fn estimate_tokens(&self, text: &str) -> usize;
}
```

### 1.3.2 ChatRequest

```rust
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::time::Duration;

/// 聊天请求
///
/// 包含发送给 LLM 的完整请求信息。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatRequest {
    /// 对话消息列表（按时间顺序排列）
    pub messages: Vec<ChatMessage>,

    /// 请求使用的模型 ID（覆盖 Provider 默认模型）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,

    /// 采样温度（0.0 ~ 2.0）
    /// - 0.0: 确定性输出
    /// - 1.0: 默认值，平衡创造性与一致性
    /// - 2.0: 最大随机性
    #[serde(default = "default_temperature")]
    pub temperature: f32,

    /// Top-P 核采样参数（0.0 ~ 1.0）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub top_p: Option<f32>,

    /// 最大生成 Token 数
    #[serde(skip_serializing_if = "Option::is_none")]
    pub max_tokens: Option<u32>,

    /// 停止序列列表
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub stop_sequences: Vec<String>,

    /// 可用工具定义列表
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tools: Vec<ToolDefinition>,

    /// 响应格式约束（如 JSON 模式）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub response_format: Option<ResponseFormat>,

    /// 请求超时时间
    #[serde(skip_serializing_if = "Option::is_none")]
    pub timeout: Option<Duration>,

    /// 用户标识符（用于速率限制与审计）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub user_id: Option<String>,

    /// 请求级缓存控制点
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub cache_control_points: Vec<CacheControlPoint>,

    /// 自定义请求头（传递给底层 HTTP 客户端）
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub extra_headers: HashMap<String, String>,
}

fn default_temperature() -> f32 {
    1.0
}

impl Default for ChatRequest {
    fn default() -> Self {
        Self {
            messages: Vec::new(),
            model: None,
            temperature: default_temperature(),
            top_p: None,
            max_tokens: None,
            stop_sequences: Vec::new(),
            tools: Vec::new(),
            response_format: None,
            timeout: None,
            user_id: None,
            cache_control_points: Vec::new(),
            extra_headers: HashMap::new(),
        }
    }
}
```

### 1.3.3 ChatResponse

```rust
/// 聊天响应
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatResponse {
    /// 响应的唯一标识符
    pub id: String,

    /// 使用的模型 ID
    pub model: String,

    /// 响应消息
    pub message: ChatMessage,

    /// Token 使用统计
    pub usage: TokenUsage,

    /// 完成原因
    pub finish_reason: FinishReason,

    /// 响应时间（毫秒）
    pub latency_ms: u64,

    /// 提供者原始响应（用于调试）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub raw_response: Option<serde_json::Value>,
}
```

### 1.3.4 ChatMessage / MessageRole / MessageContent / ContentPart

```rust
/// 对话消息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatMessage {
    /// 消息角色
    pub role: MessageRole,

    /// 消息内容
    pub content: MessageContent,

    /// 消息名称（用于 function calling）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,

    /// 工具调用列表（assistant 角色发出）
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tool_calls: Vec<ToolCall>,

    /// 工具调用 ID（tool 角色使用）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tool_call_id: Option<String>,

    /// 缓存控制（用于 Prompt Caching）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cache_control: Option<CacheControlType>,
}

/// 消息角色
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MessageRole {
    /// 系统提示词
    System,
    /// 用户消息
    User,
    /// 助手回复
    Assistant,
    /// 工具执行结果
    Tool,
}

/// 消息内容（支持多模态）
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum MessageContent {
    /// 纯文本内容
    Text(String),
    /// 多模态内容（文本 + 图片 + 文件等）
    Parts(Vec<ContentPart>),
}

impl MessageContent {
    /// 提取纯文本内容
    pub fn to_text(&self) -> String {
        match self {
            MessageContent::Text(s) => s.clone(),
            MessageContent::Parts(parts) => parts
                .iter()
                .filter_map(|p| match p {
                    ContentPart::Text { text } => Some(text.as_str()),
                    _ => None,
                })
                .collect::<Vec<_>>()
                .join(""),
        }
    }
}

/// 内容部分（多模态）
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ContentPart {
    /// 文本部分
    Text {
        text: String,
    },
    /// 图片部分
    Image {
        /// 图片 URL 或 base64 data URI
        url: String,
        /// 图片详细程度（low / high / auto）
        #[serde(default = "default_image_detail")]
        detail: ImageDetail,
    },
    /// 文件内容
    File {
        /// 文件名
        filename: String,
        /// 文件 MIME 类型
        mime_type: String,
        /// 文件内容（base64 编码）
        data: String,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ImageDetail {
    Low,
    High,
    Auto,
}

fn default_image_detail() -> ImageDetail {
    ImageDetail::Auto
}
```

### 1.3.5 TokenUsage / ModelInfo / ToolDefinition / ResponseFormat

```rust
/// Token 使用统计
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct TokenUsage {
    /// 输入 Token 数（含缓存命中）
    pub prompt_tokens: u32,
    /// 输出 Token 数
    pub completion_tokens: u32,
    /// 缓存命中的输入 Token 数
    pub cached_tokens: u32,
    /// 总 Token 数
    pub total_tokens: u32,
}

impl TokenUsage {
    /// 计算缓存命中率（0.0 ~ 1.0）
    pub fn cache_hit_rate(&self) -> f64 {
        if self.prompt_tokens == 0 {
            0.0
        } else {
            self.cached_tokens as f64 / self.prompt_tokens as f64
        }
    }

    /// 估算成本（美元）
    pub fn estimate_cost(&self, input_price_per_1k: f64, output_price_per_1k: f64) -> f64 {
        let uncached_prompt = self.prompt_tokens.saturating_sub(self.cached_tokens);
        let input_cost = (uncached_prompt as f64 / 1000.0) * input_price_per_1k;
        let output_cost = (self.completion_tokens as f64 / 1000.0) * output_price_per_1k;
        input_cost + output_cost
    }
}

/// 模型信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelInfo {
    /// 模型 ID（如 "gpt-4o", "claude-3-5-sonnet-20241022"）
    pub id: String,

    /// 模型显示名称
    pub display_name: String,

    /// 提供者 ID
    pub provider_id: String,

    /// 最大上下文窗口（Token 数）
    pub max_context_tokens: u32,

    /// 最大输出 Token 数
    pub max_output_tokens: u32,

    /// 输入价格（每 1000 Token，美元）
    pub input_price_per_1k: f64,

    /// 输出价格（每 1000 Token，美元）
    pub output_price_per_1k: f64,

    /// 缓存输入价格（每 1000 Token，美元）
    pub cache_read_price_per_1k: f64,

    /// 缓存写入价格（每 1000 Token，美元）
    pub cache_write_price_per_1k: f64,

    /// 是否支持流式输出
    pub supports_streaming: bool,

    /// 是否支持函数调用
    pub supports_tools: bool,

    /// 是否支持视觉输入
    pub supports_vision: bool,

    /// 是否支持 JSON 模式
    pub supports_json_mode: bool,
}

/// 工具定义（传递给 LLM）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolDefinition {
    /// 工具名称
    pub name: String,

    /// 工具描述（供 LLM 理解工具用途）
    pub description: String,

    /// 工具参数 JSON Schema
    pub parameters: serde_json::Value,

    /// 是否为严格模式（参数必须完全匹配 Schema）
    #[serde(default)]
    pub strict: bool,
}

/// 工具调用
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolCall {
    /// 调用 ID
    pub id: String,

    /// 工具名称
    pub name: String,

    /// 工具参数（JSON 字符串）
    pub arguments: String,
}

/// 响应格式约束
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ResponseFormat {
    /// 文本模式（默认）
    Text,
    /// JSON 对象模式
    JsonObject,
    /// JSON Schema 模式
    JsonSchema {
        /// JSON Schema 定义
        schema: serde_json::Value,
        /// Schema 名称
        name: String,
        /// 是否严格模式
        #[serde(default)]
        strict: bool,
    },
}
```

### 1.3.6 StreamEvent / FinishReason / LlmError

```rust
/// 流式事件
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum StreamEvent {
    /// 内容增量
    Delta {
        /// 增量文本
        content: String,
        /// 当前累计 Token 数
        cumulative_tokens: Option<u32>,
    },
    /// 工具调用增量
    ToolCallDelta {
        /// 工具调用索引
        index: u32,
        /// 工具调用 ID（首次出现时提供）
        id: Option<String>,
        /// 工具名称（首次出现时提供）
        name: Option<String>,
        /// 参数增量（JSON 片段）
        arguments_delta: String,
    },
    /// 流结束
    Finish {
        /// 完成原因
        reason: FinishReason,
        /// Token 使用统计
        usage: Option<TokenUsage>,
        /// 响应 ID
        response_id: String,
    },
    /// 流式错误（流中途发生错误，用于通知调用方）
    Error(String),
}

impl StreamEvent {
    /// 判断是否为结束事件
    pub fn is_finish(&self) -> bool {
        matches!(self, StreamEvent::Finish { .. })
    }

    /// 提取内容增量文本
    pub fn as_delta_content(&self) -> Option<&str> {
        match self {
            StreamEvent::Delta { content, .. } => Some(content),
            _ => None,
        }
    }
}

/// 完成原因
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FinishReason {
    /// 正常完成
    Stop,
    /// 达到最大 Token 限制
    Length,
    /// 模型请求调用工具
    ToolCalls,
    /// 内容被安全策略过滤
    ContentFilter,
    /// 请求被取消
    Cancelled,
}

/// LLM 错误类型
#[derive(Debug, Clone, thiserror::Error)]
pub enum LlmError {
    /// API 请求失败
    #[error("API request failed: {0}")]
    ApiError(String),

    /// 认证失败
    #[error("Authentication failed for provider '{provider}': {reason}")]
    AuthenticationFailed {
        provider: String,
        reason: String,
    },

    /// 速率限制
    #[error("Rate limited by {provider}: retry after {retry_after_ms:?}ms")]
    RateLimited {
        provider: String,
        retry_after_ms: Option<u64>,
    },

    /// 请求超时
    #[error("Request timed out after {timeout_ms}ms")]
    Timeout {
        timeout_ms: u64,
    },

    /// 上下文长度超出
    #[error("Context length exceeded: {prompt_tokens} tokens > {max_tokens} limit")]
    ContextLengthExceeded {
        prompt_tokens: u32,
        max_tokens: u32,
    },

    /// 模型不可用
    #[error("Model '{model_id}' not available: {reason}")]
    ModelUnavailable {
        model_id: String,
        reason: String,
    },

    /// 请求被取消
    #[error("Request cancelled: {reason}")]
    Cancelled {
        reason: String,
    },

    #[error("Stream error: {0}")]
    StreamError(String),

    #[error("Internal error: {0}")]
    Internal(String),
}

impl LlmError {
    /// 判断是否为可重试错误
    pub fn is_retryable(&self) -> bool {
        matches!(
            self,
            LlmError::RateLimited { .. } | LlmError::Timeout { .. } | LlmError::ApiError(_)
        )
    }

    /// 获取建议的重试延迟（毫秒）
    pub fn retry_delay_ms(&self) -> Option<u64> {
        match self {
            LlmError::RateLimited { retry_after_ms, .. } => {
                Some(retry_after_ms.unwrap_or(1000))
            }
            LlmError::Timeout { timeout_ms } => Some(*timeout_ms / 2),
            LlmError::ApiError(_) => Some(1000),
            _ => None,
        }
    }
}
```

### 1.3.7 StreamForwarder / EventBus trait

```rust
use tokio::sync::mpsc;
use tokio_util::sync::CancellationToken;

/// 流式事件转发器
///
/// 负责将 Provider 的流式事件转发给多个消费者，
/// 并支持背压控制与取消。
pub struct StreamForwarder {
    /// 事件发送端（连接到 Provider 的接收端）
    sender: mpsc::Sender<StreamEvent>,
    /// 事件接收端（分发给消费者）
    receivers: Vec<mpsc::Receiver<StreamEvent>>,
    /// 取消令牌
    cancel_token: CancellationToken,
    /// 是否已结束
    finished: std::sync::atomic::AtomicBool,
}

impl StreamForwarder {
    /// 创建新的流式转发器
    ///
    /// # 参数
    /// - `buffer_size`: 事件缓冲区大小
    /// - `num_consumers`: 消费者数量
    pub fn new(buffer_size: usize, num_consumers: usize) -> Self {
        let (sender, _) = mpsc::channel(buffer_size);
        let receivers = Vec::with_capacity(num_consumers);
        Self {
            sender,
            receivers,
            cancel_token: CancellationToken::new(),
            finished: std::sync::atomic::AtomicBool::new(false),
        }
    }

    /// 注册事件回调
    ///
    /// 每收到一个事件时调用回调函数。
    /// 回调返回 false 时停止转发。
    pub fn on_event<F>(&mut self, callback: F)
    where
        F: Fn(&StreamEvent) -> bool + Send + Sync + 'static,
    {
        // 注册回调到内部事件总线
        // 回调在独立任务中执行，不阻塞转发循环
    }

    /// 将流式事件聚合为完整内容
    ///
    /// 消费所有事件直到 Finish，拼接所有 Delta 内容。
    pub async fn into_content(mut self) -> Result<(String, TokenUsage), LlmError> {
        let mut content = String::new();
        let mut final_usage = TokenUsage {
            prompt_tokens: 0,
            completion_tokens: 0,
            cached_tokens: 0,
            total_tokens: 0,
        };

        while let Some(event) = self.receivers.pop() {
            // 从最后一个接收端消费事件
            // 实际实现中应使用 select! 监听所有接收端
        }

        Ok((content, final_usage))
    }

    /// 取消流式转发
    pub fn cancel(&self) {
        self.cancel_token.cancel();
    }

    /// 判断是否已结束
    pub fn is_finished(&self) -> bool {
        self.finished.load(std::sync::atomic::Ordering::Relaxed)
    }
}

/// 事件总线 trait
///
/// 允许流式事件的发布/订阅，支持多消费者模式。
pub trait EventBus: Send + Sync {
    /// 发布事件
    fn publish(&self, event: StreamEvent);

    /// 订阅事件
    ///
    /// 返回一个 Receiver 用于接收事件。
    /// 当 EventBus 被 drop 时，所有 Receiver 将收到 None。
    fn subscribe(&self) -> mpsc::Receiver<StreamEvent>;

    /// 获取当前订阅者数量
    fn subscriber_count(&self) -> usize;
}
```

### 1.3.8 CacheCapability / CacheControlPoint / CacheControlType / OpenAiCacheStrategy

```rust
/// 缓存能力描述
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheCapability {
    /// 是否支持 Prompt Caching
    pub supports_prompt_caching: bool,

    /// 最大缓存 TTL（秒）
    pub max_cache_ttl_secs: Option<u64>,

    /// 最小缓存段大小（Token 数）
    pub min_cacheable_tokens: u32,

    /// 支持的缓存控制类型
    pub supported_control_types: Vec<CacheControlType>,

    /// 缓存策略
    pub strategy: CacheStrategy,
}

/// 缓存策略
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CacheStrategy {
    /// OpenAI 兼容缓存策略
    OpenAi(OpenAiCacheStrategy),
    /// Anthropic 兼容缓存策略
    Anthropic {
        /// 缓存断点标记
        breakpoint_marker: String,
    },
    /// 无缓存
    None,
}

/// 缓存控制点
///
/// 标记消息列表中的缓存断点位置。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheControlPoint {
    /// 消息索引（从 0 开始）
    pub message_index: usize,

    /// 缓存控制类型
    pub control_type: CacheControlType,

    /// 缓存 TTL（秒），None 表示使用默认值
    pub ttl_secs: Option<u64>,
}

/// 缓存控制类型
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CacheControlType {
    /// 缓存此点之前的内容
    CacheBreakpoint,
    /// 不缓存（ephemeral）
    Ephemeral,
}

/// OpenAI 缓存策略
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OpenAiCacheStrategy {
    /// 是否启用自动缓存检测
    pub auto_detect: bool,

    /// 前缀匹配最小长度（字符数）
    pub prefix_match_min_length: usize,

    /// 缓存预热阈值（相同前缀出现次数达到此值时触发缓存）
    pub warmup_threshold: u32,
}

impl Default for OpenAiCacheStrategy {
    fn default() -> Self {
        Self {
            auto_detect: true,
            prefix_match_min_length: 1024,
            warmup_threshold: 2,
        }
    }
}
```

### 1.3.9 OpenAI 兼容实现（OpenAiProvider）

```rust
use reqwest::Client;
use std::sync::Arc;

/// OpenAI 兼容 LLM 提供者
///
/// 支持任何兼容 OpenAI Chat Completions API 的服务
/// （包括 Azure OpenAI、vLLM、Ollama 等）。
pub struct OpenAiProvider {
    /// HTTP 客户端
    client: Client,

    /// API 基础 URL
    base_url: String,

    /// API 密钥
    api_key: Arc<str>,

    /// 默认模型信息
    model: ModelInfo,

    /// 默认请求头
    default_headers: HashMap<String, String>,

    /// 缓存能力
    cache_capability: CacheCapability,

    /// 活跃请求追踪
    active_requests: tokio::sync::RwLock<HashMap<String, CancellationToken>>,
}

impl OpenAiProvider {
    /// 创建新的 OpenAI 兼容提供者
    ///
    /// # 参数
    /// - `base_url`: API 基础 URL（如 "https://api.openai.com/v1"）
    /// - `api_key`: API 密钥
    /// - `model`: 默认模型信息
    pub fn new(
        base_url: impl Into<String>,
        api_key: impl Into<Arc<str>>,
        model: ModelInfo,
    ) -> Result<Self, LlmError> {
        let client = Client::builder()
            .timeout(std::time::Duration::from_secs(120))
            .build()
            .map_err(|e| LlmError::ApiError(format!("Failed to create HTTP client: {e}")))?;

        Ok(Self {
            client,
            base_url: base_url.into(),
            api_key: api_key.into(),
            model,
            default_headers: HashMap::new(),
            cache_capability: CacheCapability {
                supports_prompt_caching: true,
                max_cache_ttl_secs: Some(3600),
                min_cacheable_tokens: 128,
                supported_control_types: vec![CacheControlType::Ephemeral],
                strategy: CacheStrategy::OpenAi(OpenAiCacheStrategy::default()),
            },
            active_requests: tokio::sync::RwLock::new(HashMap::new()),
        })
    }

    /// 设置自定义请求头
    pub fn with_header(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.default_headers.insert(key.into(), value.into());
        self
    }

    /// 构建聊天 API 请求体
    fn build_chat_body(&self, request: &ChatRequest) -> serde_json::Value {
        let model = request.model.as_deref().unwrap_or(&self.model.id);

        let mut messages = Vec::new();
        for msg in &request.messages {
            let mut msg_obj = serde_json::json!({
                "role": msg.role,
                "content": match &msg.content {
                    MessageContent::Text(s) => serde_json::Value::String(s.clone()),
                    MessageContent::Parts(parts) => {
                        serde_json::to_value(parts).unwrap_or_default()
                    }
                },
            });

            // 添加 cache_control 扩展字段
            if let Some(cache_control) = &msg.cache_control {
                msg_obj["cache_control"] = serde_json::json!({
                    "type": match cache_control {
                        CacheControlType::CacheBreakpoint => "breakpoint",
                        CacheControlType::Ephemeral => "ephemeral",
                    }
                });
            }

            messages.push(msg_obj);
        }

        let mut body = serde_json::json!({
            "model": model,
            "messages": messages,
            "temperature": request.temperature,
            "stream": false,
        });

        if let Some(top_p) = request.top_p {
            body["top_p"] = serde_json::json!(top_p);
        }
        if let Some(max_tokens) = request.max_tokens {
            body["max_tokens"] = serde_json::json!(max_tokens);
        }
        if !request.stop_sequences.is_empty() {
            body["stop"] = serde_json::json!(request.stop_sequences);
        }
        if !request.tools.is_empty() {
            body["tools"] = serde_json::to_value(&request.tools).unwrap_or_default();
        }
        if let Some(fmt) = &request.response_format {
            body["response_format"] = serde_json::to_value(fmt).unwrap_or_default();
        }

        body
    }
}

impl LlmProvider for OpenAiProvider {
    fn provider_id(&self) -> &str {
        &self.model.provider_id
    }

    fn model_info(&self) -> &ModelInfo {
        &self.model
    }

    fn chat(
        &self,
        request: ChatRequest,
    ) -> Pin<Box<dyn Future<Output = Result<ChatResponse, LlmError>> + Send + '_>> {
        Box::pin(async move {
            let body = self.build_chat_body(&request);
            let url = format!("{}/chat/completions", self.base_url);

            let mut req_builder = self
                .client
                .post(&url)
                .header("Authorization", format!("Bearer {}", &self.api_key))
                .json(&body);

            for (key, value) in &self.default_headers {
                req_builder = req_builder.header(key.as_str(), value.as_str());
            }
            for (key, value) in &request.extra_headers {
                req_builder = req_builder.header(key.as_str(), value.as_str());
            }

            let start = std::time::Instant::now();
            let response = req_builder.send().await.map_err(|e| {
                if e.is_timeout() {
                    LlmError::Timeout {
                        timeout_ms: request
                            .timeout
                            .map(|d| d.as_millis() as u64)
                            .unwrap_or(120_000),
                    }
                } else {
                    LlmError::ApiError(format!("HTTP request failed: {e}"))
                }
            })?;

            let status = response.status();
            let body_text = response.text().await.map_err(|e| {
                LlmError::ApiError(format!("Failed to read response body: {e}"))
            })?;

            if status.is_success() {
                // 解析响应...
                let latency_ms = start.elapsed().as_millis() as u64;
                // 返回 ChatResponse
                todo!("Parse OpenAI response into ChatResponse")
            } else if status.as_u16() == 429 {
                let retry_after = response
                    .headers()
                    .get("retry-after")
                    .and_then(|v| v.to_str().ok())
                    .and_then(|v| v.parse::<u64>().ok());
                Err(LlmError::RateLimited {
                    provider: self.model.provider_id.clone(),
                    retry_after_ms: retry_after,
                })
            } else if status.as_u16() == 401 {
                Err(LlmError::AuthenticationFailed {
                    provider: self.model.provider_id.clone(),
                    reason: body_text,
                })
            } else {
                Err(LlmError::ApiError(format!(
                    "API returned status {status}: {body_text}"
                )))
            }
        })
    }

    fn chat_stream(
        &self,
        request: ChatRequest,
        cancel_token: CancellationToken,
    ) -> Pin<Box<dyn Future<Output = Result<mpsc::Receiver<StreamEvent>, LlmError>> + Send + '_>>
    {
        Box::pin(async move {
            let (tx, rx) = mpsc::channel(64);
            let body = self.build_chat_body(&request);
            // 流式请求实现...
            // 使用 SSE (Server-Sent Events) 解析流式响应
            // 通过 cancel_token 监听取消信号
            Ok(rx)
        })
    }

    fn cache_capability(&self) -> CacheCapability {
        self.cache_capability.clone()
    }

    fn list_models(
        &self,
    ) -> Pin<Box<dyn Future<Output = Result<Vec<ModelInfo>, LlmError>> + Send + '_>> {
        Box::pin(async move {
            let url = format!("{}/models", self.base_url);
            let response = self
                .client
                .get(&url)
                .header("Authorization", format!("Bearer {}", &self.api_key))
                .send()
                .await
                .map_err(|e| LlmError::ApiError(format!("Failed to list models: {e}")))?;

            let body: serde_json::Value = response
                .json()
                .await
                .map_err(|e| LlmError::ApiError(format!("Failed to parse models response: {e}")))?;

            // 解析模型列表...
            Ok(Vec::new())
        })
    }

    fn cancel_request(&self, request_id: &str) -> Result<(), LlmError> {
        let rt = tokio::runtime::Handle::current();
        rt.block_on(async {
            let mut requests = self.active_requests.write().await;
            if let Some(token) = requests.remove(request_id) {
                token.cancel();
                Ok(())
            } else {
                Err(LlmError::ApiError(format!(
                    "Request '{request_id}' not found"
                )))
            }
        })
    }

    fn estimate_tokens(&self, text: &str) -> usize {
        estimate_text_tokens(text)
    }
}
```

### 1.3.10 语义缓存

```rust
use std::collections::HashMap;
use std::time::{Duration, Instant};

/// 语义缓存配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SemanticCacheConfig {
    /// 相似度阈值（0.0 ~ 1.0），超过此值视为命中
    #[serde(default = "default_similarity_threshold")]
    pub similarity_threshold: f64,

    /// 缓存条目最大 TTL
    #[serde(default = "default_cache_ttl")]
    pub max_ttl: Duration,

    /// 最大缓存条目数
    #[serde(default = "default_max_entries")]
    pub max_entries: usize,

    /// 命中统计窗口大小
    #[serde(default = "default_stats_window")]
    pub stats_window_size: usize,

    /// 是否启用缓存
    #[serde(default = "default_true")]
    pub enabled: bool,
    /// 仅对这些 Agent 启用（空 = 全部启用）
    pub enabled_agents: Vec<AgentType>,
    /// 最大可缓存响应长度（字符数，默认 4096）
    pub max_response_chars: usize,
    /// 污染检测：同一 key 连续未命中次数超过此值时触发告警（默认 3）
    pub pollution_miss_threshold: u32,
    /// 污染检测：缓存命中率低于此值时自动禁用该 namespace（默认 0.30）
    pub min_hit_rate: f32,
    /// 是否对代码生成类查询完全禁用语义缓存（默认 true）
    pub disable_for_code_generation: bool,
}

fn default_similarity_threshold() -> f64 {
    0.95
}
fn default_cache_ttl() -> Duration {
    Duration::from_secs(300) // 5 分钟
}
fn default_max_entries() -> usize {
    1000
}
fn default_stats_window() -> usize {
    100
}
fn default_true() -> bool {
    true
}

impl Default for SemanticCacheConfig {
    fn default() -> Self {
        Self {
            similarity_threshold: default_similarity_threshold(),
            max_ttl: default_cache_ttl(),
            max_entries: default_max_entries(),
            stats_window_size: default_stats_window(),
            enabled: default_true(),
        }
    }
}

/// 语义缓存命名空间
///
/// 不同命名空间的缓存互不干扰。
#[derive(Debug, Clone, Hash, Eq, PartialEq, Serialize, Deserialize)]
pub struct SemanticCacheNamespace {
    /// 命名空间标识符
    pub name: String,

    /// 关联的模型 ID
    pub model_id: String,

    /// 关联的项目 ID（可选）
    pub project_id: Option<String>,
}

/// 语义缓存条目
#[derive(Debug, Clone)]
pub struct SemanticCacheEntry {
    /// 条目唯一 ID
    pub id: String,

    /// 请求消息的语义嵌入向量
    pub embedding: Vec<f32>,

    /// 缓存的响应
    pub response: ChatResponse,

    /// 创建时间
    pub created_at: Instant,

    /// 最后访问时间
    pub last_accessed_at: Instant,

    /// 命中次数
    pub hit_count: u64,

    /// 命中统计（滑动窗口）
    pub hit_stats: Vec<Instant>,

    /// 命名空间
    pub namespace: SemanticCacheNamespace,
}

impl SemanticCacheEntry {
    /// 判断条目是否过期
    pub fn is_expired(&self, max_ttl: Duration) -> bool {
        self.created_at.elapsed() > max_ttl
    }

    /// 记录一次命中
    pub fn record_hit(&mut self, stats_window_size: usize) {
        self.hit_count += 1;
        self.last_accessed_at = Instant::now();
        self.hit_stats.push(Instant::now());
        // 保留窗口内的统计
        let cutoff = Instant::now() - Duration::from_secs(300);
        self.hit_stats.retain(|t| *t > cutoff);
        if self.hit_stats.len() > stats_window_size {
            self.hit_stats.drain(..self.hit_stats.len() - stats_window_size);
        }
    }
}

/// 语义缓存存储 trait
///
/// 可替换的缓存后端实现。
pub trait SemanticCacheStore: Send + Sync {
    /// 查找相似请求
    ///
    /// 返回相似度最高的缓存条目（如果超过阈值）。
    fn find_similar(
        &self,
        namespace: &SemanticCacheNamespace,
        embedding: &[f32],
        threshold: f64,
    ) -> Pin<Box<dyn Future<Output = Option<SemanticCacheEntry>> + Send + '_>>;

    /// 存储缓存条目
    fn store(
        &self,
        entry: SemanticCacheEntry,
    ) -> Pin<Box<dyn Future<Output = Result<(), String>> + Send + '_>>;

    /// 删除指定命名空间的所有缓存
    fn invalidate_namespace(
        &self,
        namespace: &SemanticCacheNamespace,
    ) -> Pin<Box<dyn Future<Output = Result<usize, String>> + Send + '_>>;

    /// 获取缓存统计信息
    fn stats(
        &self,
        namespace: &SemanticCacheNamespace,
    ) -> Pin<Box<dyn Future<Output = CacheStats> + Send + '_>>;
}

/// 缓存统计信息
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct CacheStats {
    /// 总条目数
    pub total_entries: usize,
    /// 总命中次数
    pub total_hits: u64,
    /// 总未命中次数
    pub total_misses: u64,
    /// 命中率
    pub hit_rate: f64,
    /// 平均相似度
    pub avg_similarity: f64,
}

/// 语义缓存中间件
///
/// 包装 LlmProvider，在请求前检查缓存，在响应后更新缓存。
pub struct SemanticCacheMiddleware<P: LlmProvider, S: SemanticCacheStore> {
    /// 内部 Provider
    inner: P,

    /// 缓存存储
    store: S,

    /// 缓存配置
    config: SemanticCacheConfig,

    /// 嵌入计算函数
    embed_fn: fn(&str) -> Vec<f32>,

    /// 统计信息
    stats: tokio::sync::RwLock<CacheStats>,

    /// 命中统计：(hits, total)
    hit_stats: HashMap<String, (u32, u32)>,
    /// 连续未命中计数器
    miss_counters: HashMap<String, u32>,
}

impl<P: LlmProvider, S: SemanticCacheStore> SemanticCacheMiddleware<P, S> {
    /// 创建新的语义缓存中间件
    pub fn new(inner: P, store: S, config: SemanticCacheConfig) -> Self {
        Self {
            inner,
            store,
            config,
            embed_fn: |text| {
                // 默认嵌入函数（简单哈希，生产环境应使用真实嵌入模型）
                text.bytes()
                    .map(|b| (b as f32) / 255.0)
                    .collect()
            },
            stats: tokio::sync::RwLock::new(CacheStats::default()),
        }
    }

    /// 使用自定义嵌入函数
    pub fn with_embed_fn(mut self, f: fn(&str) -> Vec<f32>) -> Self {
        self.embed_fn = f;
        self
    }

    /// 清理过期的统计信息
    ///
    /// 移除超过统计窗口的命中记录，重新计算命中率。
    pub async fn cleanup_stale_stats(&self) {
        let mut stats = self.stats.write().await;
        let cutoff = Instant::now() - Duration::from_secs(300);
        // 重新计算统计数据
        stats.hit_rate = if stats.total_hits + stats.total_misses > 0 {
            stats.total_hits as f64 / (stats.total_hits + stats.total_misses) as f64
        } else {
            0.0
        };
    }

    /// 生成缓存键（基于请求消息的嵌入向量）
    fn compute_embedding(&self, request: &ChatRequest) -> Vec<f32> {
        let text: String = request
            .messages
            .iter()
            .map(|m| m.content.to_text())
            .collect::<Vec<_>>()
            .join("\n");
        (self.embed_fn)(&text)
    }

    /// 计算余弦相似度
    fn cosine_similarity(a: &[f32], b: &[f32]) -> f64 {
        if a.is_empty() || b.is_empty() || a.len() != b.len() {
            return 0.0;
        }
        let dot: f64 = a.iter().zip(b.iter()).map(|(x, y)| (*x as f64) * (*y as f64)).sum();
        let norm_a: f64 = a.iter().map(|x| (*x as f64) * (*x as f64)).sum::<f64>().sqrt();
        let norm_b: f64 = b.iter().map(|x| (*x as f64) * (*x as f64)).sum::<f64>().sqrt();
        if norm_a == 0.0 || norm_b == 0.0 {
            return 0.0;
        }
        dot / (norm_a * norm_b)
    }

    /// 检查指定 namespace 的缓存是否因命中率过低被自动禁用
    fn is_namespace_disabled(&self, ns_key: &str) -> bool {
        if let Some((hits, total)) = self.hit_stats.get(ns_key) {
            if *total >= 10 {
                let hit_rate = *hits as f64 / *total as f64;
                return hit_rate < self.config.min_hit_rate as f64;
            }
        }
        false
    }

    /// 记录缓存命中/未命中结果，并检测污染
    fn record_cache_result(&self, ns_key: &str, hit: bool) {
        self.hit_stats.entry(ns_key.to_string())
            .and_modify(|(hits, total)| {
                *total += 1;
                if hit { *hits += 1; }
            })
            .or_insert((if hit { 1 } else { 0 }, 1));

        if hit {
            self.miss_counters.insert(ns_key.to_string(), 0);
        } else {
            self.miss_counters.entry(ns_key.to_string())
                .and_modify(|count| *count += 1)
                .or_insert(1);

            if let Some(count) = self.miss_counters.get(ns_key) {
                if *count >= self.config.pollution_miss_threshold {
                    tracing::warn!(
                        namespace = ns_key,
                        consecutive_misses = *count,
                        "语义缓存可能已污染：连续多次未命中，建议清除该 namespace"
                    );
                }
            }
        }
    }
}
```

### 1.3.11 Token 计数

```rust
/// 估算文本的 Token 数量
///
/// 使用启发式算法进行快速估算：
/// 1. ASCII 文本：约 4 字符 / Token（快速路径）
/// 2. CJK 文本：约 1.5 字符 / Token（加权计算）
/// 3. 混合文本：按比例加权
///
/// 精度要求：±10%（与实际 tokenizer 相比）
pub fn estimate_text_tokens(text: &str) -> usize {
    if text.is_empty() {
        return 0;
    }

    let mut ascii_chars = 0usize;
    let mut cjk_chars = 0usize;
    let mut other_chars = 0usize;

    for ch in text.chars() {
        if ch.is_ascii() {
            ascii_chars += 1;
        } else if is_cjk_char(ch) {
            cjk_chars += 1;
        } else {
            other_chars += 1;
        }
    }

    // ASCII 快速路径：约 4 字符 / Token
    let ascii_tokens = (ascii_chars as f64 / 4.0).ceil() as usize;

    // CJK 加权：约 1.5 字符 / Token
    let cjk_tokens = (cjk_chars as f64 / 1.5).ceil() as usize;

    // 其他字符：约 3 字符 / Token
    let other_tokens = (other_chars as f64 / 3.0).ceil() as usize;

    ascii_tokens + cjk_tokens + other_tokens
}

/// 判断字符是否为 CJK（中日韩）字符
fn is_cjk_char(ch: char) -> bool {
    let cp = ch as u32;
    // CJK Unified Ideographs
    (0x4E00..=0x9FFF).contains(&cp)
        // CJK Extension A
        || (0x3400..=0x4DBF).contains(&cp)
        // CJK Extension B
        || (0x20000..=0x2A6DF).contains(&cp)
        // CJK Compatibility Ideographs
        || (0xF900..=0xFAFF).contains(&cp)
        // Hiragana
        || (0x3040..=0x309F).contains(&cp)
        // Katakana
        || (0x30A0..=0x30FF).contains(&cp)
        // Hangul Syllables
        || (0xAC00..=0xD7AF).contains(&cp)
        // CJK Radicals Supplement
        || (0x2E80..=0x2EFF).contains(&cp)
        // Kangxi Radicals
        || (0x2F00..=0x2FDF).contains(&cp)
        // CJK Symbols and Punctuation
        || (0x3000..=0x303F).contains(&cp)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_estimate_empty_text() {
        assert_eq!(estimate_text_tokens(""), 0);
    }

    #[test]
    fn test_estimate_ascii_text() {
        // "Hello, world!" = 13 chars -> ~4 tokens
        let tokens = estimate_text_tokens("Hello, world!");
        assert!((3..=5).contains(&tokens));
    }

    #[test]
    fn test_estimate_cjk_text() {
        // "你好世界" = 4 CJK chars -> ~3 tokens
        let tokens = estimate_text_tokens("你好世界");
        assert!((2..=4).contains(&tokens));
    }

    #[test]
    fn test_estimate_mixed_text() {
        let tokens = estimate_text_tokens("Hello你好World世界");
        assert!(tokens > 0);
    }
}
```

### 1.3.12 成本追踪

```rust
use std::sync::atomic::{AtomicU64, Ordering};

/// 预算节点
///
/// 使用原子操作实现并发安全的预算管理。
/// 支持多线程并发扣减预算。
pub struct BudgetNode {
    /// 剩余预算（以最小货币单位计，如美分）
    remaining: AtomicU64,

    /// 初始预算
    initial: u64,

    /// 已使用预算
    used: AtomicU64,

    /// 预算耗尽回调
    on_exhausted: Option<std::sync::Arc<dyn Fn() + Send + Sync>>,
}

impl BudgetNode {
    /// 创建新的预算节点
    ///
    /// # 参数
    /// - `initial_budget`: 初始预算（最小货币单位）
    pub fn new(initial_budget: u64) -> Self {
        Self {
            remaining: AtomicU64::new(initial_budget),
            initial: initial_budget,
            used: AtomicU64::new(0),
            on_exhausted: None,
        }
    }

    /// 尝试扣减预算
    ///
    /// 使用 compare_exchange 循环确保并发安全。
    ///
    /// # 返回
    /// - `Ok(remaining)`: 扣减成功，返回剩余预算
    /// - `Err(BudgetError)`: 预算不足
    pub fn try_deduct(&self, amount: u64) -> Result<u64, BudgetError> {
        loop {
            let current = self.remaining.load(Ordering::Acquire);
            if current < amount {
                return Err(BudgetError::InsufficientBudget {
                    required: amount,
                    remaining: current,
                });
            }
            let new_remaining = current - amount;
            match self.remaining.compare_exchange_weak(
                current,
                new_remaining,
                Ordering::AcqRel,
                Ordering::Acquire,
            ) {
                Ok(_) => {
                    self.used.fetch_add(amount, Ordering::Release);
                    if new_remaining == 0 {
                        if let Some(ref callback) = self.on_exhausted {
                            callback();
                        }
                    }
                    return Ok(new_remaining);
                }
                Err(_) => continue, // CAS 失败，重试
            }
        }
    }

    /// 获取剩余预算
    pub fn remaining(&self) -> u64 {
        self.remaining.load(Ordering::Acquire)
    }

    /// 获取已使用预算
    pub fn used(&self) -> u64 {
        self.used.load(Ordering::Acquire)
    }

    /// 获取使用率（0.0 ~ 1.0）
    pub fn usage_rate(&self) -> f64 {
        if self.initial == 0 {
            return 0.0;
        }
        self.used.load(Ordering::Acquire) as f64 / self.initial as f64
    }

    /// 设置预算耗尽回调
    pub fn on_exhausted<F: Fn() + Send + Sync + 'static>(&mut self, callback: F) {
        self.on_exhausted = Some(std::sync::Arc::new(callback));
    }

    /// 重置预算
    pub fn reset(&self, new_budget: u64) {
        self.remaining.store(new_budget, Ordering::Release);
        self.used.store(0, Ordering::Release);
    }
}

/// 预算错误
#[derive(Debug, Clone, thiserror::Error)]
pub enum BudgetError {
    /// 预算不足
    #[error("Insufficient budget: required {required}, remaining {remaining}")]
    InsufficientBudget { required: u64, remaining: u64 },
}

/// 校准预算估算值
///
/// 使用 AcqRel 内存序确保在多线程环境下的可见性。
/// 根据实际使用数据调整估算参数。
///
/// # 参数
/// - `estimated`: 当前估算值
/// - `actual`: 实际值
/// - `alpha`: 学习率（0.0 ~ 1.0），默认 0.1
///
/// # 返回
/// 校准后的估算值
pub fn calibrate(estimated: f64, actual: f64, alpha: Option<f64>) -> f64 {
    let alpha = alpha.unwrap_or(0.1);
    // 指数移动平均（EMA）
    // 使用 AcqRel 确保多线程可见性
    let _ = std::sync::atomic::fence(Ordering::AcqRel);
    estimated + alpha * (actual - estimated)
}

/// 成本追踪器
pub struct CostTracker {
    /// 预算节点
    budget: BudgetNode,

    /// 按模型统计的成本
    model_costs: tokio::sync::RwLock<HashMap<String, ModelCostRecord>>,
}

/// 模型成本记录
#[derive(Debug, Clone, Default)]
pub struct ModelCostRecord {
    /// 总请求数
    pub total_requests: u64,
    /// 总输入 Token
    pub total_input_tokens: u64,
    /// 总输出 Token
    pub total_output_tokens: u64,
    /// 总缓存命中 Token
    pub total_cached_tokens: u64,
    /// 总成本（美分）
    pub total_cost_cents: u64,
}

impl CostTracker {
    /// 创建新的成本追踪器
    pub fn new(budget_cents: u64) -> Self {
        Self {
            budget: BudgetNode::new(budget_cents),
            model_costs: tokio::sync::RwLock::new(HashMap::new()),
        }
    }

    /// 记录一次 API 调用成本
    pub async fn record_usage(
        &self,
        model_id: &str,
        model_info: &ModelInfo,
        usage: &TokenUsage,
    ) -> Result<(), BudgetError> {
        // 计算成本（美分）
        let uncached_prompt = usage.prompt_tokens.saturating_sub(usage.cached_tokens);
        let input_cost = (uncached_prompt as f64 / 1000.0) * model_info.input_price_per_1k;
        let output_cost = (usage.completion_tokens as f64 / 1000.0) * model_info.output_price_per_1k;
        let cache_cost = (usage.cached_tokens as f64 / 1000.0) * model_info.cache_read_price_per_1k;
        let total_cost_cents = ((input_cost + output_cost + cache_cost) * 100.0).ceil() as u64;

        // 扣减预算
        self.budget.try_deduct(total_cost_cents)?;

        // 更新模型统计
        let mut costs = self.model_costs.write().await;
        let record = costs
            .entry(model_id.to_string())
            .or_insert_with(ModelCostRecord::default);
        record.total_requests += 1;
        record.total_input_tokens += usage.prompt_tokens as u64;
        record.total_output_tokens += usage.completion_tokens as u64;
        record.total_cached_tokens += usage.cached_tokens as u64;
        record.total_cost_cents += total_cost_cents;

        Ok(())
    }

    /// 获取预算使用率
    pub fn budget_usage_rate(&self) -> f64 {
        self.budget.usage_rate()
    }

    /// 获取剩余预算
    pub fn remaining_budget(&self) -> u64 {
        self.budget.remaining()
    }
}
```

---

## 1.4 功能需求清单

### FR-LLM-001：Chat 请求（非流式）

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 支持向 LLM 发送同步聊天请求并获取完整响应 |
| **前置条件** | Provider 已初始化，API 密钥有效 |
| **输入** | `ChatRequest`（messages、model、temperature 等） |
| **输出** | `Result<ChatResponse, LlmError>` |
| **验收标准** | 1. 正确序列化请求并发送至 API；2. 正确解析响应为 `ChatResponse`；3. 错误状态码映射为对应 `LlmError` 变体 |

### FR-LLM-002：Chat Stream 请求（流式）

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 支持流式聊天请求，通过 `mpsc::Receiver` 逐事件返回 |
| **前置条件** | Provider 已初始化，模型支持流式输出 |
| **输入** | `ChatRequest` + `CancellationToken` |
| **输出** | `Result<mpsc::Receiver<StreamEvent>, LlmError>` |
| **验收标准** | 1. 正确解析 SSE 事件为 `StreamEvent`；2. 取消时立即关闭通道；3. 最终发送 `StreamEvent::Finish` |

### FR-LLM-003：请求重试

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 对可重试错误（RateLimited、Timeout、ApiError）自动重试 |
| **配置** | 最大重试次数（默认 3）、退避策略（指数退避 + 抖动） |
| **验收标准** | 1. 仅对 `is_retryable()` 返回 true 的错误重试；2. 使用 `retry_delay_ms()` 获取延迟；3. 超过最大重试次数后返回最后一次错误 |

### FR-LLM-004：请求超时

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 支持请求级别的超时控制 |
| **配置** | 默认 120 秒，可通过 `ChatRequest.timeout` 覆盖 |
| **验收标准** | 1. 超时后返回 `LlmError::Timeout`；2. 超时后自动取消底层 HTTP 请求 |

### FR-LLM-005：请求取消

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 支持通过 `CancellationToken` 取消正在进行的请求 |
| **验收标准** | 1. 取消后立即停止流式事件发送；2. 返回 `LlmError::Cancelled`；3. 非流式请求也支持取消 |

### FR-LLM-006：流式转发

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | `StreamForwarder` 将 Provider 事件流转发给多个消费者 |
| **验收标准** | 1. 所有消费者收到相同的事件序列；2. `into_content()` 正确聚合内容；3. 取消时所有消费者收到结束信号 |

### FR-LLM-007：语义缓存

| 属性 | 说明 |
|------|------|
| **优先级** | P2 |
| **描述** | 对语义相似的请求进行缓存命中，降低重复调用成本 |
| **配置** | 相似度阈值（默认 0.95）、TTL（默认 5 分钟）、最大条目数（默认 1000） |
| **验收标准** | 1. 相似度超过阈值时返回缓存响应；2. 缓存条目过期后自动淘汰；3. `cleanup_stale_stats()` 正确清理过期统计 |

### FR-LLM-008：Token 计数

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 提供快速的 Token 数量估算 |
| **验收标准** | 1. ASCII 文本使用快速路径（4 字符/Token）；2. CJK 文本使用加权计算（1.5 字符/Token）；3. 估算精度 ±10% |

### FR-LLM-009：成本追踪

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 跟踪 API 调用成本，支持预算管理 |
| **验收标准** | 1. `BudgetNode` 使用 CAS 循环保证并发安全；2. 预算不足时返回 `BudgetError`；3. `calibrate()` 使用 AcqRel 内存序 |

---

## 1.5 接口契约

### IC-LLM-001：LlmProvider::chat

```
输入: ChatRequest
输出: Result<ChatResponse, LlmError>
超时: 由 ChatRequest.timeout 决定，默认 120s
重试: 对可重试错误最多重试 3 次（指数退避）
取消: 不支持（使用 chat_stream + CancellationToken 代替）
```

### IC-LLM-002：LlmProvider::chat_stream

```
输入: ChatRequest + CancellationToken
输出: Result<mpsc::Receiver<StreamEvent>, LlmError>
通道容量: 64（默认）
事件顺序: Delta/ToolCallDelta（0..N） -> Finish（1）
取消: 通过 CancellationToken 立即停止
背压: 当接收端缓冲区满时，发送端阻塞
```

### IC-LLM-003：SemanticCacheMiddleware 缓存查找

```
输入: ChatRequest
输出: Option<ChatResponse>（缓存命中）或 None（未命中）
相似度计算: 余弦相似度
阈值: 0.95（可配置）
TTL: 300s（可配置）
```

### IC-LLM-004：BudgetNode::try_deduct

```
输入: amount: u64（扣减金额，美分）
输出: Result<u64, BudgetError>（剩余金额）
并发安全: CAS 循环（AcqRel 内存序）
原子性: 保证
```

---

## 1.6 测试要点

### TC-LLM-001：LlmProvider trait 实现测试

| 测试项 | 说明 |
|--------|------|
| provider_id 返回值 | 验证返回非空字符串 |
| model_info 完整性 | 验证 ModelInfo 所有字段有效 |
| chat 基本功能 | 发送简单请求，验证响应结构 |
| chat 错误处理 | 模拟 401/429/500 错误，验证 LlmError 变体 |
| chat_stream 事件序列 | 验证 Delta -> Finish 事件顺序 |
| chat_stream 取消 | 验证取消后通道关闭 |
| list_models | 验证返回非空模型列表 |

### TC-LLM-002：Token 计数测试

| 测试项 | 说明 |
|--------|------|
| 空文本 | 返回 0 |
| 纯 ASCII | 验证快速路径精度 |
| 纯 CJK | 验证加权计算精度 |
| 混合文本 | 验证混合计算逻辑 |
| 长文本性能 | 10000 字符文本 < 1ms |

### TC-LLM-003：语义缓存测试

| 测试项 | 说明 |
|--------|------|
| 缓存命中 | 相同请求返回缓存响应 |
| 缓存未命中 | 不同请求返回 None |
| TTL 过期 | 超时后缓存条目不可用 |
| 容量限制 | 超过 max_entries 时淘汰最旧条目 |
| cleanup_stale_stats | 验证统计信息正确清理 |

### TC-LLM-004：成本追踪测试

| 测试项 | 说明 |
|--------|------|
| 并发扣减 | 多线程同时扣减预算，验证无竞态 |
| 预算不足 | 扣减超过剩余预算时返回错误 |
| CAS 重试 | 高并发下 CAS 循环正确完成 |
| calibrate | 验证 EMA 校准逻辑 |
| 内存序 | 验证 AcqRel 保证跨线程可见性 |

### TC-LLM-005：OpenAiProvider 集成测试

| 测试项 | 说明 |
|--------|------|
| 基本聊天 | 发送消息并验证响应 |
| 流式聊天 | 验证 SSE 解析正确性 |
| cache_control | 验证缓存控制字段正确传递 |
| 重试逻辑 | 模拟 429 响应，验证指数退避 |
| 超时处理 | 验证超时后正确返回错误 |

---

# P2-2 mc-prompt — Prompt 缓存与模板管理

## 2.1 模块概述

`mc-prompt` 是 MoreCode 的 Prompt 管理层，负责：

1. **四层 Prompt 管理**：通过 `PromptLayer` 枚举实现 Global / Organization / Project / Session / Turn 五层 Prompt 的分层管理与优先级覆盖。
2. **版本追踪**：`PromptLayerManager` 维护每层 Prompt 的版本号，支持增量更新与失效回滚。
3. **模板系统**：`PromptTemplate` + `TemplateRenderer` 支持 `{{variable}}` 语法的变量替换，`TemplateManager` 负责模板的加载、编译与缓存。
4. **文件监听**：`start_file_watcher()` 通过 `notify` crate 监听 Prompt 文件变更，自动触发缓存失效。
5. **缓存预热**：`CacheWarmupStrategy` 定义预热策略，`calculate_cache_savings()` 估算缓存节省。

### 架构文档引用

| 文档 | 关联章节 |
|------|----------|
| `15-Prompt缓存与模板管理.md` | 全文 — 四层管理、缓存控制点、模板系统、预热策略 |
| `24-Agent系统提示词定义.md` | §系统提示词分层、§变量替换规则、§缓存断点设置 |

---

## 2.2 大模型开发提示词

```
你是 MoreCode 项目的 mc-prompt 模块开发者。请遵循以下规范：

1. Prompt 层级严格遵循 Global -> Organization -> Project -> Session -> Turn 的优先级顺序。
2. 所有 Prompt 更新必须通过 PromptLayerManager 进行，禁止直接修改底层存储。
3. 模板变量使用 {{variable}} 语法，变量名仅允许 [a-zA-Z0-9_]。
4. 文件监听使用 notify crate，监听 .md / .yaml / .json 三种格式。
5. 缓存失效事件通过 CacheInvalidationEvent 广播，所有订阅者必须处理。
6. should_set_cache_breakpoint() 仅在 Turn 层消息数 >= 3 时返回 true。
7. calculate_cache_savings() 必须考虑缓存 TTL 与命中率。
8. 模板渲染失败时返回 PromptCacheError::TemplateRenderError，禁止 panic。
```

---

## 2.3 核心类型定义

### 2.3.1 PromptLayer 枚举

```rust
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Prompt 层级
///
/// 从低到高优先级排列：
/// Global < Organization < Project < Session < Turn
///
/// 高优先级层可以覆盖低优先级层的同名变量。
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub enum PromptLayer {
    /// 全局层 — 系统默认 Prompt，所有用户共享
    Global,
    /// 组织层 — 组织级 Prompt，组织内所有项目共享
    Organization,
    /// 项目层 — 项目级 Prompt，项目内所有会话共享
    Project,
    /// 会话层 — 会话级 Prompt，会话内所有轮次共享
    Session,
    /// 轮次层 — 当前对话轮次的 Prompt，优先级最高
    Turn,
}

impl PromptLayer {
    /// 返回层级深度（0 = Global, 4 = Turn）
    pub fn depth(&self) -> u8 {
        match self {
            PromptLayer::Global => 0,
            PromptLayer::Organization => 1,
            PromptLayer::Project => 2,
            PromptLayer::Session => 3,
            PromptLayer::Turn => 4,
        }
    }

    /// 返回层级名称
    pub fn name(&self) -> &'static str {
        match self {
            PromptLayer::Global => "global",
            PromptLayer::Organization => "organization",
            PromptLayer::Project => "project",
            PromptLayer::Session => "session",
            PromptLayer::Turn => "turn",
        }
    }

    /// 返回所有层级（按优先级从低到高）
    pub fn all() -> [PromptLayer; 5] {
        [
            PromptLayer::Global,
            PromptLayer::Organization,
            PromptLayer::Project,
            PromptLayer::Session,
            PromptLayer::Turn,
        ]
    }
}

impl std::fmt::Display for PromptLayer {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.name())
    }
}
```

### 2.3.2 PromptLayerContent / PromptLayers / TurnMessage

```rust
/// 单层 Prompt 内容
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PromptLayerContent {
    /// 层级
    pub layer: PromptLayer,

    /// 系统提示词文本
    pub system_prompt: String,

    /// 变量定义（键值对）
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub variables: HashMap<String, String>,

    /// 缓存控制点位置（在此层之后设置缓存断点）
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub cache_breakpoints: Vec<usize>,

    /// 版本号（每次更新递增）
    pub version: u64,
    /// 内容哈希（用于快速比较变更，u64 seahash）
    pub content_hash: u64,
    /// 最后更新时间
    pub updated_at: chrono::DateTime<chrono::Utc>,
}

impl PromptLayerContent {
    /// 创建新的层内容
    pub fn new(layer: PromptLayer, system_prompt: impl Into<String>) -> Self {
        Self {
            layer,
            system_prompt: system_prompt.into(),
            variables: HashMap::new(),
            cache_breakpoints: Vec::new(),
            version: 0,
            updated_at: chrono::Utc::now(),
        }
    }

    /// 设置变量
    pub fn with_variable(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.variables.insert(key.into(), value.into());
        self
    }

    /// 递增版本号
    pub fn bump_version(&mut self) {
        self.version += 1;
        self.updated_at = chrono::Utc::now();
    }
}

/// 五层 Prompt 完整结构
///
/// 权威定义来源：15-Prompt缓存与模板管理.md
/// L1-L4 为静态层（从配置/文件加载），L5 为动态层（对话历史）。
pub struct PromptLayers {
    /// L1 全局层（系统级指令）
    pub global: PromptLayerContent,
    /// L2 组织层（团队规范，可选）
    pub organization: Option<PromptLayerContent>,
    /// L3 项目层（项目特定指令，可选）
    pub project: Option<PromptLayerContent>,
    /// L4 会话层（会话级上下文，可选）
    pub session: Option<PromptLayerContent>,
    /// L5 轮次层（对话历史）
    pub turn_history: Vec<TurnMessage>,
}

impl PromptLayers {
    /// 获取指定层的内容
    pub fn get(&self, layer: &PromptLayer) -> Option<&PromptLayerContent> {
        self.layers.get(layer)
    }

    /// 设置指定层的内容
    pub fn set(&mut self, content: PromptLayerContent) {
        self.layers.insert(content.layer, content);
    }

    /// 移除指定层
    pub fn remove(&mut self, layer: &PromptLayer) -> Option<PromptLayerContent> {
        self.layers.remove(layer)
    }

    /// 获取所有已设置的层级（按优先级从低到高排序）
    pub fn sorted_layers(&self) -> Vec<&PromptLayerContent> {
        let mut layers: Vec<_> = self.layers.values().collect();
        layers.sort_by_key(|c| c.layer);
        layers
    }

    /// 合并所有层的变量（高优先级覆盖低优先级）
    pub fn merge_variables(&self) -> HashMap<String, String> {
        let mut merged = HashMap::new();
        for content in self.sorted_layers() {
            for (key, value) in &content.variables {
                merged.insert(key.clone(), value.clone());
            }
        }
        merged
    }
}

/// 轮次消息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TurnMessage {
    /// 消息角色
    pub role: String,

    /// 消息内容
    pub content: String,

    /// 消息时间戳
    pub timestamp: chrono::DateTime<chrono::Utc>,

    /// Token 计数（估算）
    pub token_count: usize,
}

impl TurnMessage {
    /// 创建用户消息
    pub fn user(content: impl Into<String>) -> Self {
        let content = content.into();
        Self {
            role: "user".to_string(),
            token_count: crate::mc_llm::estimate_text_tokens(&content),
            timestamp: chrono::Utc::now(),
            content,
        }
    }

    /// 创建助手消息
    pub fn assistant(content: impl Into<String>) -> Self {
        let content = content.into();
        Self {
            role: "assistant".to_string(),
            token_count: crate::mc_llm::estimate_text_tokens(&content),
            timestamp: chrono::Utc::now(),
            content,
        }
    }
}
```

### 2.3.3 PromptLayerManager

```rust
use tokio::sync::{broadcast, RwLock};

/// Prompt 层管理器
///
/// 管理五层 Prompt 的生命周期，包括更新、失效、版本追踪。
pub struct PromptLayerManager {
    /// 各层 Prompt 内容
    layers: RwLock<PromptLayers>,

    /// 缓存失效事件广播通道
    invalidation_tx: broadcast::Sender<CacheInvalidationEvent>,

    /// 全局版本号
    global_version: std::sync::atomic::AtomicU64,

    /// 文件监听句柄
    file_watcher: Option<tokio::task::JoinHandle<()>>,
}

impl PromptLayerManager {
    /// 创建新的 Prompt 层管理器
    pub fn new() -> Self {
        let (invalidation_tx, _) = broadcast::channel(64);
        Self {
            layers: RwLock::new(PromptLayers::default()),
            invalidation_tx,
            global_version: std::sync::atomic::AtomicU64::new(0),
            file_watcher: None,
        }
    }

    /// 更新指定层的 Prompt 内容
    ///
    /// # 参数
    /// - `layer`: 目标层级
    /// - `system_prompt`: 新的系统提示词
    /// - `variables`: 新的变量集合
    ///
    /// # 返回
    /// 更新后的版本号
    pub async fn update_layer(
        &self,
        layer: PromptLayer,
        system_prompt: impl Into<String>,
        variables: HashMap<String, String>,
    ) -> Result<u64, PromptCacheError> {
        let mut layers = self.layers.write().await;
        let mut content = PromptLayerContent::new(layer, system_prompt);
        content.variables = variables;

        // 如果已存在，继承旧版本号
        if let Some(old) = layers.get(&layer) {
            content.version = old.version;
        }
        content.bump_version();

        let new_version = content.version;
        layers.set(content);

        // 递增全局版本
        let global_ver = self
            .global_version
            .fetch_add(1, std::sync::atomic::Ordering::Release)
            + 1;

        // 广播失效事件
        let _ = self.invalidation_tx.send(CacheInvalidationEvent {
            layer,
            version: new_version,
            global_version: global_ver,
            reason: InvalidationReason::LayerUpdated,
            timestamp: chrono::Utc::now(),
        });

        Ok(new_version)
    }

    /// 处理缓存失效事件
    ///
    /// 当收到失效事件时，清除相关缓存并通知订阅者。
    pub async fn on_invalidation(
        &self,
        event: CacheInvalidationEvent,
    ) -> Result<(), PromptCacheError> {
        // 验证事件版本是否比当前版本更新
        let layers = self.layers.read().await;
        if let Some(current) = layers.get(&event.layer) {
            if event.version < current.version {
                return Err(PromptCacheError::StaleEvent {
                    event_version: event.version,
                    current_version: current.version,
                });
            }
        }

        // 清除缓存（具体实现取决于缓存后端）
        // 通知所有订阅者
        Ok(())
    }

    /// 获取指定层的版本号
    pub async fn get_version(&self, layer: PromptLayer) -> u64 {
        let layers = self.layers.read().await;
        layers.get(&layer).map(|c| c.version).unwrap_or(0)
    }

    /// 获取全局版本号
    pub fn get_global_version(&self) -> u64 {
        self.global_version.load(std::sync::atomic::Ordering::Acquire)
    }

    /// 构建完整的消息列表
    ///
    /// 按层级优先级合并所有 Prompt，生成发送给 LLM 的消息列表。
    pub async fn build_messages(
        &self,
        turn_messages: &[TurnMessage],
        template_vars: &HashMap<String, String>,
    ) -> Result<Vec<crate::mc_llm::ChatMessage>, PromptCacheError> {
        let layers = self.layers.read().await;
        let mut messages = Vec::new();

        // 合并所有层的系统提示词
        let mut system_parts = Vec::new();
        for content in layers.sorted_layers() {
            // 渲染模板变量
            let rendered = TemplateRenderer::new()
                .with_variables(&content.variables)
                .with_variables(template_vars)
                .render(&content.system_prompt)?;

            if !rendered.is_empty() {
                system_parts.push(rendered);
            }
        }

        // 构建系统消息
        if !system_parts.is_empty() {
            let system_prompt = system_parts.join("\n\n---\n\n");
            messages.push(crate::mc_llm::ChatMessage {
                role: crate::mc_llm::MessageRole::System,
                content: crate::mc_llm::MessageContent::Text(system_prompt),
                name: None,
                tool_calls: Vec::new(),
                tool_call_id: None,
                cache_control: None,
            });
        }

        // 添加轮次消息
        for msg in turn_messages {
            let role = match msg.role.as_str() {
                "user" => crate::mc_llm::MessageRole::User,
                "assistant" => crate::mc_llm::MessageRole::Assistant,
                _ => continue,
            };
            messages.push(crate::mc_llm::ChatMessage {
                role,
                content: crate::mc_llm::MessageContent::Text(msg.content.clone()),
                name: None,
                tool_calls: Vec::new(),
                tool_call_id: None,
                cache_control: None,
            });
        }

        // 设置缓存断点
        if should_set_cache_breakpoint(&messages) {
            if let Some(last) = messages.last_mut() {
                last.cache_control =
                    Some(crate::mc_llm::CacheControlType::CacheBreakpoint);
            }
        }

        Ok(messages)
    }

    /// 订阅缓存失效事件
    pub fn subscribe_invalidation(&self) -> broadcast::Receiver<CacheInvalidationEvent> {
        self.invalidation_tx.subscribe()
    }

    /// 启动文件监听
    pub fn start_file_watcher(&mut self, watch_paths: &[String]) -> Result<(), PromptCacheError> {
        let tx = self.invalidation_tx.clone();
        let paths: Vec<std::path::PathBuf> = watch_paths
            .iter()
            .map(|p| std::path::PathBuf::from(p))
            .collect();

        let handle = tokio::spawn(async move {
            // 使用 notify crate 监听文件变更
            // 当检测到 .md / .yaml / .json 文件变更时，
            // 发送 CacheInvalidationEvent
            if let Err(e) = start_file_watcher(&paths, tx).await {
                tracing::error!("File watcher error: {}", e);
            }
        });

        self.file_watcher = Some(handle);
        Ok(())
    }
}

impl Drop for PromptLayerManager {
    fn drop(&mut self) {
        if let Some(handle) = self.file_watcher.take() {
            handle.abort();
        }
    }
}
```

### 2.3.4 CacheInvalidationEvent / PromptCacheError

```rust
/// 缓存失效事件
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheInvalidationEvent {
    /// 触发失效的层级
    pub layer: PromptLayer,

    /// 失效的版本号
    pub version: u64,

    /// 全局版本号
    pub global_version: u64,

    /// 失效原因
    pub reason: InvalidationReason,

    /// 事件时间戳
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

/// 失效原因
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum InvalidationReason {
    /// 层内容更新
    LayerUpdated,
    /// 文件变更
    FileChanged,
    /// 手动失效
    ManualInvalidate,
    /// TTL 过期
    TtlExpired,
    /// 版本冲突
    VersionConflict,
}

/// Prompt 缓存错误
#[derive(Debug, Clone, thiserror::Error)]
pub enum PromptCacheError {
    /// 模板渲染失败
    #[error("Template render error: {0}")]
    TemplateRenderError(String),

    /// 变量未定义
    #[error("Undefined variable: {0}")]
    UndefinedVariable(String),

    /// 版本冲突
    #[error("Version conflict: event version {event_version} < current version {current_version}")]
    VersionConflict { event_version: u64, current_version: u64 },

    /// 过期事件
    #[error("Stale event: version {event_version} < current version {current_version}")]
    StaleEvent { event_version: u64, current_version: u64 },

    /// 文件监听错误
    #[error("File watcher error: {0}")]
    FileWatcherError(String),

    /// 模板加载失败
    #[error("Template load error: {0}")]
    TemplateLoadError(String),

    /// 锁冲突
    #[error("Lock mismatch: expected layer {expected}, got {actual}")]
    LockMismatch { expected: String, actual: String },
}
```

### 2.3.5 PromptTemplate / TemplateVariable / TemplateRenderer

```rust
use std::collections::HashMap;
use regex::Regex;

/// Prompt 模板
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PromptTemplate {
    /// 模板 ID
    pub id: String,

    /// 模板名称
    pub name: String,

    /// 模板内容（支持 {{variable}} 语法）
    pub content: String,

    /// 模板描述
    pub description: String,

    /// 必需变量列表
    pub required_variables: Vec<String>,

    /// 可选变量及其默认值
    pub optional_variables: HashMap<String, String>,

    /// 模板版本
    pub version: u64,

    /// 创建时间
    pub created_at: chrono::DateTime<chrono::Utc>,
}

impl PromptTemplate {
    /// 创建新的模板
    pub fn new(
        id: impl Into<String>,
        name: impl Into<String>,
        content: impl Into<String>,
    ) -> Self {
        Self {
            id: id.into(),
            name: name.into(),
            content: content.into(),
            description: String::new(),
            required_variables: Vec::new(),
            optional_variables: HashMap::new(),
            version: 0,
            created_at: chrono::Utc::now(),
        }
    }

    /// 设置必需变量
    pub fn with_required(mut self, vars: &[&str]) -> Self {
        self.required_variables = vars.iter().map(|s| s.to_string()).collect();
        self
    }

    /// 设置可选变量（带默认值）
    pub fn with_optional(mut self, key: impl Into<String>, default: impl Into<String>) -> Self {
        self.optional_variables.insert(key.into(), default.into());
        self
    }

    /// 提取模板中的所有变量名
    pub fn extract_variables(&self) -> Vec<String> {
        let re = Regex::new(r"\{\{(\w+)\}\}").unwrap();
        let mut vars: Vec<String> = re
            .captures_iter(&self.content)
            .map(|cap| cap[1].to_string())
            .collect();
        vars.sort();
        vars.dedup();
        vars
    }

    /// 验证变量完整性
    pub fn validate_variables(&self, provided: &HashMap<String, String>) -> Result<(), PromptCacheError> {
        for var in &self.required_variables {
            if !provided.contains_key(var) {
                return Err(PromptCacheError::UndefinedVariable(var.clone()));
            }
        }
        Ok(())
    }
}

/// 模板变量
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemplateVariable {
    /// 变量名
    pub name: String,

    /// 变量值
    pub value: String,

    /// 是否为必需
    pub required: bool,

    /// 默认值（可选）
    pub default_value: Option<String>,
}

/// 模板渲染器
///
/// 支持 {{variable}} 语法的变量替换。
/// 变量名仅允许 [a-zA-Z0-9_]。
pub struct TemplateRenderer {
    /// 变量集合
    variables: HashMap<String, String>,

    /// 变量正则表达式（预编译）
    var_regex: Regex,
}

impl TemplateRenderer {
    /// 创建新的渲染器
    pub fn new() -> Self {
        Self {
            variables: HashMap::new(),
            var_regex: Regex::new(r"\{\{(\w+)\}\}").unwrap(),
        }
    }

    /// 添加变量
    pub fn with_variable(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.variables.insert(key.into(), value.into());
        self
    }

    /// 批量添加变量
    pub fn with_variables(mut self, vars: &HashMap<String, String>) -> Self {
        for (k, v) in vars {
            self.variables.insert(k.clone(), v.clone());
        }
        self
    }

    /// 渲染模板
    ///
    /// 将模板中的 {{variable}} 替换为对应变量值。
    /// 未定义的变量保持原样（不替换）。
    pub fn render(&self, template: &str) -> Result<String, PromptCacheError> {
        let mut result = template.to_string();
        for cap in self.var_regex.captures_iter(template) {
            let var_name = &cap[1];
            if let Some(value) = self.variables.get(var_name) {
                result = result.replace(&cap[0], value);
            }
            // 未定义变量保持原样
        }
        Ok(result)
    }

    /// 渲染模板（严格模式）
    ///
    /// 未定义的变量返回错误。
    pub fn render_strict(&self, template: &str) -> Result<String, PromptCacheError> {
        let mut result = template.to_string();
        for cap in self.var_regex.captures_iter(template) {
            let var_name = &cap[1];
            match self.variables.get(var_name) {
                Some(value) => {
                    result = result.replace(&cap[0], value);
                }
                None => {
                    return Err(PromptCacheError::UndefinedVariable(var_name.to_string()));
                }
            }
        }
        Ok(result)
    }

    /// 获取所有未定义的变量
    pub fn undefined_variables(&self, template: &str) -> Vec<String> {
        let mut undefined = Vec::new();
        for cap in self.var_regex.captures_iter(template) {
            let var_name = &cap[1];
            if !self.variables.contains_key(var_name) {
                if !undefined.contains(&var_name.to_string()) {
                    undefined.push(var_name.to_string());
                }
            }
        }
        undefined
    }
}

impl Default for TemplateRenderer {
    fn default() -> Self {
        Self::new()
    }
}
```

### 2.3.6 TemplateManager

```rust
use std::path::{Path, PathBuf};

/// 模板管理器
///
/// 负责模板的加载、编译、缓存与生命周期管理。
pub struct TemplateManager {
    /// 模板存储（ID -> 模板）
    templates: RwLock<HashMap<String, PromptTemplate>>,

    /// 模板搜索路径
    search_paths: Vec<PathBuf>,

    /// 模板文件映射（文件路径 -> 模板 ID）
    file_mapping: RwLock<HashMap<PathBuf, String>>,
}

impl TemplateManager {
    /// 创建新的模板管理器
    pub fn new() -> Self {
        Self {
            templates: RwLock::new(HashMap::new()),
            search_paths: Vec::new(),
            file_mapping: RwLock::new(HashMap::new()),
        }
    }

    /// 添加模板搜索路径
    pub fn add_search_path(&mut self, path: impl Into<PathBuf>) {
        self.search_paths.push(path.into());
    }

    /// 注册模板
    pub async fn register(&self, template: PromptTemplate) -> Result<(), PromptCacheError> {
        let mut templates = self.templates.write().await;
        templates.insert(template.id.clone(), template);
        Ok(())
    }

    /// 获取模板
    pub async fn get(&self, id: &str) -> Result<PromptTemplate, PromptCacheError> {
        let templates = self.templates.read().await;
        templates
            .get(id)
            .cloned()
            .ok_or_else(|| PromptCacheError::TemplateLoadError(format!("Template '{id}' not found")))
    }

    /// 从文件加载模板
    ///
    /// 支持 .md / .yaml / .json 三种格式。
    pub async fn load_from_file(&self, path: &Path) -> Result<PromptTemplate, PromptCacheError> {
        let extension = path
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("");

        let content = tokio::fs::read_to_string(path)
            .await
            .map_err(|e| PromptCacheError::TemplateLoadError(format!("Failed to read file: {e}")))?;

        let template = match extension {
            "md" => {
                // Markdown 格式：文件名作为 ID，第一行 # 标题作为名称
                let id = path.file_stem().and_then(|s| s.to_str()).unwrap_or("unknown");
                let name = content
                    .lines()
                    .next()
                    .and_then(|line| line.strip_prefix("# "))
                    .unwrap_or(id);
                PromptTemplate::new(id, name, content)
            }
            "yaml" | "yml" => {
                // YAML 格式：解析为 PromptTemplate
                serde_yaml::from_str(&content)
                    .map_err(|e| PromptCacheError::TemplateLoadError(format!("YAML parse error: {e}")))?
            }
            "json" => {
                // JSON 格式：解析为 PromptTemplate
                serde_json::from_str(&content)
                    .map_err(|e| PromptCacheError::TemplateLoadError(format!("JSON parse error: {e}")))?
            }
            _ => {
                return Err(PromptCacheError::TemplateLoadError(format!(
                    "Unsupported format: {extension}"
                )));
            }
        };

        // 记录文件映射
        let mut mapping = self.file_mapping.write().await;
        mapping.insert(path.to_path_buf(), template.id.clone());

        // 注册模板
        self.register(template).await?;
        Ok(self.get(mapping.get(path).unwrap()).await?)
    }

    /// 列出所有已注册的模板 ID
    pub async fn list_templates(&self) -> Vec<String> {
        let templates = self.templates.read().await;
        templates.keys().cloned().collect()
    }

    /// 删除模板
    pub async fn unregister(&self, id: &str) -> Result<(), PromptCacheError> {
        let mut templates = self.templates.write().await;
        if templates.remove(id).is_none() {
            return Err(PromptCacheError::TemplateLoadError(format!(
                "Template '{id}' not found"
            )));
        }
        Ok(())
    }
}
```

### 2.3.7 PromptsLock / TemplateLockEntry / LockMismatch

```rust
/// Prompt 锁
///
/// 防止并发修改同一 Prompt 层的内容。
pub struct PromptsLock {
    /// 锁条目
    entries: RwLock<HashMap<String, TemplateLockEntry>>,

    /// 锁超时时间
    timeout: std::time::Duration,
}

/// 模板锁条目
#[derive(Debug, Clone)]
pub struct TemplateLockEntry {
    /// 持有者标识
    pub holder: String,

    /// 锁定的层级
    pub layer: PromptLayer,

    /// 获取锁的时间
    pub acquired_at: chrono::DateTime<chrono::Utc>,

    /// 锁的过期时间
    pub expires_at: chrono::DateTime<chrono::Utc>,
}

impl TemplateLockEntry {
    /// 判断锁是否已过期
    pub fn is_expired(&self) -> bool {
        chrono::Utc::now() > self.expires_at
    }
}

/// 锁冲突错误
#[derive(Debug, Clone, thiserror::Error)]
pub enum LockMismatch {
    /// 层级已被锁定
    #[error("Layer '{layer}' is locked by '{holder}' since {acquired_at}")]
    AlreadyLocked {
        layer: String,
        holder: String,
        acquired_at: chrono::DateTime<chrono::Utc>,
    },

    /// 锁持有者不匹配
    #[error("Lock holder mismatch: expected '{expected}', got '{actual}'")]
    HolderMismatch { expected: String, actual: String },

    /// 锁已过期
    #[error("Lock for layer '{layer}' has expired")]
    Expired { layer: String },
}

impl PromptsLock {
    /// 创建新的 Prompt 锁
    pub fn new(timeout: std::time::Duration) -> Self {
        Self {
            entries: RwLock::new(HashMap::new()),
            timeout,
        }
    }

    /// 尝试获取锁
    pub async fn acquire(
        &self,
        layer: PromptLayer,
        holder: impl Into<String>,
    ) -> Result<(), LockMismatch> {
        let holder = holder.into();
        let key = layer.name().to_string();
        let mut entries = self.entries.write().await;

        if let Some(entry) = entries.get(&key) {
            if !entry.is_expired() && entry.holder != holder {
                return Err(LockMismatch::AlreadyLocked {
                    layer: key,
                    holder: entry.holder.clone(),
                    acquired_at: entry.acquired_at,
                });
            }
        }

        let now = chrono::Utc::now();
        entries.insert(
            key,
            TemplateLockEntry {
                holder,
                layer,
                acquired_at: now,
                expires_at: now + chrono::Duration::from_std(self.timeout).unwrap(),
            },
        );

        Ok(())
    }

    /// 释放锁
    pub async fn release(
        &self,
        layer: PromptLayer,
        holder: impl Into<String>,
    ) -> Result<(), LockMismatch> {
        let holder = holder.into();
        let key = layer.name().to_string();
        let mut entries = self.entries.write().await;

        if let Some(entry) = entries.get(&key) {
            if entry.holder != holder {
                return Err(LockMismatch::HolderMismatch {
                    expected: entry.holder.clone(),
                    actual: holder,
                });
            }
            entries.remove(&key);
        }

        Ok(())
    }

    /// 清理过期锁
    pub async fn cleanup_expired(&self) {
        let mut entries = self.entries.write().await;
        entries.retain(|_, entry| !entry.is_expired());
    }
}
```

### 2.3.8 FileLayerMapping / start_file_watcher()

```rust
/// 文件与 Prompt 层的映射
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileLayerMapping {
    /// 文件路径
    pub file_path: PathBuf,

    /// 对应的 Prompt 层级
    pub layer: PromptLayer,

    /// 文件最后修改时间
    pub last_modified: std::time::SystemTime,

    /// 文件哈希（用于变更检测）
    pub content_hash: String,
}

impl FileLayerMapping {
    /// 创建新的文件映射
    pub fn new(file_path: impl Into<PathBuf>, layer: PromptLayer) -> Self {
        Self {
            file_path: file_path.into(),
            layer,
            last_modified: std::time::SystemTime::UNIX_EPOCH,
            content_hash: String::new(),
        }
    }

    /// 检查文件是否已变更
    pub fn has_changed(&self) -> bool {
        if let Ok(metadata) = std::fs::metadata(&self.file_path) {
            if let Ok(modified) = metadata.modified() {
                return modified != self.last_modified;
            }
        }
        false
    }

    /// 更新映射（读取文件并计算哈希）
    pub fn update(&mut self) -> Result<(), PromptCacheError> {
        let content = std::fs::read_to_string(&self.file_path)
            .map_err(|e| PromptCacheError::FileWatcherError(format!("Failed to read file: {e}")))?;

        self.content_hash = format!("{:x}", md5::compute(content.as_bytes()));
        self.last_modified = std::fs::metadata(&self.file_path)
            .and_then(|m| m.modified())
            .unwrap_or(std::time::SystemTime::UNIX_EPOCH);

        Ok(())
    }
}

/// 启动文件监听器
///
/// 使用 notify crate 监听指定路径下的文件变更。
/// 当检测到变更时，通过 broadcast 通道发送缓存失效事件。
///
/// # 支持的文件格式
/// - `.md` (Markdown)
/// - `.yaml` / `.yml` (YAML)
/// - `.json` (JSON)
///
/// # 参数
/// - `paths`: 监听的目录路径列表
/// - `tx`: 失效事件广播发送端
pub async fn start_file_watcher(
    paths: &[std::path::PathBuf],
    tx: broadcast::Sender<CacheInvalidationEvent>,
) -> Result<(), PromptCacheError> {
    use notify::{RecommendedWatcher, RecursiveMode, Watcher, Event as NotifyEvent, EventKind};

    let (notify_tx, mut notify_rx) = tokio::sync::mpsc::channel::<Result<NotifyEvent, notify::Error>>(64);

    // 创建 notify watcher
    let mut watcher = RecommendedWatcher::new(
        move |res| {
            let _ = notify_tx.blocking_send(res);
        },
        notify::Config::default(),
    )
    .map_err(|e| PromptCacheError::FileWatcherError(format!("Failed to create watcher: {e}")))?;

    // 注册监听路径
    for path in paths {
        watcher
            .watch(path, RecursiveMode::Recursive)
            .map_err(|e| {
                PromptCacheError::FileWatcherError(format!("Failed to watch path '{}': {e}", path.display()))
            })?;
    }

    // 事件处理循环
    while let Some(result) = notify_rx.recv().await {
        match result {
            Ok(event) => {
                // 只处理文件修改/创建/删除事件
                match event.kind {
                    EventKind::Create(_)
                    | EventKind::Modify(_)
                    | EventKind::Remove(_) => {
                        for path in &event.paths {
                            let extension = path
                                .extension()
                                .and_then(|e| e.to_str())
                                .unwrap_or("");

                            if matches!(extension, "md" | "yaml" | "yml" | "json") {
                                let _ = tx.send(CacheInvalidationEvent {
                                    layer: PromptLayer::Project, // 默认为项目层
                                    version: 0,
                                    global_version: 0,
                                    reason: InvalidationReason::FileChanged,
                                    timestamp: chrono::Utc::now(),
                                });
                            }
                        }
                    }
                    _ => {}
                }
            }
            Err(e) => {
                tracing::warn!("File watch error: {}", e);
            }
        }
    }

    Ok(())
}
```

### 2.3.9 CacheWarmupStrategy / WarmupResult

```rust
/// 缓存预热策略
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CacheWarmupStrategy {
    /// 无预热
    None,

    /// 启动时预热所有层
    FullWarmup,

    /// 仅预热指定层级
    Selective {
        /// 预热的层级列表
        layers: Vec<PromptLayer>,
    },

    /// 基于使用频率预热
    FrequencyBased {
        /// 最小使用次数阈值
        min_access_count: u32,
        /// 最大预热条目数
        max_entries: usize,
    },

    /// 基于成本优化预热
    CostOptimized {
        /// 预算限制（美分）
        budget_cents: u64,
        /// 预期命中率阈值
        min_hit_rate: f64,
    },
}

/// 预热结果
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct WarmupResult {
    /// 预热的条目数
    pub entries_warmed: usize,

    /// 预热耗时（毫秒）
    pub duration_ms: u64,

    /// 预估节省的 Token 数
    pub estimated_tokens_saved: u64,

    /// 预估节省的成本（美分）
    pub estimated_cost_saved_cents: u64,

    /// 预热失败的条目数
    pub failed_entries: usize,

    /// 失败原因
    pub failures: Vec<String>,
}

impl WarmupResult {
    /// 合并多个预热结果
    pub fn merge(results: Vec<WarmupResult>) -> Self {
        let mut merged = Self::default();
        for result in results {
            merged.entries_warmed += result.entries_warmed;
            merged.duration_ms += result.duration_ms;
            merged.estimated_tokens_saved += result.estimated_tokens_saved;
            merged.estimated_cost_saved_cents += result.estimated_cost_saved_cents;
            merged.failed_entries += result.failed_entries;
            merged.failures.extend(result.failures);
        }
        merged
    }
}
```

### 2.3.10 should_set_cache_breakpoint() / calculate_cache_savings()

```rust
use crate::mc_llm::{ChatMessage, CacheControlType, TokenUsage};

/// 判断是否应设置缓存断点
///
/// 仅在以下条件满足时返回 true：
/// 1. Turn 层消息数 >= 3
/// 2. 系统提示词 Token 数 >= 128
/// 3. 总消息 Token 数 >= 256
///
/// # 参数
/// - `messages`: 当前消息列表
///
/// # 返回
/// 是否应设置缓存断点
pub fn should_set_cache_breakpoint(messages: &[ChatMessage]) -> bool {
    if messages.len() < 3 {
        return false;
    }

    // 计算系统提示词 Token 数
    let system_tokens: usize = messages
        .iter()
        .filter(|m| matches!(m.role, crate::mc_llm::MessageRole::System))
        .map(|m| crate::mc_llm::estimate_text_tokens(&m.content.to_text()))
        .sum();

    if system_tokens < 128 {
        return false;
    }

    // 计算总 Token 数
    let total_tokens: usize = messages
        .iter()
        .map(|m| crate::mc_llm::estimate_text_tokens(&m.content.to_text()))
        .sum();

    total_tokens >= 256
}

/// 计算缓存节省
///
/// 估算使用 Prompt Caching 后可节省的 Token 数与成本。
///
/// # 参数
/// - `usage`: 当前 Token 使用统计
/// - `model_info`: 模型信息（用于计算价格）
/// - `cache_ttl_secs`: 缓存 TTL（秒）
/// - `estimated_requests_per_ttl`: TTL 内预估请求数
///
/// # 返回
/// (节省的 Token 数, 节省的成本（美分）)
pub fn calculate_cache_savings(
    usage: &TokenUsage,
    model_info: &crate::mc_llm::ModelInfo,
    cache_ttl_secs: u64,
    estimated_requests_per_ttl: u32,
) -> (u64, u64) {
    // 每次请求可缓存的 Token 数
    let cacheable_tokens = usage.prompt_tokens as u64;

    // TTL 内总缓存命中 Token 数
    let total_cached_tokens = cacheable_tokens * estimated_requests_per_ttl as u64;

    // 节省的成本（非缓存输入价格 - 缓存读取价格）
    let savings_per_1k = model_info.input_price_per_1k - model_info.cache_read_price_per_1k;
    let savings_cents = ((total_cached_tokens as f64 / 1000.0) * savings_per_1k * 100.0).ceil() as u64;

    (total_cached_tokens, savings_cents)
}
```

---

## 2.4 功能需求清单

### FR-PROMPT-001：四层 Prompt 管理

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 支持 Global / Organization / Project / Session / Turn 五层 Prompt 的分层管理 |
| **验收标准** | 1. 各层独立存储与更新；2. 高优先级层覆盖低优先级层；3. `build_messages()` 按优先级合并 |

### FR-PROMPT-002：变量替换

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 支持 `{{variable}}` 语法的模板变量替换 |
| **验收标准** | 1. 正确替换已定义变量；2. 未定义变量在非严格模式下保持原样；3. 严格模式下返回 `UndefinedVariable` 错误 |

### FR-PROMPT-003：版本追踪

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 每层 Prompt 维护独立版本号，全局版本号单调递增 |
| **验收标准** | 1. 更新时版本号递增；2. 失效事件携带版本号；3. 过期事件被正确拒绝 |

### FR-PROMPT-004：文件监听

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 通过 notify crate 监听 Prompt 文件变更，自动触发缓存失效 |
| **验收标准** | 1. 监听 .md / .yaml / .json 文件；2. 文件变更时发送失效事件；3. 支持递归监听 |

### FR-PROMPT-005：缓存预热

| 属性 | 说明 |
|------|------|
| **优先级** | P2 |
| **描述** | 支持多种预热策略，启动时预热高频 Prompt |
| **验收标准** | 1. `FullWarmup` 预热所有层；2. `FrequencyBased` 按使用频率排序；3. `WarmupResult` 正确统计 |

---

## 2.5 接口契约

### IC-PROMPT-001：PromptLayerManager::update_layer

```
输入: layer: PromptLayer, system_prompt: String, variables: HashMap<String, String>
输出: Result<u64, PromptCacheError>（新版本号）
副作用: 广播 CacheInvalidationEvent
并发安全: 是（RwLock）
```

### IC-PROMPT-002：PromptLayerManager::build_messages

```
输入: turn_messages: &[TurnMessage], template_vars: &HashMap<String, String>
输出: Result<Vec<ChatMessage>, PromptCacheError>
行为: 按优先级合并各层系统提示词，追加轮次消息，设置缓存断点
```

### IC-PROMPT-003：TemplateRenderer::render

```
输入: template: &str
输出: Result<String, PromptCacheError>
行为: 替换 {{variable}} 为变量值，未定义变量保持原样
```

### IC-PROMPT-004：should_set_cache_breakpoint

```
输入: messages: &[ChatMessage]
输出: bool
条件: Turn 消息 >= 3 && 系统 Token >= 128 && 总 Token >= 256
```

---

## 2.6 测试要点

### TC-PROMPT-001：PromptLayer 测试

| 测试项 | 说明 |
|--------|------|
| 层级排序 | 验证 `all()` 返回按优先级排序的数组 |
| depth() | 验证 Global=0, Turn=4 |
| name() | 验证各层级名称正确 |

### TC-PROMPT-002：PromptLayerManager 测试

| 测试项 | 说明 |
|--------|------|
| update_layer | 验证版本号递增 |
| build_messages | 验证消息按优先级合并 |
| on_invalidation | 验证过期事件被拒绝 |
| get_version | 验证版本号正确返回 |
| 并发更新 | 多线程同时更新不同层，验证无死锁 |

### TC-PROMPT-003：TemplateRenderer 测试

| 测试项 | 说明 |
|--------|------|
| 基本替换 | `{{name}}` -> `Alice` |
| 多变量替换 | 多个变量同时替换 |
| 未定义变量 | 非严格模式保持原样 |
| 严格模式 | 未定义变量返回错误 |
| 嵌套变量 | `{{{{name}}}}` 不处理嵌套 |

### TC-PROMPT-004：缓存断点测试

| 测试项 | 说明 |
|--------|------|
| 消息不足 | 消息 < 3 条，返回 false |
| Token 不足 | 系统 Token < 128，返回 false |
| 正常设置 | 满足条件时返回 true |

### TC-PROMPT-005：文件监听测试

| 测试项 | 说明 |
|--------|------|
| 文件创建 | 新建文件触发事件 |
| 文件修改 | 修改文件触发事件 |
| 文件删除 | 删除文件触发事件 |
| 非支持格式 | .txt 文件不触发事件 |

---

# P2-3 mc-sandbox — 权限与沙箱安全

## 3.1 模块概述

`mc-sandbox` 是 MoreCode 的安全执行层，负责：

1. **Guardian 守护进程**：核心安全检查组件，通过 `GuardianMode` 控制不同安全级别，所有工具调用必须经过 `check_tool_call` 检查。
2. **命令白名单与路径限制**：`CommandWhitelist` 定义允许执行的命令集合，`PathRestriction` 限制文件系统访问范围。
3. **结构化危险命令检测**：`parse_command` + `check_destructive_patterns` 对 shell 命令进行结构化解析，识别破坏性操作。
4. **权限管理**：`TaskPermissionManager` 管理任务级权限，`Capability` 声明工具所需能力，`Drop` trait 自动清理过期权限。
5. **沙箱策略**：`LandlockConfig`（Linux 内核级沙箱）、`WasmSandbox`（WASM 沙箱）提供多层隔离。
6. **审计日志**：所有工具调用始终记录审计日志，不可关闭。

### 架构文档引用

| 文档 | 关联章节 |
|------|----------|
| `13-权限与沙箱安全.md` | 全文 — Guardian 设计、权限模型、沙箱策略、审计日志、TOCTOU 缓解 |

---

## 3.2 大模型开发提示词

```
你是 MoreCode 项目的 mc-sandbox 模块开发者。请遵循以下规范：

1. 所有工具调用必须经过 Guardian::check_tool_call 检查，无例外。
2. audit_enabled 始终为 true，禁止提供关闭审计日志的选项。
3. GuardianMode::Bypass 仍需拦截破坏性命令（rm -rf /、format、mkfs 等）。
4. 命令解析使用 parse_command 进行结构化检查，禁止直接执行字符串拼接的命令。
5. 路径限制使用 PathRestriction::is_allowed 检查，禁止通过符号链接绕过。
6. TOCTOU 缓解：文件操作使用 openat2 + RESOLVE_NO_SYMLINKS。
7. TaskPermissionManager 使用 Drop trait 自动清理过期权限。
8. CapabilityDeclaration 必须声明工具的所有能力需求。
9. ShellExecTool 使用 regex::escape 转义用户输入，防止命令注入。
10. 所有审计日志包含：时间戳、调用者、工具名、参数、决策结果。
```

---

## 3.3 核心类型定义

### 3.3.1 Guardian struct

```rust
use std::collections::{HashMap, HashSet};
use std::path::PathBuf;
use std::sync::Arc;
use tokio::sync::RwLock;

/// 安全守护进程
///
/// 所有工具调用的安全检查入口。
/// 审计日志始终启用，不可关闭。
pub struct Guardian {
    /// 安全模式
    mode: RwLock<GuardianMode>,

    /// 安全命令白名单
    safe_commands: RwLock<CommandWhitelist>,

    /// 受保护路径列表
    protected_paths: RwLock<Vec<PathRestriction>>,

    /// 审计日志（始终启用）
    audit_log: Arc<AuditLogger>,

    /// 审计启用标志（始终 true）
    audit_enabled: bool,
}

impl Guardian {
    /// 创建新的 Guardian 实例
    ///
    /// # 参数
    /// - `mode`: 初始安全模式
    /// - `safe_commands`: 安全命令白名单
    /// - `protected_paths`: 受保护路径列表
    pub fn new(
        mode: GuardianMode,
        safe_commands: CommandWhitelist,
        protected_paths: Vec<PathRestriction>,
    ) -> Self {
        Self {
            mode: RwLock::new(mode),
            safe_commands: RwLock::new(safe_commands),
            protected_paths: RwLock::new(protected_paths),
            audit_log: Arc::new(AuditLogger::new()),
            audit_enabled: true, // 始终为 true
        }
    }

    /// 检查工具调用是否被允许
    ///
    /// 即使在 Bypass 模式下，破坏性命令仍会被拦截。
    ///
    /// # 参数
    /// - `caller`: 调用者标识
    /// - `tool_name`: 工具名称
    /// - `args`: 工具调用参数
    ///
    /// # 返回
    /// 守护决策
    pub async fn check_tool_call(
        &self,
        caller: &str,
        tool_name: &str,
        args: &ToolCallArgs,
    ) -> GuardianDecision {
        let mode = self.mode.read().await;
        let safe_commands = self.safe_commands.read().await;
        let protected_paths = self.protected_paths.read().await;

        // 步骤 1：检查破坏性命令（所有模式下均执行）
        if let Some(command) = &args.command {
            if is_destructive_command(command) {
                let decision = GuardianDecision::Blocked {
                    reason: format!("Destructive command detected: {command}"),
                    rule_id: "DESTRUCTIVE_CMD".to_string(),
                };
                self.audit_log.log(AuditEntry {
                    timestamp: chrono::Utc::now(),
                    caller: caller.to_string(),
                    tool_name: tool_name.to_string(),
                    args: format!("{args:?}"),
                    decision: decision.clone(),
                    mode: *mode,
                });
                return decision;
            }
        }

        // 步骤 2：Bypass 模式下，非破坏性命令直接放行
        if matches!(mode, GuardianMode::Bypass) {
            let decision = GuardianDecision::Allowed {
                conditions: vec!["Bypass mode: destructive checks only".to_string()],
            };
            self.audit_log.log(AuditEntry {
                timestamp: chrono::Utc::now(),
                caller: caller.to_string(),
                tool_name: tool_name.to_string(),
                args: format!("{args:?}"),
                decision: decision.clone(),
                mode: *mode,
            });
            return decision;
        }

        // 步骤 3：检查命令白名单
        if let Some(command) = &args.command {
            if !safe_commands.is_safe(command) {
                let decision = GuardianDecision::Blocked {
                    reason: format!("Command not in whitelist: {command}"),
                    rule_id: "CMD_NOT_WHITELISTED".to_string(),
                };
                self.audit_log.log(AuditEntry {
                    timestamp: chrono::Utc::now(),
                    caller: caller.to_string(),
                    tool_name: tool_name.to_string(),
                    args: format!("{args:?}"),
                    decision: decision.clone(),
                    mode: *mode,
                });
                return decision;
            }
        }

        // 步骤 4：检查路径限制
        if let Some(target_path) = &args.target_path {
            for restriction in protected_paths.iter() {
                if !restriction.is_allowed(target_path) {
                    let decision = GuardianDecision::Blocked {
                        reason: format!("Path access denied: {target_path:?}"),
                        rule_id: "PATH_RESTRICTED".to_string(),
                    };
                    self.audit_log.log(AuditEntry {
                        timestamp: chrono::Utc::now(),
                        caller: caller.to_string(),
                        tool_name: tool_name.to_string(),
                        args: format!("{args:?}"),
                        decision: decision.clone(),
                        mode: *mode,
                    });
                    return decision;
                }
            }
        }

        // 步骤 5：根据模式决定
        let decision = match mode {
            GuardianMode::Strict => GuardianDecision::NeedsApproval {
                reason: "Strict mode requires explicit approval".to_string(),
                required_capabilities: vec![],
            },
            GuardianMode::Standard => GuardianDecision::Allowed {
                conditions: vec!["Standard mode: all checks passed".to_string()],
            },
            GuardianMode::Sandboxed => GuardianDecision::Allowed {
                conditions: vec!["Sandboxed mode: executing in restricted environment".to_string()],
            },
            GuardianMode::ReadOnly => {
                if args.is_write {
                    GuardianDecision::Blocked {
                        reason: "Write operation not allowed in ReadOnly mode".to_string(),
                        rule_id: "READONLY_VIOLATION".to_string(),
                    }
                } else {
                    GuardianDecision::Allowed {
                        conditions: vec!["ReadOnly mode: read operation allowed".to_string()],
                    }
                }
            }
            GuardianMode::Bypass => unreachable!(), // 已在步骤 2 处理
        };

        self.audit_log.log(AuditEntry {
            timestamp: chrono::Utc::now(),
            caller: caller.to_string(),
            tool_name: tool_name.to_string(),
            args: format!("{args:?}"),
            decision: decision.clone(),
            mode: *mode,
        });

        decision
    }

    /// 设置安全模式
    pub async fn set_mode(&self, mode: GuardianMode) {
        let mut current = self.mode.write().await;
        *current = mode;
    }

    /// 获取当前安全模式
    pub async fn get_mode(&self) -> GuardianMode {
        *self.mode.read().await
    }

    /// 添加受保护路径
    pub async fn add_protected_path(&self, restriction: PathRestriction) {
        let mut paths = self.protected_paths.write().await;
        paths.push(restriction);
    }

    /// 获取审计日志引用
    pub fn audit_log(&self) -> Arc<AuditLogger> {
        Arc::clone(&self.audit_log)
    }
}
```

### 3.3.2 GuardianMode / GuardianDecision

```rust
/// Guardian 权限模式
///
/// 权威定义来源：13-权限与沙箱安全.md §权限模式
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum GuardianMode {
    /// 默认模式：写操作和危险命令需用户确认
    Default,
    /// 自动模式：放行所有调用（仅限可信环境）
    Auto,
    /// 只读模式：仅允许只读操作
    ReadOnly,
    /// 规划模式：只规划不执行
    Plan,
    /// 绕过模式：跳过所有检查（仅内部调试）
    Bypass,
}

impl Default for GuardianMode {
    fn default() -> Self {
        GuardianMode::Default
    }
}

impl std::fmt::Display for GuardianMode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            GuardianMode::Default => write!(f, "default"),
            GuardianMode::Auto => write!(f, "auto"),
            GuardianMode::ReadOnly => write!(f, "readonly"),
            GuardianMode::Plan => write!(f, "plan"),
            GuardianMode::Bypass => write!(f, "bypass"),
        }
    }
}

/// Guardian 检查结果
///
/// 权威定义来源：13-权限与沙箱安全.md §检查结果
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum GuardianDecision {
    /// 允许执行
    Allow,
    /// 拒绝执行
    Deny { reason: String },
    /// 需要用户确认
    ConfirmRequired { reason: String },
    /// 模拟执行（Plan 模式下返回模拟结果而非实际执行）
    Simulate { mock_result: String },
}

impl GuardianDecision {
    /// 判断是否被允许
    pub fn is_allowed(&self) -> bool {
        matches!(self, GuardianDecision::Allow)
    }

    /// 判断是否被拦截
    pub fn is_blocked(&self) -> bool {
        matches!(self, GuardianDecision::Deny { .. })
    }
}
```

### 3.3.3 命令解析与检查

```rust
use regex::Regex;

/// 解析命令字符串为结构化形式
///
/// 提取命令名和参数，支持引号包裹的参数。
///
/// # 示例
/// ```
/// let parsed = parse_command("git commit -m \"hello world\"");
/// assert_eq!(parsed.command, "git");
/// assert_eq!(parsed.args, vec!["commit", "-m", "hello world"]);
/// ```
pub fn parse_command(input: &str) -> ParsedCommand {
    let mut chars = input.trim().chars().peekable();
    let mut command = String::new();
    let mut args = Vec::new();
    let mut current_arg = String::new();
    let mut in_quotes = false;
    let mut quote_char = ' ';
    let mut in_escape = false;

    // 提取命令名（第一个 token）
    while let Some(&ch) = chars.peek() {
        if ch.is_whitespace() {
            if !command.is_empty() {
                chars.next();
                break;
            }
            chars.next();
        } else {
            command.push(ch);
            chars.next();
        }
    }

    // 提取参数
    while let Some(&ch) = chars.peek() {
        if in_escape {
            current_arg.push(ch);
            in_escape = false;
            chars.next();
        } else if ch == '\\' {
            in_escape = true;
            chars.next();
        } else if in_quotes {
            if ch == quote_char {
                in_quotes = false;
                chars.next();
            } else {
                current_arg.push(ch);
                chars.next();
            }
        } else if ch == '"' || ch == '\'' {
            in_quotes = true;
            quote_char = ch;
            chars.next();
        } else if ch.is_whitespace() {
            if !current_arg.is_empty() {
                args.push(current_arg.clone());
                current_arg.clear();
            }
            chars.next();
        } else {
            current_arg.push(ch);
            chars.next();
        }
    }

    if !current_arg.is_empty() {
        args.push(current_arg);
    }

    ParsedCommand { command, args }
}

/// 解析后的命令
#[derive(Debug, Clone)]
pub struct ParsedCommand {
    /// 命令名
    pub command: String,
    /// 参数列表
    pub args: Vec<String>,
}

impl ParsedCommand {
    /// 获取完整命令字符串
    pub fn full_command(&self) -> String {
        let mut cmd = self.command.clone();
        for arg in &self.args {
            cmd.push(' ');
            if arg.contains(' ') || arg.contains('"') {
                cmd.push_str(&format!("\"{}\"", arg.replace('"', "\\\"")));
            } else {
                cmd.push_str(arg);
            }
        }
        cmd
    }
}

/// 判断命令是否在安全白名单中
pub fn is_safe_command(command: &str, whitelist: &CommandWhitelist) -> bool {
    let parsed = parse_command(command);
    whitelist.is_safe(&parsed.command)
}

/// 判断命令是否为破坏性命令
///
/// 检查以下模式：
/// - `rm -rf /` 或 `rm -rf /*`
/// - `format` / `mkfs`
/// - `dd if=/dev/zero`
/// - `> /dev/sda`
/// - `chmod -R 777 /`
/// - `shutdown` / `reboot` / `halt` / `poweroff`
/// - `mv / /dev/null`
/// - `:(){ :|:& };:` (fork bomb)
pub fn is_destructive_command(command: &str) -> bool {
    let cmd_lower = command.to_lowercase();
    let parsed = parse_command(command);

    // 检查命令名
    let destructive_commands = [
        "format", "mkfs", "mkfs.", "fdisk", "parted",
        "shutdown", "reboot", "halt", "poweroff", "init",
    ];
    for dc in &destructive_commands {
        if parsed.command == *dc || parsed.command.starts_with(dc) {
            return true;
        }
    }

    // 检查危险模式
    let dangerous_patterns = [
        "rm -rf /",
        "rm -rf /*",
        "rm -rf ~",
        "dd if=/dev/zero",
        "dd of=/dev/",
        "> /dev/sd",
        "chmod -r 777 /",
        "chmod 777 /",
        "mv / /dev",
        "mv /* /dev",
        ":(){ :|:& };:",
        "fork bomb",
        "> /dev/null",
        "curl | sh",
        "curl | bash",
        "wget | sh",
        "wget | bash",
    ];

    for pattern in &dangerous_patterns {
        if cmd_lower.contains(pattern) {
            return true;
        }
    }

    false
}

/// 结构化危险命令检查（替代正则匹配，防止 `rm --recursive --force /` 等绕过）
///
/// 权威定义来源：13-权限与沙箱安全.md §结构化危险命令检测
/// 使用 ParsedCommand 的 argv 进行精确匹配，而非字符串 contains。
pub fn check_destructive_patterns(parsed: &ParsedCommand) -> Option<String> {
    match parsed.executable_name.as_str() {
        "rm" => {
            let has_recursive = parsed.argv.iter().any(|a| {
                matches!(a.as_str(), "-r" | "-R" | "-rf" | "-fr" | "--recursive" | "-Rf")
            });
            let has_force = parsed.argv.iter().any(|a| {
                matches!(a.as_str(), "-f" | "--force")
            });
            if has_recursive && has_force {
                let targets: Vec<_> = parsed.argv.iter()
                    .filter(|a| a.starts_with('/') || a == "*" || a == ".*")
                    .collect();
                if targets.iter().any(|t| t.starts_with('/') || *t == "*" || *t == ".*") {
                    return Some(format!("rm 递归强制删除根目录或通配符: {:?}", targets));
                }
            }
        }
        "sudo" | "su" | "doas" | "run0" => {
            return Some(format!("权限提升命令被拦截: {}", parsed.executable_name));
        }
        "chmod" | "chown" | "chgrp" => {
            let targets: Vec<_> = parsed.argv.iter()
                .filter(|a| a.starts_with('/'))
                .collect();
            let system_paths = ["/etc", "/usr", "/bin", "/sbin", "/boot", "/lib", "/var"];
            if targets.iter().any(|t| system_paths.iter().any(|p| t.starts_with(p))) {
                return Some(format!("系统路径权限修改被拦截: {:?}", targets));
            }
        }
        "mkfs" | "dd" | "shred" => {
            return Some(format!("磁盘/数据破坏性命令被拦截: {}", parsed.executable_name));
        }
        _ => {}
    }
    None
}

/// 结构化命令解析结果（用于危险命令检测）
#[derive(Debug, Clone)]
pub struct ParsedCommand {
    /// 可执行文件名（不含路径）
    pub executable_name: String,
    /// 命令行参数列表
    pub argv: Vec<String>,
}
```

### 3.3.4 ToolCallArgs

```rust
/// 工具调用参数
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolCallArgs {
    /// 要执行的命令（可选）
    pub command: Option<String>,

    /// 目标路径（可选）
    pub target_path: Option<PathBuf>,

    /// 是否为写操作
    pub is_write: bool,

    /// 额外参数
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub extra: HashMap<String, serde_json::Value>,
}

impl ToolCallArgs {
    /// 创建文件读取参数
    pub fn file_read(path: impl Into<PathBuf>) -> Self {
        Self {
            command: None,
            target_path: Some(path.into()),
            is_write: false,
            extra: HashMap::new(),
        }
    }

    /// 创建文件写入参数
    pub fn file_write(path: impl Into<PathBuf>) -> Self {
        Self {
            command: None,
            target_path: Some(path.into()),
            is_write: true,
            extra: HashMap::new(),
        }
    }

    /// 创建命令执行参数
    pub fn shell_exec(command: impl Into<String>) -> Self {
        Self {
            command: Some(command.into()),
            target_path: None,
            is_write: false,
            extra: HashMap::new(),
        }
    }

    /// 推导此工具调用所需的 Capability
    ///
    /// 权威定义来源：13-权限与沙箱安全.md §ToolCallArgs
    pub fn required_capability(&self) -> Capability {
        if self.is_write {
            Capability::WriteFile {
                pattern: self.target_path
                    .as_ref()
                    .map(|p| p.to_string_lossy().to_string())
                    .unwrap_or_default(),
            }
        } else {
            Capability::ReadFile {
                pattern: self.target_path
                    .as_ref()
                    .map(|p| p.to_string_lossy().to_string())
                    .unwrap_or_default(),
            }
        }
    }
}
```

### 3.3.5 TaskPermission / Capability / TaskPermissionManager

```rust
use std::collections::HashMap;
use std::time::{Duration, Instant};

/// 任务权限
#[derive(Debug, Clone)]
pub struct TaskPermission {
    /// 任务 ID
    pub task_id: String,

    /// 授予的能力列表
    pub capabilities: Vec<Capability>,

    /// 权限创建时间
    pub created_at: Instant,

    /// 权限过期时间
    pub expires_at: Instant,

    /// 最大使用次数
    pub max_uses: Option<u32>,

    /// 已使用次数
    pub uses: u32,
}

impl TaskPermission {
    /// 判断权限是否已过期
    pub fn is_expired(&self) -> bool {
        Instant::now() > self.expires_at
    }

    /// 判断权限是否已耗尽
    pub fn is_exhausted(&self) -> bool {
        if let Some(max) = self.max_uses {
            self.uses >= max
        } else {
            false
        }
    }

    /// 判断权限是否有效
    pub fn is_valid(&self) -> bool {
        !self.is_expired() && !self.is_exhausted()
    }

    /// 记录一次使用
    pub fn record_use(&mut self) {
        self.uses += 1;
    }

    /// 检查是否拥有指定能力
    pub fn has_capability(&self, cap: &Capability) -> bool {
        self.capabilities.iter().any(|c| c == cap)
    }
}

/// 能力类型——细粒度的权限描述
///
/// 权威定义来源：13-权限与沙箱安全.md §能力类型
/// 每个 Capability 携带 pattern 参数，用于精确控制权限范围。
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Capability {
    /// 读取文件（pattern 为允许的路径 glob）
    ReadFile {
        pattern: String,
    },
    /// 写入文件（pattern 为允许的路径 glob）
    WriteFile {
        pattern: String,
    },
    /// 执行命令（pattern 为允许的命令正则）
    RunCommand {
        pattern: String,
    },
    /// 网络访问（pattern 为允许的域名/IP glob）
    NetworkAccess {
        pattern: String,
    },
}

impl std::fmt::Display for Capability {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Capability::ReadFile { pattern } => write!(f, "read_file({pattern})"),
            Capability::WriteFile { pattern } => write!(f, "write_file({pattern})"),
            Capability::RunCommand { pattern } => write!(f, "run_command({pattern})"),
            Capability::NetworkAccess { pattern } => write!(f, "network_access({pattern})"),
        }
    }
}

/// 任务权限管理器
///
/// 管理任务级权限的生命周期。
/// 使用 Drop trait 自动清理过期权限。
pub struct TaskPermissionManager {
    /// 权限存储
    permissions: RwLock<HashMap<String, TaskPermission>>,

    /// 默认 TTL
    default_ttl: Duration,

    /// 清理间隔
    cleanup_interval: Duration,
}

impl TaskPermissionManager {
    /// 创建新的权限管理器
    pub fn new(default_ttl: Duration) -> Self {
        Self {
            permissions: RwLock::new(HashMap::new()),
            default_ttl,
            cleanup_interval: Duration::from_secs(60),
        }
    }

    /// 授予权限
    pub async fn grant(
        &self,
        task_id: impl Into<String>,
        capabilities: Vec<Capability>,
    ) -> TaskPermission {
        let task_id = task_id.into();
        let now = Instant::now();
        let permission = TaskPermission {
            task_id: task_id.clone(),
            capabilities,
            created_at: now,
            expires_at: now + self.default_ttl,
            max_uses: None,
            uses: 0,
        };

        let mut permissions = self.permissions.write().await;
        permissions.insert(task_id, permission.clone());
        permission
    }

    /// 授予有限次使用的权限
    pub async fn grant_limited(
        &self,
        task_id: impl Into<String>,
        capabilities: Vec<Capability>,
        max_uses: u32,
    ) -> TaskPermission {
        let task_id = task_id.into();
        let now = Instant::now();
        let permission = TaskPermission {
            task_id: task_id.clone(),
            capabilities,
            created_at: now,
            expires_at: now + self.default_ttl,
            max_uses: Some(max_uses),
            uses: 0,
        };

        let mut permissions = self.permissions.write().await;
        permissions.insert(task_id, permission.clone());
        permission
    }

    /// 检查权限
    pub async fn check_permission(
        &self,
        task_id: &str,
        required: &Capability,
    ) -> PermissionCheckResult {
        let mut permissions = self.permissions.write().await;

        match permissions.get_mut(task_id) {
            Some(perm) => {
                if !perm.is_valid() {
                    permissions.remove(task_id);
                    PermissionCheckResult::Denied {
                        reason: if perm.is_expired() {
                            "Permission expired".to_string()
                        } else {
                            "Permission exhausted".to_string()
                        },
                    }
                } else if perm.has_capability(required) {
                    perm.record_use();
                    PermissionCheckResult::Granted
                } else {
                    PermissionCheckResult::Denied {
                        reason: format!("Missing capability: {required}"),
                    }
                }
            }
            None => PermissionCheckResult::Denied {
                reason: format!("No permission for task '{task_id}'"),
            },
        }
    }

    /// 撤销权限
    pub async fn revoke(&self, task_id: &str) {
        let mut permissions = self.permissions.write().await;
        permissions.remove(task_id);
    }

    /// 清理过期权限（自动调用）
    pub async fn cleanup_expired(&self) {
        let mut permissions = self.permissions.write().await;
        permissions.retain(|_, perm| perm.is_valid());
    }
}

impl Drop for TaskPermissionManager {
    fn drop(&mut self) {
        // Drop 时清理所有权限
        // 注意：由于 RwLock 的异步特性，这里使用 try_write
        if let Ok(mut permissions) = self.permissions.try_write() {
            permissions.clear();
        }
    }
}

/// 权限检查结果
#[derive(Debug, Clone)]
pub enum PermissionCheckResult {
    /// 授予
    Granted,
    /// 拒绝
    Denied { reason: String },
}
```

### 3.3.6 CapabilityDeclaration trait / FileReadTool / ShellExecTool

```rust
/// 能力声明 trait
///
/// 所有工具必须实现此 trait，声明其所需的能力。
pub trait CapabilityDeclaration {
    /// 返回工具所需的能力列表
    fn required_capabilities(&self) -> Vec<Capability>;

    /// 返回工具是否为只读
    fn is_read_only(&self) -> bool;

    /// 返回工具名称
    fn tool_name(&self) -> &str;
}

/// 文件读取工具
pub struct FileReadTool {
    /// 允许读取的路径前缀
    allowed_prefixes: Vec<PathBuf>,
}

impl FileReadTool {
    pub fn new(allowed_prefixes: Vec<PathBuf>) -> Self {
        Self { allowed_prefixes }
    }

    /// 读取文件内容
    ///
    /// # TOCTOU 缓解
    /// 使用 openat2 + RESOLVE_NO_SYMLINKS 防止符号链接竞态。
    pub async fn read_file(&self, path: &std::path::Path) -> Result<String, SandboxError> {
        // 检查路径前缀
        let canonical = path
            .canonicalize()
            .map_err(|e| SandboxError::PathAccessDenied {
                path: path.to_path_buf(),
                reason: format!("Cannot canonicalize path: {e}"),
            })?;

        let is_allowed = self.allowed_prefixes.iter().any(|prefix| {
            canonical.starts_with(prefix)
        });

        if !is_allowed {
            return Err(SandboxError::PathAccessDenied {
                path: path.to_path_buf(),
                reason: "Path not in allowed prefixes".to_string(),
            });
        }

        // TOCTOU 缓解：使用 O_NOFOLLOW 打开
        #[cfg(target_os = "linux")]
        {
            use std::os::unix::ffi::OsStrExt;
            let path_bytes = path.as_os_str().as_bytes();
            // 使用 openat2 + RESOLVE_NO_SYMLINKS（Linux 5.6+）
            // 回退到 O_NOFOLLOW
            let fd = unsafe {
                libc::open(
                    path_bytes.as_ptr() as *const i8,
                    libc::O_RDONLY | libc::O_NOFOLLOW,
                    0,
                )
            };

            if fd < 0 {
                return Err(SandboxError::PathAccessDenied {
                    path: path.to_path_buf(),
                    reason: "Cannot open file (possible symlink)".to_string(),
                });
            }

            // 读取文件内容
            let file = unsafe { std::fs::File::from_raw_fd(fd) };
            let mut content = String::new();
            std::io::Read::read_to_string(&mut file, &mut content)
                .map_err(|e| SandboxError::IoError(e.to_string()))?;
            return Ok(content);
        }

        #[cfg(not(target_os = "linux"))]
        {
            tokio::fs::read_to_string(path)
                .await
                .map_err(|e| SandboxError::IoError(e.to_string()))
        }
    }
}

impl CapabilityDeclaration for FileReadTool {
    fn required_capabilities(&self) -> Vec<Capability> {
        vec![Capability::FileRead]
    }

    fn is_read_only(&self) -> bool {
        true
    }

    fn tool_name(&self) -> &str {
        "file_read"
    }
}

/// Shell 执行工具
pub struct ShellExecTool {
    /// 允许执行的命令白名单
    allowed_commands: CommandWhitelist,

    /// 命令超时
    timeout: Duration,
}

impl ShellExecTool {
    pub fn new(allowed_commands: CommandWhitelist, timeout: Duration) -> Self {
        Self {
            allowed_commands,
            timeout,
        }
    }

    /// 执行命令
    ///
    /// 使用 regex::escape 转义用户输入，防止命令注入。
    pub async fn execute(
        &self,
        command: &str,
        args: &[String],
    ) -> Result<ShellOutput, SandboxError> {
        // 结构化检查
        let parsed = parse_command(command);
        if !self.allowed_commands.is_safe(&parsed.command) {
            return Err(SandboxError::CommandNotAllowed {
                command: parsed.command,
                reason: "Command not in whitelist".to_string(),
            });
        }

        // 构建安全命令（转义参数）
        let safe_args: Vec<String> = args
            .iter()
            .map(|arg| {
                // 使用 regex::escape 转义 shell 特殊字符
                let escaped = regex::escape(arg);
                // 单引号包裹，防止 shell 展开
                format!("'{}'", escaped.replace("'", "'\\''"))
            })
            .collect();

        let full_cmd = format!("{} {}", parsed.command, safe_args.join(" "));

        // 执行命令（带超时）
        let result = tokio::time::timeout(self.timeout, tokio::process::Command::new("sh")
            .arg("-c")
            .arg(&full_cmd)
            .output())
            .await
            .map_err(|_| SandboxError::Timeout {
                command: full_cmd.clone(),
                timeout_ms: self.timeout.as_millis() as u64,
            })?
            .map_err(|e| SandboxError::CommandExecutionFailed {
                command: full_cmd.clone(),
                reason: e.to_string(),
            })?;

        Ok(ShellOutput {
            stdout: String::from_utf8_lossy(&result.stdout).to_string(),
            stderr: String::from_utf8_lossy(&result.stderr).to_string(),
            exit_code: result.status.code().unwrap_or(-1),
        })
    }
}

impl CapabilityDeclaration for ShellExecTool {
    fn required_capabilities(&self) -> Vec<Capability> {
        vec![Capability::ShellExec]
    }

    fn is_read_only(&self) -> bool {
        false
    }

    fn tool_name(&self) -> &str {
        "shell_exec"
    }
}

/// Shell 命令输出
#[derive(Debug, Clone)]
pub struct ShellOutput {
    /// 标准输出
    pub stdout: String,
    /// 标准错误
    pub stderr: String,
    /// 退出码
    pub exit_code: i32,
}
```

### 3.3.7 SandboxPolicy / CommandWhitelist / PathRestriction

```rust
/// 沙箱策略
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SandboxPolicy {
    /// 策略名称
    pub name: String,

    /// 安全模式
    pub mode: GuardianMode,

    /// 命令白名单
    pub command_whitelist: CommandWhitelist,

    /// 路径限制列表
    pub path_restrictions: Vec<PathRestriction>,

    /// 是否启用 Landlock
    pub enable_landlock: bool,

    /// Landlock 配置
    pub landlock_config: Option<LandlockConfig>,

    /// 是否启用 WASM 沙箱
    pub enable_wasm_sandbox: bool,

    /// WASM 沙箱限制
    pub wasm_limits: Option<WasmSandboxLimits>,
}

impl Default for SandboxPolicy {
    fn default() -> Self {
        Self {
            name: "default".to_string(),
            mode: GuardianMode::Standard,
            command_whitelist: CommandWhitelist::default(),
            path_restrictions: Vec::new(),
            enable_landlock: false,
            landlock_config: None,
            enable_wasm_sandbox: false,
            wasm_limits: None,
        }
    }
}

/// 命令白名单
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct CommandWhitelist {
    /// 允许的命令列表
    allowed: HashSet<String>,

    /// 允许的命令前缀列表
    allowed_prefixes: Vec<String>,
}

impl CommandWhitelist {
    /// 创建新的白名单
    pub fn new() -> Self {
        Self::default()
    }

    /// 添加允许的命令
    pub fn allow(mut self, command: impl Into<String>) -> Self {
        self.allowed.insert(command.into());
        self
    }

    /// 添加允许的命令前缀
    pub fn allow_prefix(mut self, prefix: impl Into<String>) -> Self {
        self.allowed_prefixes.push(prefix.into());
        self
    }

    /// 判断命令是否安全
    pub fn is_safe(&self, command: &str) -> bool {
        // 精确匹配
        if self.allowed.contains(command) {
            return true;
        }

        // 前缀匹配
        for prefix in &self.allowed_prefixes {
            if command.starts_with(prefix) {
                return true;
            }
        }

        false
    }

    /// 获取所有允许的命令
    pub fn allowed_commands(&self) -> &HashSet<String> {
        &self.allowed
    }
}

/// 路径限制
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PathRestriction {
    /// 限制类型
    pub restriction_type: PathRestrictionType,

    /// 路径模式
    pub path: PathBuf,

    /// 是否递归应用
    pub recursive: bool,

    /// 描述
    pub description: String,
}

/// 路径限制类型
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PathRestrictionType {
    /// 允许访问
    Allow,
    /// 拒绝访问
    Deny,
    /// 只读访问
    ReadOnly,
}

impl PathRestriction {
    /// 创建允许规则
    pub fn allow(path: impl Into<PathBuf>) -> Self {
        Self {
            restriction_type: PathRestrictionType::Allow,
            path: path.into(),
            recursive: true,
            description: String::new(),
        }
    }

    /// 创建拒绝规则
    pub fn deny(path: impl Into<PathBuf>) -> Self {
        Self {
            restriction_type: PathRestrictionType::Deny,
            path: path.into(),
            recursive: true,
            description: String::new(),
        }
    }

    /// 创建只读规则
    pub fn read_only(path: impl Into<PathBuf>) -> Self {
        Self {
            restriction_type: PathRestrictionType::ReadOnly,
            path: path.into(),
            recursive: true,
            description: String::new(),
        }
    }

    /// 判断路径是否被允许
    pub fn is_allowed(&self, target: &PathBuf) -> bool {
        let matches = if self.recursive {
            target.starts_with(&self.path)
        } else {
            target == self.path
        };

        match self.restriction_type {
            PathRestrictionType::Allow => matches,
            PathRestrictionType::Deny => !matches,
            PathRestrictionType::ReadOnly => matches, // 允许访问，但写操作需额外检查
        }
    }
}
```

### 3.3.8 LandlockConfig / WasmSandboxLimits / WasmSandbox

```rust
/// Landlock 配置（Linux 内核级沙箱）
///
/// Landlock 提供内核级别的文件系统隔离，
/// 即使进程被攻破也无法访问受限路径外的文件。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LandlockConfig {
    /// 允许读写的路径
    pub read_write_paths: Vec<PathBuf>,

    /// 允许只读的路径
    pub read_only_paths: Vec<PathBuf>,

    /// 是否限制网络访问
    pub restrict_network: bool,
}

impl LandlockConfig {
    /// 为任务创建 Landlock 配置
    pub fn for_task(
        workspace: &PathBuf,
        temp_dir: &PathBuf,
    ) -> Self {
        Self {
            read_write_paths: vec![workspace.clone(), temp_dir.clone()],
            read_only_paths: vec![
                PathBuf::from("/usr"),
                PathBuf::from("/lib"),
                PathBuf::from("/bin"),
            ],
            restrict_network: true,
        }
    }

    /// 应用 Landlock 沙箱
    ///
    /// # 错误
    /// 返回 SandboxError::LandlockNotAvailable 当内核不支持 Landlock 时。
    /// 返回 SandboxError::LandlockSetupFailed 当沙箱设置失败时。
    #[cfg(target_os = "linux")]
    pub fn apply(&self) -> Result<(), SandboxError> {
        // 检查 Landlock 可用性
        let abi_version = unsafe { landlock_sys::get_abi_version() };
        if abi_version < 1 {
            return Err(SandboxError::LandlockNotAvailable {
                reason: format!("Landlock ABI version {abi_version} < 1"),
            });
        }

        // 创建 Landlock 规则
        let mut rules = landlock_sys::Ruleset::new()
            .map_err(|e| SandboxError::LandlockSetupFailed {
                reason: format!("Failed to create ruleset: {e}"),
            })?;

        // 添加读写路径规则
        for path in &self.read_write_paths {
            rules
                .add_rule(path, landlock_sys::Access::Read | landlock_sys::Access::Write)
                .map_err(|e| SandboxError::LandlockSetupFailed {
                    reason: format!("Failed to add rule for {:?}: {e}", path),
                })?;
        }

        // 添加只读路径规则
        for path in &self.read_only_paths {
            rules
                .add_rule(path, landlock_sys::Access::Read)
                .map_err(|e| SandboxError::LandlockSetupFailed {
                    reason: format!("Failed to add rule for {:?}: {e}", path),
                })?;
        }

        // 应用规则
        rules
            .apply()
            .map_err(|e| SandboxError::LandlockSetupFailed {
                reason: format!("Failed to apply ruleset: {e}"),
            })?;

        Ok(())
    }

    #[cfg(not(target_os = "linux"))]
    pub fn apply(&self) -> Result<(), SandboxError> {
        Err(SandboxError::LandlockNotAvailable {
            reason: "Landlock is only available on Linux".to_string(),
        })
    }
}

/// WASM 沙箱资源限制
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WasmSandboxLimits {
    /// 最大内存（字节）
    pub max_memory_bytes: u64,

    /// 最大执行时间（毫秒）
    pub max_execution_time_ms: u64,

    /// 最大文件系统大小（字节）
    pub max_fs_size_bytes: u64,

    /// 是否允许网络访问
    pub allow_network: bool,

    /// 最大输出大小（字节）
    pub max_output_bytes: u64,

    /// epoch 递增间隔（默认 10ms）
    pub epoch_interval: Duration,
}

impl Default for WasmSandboxLimits {
    fn default() -> Self {
        Self {
            max_memory_bytes: 64 * 1024 * 1024, // 64 MB
            max_execution_time_ms: 30_000,       // 30 秒
            max_fs_size_bytes: 10 * 1024 * 1024, // 10 MB
            allow_network: false,
            max_output_bytes: 1024 * 1024,       // 1 MB
            epoch_interval: Duration::from_millis(10), // 10 ms
        }
    }
}

/// WASM 沙箱
pub struct WasmSandbox {
    /// 资源限制
    limits: WasmSandboxLimits,

    /// WASM 引擎
    engine: wasmtime::Engine,

    /// 已编译的模块缓存
    modules: RwLock<HashMap<String, wasmtime::Module>>,
}

impl WasmSandbox {
    /// 创建新的 WASM 沙箱
    pub fn new(limits: WasmSandboxLimits) -> Result<Self, SandboxError> {
        let mut config = wasmtime::Config::new();
        config
            .consume_fuel(true)
            .max_wasm_memory(limits.max_memory_bytes as usize)
            .wasm_threads(false)
            .wasm_simd(true);

        let engine = wasmtime::Engine::new(&config)
            .map_err(|e| SandboxError::WasmSetupFailed {
                reason: format!("Failed to create WASM engine: {e}"),
            })?;

        Ok(Self {
            limits,
            engine,
            modules: RwLock::new(HashMap::new()),
        })
    }

    /// 执行 WASM 模块
    pub async fn execute(
        &self,
        module_id: &str,
        function_name: &str,
        input: &[u8],
    ) -> Result<Vec<u8>, SandboxError> {
        let modules = self.modules.read().await;
        let module = modules.get(module_id).ok_or_else(|| {
            SandboxError::WasmModuleNotFound {
                module_id: module_id.to_string(),
            }
        })?;

        let mut store = wasmtime::Store::new(
            &self.engine,
            wasmtime::Fuel(0),
        );

        // 设置燃料限制（用于超时控制）
        let fuel = (self.limits.max_execution_time_ms as u64) * 1_000_000; // 近似值
        store.add_fuel(fuel).map_err(|e| SandboxError::WasmExecutionFailed {
            reason: format!("Failed to set fuel: {e}"),
        })?;

        let linker = wasmtime::Linker::new(&self.engine);
        let instance = linker
            .instantiate(&mut store, module)
            .map_err(|e| SandboxError::WasmExecutionFailed {
                reason: format!("Failed to instantiate: {e}"),
            })?;

        // 调用函数
        let func = instance
            .get_typed_func::<(u32, u32), u32>(&mut store, function_name)
            .map_err(|e| SandboxError::WasmExecutionFailed {
                reason: format!("Function '{function_name}' not found: {e}"),
            })?;

        let result = func.call(&mut store, (0, input.len() as u32));

        match result {
            Ok(_) => Ok(vec![]), // 简化：实际应从内存中读取输出
            Err(e) => {
                if store.get_fuel().map(|f| f.0).unwrap_or(0) == 0 {
                    Err(SandboxError::Timeout {
                        command: format!("wasm::{module_id}::{function_name}"),
                        timeout_ms: self.limits.max_execution_time_ms,
                    })
                } else {
                    Err(SandboxError::WasmExecutionFailed {
                        reason: format!("WASM trap: {e}"),
                    })
                }
            }
        }
    }

    /// 宿主需要定期递增 epoch，Wasmtime 才能在检查点中断死循环
    ///
    /// 权威定义来源：13-权限与沙箱安全.md §WASM 沙箱
    /// 在独立线程中运行，通过 shutdown 信号控制生命周期。
    pub fn spawn_epoch_pump(&self, shutdown: Arc<AtomicBool>) {
        let engine = self.engine.clone();
        let interval = self.limits.epoch_interval;

        std::thread::spawn(move || {
            while !shutdown.load(Ordering::Relaxed) {
                std::thread::sleep(interval);
                engine.increment_epoch();
            }
        });
    }

    /// 创建受限的 WASI 环境（Deny-by-default）
    ///
    /// 权威定义来源：13-权限与沙箱安全.md §WASM 沙箱
    /// 仅预开放指定目录，其他文件系统访问被拒绝。
    pub fn create_restricted_wasi(
        &self,
        allowed_dirs: &[PathBuf],
    ) -> Result<WasiCtxBuilder, SandboxError> {
        let mut wasi = WasiCtxBuilder::new();

        for dir in allowed_dirs {
            wasi.preopened_dir(dir, dir)?;
        }

        Ok(wasi)
    }
}
```

### 3.3.9 审计日志

```rust
use std::sync::Arc;

/// 审计日志条目
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditEntry {
    /// 时间戳
    pub timestamp: chrono::DateTime<chrono::Utc>,

    /// 调用者标识
    pub caller: String,

    /// 工具名称
    pub tool_name: String,

    /// 工具参数
    pub args: String,

    /// 守护决策
    pub decision: GuardianDecision,

    /// 安全模式
    pub mode: GuardianMode,
}

/// 审计日志器
///
/// 审计日志始终启用，不可关闭。
pub struct AuditLogger {
    /// 日志条目
    entries: RwLock<Vec<AuditEntry>>,

    /// 最大保留条目数
    max_entries: usize,

    /// 日志文件路径（可选）
    log_file: Option<PathBuf>,
}

impl AuditLogger {
    /// 创建新的审计日志器
    pub fn new() -> Self {
        Self {
            entries: RwLock::new(Vec::new()),
            max_entries: 100_000,
            log_file: None,
        }
    }

    /// 设置日志文件路径
    pub fn with_log_file(mut self, path: impl Into<PathBuf>) -> Self {
        self.log_file = Some(path.into());
        self
    }

    /// 记录审计条目
    pub fn log(&self, entry: AuditEntry) {
        // 同步写入（审计日志不可丢失）
        if let Ok(mut entries) = self.entries.try_write() {
            entries.push(entry.clone());
            if entries.len() > self.max_entries {
                entries.drain(..entries.len() - self.max_entries);
            }
        }

        // 写入文件（如果配置）
        if let Some(ref path) = self.log_file {
            if let Ok(mut file) = std::fs::OpenOptions::new()
                .create(true)
                .append(true)
                .open(path)
            {
                use std::io::Write;
                let _ = writeln!(
                    file,
                    "[{}] caller={} tool={} decision={}",
                    entry.timestamp.to_rfc3339(),
                    entry.caller,
                    entry.tool_name,
                    match &entry.decision {
                        GuardianDecision::Allowed { .. } => "ALLOWED",
                        GuardianDecision::Blocked { reason, .. } => {
                            format!("BLOCKED: {reason}")
                        }
                        GuardianDecision::NeedsApproval { reason, .. } => {
                            format!("NEEDS_APPROVAL: {reason}")
                        }
                        GuardianDecision::Sandboxed { .. } => "SANDBOXED",
                    }
                );
            }
        }
    }

    /// 查询审计日志
    pub async fn query(
        &self,
        filter: AuditFilter,
    ) -> Vec<AuditEntry> {
        let entries = self.entries.read().await;
        let mut results: Vec<AuditEntry> = entries
            .iter()
            .filter(|e| {
                if let Some(ref caller) = filter.caller {
                    if &e.caller != caller {
                        return false;
                    }
                }
                if let Some(ref tool) = filter.tool_name {
                    if &e.tool_name != tool {
                        return false;
                    }
                }
                if let Some(ref decision_type) = filter.decision_type {
                    match (decision_type, &e.decision) {
                        (AuditDecisionType::Allowed, GuardianDecision::Allowed { .. }) => {}
                        (AuditDecisionType::Blocked, GuardianDecision::Blocked { .. }) => {}
                        (AuditDecisionType::NeedsApproval, GuardianDecision::NeedsApproval { .. }) => {}
                        _ => return false,
                    }
                }
                if let Some(start) = filter.since {
                    if e.timestamp < start {
                        return false;
                    }
                }
                true
            })
            .cloned()
            .collect();

        // 按时间倒序
        results.sort_by(|a, b| b.timestamp.cmp(&a.timestamp));
        results
    }
}

/// 审计日志过滤器
#[derive(Debug, Clone, Default)]
pub struct AuditFilter {
    /// 按调用者过滤
    pub caller: Option<String>,
    /// 按工具名过滤
    pub tool_name: Option<String>,
    /// 按决策类型过滤
    pub decision_type: Option<AuditDecisionType>,
    /// 起始时间
    pub since: Option<chrono::DateTime<chrono::Utc>>,
}

/// 审计决策类型
#[derive(Debug, Clone, Copy)]
pub enum AuditDecisionType {
    Allowed,
    Blocked,
    NeedsApproval,
}

/// 沙箱错误
#[derive(Debug, Clone, thiserror::Error)]
pub enum SandboxError {
    /// 路径访问被拒绝
    #[error("Path access denied: {path:?} - {reason}")]
    PathAccessDenied { path: PathBuf, reason: String },

    /// 命令不允许
    #[error("Command not allowed: {command} - {reason}")]
    CommandNotAllowed { command: String, reason: String },

    /// 命令执行失败
    #[error("Command execution failed: {command} - {reason}")]
    CommandExecutionFailed { command: String, reason: String },

    /// 超时
    #[error("Command timed out: {command} after {timeout_ms}ms")]
    Timeout { command: String, timeout_ms: u64 },

    /// IO 错误
    #[error("IO error: {0}")]
    IoError(String),

    /// Landlock 不可用
    #[error("Landlock not available: {reason}")]
    LandlockNotAvailable { reason: String },

    /// Landlock 设置失败
    #[error("Landlock setup failed: {reason}")]
    LandlockSetupFailed { reason: String },

    /// WASM 设置失败
    #[error("WASM setup failed: {reason}")]
    WasmSetupFailed { reason: String },

    /// WASM 执行失败
    #[error("WASM execution failed: {reason}")]
    WasmExecutionFailed { reason: String },

    /// WASM 模块未找到
    #[error("WASM module not found: {module_id}")]
    WasmModuleNotFound { module_id: String },
}
```

---

## 3.4 功能需求清单

### FR-SANDBOX-001：命令白名单

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 仅允许白名单内的命令执行 |
| **验收标准** | 1. 白名单外的命令被拦截；2. 支持精确匹配和前缀匹配；3. 白名单可动态更新 |

### FR-SANDBOX-002：路径限制

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 限制文件系统访问范围 |
| **验收标准** | 1. 受保护路径不可访问；2. 符号链接不能绕过限制；3. 支持递归限制 |

### FR-SANDBOX-003：结构化危险命令检查

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 对 shell 命令进行结构化解析，识别破坏性操作 |
| **验收标准** | 1. `rm -rf /` 等破坏性命令被拦截；2. `curl | bash` 等远程执行被拦截；3. fork bomb 被识别 |

### FR-SANDBOX-004：TOCTOU 缓解

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 防止检查时间与使用时间之间的竞态条件 |
| **验收标准** | 1. Linux 使用 `O_NOFOLLOW` 打开文件；2. 路径检查与文件操作在同一系统调用中完成 |

### FR-SANDBOX-005：权限管理

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 任务级权限管理，支持能力声明与自动清理 |
| **验收标准** | 1. 权限有过期时间；2. 支持有限次使用；3. `Drop` 自动清理过期权限 |

### FR-SANDBOX-006：审计日志

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 所有工具调用始终记录审计日志 |
| **验收标准** | 1. `audit_enabled` 始终为 true；2. 日志包含完整调用信息；3. 支持按调用者/工具/时间查询 |

---

## 3.5 接口契约

### IC-SANDBOX-001：Guardian::check_tool_call

```
输入: caller: &str, tool_name: &str, args: &ToolCallArgs
输出: GuardianDecision
行为:
  1. 检查破坏性命令（所有模式）
  2. Bypass 模式下非破坏性命令放行
  3. 检查命令白名单
  4. 检查路径限制
  5. 根据模式返回决策
副作用: 始终记录审计日志
```

### IC-SANDBOX-002：TaskPermissionManager::check_permission

```
输入: task_id: &str, required: &Capability
输出: PermissionCheckResult
行为:
  1. 检查权限是否存在
  2. 检查是否过期/耗尽
  3. 检查能力匹配
  4. 记录使用次数
```

### IC-SANDBOX-003：LandlockConfig::apply

```
输入: 无（使用配置中的路径规则）
输出: Result<(), SandboxError>
行为:
  1. 检查内核 Landlock 支持
  2. 创建规则集
  3. 应用到当前进程
不可逆: 一旦应用，无法解除限制
```

---

## 3.6 测试要点

### TC-SANDBOX-001：Guardian 测试

| 测试项 | 说明 |
|--------|------|
| Bypass + 破坏性命令 | `rm -rf /` 在 Bypass 模式下仍被拦截 |
| Bypass + 安全命令 | `ls` 在 Bypass 模式下放行 |
| Standard + 白名单 | 白名单内命令放行，外命令拦截 |
| ReadOnly + 写操作 | 写操作在 ReadOnly 模式下被拦截 |
| Strict | 所有操作需要审批 |
| 审计日志 | 每次检查都记录审计条目 |

### TC-SANDBOX-002：命令解析测试

| 测试项 | 说明 |
|--------|------|
| 简单命令 | `ls -la` -> command="ls", args=["-la"] |
| 引号参数 | `echo "hello world"` 正确解析 |
| 转义字符 | `echo \"hello\"` 正确解析 |
| 破坏性检测 | `rm -rf /` 返回 true |
| 远程执行检测 | `curl | bash` 返回 true |

### TC-SANDBOX-003：权限管理测试

| 测试项 | 说明 |
|--------|------|
| 授予权限 | 权限正确创建并存储 |
| 权限过期 | 过期权限返回 Denied |
| 使用次数限制 | 超过 max_uses 后返回 Denied |
| 能力检查 | 缺少能力返回 Denied |
| Drop 清理 | TaskPermissionManager drop 时清理权限 |

### TC-SANDBOX-004：TOCTOU 测试

| 测试项 | 说明 |
|--------|------|
| 符号链接 | 通过符号链接访问受限路径被拒绝 |
| 竞态条件 | 检查与使用之间的文件替换被检测 |
| O_NOFOLLOW | 使用 O_NOFOLLOW 打开文件 |

### TC-SANDBOX-005：审计日志测试

| 测试项 | 说明 |
|--------|------|
| 日志记录 | 每次工具调用都记录 |
| 日志查询 | 按调用者/工具/时间过滤 |
| 日志持久化 | 写入文件正确 |
| 不可关闭 | audit_enabled 始终为 true |

---

# P2-4 mc-tool — 工具注册与执行框架

## 4.1 模块概述

`mc-tool` 是 MoreCode 的工具管理框架，负责：

1. **Tool trait**：定义工具的统一接口，包括名称、描述、执行方法、参数定义和只读标记。
2. **ToolRegistry**：工具注册中心，支持工具的注册、发现、可见性分层与延迟加载。
3. **内置工具**：提供 `file_read`（大文件智能读取）、`file_write`、`search`（正则搜索）、`terminal`（命令执行）、`git`（Git 操作）五个核心工具。
4. **工具目录**：按使用频率分为 `core`（高频，立即加载）、`extended`（扩展，按需加载）、`deferred`（延迟，首次使用时加载）三层。
5. **沙箱集成**：每个工具通过 `CapabilityDeclaration` 声明所需能力，与 `mc-sandbox` 的 Guardian 无缝集成。
6. **权限检查**：`ToolPermission` 与 `PermissionLevel` 控制工具的访问权限。

### 架构文档引用

| 文档 | 关联章节 |
|------|----------|
| `25-代码目录与文件命名设计.md` | §3.9 — 工具目录结构、命名规范 |
| `04-执行层Agent.md` | §工具使用 — 工具调用流程、结果格式化、错误处理 |

---

## 4.2 大模型开发提示词

```
你是 MoreCode 项目的 mc-tool 模块开发者。请遵循以下规范：

1. 所有工具必须实现 Tool trait，禁止直接调用工具逻辑。
2. 工具注册必须通过 ToolRegistry 进行，支持可见性分层。
3. file_read 工具对大文件（>1MB）使用智能分段读取，返回摘要 + 指定行范围。
4. search 工具使用 regex crate，支持正则表达式搜索。
5. terminal 工具必须经过 Guardian::check_tool_call 检查后才能执行。
6. git 工具仅允许安全的 Git 操作（status、log、diff、show），禁止 push --force。
7. 工具结果使用 ToolResult 统一格式，包含 success/error/content 三种状态。
8. 延迟加载工具使用 once_cell::sync::Lazy 实现按需初始化。
9. 每个工具必须声明 CapabilityDeclaration，与 mc-sandbox 集成。
10. 工具名称使用 snake_case，描述使用中文。
```

---

## 4.3 核心类型定义

### 4.3.1 Tool trait

```rust
use std::collections::HashMap;
use std::future::Future;
use std::pin::Pin;
use serde_json::Value;

/// 工具 trait
///
/// 所有工具必须实现此 trait。
/// 实现者需保证线程安全（Send + Sync）。
pub trait Tool: Send + Sync {
    /// 工具名称（snake_case）
    ///
    /// 此名称将作为 LLM function calling 的工具标识符。
    fn name(&self) -> &str;

    /// 工具描述（供 LLM 理解工具用途）
    ///
    /// 应清晰描述工具的功能、适用场景和使用限制。
    fn description(&self) -> &str;

    /// 执行工具
    ///
    /// # 参数
    /// - `params`: 工具参数（JSON 对象）
    ///
    /// # 返回
    /// 工具执行结果
    fn execute(
        &self,
        params: Value,
    ) -> Pin<Box<dyn Future<Output = ToolResult> + Send + '_>>;

    /// 返回工具的必需参数 JSON Schema
    ///
    /// 此 Schema 将传递给 LLM 作为 function calling 的参数定义。
    fn required_parameters(&self) -> Value;

    /// 判断工具是否为只读
    ///
    /// 只读工具不会修改文件系统或外部状态。
    fn is_read_only(&self) -> bool;

    /// 返回工具所属目录
    fn category(&self) -> ToolCategory {
        ToolCategory::Core
    }

    /// 返回工具所需的权限级别
    fn permission_level(&self) -> PermissionLevel {
        PermissionLevel::Standard
    }
}
```

### 4.3.2 ToolRegistry

```rust
use std::sync::Arc;
use tokio::sync::RwLock;

/// 工具注册中心
///
/// 管理所有工具的注册、发现与生命周期。
/// 支持可见性分层与延迟加载。
pub struct ToolRegistry {
    /// 已注册的工具（按名称索引）
    tools: RwLock<HashMap<String, Arc<dyn Tool>>>,

    /// 工具可见性配置
    visibility: RwLock<HashMap<String, VisibilityLayer>>,

    /// 延迟加载工厂
    deferred_factories: RwLock<HashMap<String, Box<dyn Fn() -> Arc<dyn Tool> + Send + Sync>>>,

    /// Guardian 引用（用于权限检查）
    guardian: Option<Arc<crate::mc_sandbox::Guardian>>,
}

/// 工具目录
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ToolCategory {
    /// 核心工具（高频，立即加载）
    Core,
    /// 扩展工具（按需加载）
    Extended,
    /// 延迟工具（首次使用时加载）
    Deferred,
}

/// 可见性层
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum VisibilityLayer {
    /// 所有用户可见
    Public,
    /// 仅项目成员可见
    Project,
    /// 仅管理员可见
    Admin,
    /// 隐藏（不暴露给 LLM）
    Hidden,
}

impl ToolRegistry {
    /// 创建新的工具注册中心
    pub fn new() -> Self {
        Self {
            tools: RwLock::new(HashMap::new()),
            visibility: RwLock::new(HashMap::new()),
            deferred_factories: RwLock::new(HashMap::new()),
            guardian: None,
        }
    }

    /// 设置 Guardian 引用
    pub fn with_guardian(mut self, guardian: Arc<crate::mc_sandbox::Guardian>) -> Self {
        self.guardian = Some(guardian);
        self
    }

    /// 注册工具
    pub async fn register<T: Tool + 'static>(&self, tool: T) {
        let name = tool.name().to_string();
        let visibility = match tool.permission_level() {
            PermissionLevel::Public => VisibilityLayer::Public,
            PermissionLevel::Standard => VisibilityLayer::Public,
            PermissionLevel::Elevated => VisibilityLayer::Project,
            PermissionLevel::Admin => VisibilityLayer::Admin,
        };

        let mut tools = self.tools.write().await;
        let mut vis = self.visibility.write().await;
        tools.insert(name.clone(), Arc::new(tool));
        vis.insert(name, visibility);
    }

    /// 注册延迟加载工具
    pub async fn register_deferred<F>(&self, name: &str, factory: F)
    where
        F: Fn() -> Arc<dyn Tool> + Send + Sync + 'static,
    {
        let mut factories = self.deferred_factories.write().await;
        factories.insert(name.to_string(), Box::new(factory));
    }

    /// 获取工具
    ///
    /// 如果工具是延迟加载的，首次获取时触发加载。
    pub async fn get(&self, name: &str) -> Option<Arc<dyn Tool>> {
        // 先检查已注册的工具
        {
            let tools = self.tools.read().await;
            if let Some(tool) = tools.get(name) {
                return Some(Arc::clone(tool));
            }
        }

        // 检查延迟加载工厂
        {
            let mut factories = self.deferred_factories.write().await;
            if let Some(factory) = factories.remove(name) {
                let tool = factory();
                let mut tools = self.tools.write().await;
                tools.insert(name.to_string(), Arc::clone(&tool));
                return Some(tool);
            }
        }

        None
    }

    /// 列出所有可见工具
    ///
    /// 根据可见性层过滤工具列表。
    pub async fn list_tools(&self, layer: VisibilityLayer) -> Vec<Arc<dyn Tool>> {
        let tools = self.tools.read().await;
        let vis = self.visibility.read().await;

        let mut result: Vec<Arc<dyn Tool>> = tools
            .iter()
            .filter(|(name, _)| {
                vis.get(*name)
                    .map(|v| v <= &layer)
                    .unwrap_or(true)
            })
            .map(|(_, tool)| Arc::clone(tool))
            .collect();

        // 按名称排序
        result.sort_by(|a, b| a.name().cmp(b.name()));
        result
    }

    /// 获取工具定义列表（用于 LLM function calling）
    pub async fn tool_definitions(&self, layer: VisibilityLayer) -> Vec<ToolDefinition> {
        let tools = self.list_tools(layer).await;
        tools
            .iter()
            .map(|tool| ToolDefinition {
                name: tool.name().to_string(),
                description: tool.description().to_string(),
                parameters: tool.required_parameters(),
                strict: false,
            })
            .collect()
    }

    /// 执行工具
    ///
    /// 包含权限检查与审计日志。
    pub async fn execute_tool(
        &self,
        caller: &str,
        tool_name: &str,
        params: Value,
    ) -> ToolResult {
        // 获取工具
        let tool = match self.get(tool_name).await {
            Some(t) => t,
            None => {
                return ToolResult::error(format!("Tool '{tool_name}' not found"));
            }
        };

        // Guardian 权限检查（如果配置）
        if let Some(ref guardian) = self.guardian {
            let args = crate::mc_sandbox::ToolCallArgs {
                command: params.get("command").and_then(|v| v.as_str()).map(String::from),
                target_path: params.get("path").and_then(|v| v.as_str()).map(PathBuf::from),
                is_write: !tool.is_read_only(),
                extra: HashMap::new(),
            };

            let decision = guardian.check_tool_call(caller, tool_name, &args).await;
            if decision.is_blocked() {
                return ToolResult::error(format!("Tool execution blocked by Guardian"));
            }
        }

        // 执行工具
        tool.execute(params).await
    }

    /// 注销工具
    pub async fn unregister(&self, name: &str) -> bool {
        let mut tools = self.tools.write().await;
        let mut vis = self.visibility.write().await;
        tools.remove(name).is_some() & vis.remove(name).is_some()
    }
}
```

### 4.3.3 ToolDefinition / ToolResult / ToolPermission / PermissionLevel

```rust
/// 工具定义（传递给 LLM）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolDefinition {
    /// 工具名称
    pub name: String,

    /// 工具描述
    pub description: String,

    /// 参数 JSON Schema
    pub parameters: serde_json::Value,

    /// 是否为严格模式
    pub strict: bool,
}

/// 工具执行结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolResult {
    /// 结果状态
    pub status: ToolResultStatus,

    /// 结果内容
    pub content: String,

    /// 结构化数据（可选）
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<serde_json::Value>,

    /// 元数据
    #[serde(default, skip_serializing_if = "HashMap::is_empty")]
    pub metadata: HashMap<String, String>,

    /// 执行耗时（毫秒）
    pub duration_ms: u64,
}

/// 工具结果状态
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ToolResultStatus {
    /// 成功
    Success,
    /// 部分成功
    PartialSuccess,
    /// 错误
    Error,
    /// 需要用户确认
    NeedsConfirmation,
}

impl ToolResult {
    /// 创建成功结果
    pub fn success(content: impl Into<String>) -> Self {
        Self {
            status: ToolResultStatus::Success,
            content: content.into(),
            data: None,
            metadata: HashMap::new(),
            duration_ms: 0,
        }
    }

    /// 创建成功结果（带结构化数据）
    pub fn success_with_data(content: impl Into<String>, data: serde_json::Value) -> Self {
        Self {
            status: ToolResultStatus::Success,
            content: content.into(),
            data: Some(data),
            metadata: HashMap::new(),
            duration_ms: 0,
        }
    }

    /// 创建错误结果
    pub fn error(message: impl Into<String>) -> Self {
        Self {
            status: ToolResultStatus::Error,
            content: message.into(),
            data: None,
            metadata: HashMap::new(),
            duration_ms: 0,
        }
    }

    /// 创建部分成功结果
    pub fn partial(content: impl Into<String>) -> Self {
        Self {
            status: ToolResultStatus::PartialSuccess,
            content: content.into(),
            data: None,
            metadata: HashMap::new(),
            duration_ms: 0,
        }
    }

    /// 设置执行耗时
    pub fn with_duration(mut self, duration: std::time::Duration) -> Self {
        self.duration_ms = duration.as_millis() as u64;
        self
    }

    /// 添加元数据
    pub fn with_metadata(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.metadata.insert(key.into(), value.into());
        self
    }

    /// 判断是否成功
    pub fn is_success(&self) -> bool {
        matches!(self.status, ToolResultStatus::Success | ToolResultStatus::PartialSuccess)
    }
}

/// 工具权限
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolPermission {
    /// 工具名称
    pub tool_name: String,

    /// 权限级别
    pub level: PermissionLevel,

    /// 授权范围
    pub scope: PermissionScope,
}

/// 权限级别
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum PermissionLevel {
    /// 公开 — 所有用户可用
    Public,
    /// 标准 — 需要基本认证
    Standard,
    /// 提升 — 需要项目级授权
    Elevated,
    /// 管理 — 仅管理员可用
    Admin,
}

/// 权限范围
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PermissionScope {
    /// 全局范围
    Global,
    /// 项目范围
    Project { project_id: String },
    /// 会话范围
    Session { session_id: String },
    /// 一次性
    OneTime { request_id: String },
}
```

### 4.3.4 内置工具：file_read

```rust
use std::path::PathBuf;

/// 文件读取工具
///
/// 支持大文件智能读取：
/// - 小文件（<1MB）：直接返回全部内容
/// - 大文件（>=1MB）：返回摘要 + 指定行范围
pub struct FileReadTool {
    /// 大文件阈值（字节）
    large_file_threshold: u64,

    /// 默认读取行数（大文件模式）
    default_line_count: usize,
}

impl FileReadTool {
    pub fn new() -> Self {
        Self {
            large_file_threshold: 1024 * 1024, // 1MB
            default_line_count: 200,
        }
    }

    /// 读取文件
    async fn read_file(
        &self,
        path: &str,
        offset: Option<usize>,
        limit: Option<usize>,
    ) -> ToolResult {
        let path = PathBuf::from(path);
        let start = std::time::Instant::now();

        // 检查文件是否存在
        let metadata = match tokio::fs::metadata(&path).await {
            Ok(m) => m,
            Err(e) => return ToolResult::error(format!("Cannot access file: {e}")),
        };

        let file_size = metadata.len();

        // 大文件智能读取
        if file_size >= self.large_file_threshold {
            return self.read_large_file(&path, file_size, offset, limit, start).await;
        }

        // 小文件直接读取
        match tokio::fs::read_to_string(&path).await {
            Ok(content) => {
                let line_count = content.lines().count();
                ToolResult::success_with_data(
                    content,
                    serde_json::json!({
                        "path": path.to_string_lossy(),
                        "size_bytes": file_size,
                        "line_count": line_count,
                        "mode": "full",
                    }),
                )
                .with_duration(start.elapsed())
            }
            Err(e) => ToolResult::error(format!("Failed to read file: {e}")),
        }
    }

    /// 大文件智能读取
    async fn read_large_file(
        &self,
        path: &PathBuf,
        file_size: u64,
        offset: Option<usize>,
        limit: Option<usize>,
        start: std::time::Instant,
    ) -> ToolResult {
        let offset = offset.unwrap_or(0);
        let limit = limit.unwrap_or(self.default_line_count);

        // 读取指定行范围
        let content = match tokio::fs::read_to_string(path).await {
            Ok(c) => c,
            Err(e) => return ToolResult::error(format!("Failed to read file: {e}")),
        };

        let total_lines = content.lines().count();
        let lines: Vec<&str> = content
            .lines()
            .skip(offset)
            .take(limit)
            .collect();

        let selected_content = lines.join("\n");

        // 生成文件摘要（前 50 行 + 后 20 行的统计信息）
        let summary = self.generate_summary(&content, file_size);

        ToolResult::success_with_data(
            selected_content,
            serde_json::json!({
                "path": path.to_string_lossy(),
                "size_bytes": file_size,
                "total_lines": total_lines,
                "offset": offset,
                "limit": limit,
                "returned_lines": lines.len(),
                "mode": "partial",
                "summary": summary,
            }),
        )
        .with_metadata("warning", "Large file: showing partial content. Use offset/limit to navigate.")
        .with_duration(start.elapsed())
    }

    /// 生成文件摘要
    fn generate_summary(&self, content: &str, file_size: u64) -> serde_json::Value {
        let total_lines = content.lines().count();
        let first_lines: Vec<&str> = content.lines().take(10).collect();
        let language = detect_language(content);

        serde_json::json!({
            "total_lines": total_lines,
            "file_size_bytes": file_size,
            "detected_language": language,
            "first_10_lines": first_lines,
        })
    }
}

/// 检测文件语言
fn detect_language(content: &str) -> &str {
    let first_line = content.lines().next().unwrap_or("");
    if first_line.starts_with("#!") || first_line.starts_with("//") {
        // 检查更多特征
        if content.contains("fn ") && content.contains("impl ") {
            return "rust";
        }
        if content.contains("function ") || content.contains("const ") {
            return "javascript";
        }
        if content.contains("def ") && content.contains("import ") {
            return "python";
        }
        return "unknown";
    }
    if content.contains("package ") && content.contains("func ") {
        return "go";
    }
    if content.contains("pub struct") || content.contains("pub enum") {
        return "rust";
    }
    "unknown"
}

impl Tool for FileReadTool {
    fn name(&self) -> &str {
        "file_read"
    }

    fn description(&self) -> &str {
        "读取文件内容。支持大文件智能分段读取。小文件返回全部内容，大文件（>=1MB）返回摘要和指定行范围。"
    }

    fn execute(
        &self,
        params: serde_json::Value,
    ) -> Pin<Box<dyn Future<Output = ToolResult> + Send + '_>> {
        Box::pin(async move {
            let path = match params.get("path").and_then(|v| v.as_str()) {
                Some(p) => p,
                None => return ToolResult::error("Missing required parameter: path"),
            };
            let offset = params.get("offset").and_then(|v| v.as_u64()).map(|v| v as usize);
            let limit = params.get("limit").and_then(|v| v.as_u64()).map(|v| v as usize);
            self.read_file(path, offset, limit).await
        })
    }

    fn required_parameters(&self) -> serde_json::Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "文件路径（绝对路径或相对路径）"
                },
                "offset": {
                    "type": "integer",
                    "description": "起始行号（从 0 开始），默认 0"
                },
                "limit": {
                    "type": "integer",
                    "description": "读取行数，默认 200"
                }
            },
            "required": ["path"]
        })
    }

    fn is_read_only(&self) -> bool {
        true
    }

    fn category(&self) -> ToolCategory {
        ToolCategory::Core
    }

    fn permission_level(&self) -> PermissionLevel {
        PermissionLevel::Standard
    }
}
```

### 4.3.5 内置工具：file_write / search / terminal / git

```rust
/// 文件写入工具
pub struct FileWriteTool;

impl FileWriteTool {
    pub fn new() -> Self {
        Self
    }

    async fn write_file(&self, path: &str, content: &str, create_dirs: bool) -> ToolResult {
        let path = PathBuf::from(path);
        let start = std::time::Instant::now();

        // 创建父目录（如果需要）
        if create_dirs {
            if let Some(parent) = path.parent() {
                if let Err(e) = tokio::fs::create_dir_all(parent).await {
                    return ToolResult::error(format!("Failed to create directories: {e}"));
                }
            }
        }

        // 写入文件
        match tokio::fs::write(&path, content).await {
            Ok(_) => {
                let bytes = content.len();
                let lines = content.lines().count();
                ToolResult::success_with_data(
                    format!("File written: {} ({} bytes, {} lines)", path.display(), bytes, lines),
                    serde_json::json!({
                        "path": path.to_string_lossy(),
                        "bytes_written": bytes,
                        "lines_written": lines,
                    }),
                )
                .with_duration(start.elapsed())
            }
            Err(e) => ToolResult::error(format!("Failed to write file: {e}")),
        }
    }
}

impl Tool for FileWriteTool {
    fn name(&self) -> &str { "file_write" }
    fn description(&self) -> &str {
        "写入文件内容。如果文件已存在则覆盖。支持自动创建父目录。"
    }
    fn execute(&self, params: serde_json::Value) -> Pin<Box<dyn Future<Output = ToolResult> + Send + '_>> {
        Box::pin(async move {
            let path = match params.get("path").and_then(|v| v.as_str()) {
                Some(p) => p,
                None => return ToolResult::error("Missing required parameter: path"),
            };
            let content = match params.get("content").and_then(|v| v.as_str()) {
                Some(c) => c,
                None => return ToolResult::error("Missing required parameter: content"),
            };
            let create_dirs = params.get("create_dirs").and_then(|v| v.as_bool()).unwrap_or(false);
            Self::new().write_file(path, content, create_dirs).await
        })
    }
    fn required_parameters(&self) -> serde_json::Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "path": { "type": "string", "description": "文件路径" },
                "content": { "type": "string", "description": "文件内容" },
                "create_dirs": { "type": "boolean", "description": "是否自动创建父目录", "default": false }
            },
            "required": ["path", "content"]
        })
    }
    fn is_read_only(&self) -> bool { false }
    fn category(&self) -> ToolCategory { ToolCategory::Core }
}

/// 正则搜索工具
pub struct SearchTool;

impl SearchTool {
    pub fn new() -> Self { Self }

    async fn search(
        &self,
        pattern: &str,
        path: &str,
        include_pattern: Option<&str>,
        max_results: usize,
    ) -> ToolResult {
        let start = std::time::Instant::now();
        let regex = match regex::Regex::new(pattern) {
            Ok(re) => re,
            Err(e) => return ToolResult::error(format!("Invalid regex pattern: {e}")),
        };

        let root = PathBuf::from(path);
        let mut results = Vec::new();

        // 遍历目录搜索
        if let Ok(mut entries) = tokio::fs::read_dir(&root).await {
            while let Ok(Some(entry)) = entries.next_entry().await {
                let path = entry.path();
                if !path.is_file() {
                    continue;
                }

                // 文件名过滤
                if let Some(include) = include_pattern {
                    let file_regex = match regex::Regex::new(include) {
                        Ok(re) => re,
                        Err(_) => continue,
                    };
                    let filename = path.file_name()
                        .and_then(|n| n.to_str())
                        .unwrap_or("");
                    if !file_regex.is_match(filename) {
                        continue;
                    }
                }

                // 读取文件并搜索
                if let Ok(content) = tokio::fs::read_to_string(&path).await {
                    for (line_num, line) in content.lines().enumerate() {
                        if regex.is_match(line) {
                            results.push(serde_json::json!({
                                "file": path.to_string_lossy(),
                                "line": line_num + 1,
                                "text": line.trim(),
                            }));
                            if results.len() >= max_results {
                                break;
                            }
                        }
                    }
                }
            }
        }

        let total_matches = results.len();
        let truncated = total_matches >= max_results;

        ToolResult::success_with_data(
            format!("Found {total_matches} matches"),
            serde_json::json!({
                "matches": results,
                "total_matches": total_matches,
                "truncated": truncated,
                "pattern": pattern,
                "search_path": path,
            }),
        )
        .with_duration(start.elapsed())
    }
}

impl Tool for SearchTool {
    fn name(&self) -> &str { "search" }
    fn description(&self) -> &str {
        "在目录中搜索匹配正则表达式的内容。支持文件名过滤和结果数量限制。"
    }
    fn execute(&self, params: serde_json::Value) -> Pin<Box<dyn Future<Output = ToolResult> + Send + '_>> {
        Box::pin(async move {
            let pattern = match params.get("pattern").and_then(|v| v.as_str()) {
                Some(p) => p,
                None => return ToolResult::error("Missing required parameter: pattern"),
            };
            let path = params.get("path").and_then(|v| v.as_str()).unwrap_or(".");
            let include = params.get("include").and_then(|v| v.as_str());
            let max_results = params.get("max_results").and_then(|v| v.as_u64()).unwrap_or(100) as usize;
            Self::new().search(pattern, path, include, max_results).await
        })
    }
    fn required_parameters(&self) -> serde_json::Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "pattern": { "type": "string", "description": "正则表达式" },
                "path": { "type": "string", "description": "搜索路径", "default": "." },
                "include": { "type": "string", "description": "文件名过滤（glob 模式）" },
                "max_results": { "type": "integer", "description": "最大结果数", "default": 100 }
            },
            "required": ["pattern"]
        })
    }
    fn is_read_only(&self) -> bool { true }
    fn category(&self) -> ToolCategory { ToolCategory::Core }
}

/// 终端命令执行工具
pub struct TerminalTool {
    /// Guardian 引用
    guardian: Option<Arc<crate::mc_sandbox::Guardian>>,
    /// 命令超时
    timeout: std::time::Duration,
}

impl TerminalTool {
    pub fn new(guardian: Option<Arc<crate::mc_sandbox::Guardian>>) -> Self {
        Self {
            guardian,
            timeout: std::time::Duration::from_secs(30),
        }
    }

    async fn execute_command(&self, caller: &str, command: &str, cwd: Option<&str>) -> ToolResult {
        let start = std::time::Instant::now();

        // Guardian 检查
        if let Some(ref guardian) = self.guardian {
            let args = crate::mc_sandbox::ToolCallArgs::shell_exec(command);
            let decision = guardian.check_tool_call(caller, "terminal", &args).await;
            if decision.is_blocked() {
                return ToolResult::error("Command blocked by Guardian");
            }
        }

        // 执行命令
        let mut cmd = tokio::process::Command::new("sh");
        cmd.arg("-c").arg(command);
        if let Some(dir) = cwd {
            cmd.current_dir(dir);
        }

        let result = tokio::time::timeout(self.timeout, cmd.output()).await;

        match result {
            Ok(Ok(output)) => {
                let stdout = String::from_utf8_lossy(&output.stdout).to_string();
                let stderr = String::from_utf8_lossy(&output.stderr).to_string();
                let exit_code = output.status.code().unwrap_or(-1);

                if exit_code == 0 {
                    ToolResult::success_with_data(
                        stdout,
                        serde_json::json!({
                            "exit_code": exit_code,
                            "stderr": stderr,
                        }),
                    )
                    .with_duration(start.elapsed())
                } else {
                    ToolResult::partial(format!("Command exited with code {exit_code}\n{stderr}"))
                        .with_metadata("exit_code", exit_code.to_string())
                        .with_duration(start.elapsed())
                }
            }
            Ok(Err(e)) => ToolResult::error(format!("Command execution failed: {e}")),
            Err(_) => ToolResult::error(format!(
                "Command timed out after {}ms",
                self.timeout.as_millis()
            )),
        }
    }
}

impl Tool for TerminalTool {
    fn name(&self) -> &str { "terminal" }
    fn description(&self) -> &str {
        "在终端中执行命令。所有命令经过安全检查。支持工作目录设置。"
    }
    fn execute(&self, params: serde_json::Value) -> Pin<Box<dyn Future<Output = ToolResult> + Send + '_>> {
        Box::pin(async move {
            let command = match params.get("command").and_then(|v| v.as_str()) {
                Some(c) => c,
                None => return ToolResult::error("Missing required parameter: command"),
            };
            let cwd = params.get("cwd").and_then(|v| v.as_str());
            let caller = params.get("caller").and_then(|v| v.as_str()).unwrap_or("unknown");
            self.execute_command(caller, command, cwd).await
        })
    }
    fn required_parameters(&self) -> serde_json::Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "command": { "type": "string", "description": "要执行的命令" },
                "cwd": { "type": "string", "description": "工作目录" }
            },
            "required": ["command"]
        })
    }
    fn is_read_only(&self) -> bool { false }
    fn category(&self) -> ToolCategory { ToolCategory::Core }
    fn permission_level(&self) -> PermissionLevel { PermissionLevel::Elevated }
}

/// Git 操作工具
pub struct GitTool {
    /// 允许的 Git 子命令
    allowed_subcommands: Vec<String>,
}

impl GitTool {
    pub fn new() -> Self {
        Self {
            allowed_subcommands: vec![
                "status".to_string(),
                "log".to_string(),
                "diff".to_string(),
                "show".to_string(),
                "branch".to_string(),
                "stash".to_string(),
                "tag".to_string(),
                "remote".to_string(),
                "fetch".to_string(),
                "pull".to_string(),
                "add".to_string(),
                "commit".to_string(),
                "push".to_string(),
                "checkout".to_string(),
                "switch".to_string(),
                "merge".to_string(),
                "rebase".to_string(),
                "reset".to_string(),
                "rev-parse".to_string(),
            ],
        }
    }

    async fn git_command(&self, subcommand: &str, args: &[String], cwd: &str) -> ToolResult {
        let start = std::time::Instant::now();

        // 检查子命令是否允许
        if !self.allowed_subcommands.contains(&subcommand.to_string()) {
            return ToolResult::error(format!("Git subcommand '{subcommand}' is not allowed"));
        }

        // 禁止危险操作
        let dangerous_flags = ["--force", "-f", "--hard", "--no-verify"];
        for arg in args {
            for flag in &dangerous_flags {
                if arg.contains(flag) {
                    return ToolResult::error(format!(
                        "Dangerous flag '{flag}' is not allowed in git {subcommand}"
                    ));
                }
            }
        }

        // 构建 Git 命令
        let mut cmd_args = vec![subcommand.to_string()];
        cmd_args.extend_from_slice(args);

        let output = tokio::process::Command::new("git")
            .args(&cmd_args)
            .current_dir(cwd)
            .output()
            .await;

        match output {
            Ok(output) => {
                let stdout = String::from_utf8_lossy(&output.stdout).to_string();
                let stderr = String::from_utf8_lossy(&output.stderr).to_string();
                let exit_code = output.status.code().unwrap_or(-1);

                if exit_code == 0 {
                    ToolResult::success_with_data(
                        stdout,
                        serde_json::json!({
                            "subcommand": subcommand,
                            "exit_code": exit_code,
                            "stderr": stderr,
                        }),
                    )
                    .with_duration(start.elapsed())
                } else {
                    ToolResult::error(format!("git {subcommand} failed (exit {exit_code}): {stderr}"))
                }
            }
            Err(e) => ToolResult::error(format!("Failed to execute git: {e}")),
        }
    }
}

impl Tool for GitTool {
    fn name(&self) -> &str { "git" }
    fn description(&self) -> &str {
        "执行 Git 操作。支持 status、log、diff、show、branch、add、commit、push 等安全子命令。禁止 --force 等危险标志。"
    }
    fn execute(&self, params: serde_json::Value) -> Pin<Box<dyn Future<Output = ToolResult> + Send + '_>> {
        Box::pin(async move {
            let subcommand = match params.get("subcommand").and_then(|v| v.as_str()) {
                Some(s) => s,
                None => return ToolResult::error("Missing required parameter: subcommand"),
            };
            let args: Vec<String> = params
                .get("args")
                .and_then(|v| v.as_array())
                .map(|arr| arr.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                .unwrap_or_default();
            let cwd = params.get("cwd").and_then(|v| v.as_str()).unwrap_or(".");
            Self::new().git_command(subcommand, &args, cwd).await
        })
    }
    fn required_parameters(&self) -> serde_json::Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "subcommand": {
                    "type": "string",
                    "description": "Git 子命令（如 status、log、diff、add、commit、push）",
                    "enum": ["status", "log", "diff", "show", "branch", "stash", "tag",
                             "remote", "fetch", "pull", "add", "commit", "push",
                             "checkout", "switch", "merge", "rebase", "reset", "rev-parse"]
                },
                "args": {
                    "type": "array",
                    "items": { "type": "string" },
                    "description": "子命令参数"
                },
                "cwd": { "type": "string", "description": "工作目录", "default": "." }
            },
            "required": ["subcommand"]
        })
    }
    fn is_read_only(&self) -> bool {
        // Git 操作可能修改仓库状态
        false
    }
    fn category(&self) -> ToolCategory { ToolCategory::Core }
    fn permission_level(&self) -> PermissionLevel { PermissionLevel::Elevated }
}
```

### 4.3.6 工具目录与延迟加载

```rust
use once_cell::sync::Lazy;

/// 核心工具列表（立即加载）
pub static CORE_TOOLS: Lazy<Vec<Arc<dyn Tool>>> = Lazy::new(|| {
    vec![
        Arc::new(FileReadTool::new()),
        Arc::new(FileWriteTool),
        Arc::new(SearchTool),
    ]
});

/// 扩展工具列表（按需加载）
pub static EXTENDED_TOOLS: Lazy<Vec<Arc<dyn Tool>>> = Lazy::new(|| {
    vec![
        Arc::new(GitTool::new()),
    ]
});

/// 延迟加载工具工厂
pub static DEFERRED_FACTORIES: Lazy<HashMap<String, Box<dyn Fn() -> Arc<dyn Tool> + Send + Sync>>> =
    Lazy::new(|| {
        let mut factories: HashMap<String, Box<dyn Fn() -> Arc<dyn Tool> + Send + Sync>> =
            HashMap::new();
        // 延迟加载的工具在此注册
        // factories.insert("web_search".to_string(), Box::new(|| Arc::new(WebSearchTool::new())));
        // factories.insert("docker".to_string(), Box::new(|| Arc::new(DockerTool::new())));
        factories
    });

/// 注册所有核心工具到注册中心
pub async fn register_core_tools(registry: &ToolRegistry) {
    for tool in CORE_TOOLS.iter() {
        registry.register_arc(Arc::clone(tool)).await;
    }
}

/// 注册所有扩展工具到注册中心
pub async fn register_extended_tools(registry: &ToolRegistry) {
    for tool in EXTENDED_TOOLS.iter() {
        registry.register_arc(Arc::clone(tool)).await;
    }
}

/// 注册所有延迟加载工具工厂
pub async fn register_deferred_tools(registry: &ToolRegistry) {
    for (name, factory) in DEFERRED_FACTORIES.iter() {
        registry.register_deferred(name, |f: &Box<dyn Fn() -> Arc<dyn Tool> + Send + Sync>| {
            // 工厂闭包包装
            f()
        }).await;
    }
}

/// 注册所有内置工具
pub async fn register_all_tools(registry: &ToolRegistry) {
    register_core_tools(registry).await;
    register_extended_tools(registry).await;
    register_deferred_tools(registry).await;
}
```

---

## 4.4 功能需求清单

### FR-TOOL-001：工具注册

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 支持工具的注册、发现与注销 |
| **验收标准** | 1. 通过 `ToolRegistry::register` 注册工具；2. 通过 `get` 按名称获取工具；3. 通过 `list_tools` 列出可见工具 |

### FR-TOOL-002：工具发现

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 生成工具定义列表供 LLM function calling 使用 |
| **验收标准** | 1. `tool_definitions()` 返回符合 JSON Schema 的工具定义；2. 按可见性层过滤；3. 按名称排序 |

### FR-TOOL-003：工具执行

| 属性 | 说明 |
|------|------|
| **优先级** | P0 |
| **描述** | 统一的工具执行入口，包含权限检查 |
| **验收标准** | 1. `execute_tool` 自动进行 Guardian 检查；2. 返回统一的 `ToolResult` 格式；3. 记录执行耗时 |

### FR-TOOL-004：权限检查

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 工具执行前进行权限检查 |
| **验收标准** | 1. Guardian 拦截时返回错误；2. 权限级别控制可见性；3. 审计日志记录检查结果 |

### FR-TOOL-005：结果格式化

| 属性 | 说明 |
|------|------|
| **优先级** | P1 |
| **描述** | 统一的工具结果格式 |
| **验收标准** | 1. `ToolResult` 包含 status/content/data/metadata/duration_ms；2. 提供 success/error/partial 便捷构造方法 |

### FR-TOOL-006：延迟加载

| 属性 | 说明 |
|------|------|
| **优先级** | P2 |
| **描述** | 低频工具延迟加载，减少启动时间 |
| **验收标准** | 1. 延迟工具首次使用时加载；2. 加载后缓存到 ToolRegistry；3. 使用 `once_cell::sync::Lazy` |

---

## 4.5 接口契约

### IC-TOOL-001：Tool trait

```
name() -> &str: 工具名称（snake_case）
description() -> &str: 工具描述（中文）
execute(params: Value) -> ToolResult: 执行工具
required_parameters() -> Value: JSON Schema
is_read_only() -> bool: 是否只读
category() -> ToolCategory: 工具目录
permission_level() -> PermissionLevel: 权限级别
```

### IC-TOOL-002：ToolRegistry::execute_tool

```
输入: caller: &str, tool_name: &str, params: Value
输出: ToolResult
流程:
  1. get(tool_name) 获取工具
  2. Guardian::check_tool_call 权限检查（如果配置）
  3. tool.execute(params) 执行工具
  4. 返回 ToolResult
```

### IC-TOOL-003：file_read 参数

```
path: string (必需) - 文件路径
offset: integer (可选) - 起始行号，默认 0
limit: integer (可选) - 读取行数，默认 200
大文件行为: >=1MB 返回摘要 + 指定行范围
```

### IC-TOOL-004：git 参数

```
subcommand: string (必需) - Git 子命令
args: string[] (可选) - 子命令参数
cwd: string (可选) - 工作目录，默认 "."
禁止: --force, -f, --hard, --no-verify
```

---

## 4.6 测试要点

### TC-TOOL-001：ToolRegistry 测试

| 测试项 | 说明 |
|--------|------|
| 注册工具 | 注册后可通过 get 获取 |
| 注销工具 | 注销后 get 返回 None |
| 列出工具 | list_tools 按可见性层过滤 |
| 工具定义 | tool_definitions 返回正确 Schema |
| 重复注册 | 同名工具覆盖旧工具 |

### TC-TOOL-002：file_read 测试

| 测试项 | 说明 |
|--------|------|
| 小文件 | <1MB 返回全部内容 |
| 大文件 | >=1MB 返回摘要 + 行范围 |
| 偏移量 | offset 参数正确跳过行 |
| 文件不存在 | 返回错误结果 |
| 二进制文件 | 返回错误或 base64 |

### TC-TOOL-003：search 测试

| 测试项 | 说明 |
|--------|------|
| 正则搜索 | 正确匹配正则表达式 |
| 文件过滤 | include 参数正确过滤文件名 |
| 结果限制 | max_results 限制返回数量 |
| 无效正则 | 返回错误结果 |

### TC-TOOL-004：terminal 测试

| 测试项 | 说明 |
|--------|------|
| 基本执行 | 执行命令返回输出 |
| Guardian 拦截 | 被拦截命令返回错误 |
| 超时 | 超时返回错误 |
| 工作目录 | cwd 参数正确设置 |

### TC-TOOL-005：git 测试

| 测试项 | 说明 |
|--------|------|
| 安全子命令 | status/log/diff 正常执行 |
| 禁止子命令 | 不允许的子命令返回错误 |
| 危险标志 | --force/--hard 被拦截 |
| 工作目录 | cwd 参数正确设置 |

### TC-TOOL-006：延迟加载测试

| 测试项 | 说明 |
|--------|------|
| 首次加载 | 首次 get 触发工厂创建 |
| 缓存 | 加载后直接从缓存获取 |
| 不可见工具 | Hidden 工具不出现在 list_tools |

---

> **文档结束** — P2 能力支撑层共包含 4 个模块：mc-llm、mc-prompt、mc-sandbox、mc-tool。
