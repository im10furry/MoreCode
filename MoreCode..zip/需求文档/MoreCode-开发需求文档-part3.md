# MoreCode Agent — 开发需求文档 Part 3：上下文与记忆层

> **版本**：v1.0
> **日期**：2026-04-17
> **定位**：P3 上下文与记忆层（mc-context、mc-memory）完整开发需求
> **预估工期**：5-7 天（P3-1 和 P3-2 并发）
> **依赖**：P1（mc-core、mc-communication、mc-config）、P2（mc-llm、mc-prompt、mc-sandbox）

---

## 架构文档引用

| 模块 | 引用文档 | 说明 |
|------|----------|------|
| mc-context | `06-平台与环境检测.md`（全文） | 平台环境检测、Shell 适配、路径处理 |
| mc-context | `09-上下文管理与通信.md`（全文） | 分层上下文池、Agent 间通信、滚动摘要 |
| mc-context | `12-上下文压缩策略.md`（全文） | 四层压缩架构、L0-L4 压缩策略 |
| mc-memory | `18-项目记忆系统.md`（全文） | 项目记忆结构、增量更新、失效检测 |
| mc-memory | `23-记忆系统增强(Letta式).md`（全文） | 四层分层记忆、Core/Working/Recall/Archival |
| mc-memory | `29-用户偏好自动记录学习.md` | 用户规则、偏好学习、置信度评估 |

---

# P3-1 mc-context — 上下文管理模块

## 模块概述

`mc-context` 负责平台环境检测、上下文池管理、上下文压缩和滚动摘要。它是所有 Agent 正确运行的基础设施——平台信息确保命令执行正确，上下文池确保 Token 高效利用，压缩策略确保长对话可持续运行。

**核心职责**：

1. **平台环境检测**：系统启动时一次性检测 OS、Shell、编码、路径风格、工具链等，生成 `PlatformInfo` 注入全局上下文
2. **分层上下文池**：管理全局上下文池（平台层 + 项目知识层 + 任务上下文层）和 Agent 独立上下文
3. **四层压缩策略**：L0 保留、L1 微压缩、L2 自动压缩、L3 暴力截断、L4 持久化，渐进式降级
4. **滚动摘要**：任务边界驱动的常态化压缩，通过专用 Summary Agent 生成结构化摘要包

---

## 大模型开发提示词

```
你正在开发 MoreCode Agent 系统的上下文管理模块 mc-context。

## 技术栈
- Rust 2021 edition，异步运行时 tokio
- 序列化：serde + serde_json
- Shell 转义：shlex crate
- 路径处理：std::path::PathBuf
- 正则缓存：std::sync::OnceLock
- 哈希：seahash（工具结果持久化文件命名）
- 时间处理：chrono

## 关键设计约束
1. 平台检测是系统启动后第一个动作，必须在 Coordinator 开始工作之前完成
2. 平台信息作为全局上下文的一部分，所有 Agent（含递归子 Agent）必须获取
3. 上下文压缩遵循零成本优先原则：能用规则解决的绝不调 LLM
4. 压缩事件必须可观测（tracing 日志 + 指标）
5. to_context_block() 输出直接注入 System Prompt，必须过滤敏感信息
6. Shell 命令转义必须使用 shlex::try_quote，防止命令注入
7. PATH 操纵安全：detect_executable_path 检测前需清理 PATH 中的用户可写目录
8. calculate_usage 应维护增量计数器，避免每次全量遍历 O(N)
9. extract_code_change 使用 OnceLock 缓存正则，避免重复编译
10. PlatformCache 使用 HMAC 签名验证缓存完整性

## 编码规范
- 错误处理：库级用 thiserror，边界用 anyhow
- 异步：所有 I/O 使用 tokio::fs，不使用 std::fs 阻塞调用
- 日志：使用 tracing crate，级别 info/warn/error
- 测试：单元测试覆盖核心逻辑，集成测试覆盖跨模块交互
```

---

## 核心类型定义

### 1. PlatformInfo — 平台环境信息

```rust
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// 平台环境完整信息（系统启动时一次性检测）
///
/// 此结构体是全局上下文池的不可省略基础层。
/// 所有 Agent（含递归子 Agent）必须获取此信息才能正确执行命令。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlatformInfo {
    /// 操作系统类型
    pub os: String,
    /// 系统架构（x86_64、aarch64、arm64 等）
    pub arch: String,
    /// 当前 Shell 类型
    pub shell: ShellType,
    /// Shell 可执行文件路径
    pub shell_path: String,
    /// Shell 版本
    pub shell_version: String,
    /// 用户主目录
    pub home_dir: PathBuf,
    /// 当前工作目录
    pub pwd: PathBuf,
    /// 关键环境变量（过滤敏感值后的安全子集）
    pub env_vars: HashMap<String, String>,
    /// 系统默认文件编码
    pub encoding: FileEncoding,
    /// 系统默认换行符
    pub line_ending: LineEnding,
    /// 路径分隔符
    pub path_separator: String,
    /// 路径是否大小写敏感
    pub case_sensitive: bool,
    /// 终端信息
    pub terminal: TerminalInfo,
    /// 可用包管理器列表
    pub package_managers: Vec<PackageManager>,
    /// 开发工具链版本信息
    pub dev_tools: DevToolChain,
    /// 是否运行在 WSL 中
    pub is_wsl: bool,
    /// 是否运行在容器中
    pub is_container: bool,
    /// Linux 发行版（仅 Linux）
    pub distribution: Option<String>,
    /// 检测时间戳
    pub detected_at: DateTime<Utc>,
}

/// Shell 类型枚举
///
/// 覆盖 Unix 系列（Bash/Zsh/Fish/Dash/Sh）和 Windows 系列（Cmd/PowerShell/Pwsh）。
/// 不同 Shell 的命令语法差异巨大，系统需要根据检测结果自动适配。
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum ShellType {
    // Unix 系列
    Bash,
    Zsh,
    Fish,
    Dash,
    Sh,
    // Windows 系列
    Cmd,           // cmd.exe
    PowerShell,    // Windows PowerShell 5.1
    Pwsh,          // PowerShell 7+ (跨平台)
    // 移动端
    Ash,           // Android / BusyBox
    // 未知
    Unknown(String),
}

/// Shell 命令适配配置
///
/// 根据当前 Shell 类型提供命令语法转换能力。
/// 所有涉及 Shell 命令拼接的场景必须通过此结构体进行转义。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ShellConfig {
    /// 当前 Shell 类型
    pub shell_type: ShellType,
    /// Shell 可执行文件路径
    pub executable_path: String,
    /// Shell 版本
    pub version: String,
    /// 是否为登录 Shell
    pub is_login_shell: bool,
    /// 是否为交互式 Shell
    pub is_interactive: bool,
    /// 系统上可用的其他 Shell
    pub available_shells: Vec<ShellType>,
}

impl ShellConfig {
    /// 设置环境变量
    ///
    /// 使用 shlex::try_quote 转义值，防止命令注入。
    /// 推荐使用 std::process::Command::env() 直接设置环境变量，
    /// 而非生成 shell 命令字符串。
    pub fn set_env_var(&self, key: &str, value: &str) -> String {
        match self.shell_type {
            ShellType::Bash | ShellType::Zsh | ShellType::Dash | ShellType::Sh => {
                // 使用 shlex::try_quote 转义值，防止命令注入
                let safe_value = shlex::try_quote(value)
                    .unwrap_or_else(|_| format!("\"{}\"", value));
                format!("export {}={}", key, safe_value)
            }
            ShellType::Fish => {
                let safe_value = shlex::try_quote(value)
                    .unwrap_or_else(|_| format!("\"{}\"", value));
                format!("set -gx {} {}", key, safe_value)
            }
            ShellType::PowerShell | ShellType::Pwsh => {
                // PowerShell 单引号内单引号双写
                format!("$env:{} = '{}'", key, value.replace('\'', "''"))
            }
            ShellType::Cmd => {
                // CMD 不支持单引号，使用双引号并转义内部双引号
                format!("set {}=\"{}\"", key, value.replace('\"', "\"\""))
            }
            _ => {
                let safe_value = shlex::try_quote(value)
                    .unwrap_or_else(|_| format!("\"{}\"", value));
                format!("export {}={}", key, safe_value)
            }
        }
    }

    /// 判断命令是否需要在特定 Shell 中执行
    ///
    /// 使用 shlex::try_quote 安全转义命令，防止 shell 注入。
    /// 返回 Some((shell_type, wrapped_command)) 表示需要切换 Shell；
    /// 返回 None 表示当前 Shell 即可执行。
    pub fn maybe_wrap_command(
        &self,
        command: &str,
        preferred_shell: &ShellType,
    ) -> Option<(ShellType, String)> {
        if &self.shell_type == preferred_shell {
            return None;
        }

        let (shell_cmd, flag) = match preferred_shell {
            ShellType::Bash => ("bash", "-c"),
            ShellType::Zsh => ("zsh", "-c"),
            ShellType::Fish => ("fish", "-c"),
            ShellType::PowerShell => ("powershell", "-Command"),
            ShellType::Pwsh => ("pwsh", "-Command"),
            ShellType::Cmd => ("cmd", "/c"),
            _ => return None,
        };

        // 使用 shlex::try_quote 安全转义命令，防止注入
        let safe_command = shlex::try_quote(command)
            .unwrap_or_else(|_| format!("'{}'", command.replace('\'', "'\\''")));

        Some((
            preferred_shell.clone(),
            format!("{} {} {}", shell_cmd, flag, safe_command),
        ))
    }
}

/// 文件编码类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum FileEncoding {
    UTF8,
    UTF8BOM,
    UTF16LE,
    UTF16BE,
    UTF32LE,
    UTF32BE,
    GBK,
    GB18030,
    ShiftJIS,
    EUCJP,
    EUCKR,
    Big5,
    ISO88591,
    ISO885915,
    Windows1252,
    ASCII,
    Unknown,
}

/// 换行符类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum LineEnding {
    LF,    // \n (Unix/macOS)
    CRLF,  // \r\n (Windows)
    CR,    // \r (旧 Mac OS)
    Mixed, // 混合使用
}

/// 终端信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TerminalInfo {
    /// TERM 环境变量
    pub term: String,
    /// 终端程序（vscode、iTerm.app、WindowsTerminal 等）
    pub term_program: String,
    /// 终端列数
    pub cols: usize,
    /// 终端行数
    pub rows: usize,
    /// 是否支持颜色
    pub color_support: bool,
    /// 是否支持真彩色 (24-bit)
    pub true_color: bool,
}

/// 包管理器信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PackageManager {
    /// 包管理器名称（apt、brew、cargo、npm、pip 等）
    pub name: String,
    /// 安装命令（apt install、brew install 等）
    pub command: String,
    /// 版本号
    pub version: String,
}

/// 开发工具链版本信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DevToolChain {
    pub git: Option<String>,
    pub rustc: Option<String>,
    pub cargo: Option<String>,
    pub node: Option<String>,
    pub npm: Option<String>,
    pub python: Option<String>,
    pub pip: Option<String>,
    pub docker: Option<String>,
    pub go: Option<String>,
    pub java: Option<String>,
}
```

### 2. PlatformInfo 检测与缓存

```rust
use std::sync::Arc;
use tokio::sync::RwLock;
use hmac::{Hmac, Mac};
use sha2::Sha256;

/// 平台缓存——避免重复执行检测命令
///
/// 使用 HMAC-SHA256 签名验证缓存完整性。
/// 缓存键为检测时的关键环境参数哈希，防止环境变化后使用过期缓存。
#[derive(Debug)]
pub struct PlatformCache {
    /// 缓存的平台信息
    cached_info: RwLock<Option<Arc<PlatformInfo>>>,
    /// 缓存签名密钥
    hmac_key: [u8; 32],
    /// 缓存有效期（秒）
    ttl_secs: u64,
    /// 缓存写入时间
    cached_at: RwLock<Option<std::time::Instant>>,
}

impl PlatformCache {
    pub fn new() -> Self {
        Self {
            cached_info: RwLock::new(None),
            hmac_key: [0u8; 32], // 实际应从安全随机源生成
            ttl_secs: 3600,      // 默认 1 小时
            cached_at: RwLock::new(None),
        }
    }

    /// 获取平台信息（缓存命中则直接返回，否则执行检测）
    pub async fn get_or_detect<F, Fut>(&self, detect_fn: F) -> anyhow::Result<Arc<PlatformInfo>>
    where
        F: FnOnce() -> Fut,
        Fut: std::future::Future<Output = anyhow::Result<PlatformInfo>>,
    {
        // 1. 快速路径：读锁检查缓存
        {
            let cached = self.cached_info.read().await;
            let cached_at = self.cached_at.read().await;

            if let (Some(info), Some(at)) = (cached.as_ref(), cached_at.as_ref()) {
                if at.elapsed().as_secs() < self.ttl_secs {
                    // HMAC 签名验证
                    if self.verify_signature(&info) {
                        return Ok(Arc::clone(info));
                    }
                }
            }
        }

        // 2. 慢路径：执行检测
        let info = detect_fn().await?;
        let info = Arc::new(info);

        // 3. 写入缓存
        {
            let mut cached = self.cached_info.write().await;
            let mut cached_at = self.cached_at.write().await;
            *cached = Some(Arc::clone(&info));
            *cached_at = Some(std::time::Instant::now());
        }

        Ok(info)
    }

    /// HMAC-SHA256 签名验证
    fn verify_signature(&self, info: &PlatformInfo) -> bool {
        type HmacSha256 = Hmac<Sha256>;

        let serialized = serde_json::to_string(info).unwrap_or_default();
        let mut mac = HmacSha256::new_from_slice(&self.hmac_key).unwrap();
        mac.update(serialized.as_bytes());

        // 实际应与存储的签名比对，此处简化为始终返回 true
        true
    }

    /// 使缓存失效
    pub async fn invalidate(&self) {
        let mut cached = self.cached_info.write().await;
        let mut cached_at = self.cached_at.write().await;
        *cached = None;
        *cached_at = None;
    }
}

impl PlatformInfo {
    /// 将平台信息格式化为 Agent 可读的上下文片段（注入到 System Prompt）
    ///
    /// **安全注意**：此内容直接注入到 LLM 的 System Prompt 中，必须确保：
    /// - 不包含敏感信息（API 密钥、密码、Token）
    /// - 过滤控制字符（NULL、ESC 等可能干扰 prompt 解析的字符）
    /// - 限制总长度（建议不超过 2000 字符），防止上下文膨胀
    /// - 所有动态值（版本号、路径等）需做基本清理
    pub fn to_context_block(&self) -> String {
        format!(
            r#"## 平台环境信息

- **操作系统**: {os} ({arch})
- **Shell**: {shell_name} {shell_version}
- **文件编码**: {encoding}
- **换行符**: {line_ending}
- **路径分隔符**: {separator}
- **路径大小写敏感**: {case_sensitive}
- **终端**: {term_program} ({cols}x{rows})
- **颜色支持**: {color_info}
- **可用包管理器**: {pkg_managers}
- **开发工具链**:
{dev_tools}

### 命令执行注意事项
- 当前 Shell 为 **{shell_name}**，请使用对应的命令语法
- 文件操作请使用 `{separator}` 作为路径分隔符
- 创建文件时请使用 `{line_ending}` 换行符
- 路径包含空格时请使用引号包裹"#,
            os = self.os,
            arch = self.arch,
            shell_name = match &self.shell {
                ShellType::Bash => "Bash",
                ShellType::Zsh => "Zsh",
                ShellType::Fish => "Fish",
                ShellType::Cmd => "CMD",
                ShellType::PowerShell => "PowerShell",
                ShellType::Pwsh => "PowerShell 7+",
                ShellType::Dash => "Dash",
                ShellType::Sh => "Sh",
                ShellType::Ash => "Ash",
                ShellType::Unknown(name) => name.as_str(),
            },
            shell_version = self.shell_version,
            encoding = match self.encoding {
                FileEncoding::UTF8 => "UTF-8",
                FileEncoding::GBK => "GBK (中文 Windows)",
                FileEncoding::ShiftJIS => "Shift-JIS (日文)",
                _ => "UTF-8",
            },
            line_ending = match self.line_ending {
                LineEnding::LF => "LF (\\n)",
                LineEnding::CRLF => "CRLF (\\r\\n)",
                _ => "LF (\\n)",
            },
            separator = self.path_separator,
            case_sensitive = if self.case_sensitive { "是" } else { "否" },
            term_program = self.terminal.term_program,
            cols = self.terminal.cols,
            rows = self.terminal.rows,
            color_info = if self.terminal.true_color {
                "真彩色 (24-bit)"
            } else if self.terminal.color_support {
                "256 色"
            } else {
                "不支持"
            },
            pkg_managers = if self.package_managers.is_empty() {
                "未检测到".to_string()
            } else {
                self.package_managers
                    .iter()
                    .map(|p| format!("{} ({})", p.name, p.version))
                    .collect::<Vec<_>>()
                    .join(", ")
            },
            dev_tools = self.format_dev_tools(),
        )
    }

    fn format_dev_tools(&self) -> String {
        let tools = [
            ("Git", &self.dev_tools.git),
            ("Rust", &self.dev_tools.rustc),
            ("Node.js", &self.dev_tools.node),
            ("Python", &self.dev_tools.python),
            ("Docker", &self.dev_tools.docker),
            ("Go", &self.dev_tools.go),
        ];

        tools
            .iter()
            .filter(|(_, v)| v.is_some())
            .map(|(name, v)| format!("  - {}: {}", name, v.as_ref().unwrap()))
            .collect::<Vec<_>>()
            .join("\n")
    }
}
```

### 3. 路径处理工具

```rust
/// 路径风格
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum PathStyle {
    Unix,    // /home/user/project
    Windows, // C:\Users\project
    Unc,     // \\server\share\path
}

/// 路径处理工具
pub struct PathHandler {
    pub style: PathStyle,
    pub separator: char,
    pub max_length: usize,
    pub case_sensitive: bool,
}

impl PathHandler {
    pub fn new(os: &str) -> Self {
        match os {
            "windows" => PathHandler {
                style: PathStyle::Windows,
                separator: '\\',
                max_length: 260,
                case_sensitive: false,
            },
            "macos" => PathHandler {
                style: PathStyle::Unix,
                separator: '/',
                max_length: 1024,
                case_sensitive: false,
            },
            _ => PathHandler {
                style: PathStyle::Unix,
                separator: '/',
                max_length: 4096,
                case_sensitive: true,
            },
        }
    }

    /// 标准化路径：统一分隔符，消除 "." 和 ".." 段
    pub fn normalize(&self, path: &str) -> String {
        let path = path.replace('\\', "/");
        // 循环替换连续的分隔符（如 "a///b" → "a/b"）
        let mut path = path;
        while path.contains("//") {
            path = path.replace("//", "/");
        }
        // 消除 "." 和 ".." 段
        let segments: Vec<&str> = path.split('/').collect();
        let mut stack: Vec<&str> = Vec::new();
        for seg in segments {
            match seg {
                "" | "." => continue,
                ".." => {
                    stack.pop();
                }
                _ => stack.push(seg),
            }
        }
        let result = stack.join("/");
        // 处理 Windows 盘符: C:/ → C:/
        if result.len() >= 2 && result.chars().nth(1) == Some(':') {
            format!("{}{}", &result[..2], &result[2..])
        } else {
            result
        }
    }
}
```

### 4. detect_executable_path — 安全检测

```rust
/// 检测可执行文件路径
///
/// **安全注意**：`which` 命令依赖 PATH 环境变量，攻击者可通过修改 PATH
/// 将恶意可执行文件放在前面。
///
/// **缓解措施**：
/// - 检测前清理 PATH 中的用户可写目录（如 `/tmp`、`~/bin`）
/// - 对检测结果做哈希校验，确认是预期的可执行文件
/// - 关键操作（如 Guardian 检查）使用硬编码路径而非 PATH 查找结果
pub async fn detect_executable_path(cmd_name: &str) -> String {
    // 清理 PATH 中的危险目录
    let safe_path = sanitize_path_env();

    #[cfg(unix)]
    {
        let output = tokio::process::Command::new("which")
            .arg(cmd_name)
            .env("PATH", &safe_path)
            .output()
            .await
            .ok()
            .and_then(|o| String::from_utf8(o.stdout).ok())
            .map(|s| s.trim().to_string())
            .unwrap_or_else(|| cmd_name.to_string());

        // 哈希校验（简化示意）
        output
    }

    #[cfg(windows)]
    {
        let output = tokio::process::Command::new("where")
            .arg(cmd_name)
            .env("PATH", &safe_path)
            .output()
            .await
            .ok()
            .and_then(|o| String::from_utf8(o.stdout).ok())
            .map(|s| s.lines().next().unwrap_or("").to_string())
            .unwrap_or_else(|| cmd_name.to_string());

        output
    }

    #[allow(unreachable_code)]
    {
        cmd_name.to_string()
    }
}

/// 清理 PATH 环境变量中的危险目录
fn sanitize_path_env() -> String {
    let current_path = std::env::var("PATH").unwrap_or_default();
    let dangerous_prefixes = ["/tmp", "/var/tmp"];

    let filtered: Vec<&str> = std::env::split_paths(&current_path)
        .filter(|p| {
            let path_str = p.to_string_lossy();
            !dangerous_prefixes.iter().any(|d| path_str.starts_with(d))
        })
        .collect();

    std::env::join_paths(filtered)
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or(current_path)
}
```

### 5. ContextPool — 分层上下文池

```rust
use std::sync::Arc;

/// 上下文注入策略
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum InjectionStrategy {
    /// 直接注入：完整内容放入 System Prompt
    DirectInjection,
    /// 压缩摘要注入：只注入摘要
    CompressedSummary,
    /// 结构化注入：按字段选择性注入
    Structured {
        /// 要注入的字段列表
        fields: Vec<String>,
    },
}

/// 上下文层类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum ContextLayer {
    /// 平台环境层（不可省略，~500 tokens）
    Platform,
    /// 项目知识层（~8K tokens）
    ProjectKnowledge,
    /// 任务上下文层（~7K tokens）
    TaskContext,
    /// Agent 独立上下文
    AgentSpecific(String),
}

/// 分层上下文池
///
/// 管理全局上下文池（三层）和各 Agent 的独立上下文。
/// 确保每个 Agent 只获取必要的信息，避免上下文污染和 Token 浪费。
pub struct ContextPool {
    /// 平台环境信息（不可省略）
    platform_info: Arc<PlatformInfo>,
    /// 项目知识层内容
    project_knowledge: RwLock<String>,
    /// 任务上下文层内容
    task_context: RwLock<String>,
    /// 各 Agent 的独立上下文
    agent_contexts: RwLock<HashMap<String, String>>,
    /// 全局 Token 预算
    global_token_budget: usize,
    /// 上下文注入策略
    injection_strategy: InjectionStrategy,
}

impl ContextPool {
    pub fn new(
        platform_info: Arc<PlatformInfo>,
        global_token_budget: usize,
    ) -> Self {
        Self {
            platform_info,
            project_knowledge: RwLock::new(String::new()),
            task_context: RwLock::new(String::new()),
            agent_contexts: RwLock::new(HashMap::new()),
            global_token_budget,
            injection_strategy: InjectionStrategy::DirectInjection,
        }
    }

    /// 为指定 Agent 构建完整上下文
    ///
    /// 拼装顺序：平台环境层 -> 项目知识层 -> 任务上下文层 -> Agent 独立上下文
    pub async fn build_context_for_agent(
        &self,
        agent_id: &str,
        agent_type: &str,
    ) -> String {
        let mut context = String::new();

        // 1. 平台环境层（不可省略）
        context.push_str(&self.platform_info.to_context_block());
        context.push_str("\n\n");

        // 2. 项目知识层
        let knowledge = self.project_knowledge.read().await;
        if !knowledge.is_empty() {
            context.push_str("## 项目知识\n\n");
            context.push_str(knowledge);
            context.push_str("\n\n");
        }

        // 3. 任务上下文层
        let task = self.task_context.read().await;
        if !task.is_empty() {
            context.push_str("## 任务上下文\n\n");
            context.push_str(task);
            context.push_str("\n\n");
        }

        // 4. Agent 独立上下文
        let agent_ctxs = self.agent_contexts.read().await;
        if let Some(agent_ctx) = agent_ctxs.get(agent_id) {
            context.push_str(&format!("## {} 专属上下文\n\n", agent_type));
            context.push_str(agent_ctx);
        }

        context
    }

    /// 更新项目知识层
    pub async fn update_project_knowledge(&self, content: String) {
        let mut knowledge = self.project_knowledge.write().await;
        *knowledge = content;
    }

    /// 更新任务上下文层
    pub async fn update_task_context(&self, content: String) {
        let mut task = self.task_context.write().await;
        *task = content;
    }

    /// 设置 Agent 独立上下文
    pub async fn set_agent_context(&self, agent_id: String, content: String) {
        let mut ctxs = self.agent_contexts.write().await;
        ctxs.insert(agent_id, content);
    }

    /// 估算当前上下文池的 Token 消耗
    pub async fn estimate_tokens(&self) -> usize {
        let knowledge = self.project_knowledge.read().await;
        let task = self.task_context.read().await;
        let agent_ctxs = self.agent_contexts.read().await;

        let platform_tokens = self.platform_info.to_context_block().len() / 4;
        let knowledge_tokens = knowledge.len() / 4;
        let task_tokens = task.len() / 4;
        let agent_tokens: usize = agent_ctxs.values().map(|c| c.len() / 4).sum();

        platform_tokens + knowledge_tokens + task_tokens + agent_tokens
    }
}
```

### 6. 四层压缩策略类型

```rust
use std::sync::OnceLock;

/// L0 保留策略：最近 N 轮完整保留
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct L0RetentionPolicy {
    /// 完整保留的最近轮次数
    pub keep_recent_rounds: usize,
}

impl Default for L0RetentionPolicy {
    fn default() -> Self {
        Self {
            keep_recent_rounds: 2,
        }
    }
}

/// L1 微压缩器——零成本规则清除
#[derive(Debug, Clone)]
pub struct MicroCompactor {
    /// 最小轮次间隔：只清除 N 轮之前的工具结果
    min_turn_gap: usize,
    /// 小结果阈值（字符数）：低于此值不处理
    small_result_threshold: usize,
    /// 大结果阈值（字符数）：超过此值持久化到磁盘
    large_result_threshold: usize,
    /// 临时文件存储目录
    temp_dir: PathBuf,
}

impl Default for MicroCompactor {
    fn default() -> Self {
        Self {
            min_turn_gap: 3,
            small_result_threshold: 10_000,
            large_result_threshold: 50_000,
            temp_dir: PathBuf::from(".assistant-memory/tmp"),
        }
    }
}

impl MicroCompactor {
    /// 对消息列表执行微压缩
    /// 返回：(压缩后的消息列表, 压缩统计)
    pub async fn compact(
        &self,
        messages: &mut Vec<ChatMessage>,
        current_turn: usize,
    ) -> CompactStats {
        let mut stats = CompactStats::default();

        for msg in messages.iter_mut() {
            if msg.role != MessageRole::Tool {
                continue;
            }

            let msg_turn = msg.turn.unwrap_or(0);
            if msg_turn >= current_turn.saturating_sub(self.min_turn_gap) {
                continue;
            }

            let content_len = msg.content.len();
            if content_len <= self.small_result_threshold {
                continue;
            }

            // 大结果：持久化到磁盘（使用 tokio::fs）
            if content_len > self.large_result_threshold {
                match self.persist_to_disk(&msg.content, msg_turn).await {
                    Ok(file_path) => {
                        msg.content = format!(
                            "[Old tool result saved to {} (was {} chars)]",
                            file_path.display(),
                            content_len
                        );
                        stats.large_cleared += 1;
                        stats.chars_saved += content_len;
                    }
                    Err(e) => {
                        // 持久化失败，降级为占位符
                        msg.content = format!(
                            "[Old tool result content cleared (was {} chars, persist failed: {})]",
                            content_len, e
                        );
                        stats.small_cleared += 1;
                        stats.chars_saved += content_len;
                    }
                }
            } else {
                // 小结果：直接替换为占位符
                msg.content = format!(
                    "[Old tool result content cleared (was {} chars)]",
                    content_len
                );
                stats.small_cleared += 1;
                stats.chars_saved += content_len;
            }
        }

        stats
    }

    /// 将大结果持久化到磁盘（使用 tokio::fs 异步 I/O）
    async fn persist_to_disk(
        &self,
        content: &str,
        turn: usize,
    ) -> anyhow::Result<PathBuf> {
        tokio::fs::create_dir_all(&self.temp_dir).await?;

        let hash = seahash::hash(content.as_bytes());
        let file_name = format!("tool-result-turn{}-{:016x}.txt", turn, hash);
        let file_path = self.temp_dir.join(&file_name);

        tokio::fs::write(&file_path, content).await?;
        Ok(file_path)
    }
}

/// L2 自动压缩器——LLM 驱动的智能摘要
#[derive(Debug, Clone)]
pub struct AutoCompactor {
    /// 触发压缩的 Token 使用率阈值
    trigger_threshold: f64,
    /// 压缩后的目标 Token 使用率
    target_usage: f64,
    /// LLM 客户端（用于生成摘要）
    llm_client: Option<Arc<dyn LlmClient>>,
    /// 压缩提示词模板
    prompt_template: String,
    /// LLM 最大上下文 Token 数
    max_context_tokens: usize,
}

impl Default for AutoCompactor {
    fn default() -> Self {
        Self {
            trigger_threshold: 0.85,
            target_usage: 0.50,
            llm_client: None,
            prompt_template: include_str!("prompts/compact_summary.txt"),
            max_context_tokens: 128_000,
        }
    }
}

/// 压缩摘要的结构化输出
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompactSummary {
    /// 用户原始请求
    pub user_request: String,
    /// 已完成的工作列表
    pub completed_work: Vec<String>,
    /// 当前执行状态
    pub current_state: String,
    /// 关键技术决策
    pub key_decisions: Vec<String>,
    /// 错误信息（含解决状态）
    pub error_info: Vec<String>,
    /// 继续上下文（下一步 + 约束）
    pub continuation_context: String,
}

impl CompactSummary {
    /// 将摘要转换为可注入上下文的消息
    pub fn to_context_message(&self) -> ChatMessage {
        let content = format!(
            "[Context Compacted]\n\
             ## User Request\n{}\n\n\
             ## Completed Work\n{}\n\n\
             ## Current State\n{}\n\n\
             ## Key Decisions\n{}\n\n\
             ## Error Info\n{}\n\n\
             ## Continuation Context\n{}",
            self.user_request,
            self.completed_work
                .iter()
                .map(|w| format!("- {}", w))
                .collect::<Vec<_>>()
                .join("\n"),
            self.current_state,
            self.key_decisions
                .iter()
                .map(|d| format!("- {}", d))
                .collect::<Vec<_>>()
                .join("\n"),
            self.error_info
                .iter()
                .map(|e| format!("- {}", e))
                .collect::<Vec<_>>()
                .join("\n"),
            self.continuation_context,
        );

        ChatMessage {
            role: MessageRole::System,
            content,
            turn: None,
            ..Default::default()
        }
    }
}

/// 压缩统计
#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct CompactStats {
    /// 小结果清除数量（直接替换为占位符）
    pub small_cleared: usize,
    /// 大结果清除数量（持久化到磁盘）
    pub large_cleared: usize,
    /// 总共节省的字符数
    pub chars_saved: usize,
}

impl CompactStats {
    /// 估算节省的 Token 数（保守按 4 字符/token）
    pub fn estimated_tokens_saved(&self) -> usize {
        self.chars_saved / 4
    }
}

/// 消息角色
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MessageRole {
    System,
    User,
    Assistant,
    Tool,
}

/// 聊天消息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatMessage {
    pub role: MessageRole,
    pub content: String,
    pub turn: Option<usize>,
    pub tool_call_id: Option<String>,
}

impl Default for ChatMessage {
    fn default() -> Self {
        Self {
            role: MessageRole::User,
            content: String::new(),
            turn: None,
            tool_call_id: None,
        }
    }
}

/// LLM 客户端 trait（由 mc-llm 提供）
#[async_trait::async_trait]
pub trait LlmClient: Send + Sync {
    async fn complete(
        &self,
        request: LlmRequest,
    ) -> Result<LlmResponse, LlmError>;
}

/// LLM 请求
#[derive(Debug, Clone)]
pub struct LlmRequest {
    pub messages: Vec<ChatMessage>,
    pub temperature: Option<f64>,
    pub max_tokens: Option<usize>,
    pub response_format: Option<ResponseFormat>,
}

/// LLM 响应
#[derive(Debug, Clone)]
pub struct LlmResponse {
    pub content: String,
}

/// 响应格式
#[derive(Debug, Clone)]
pub enum ResponseFormat {
    Json,
    Text,
}

/// LLM 错误
#[derive(Debug, thiserror::Error)]
pub enum LlmError {
    #[error("API 错误: {message}")]
    ApiError { message: String, status_code: u16 },
    #[error("上下文长度超限")]
    ContextLengthExceeded,
    #[error("超时")]
    Timeout,
}

/// Token 计数器 trait
pub trait TokenCounter: Send + Sync {
    fn count(&self, text: &str) -> usize;
}
```

### 7. AutoCompactor 实现

```rust
impl AutoCompactor {
    /// 检查是否需要压缩，如果需要则执行压缩
    /// 返回：Some(压缩后的消息列表) 或 None（无需压缩）
    pub async fn maybe_compact(
        &self,
        messages: &[ChatMessage],
        token_counter: &dyn TokenCounter,
        max_tokens: usize,
    ) -> anyhow::Result<Option<Vec<ChatMessage>>> {
        let current_usage = self.calculate_usage(messages, token_counter, max_tokens);

        if current_usage < self.trigger_threshold {
            return Ok(None);
        }

        tracing::info!(
            usage = current_usage,
            threshold = self.trigger_threshold,
            "L2 Auto-Compact triggered: token usage {:.1}% exceeds threshold {:.1}%",
            current_usage * 100.0,
            self.trigger_threshold * 100.0,
        );

        let summary = self.generate_summary(messages).await?;
        let compacted = self.rebuild_messages(messages, summary);

        Ok(Some(compacted))
    }

    /// 调用 LLM 生成压缩摘要
    ///
    /// **降级策略**：如果输入超过 LLM 窗口 70%，先做规则截断再压缩；
    /// L2 失败则降级到 L1 规则截断，最终兜底 L4 暴力截断。
    async fn generate_summary(
        &self,
        messages: &[ChatMessage],
    ) -> anyhow::Result<CompactSummary> {
        let conversation_text = messages
            .iter()
            .map(|m| format!("[{}] {}", format!("{:?}", m.role), m.content))
            .collect::<Vec<_>>()
            .join("\n\n");

        // 输入长度检查：超过 LLM 窗口 70% 时先做规则截断
        let input_tokens = conversation_text.len() / 4;
        let max_input_tokens = (self.max_context_tokens as f64 * 0.7) as usize;

        let truncated_text = if input_tokens > max_input_tokens {
            tracing::warn!(
                input_tokens,
                max_input_tokens,
                "L2 压缩输入超过窗口 70%，先做规则截断"
            );
            // 保留最近 60% + 最早 20% 的内容，丢弃中间 20%
            let total_chars = conversation_text.len();
            let head_end = total_chars * 20 / 100;
            let tail_start = total_chars * 40 / 100;
            format!(
                "[...中间 {} 字符已截断...]\n{}\n[...]\n{}",
                tail_start - head_end,
                &conversation_text[..head_end],
                &conversation_text[tail_start..]
            )
        } else {
            conversation_text
        };

        let prompt = self
            .prompt_template
            .replace("{conversation_history}", &truncated_text);

        let response = self
            .llm_client
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("LLM 客户端未配置"))?
            .complete(LlmRequest {
                messages: vec![ChatMessage::system(&prompt)],
                temperature: Some(0.1),
                max_tokens: Some(4096),
                response_format: Some(ResponseFormat::Json),
            })
            .await
            .map_err(|e| {
                tracing::error!(error = %e, "L2 压缩失败，将降级到 L1 规则截断");
                e
            })?;

        let summary: CompactSummary = serde_json::from_str(&response.content)?;
        Ok(summary)
    }

    /// 用摘要替换原始消息列表
    fn rebuild_messages(
        &self,
        messages: &[ChatMessage],
        summary: CompactSummary,
    ) -> Vec<ChatMessage> {
        let mut rebuilt = Vec::new();

        // 1. 保留系统提示（如果有）
        if let Some(sys) = messages.first().filter(|m| m.role == MessageRole::System) {
            rebuilt.push(sys.clone());
        }

        // 2. 注入压缩摘要
        rebuilt.push(summary.to_context_message());

        // 3. 保留最近 2 轮消息（确保连续性）
        let recent_count = messages.len().saturating_sub(4);
        if recent_count < messages.len() {
            rebuilt.extend(messages[recent_count..].to_vec());
        }

        rebuilt
    }

    /// 计算 Token 使用率
    ///
    /// **性能优化方向**：当前实现每次全量遍历计算，O(N) 复杂度。
    /// 生产环境应维护增量计数器：
    /// - 每次消息增删时更新 `cached_total_tokens`
    /// - `calculate_usage` 直接返回 `cached_total_tokens / max_tokens`
    /// - 仅在缓存失效时（如消息被替换）做全量重算
    fn calculate_usage(
        &self,
        messages: &[ChatMessage],
        token_counter: &dyn TokenCounter,
        max_tokens: usize,
    ) -> f64 {
        let total_tokens: usize = messages
            .iter()
            .map(|m| token_counter.count(&m.content))
            .sum();

        total_tokens as f64 / max_tokens as f64
    }
}

impl ChatMessage {
    pub fn system(content: &str) -> Self {
        Self {
            role: MessageRole::System,
            content: content.to_string(),
            turn: None,
            tool_call_id: None,
        }
    }
}
```

### 8. L3 记忆压缩器

```rust
/// L3 记忆压缩器——将关键信息提取到持久记忆
#[derive(Debug, Clone)]
pub struct MemoryCompactor {
    /// 触发压缩的 Token 使用率阈值
    trigger_threshold: f64,
    /// 记忆系统客户端
    memory_store: Option<Arc<dyn MemoryStore>>,
    /// 提取规则列表
    extraction_rules: Vec<ExtractionRule>,
}

/// 信息提取规则
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExtractionRule {
    pub name: String,
    pub pattern: String,
    pub target_file: String,
    pub extractor_type: ExtractorType,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ExtractorType {
    DependencyChange,
    Convention,
    RiskArea,
    CodeChange,
    BugRecord,
}

impl Default for MemoryCompactor {
    fn default() -> Self {
        Self {
            trigger_threshold: 0.90,
            memory_store: None,
            extraction_rules: vec![
                ExtractionRule {
                    name: "cargo_dependency".into(),
                    pattern: r"Cargo\.toml.*added|changed|removed".into(),
                    target_file: "tech-stack.json".into(),
                    extractor_type: ExtractorType::DependencyChange,
                },
                ExtractionRule {
                    name: "code_convention".into(),
                    pattern: r"convention|pattern|本项目.*使用".into(),
                    target_file: "conventions.md".into(),
                    extractor_type: ExtractorType::Convention,
                },
                ExtractionRule {
                    name: "bug_found".into(),
                    pattern: r"error|bug|panic|compile.*fail".into(),
                    target_file: "agent-notes/debugger/bug-history.json".into(),
                    extractor_type: ExtractorType::BugRecord,
                },
            ],
        }
    }
}

impl MemoryCompactor {
    /// 从压缩摘要中提取信息并写入记忆系统
    pub async fn extract_and_persist(
        &self,
        summary: &CompactSummary,
        session_id: &str,
    ) -> anyhow::Result<MemoryCompactResult> {
        let mut result = MemoryCompactResult::default();

        let store = self.memory_store.as_ref().ok_or_else(|| {
            anyhow::anyhow!("MemoryStore 未配置，无法执行记忆压缩")
        })?;

        // 1. 提取已完成工作中的代码变更
        for work_item in &summary.completed_work {
            if let Some(entry) = self.extract_code_change(work_item) {
                store
                    .append("agent-notes/coder/recent-changes.json", &entry)
                    .await?;
                result.code_changes += 1;
            }
        }

        // 2. 提取错误信息中的 Bug 记录
        for error in &summary.error_info {
            if let Some(entry) = self.extract_bug_record(error) {
                store
                    .append("agent-notes/debugger/bug-history.json", &entry)
                    .await?;
                result.bug_records += 1;
            }
        }

        // 3. 提取关键决策中的编码约定
        for decision in &summary.key_decisions {
            if self.matches_convention_pattern(decision) {
                store
                    .append("conventions.md", &format!("- {}\n", decision))
                    .await?;
                result.conventions += 1;
            }
        }

        tracing::info!(
            code_changes = result.code_changes,
            bug_records = result.bug_records,
            conventions = result.conventions,
            "L3 Memory-Compact completed",
        );

        Ok(result)
    }

    /// 从工作项中提取代码变更记录
    ///
    /// 使用 OnceLock 缓存正则表达式，避免每次调用都重新编译正则。
    fn extract_code_change(&self, work_item: &str) -> Option<serde_json::Value> {
        use std::sync::OnceLock;
        static FILE_PATTERN: OnceLock<regex::Regex> = OnceLock::new();
        let file_pattern = FILE_PATTERN.get_or_init(|| {
            regex::Regex::new(r"([\w./-]+\.\w+)").unwrap()
        });

        let captures: Vec<_> = file_pattern.captures_iter(work_item).collect();

        if captures.is_empty() {
            return None;
        }

        Some(serde_json::json!({
            "timestamp": chrono::Utc::now().to_rfc3339(),
            "files": captures.iter().map(|c| c[1].to_string()).collect::<Vec<_>>(),
            "description": work_item,
        }))
    }

    fn extract_bug_record(&self, error: &str) -> Option<serde_json::Value> {
        if error.len() < 10 {
            return None;
        }
        Some(serde_json::json!({
            "timestamp": chrono::Utc::now().to_rfc3339(),
            "error": error,
            "status": "recorded",
        }))
    }

    fn matches_convention_pattern(&self, text: &str) -> bool {
        let patterns = ["使用", "统一", "约定", "规范", "convention", "pattern"];
        patterns.iter().any(|p| text.contains(p))
    }
}

/// 记忆压缩结果
#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct MemoryCompactResult {
    pub code_changes: usize,
    pub bug_records: usize,
    pub conventions: usize,
}

/// 记忆存储 trait（由 mc-memory 提供）
#[async_trait::async_trait]
pub trait MemoryStore: Send + Sync {
    async fn append(
        &self,
        path: &str,
        entry: &serde_json::Value,
    ) -> anyhow::Result<()>;
}
```

### 9. L4 反应式截断器

```rust
/// L4 反应式截断器——最后的手段
#[derive(Debug, Clone)]
pub struct ReactiveTruncator {
    /// 保留的消息比例
    retention_ratio: f64,
    /// 是否始终保留系统提示
    keep_system_prompt: bool,
    /// 最少保留的消息数
    min_messages: usize,
}

impl Default for ReactiveTruncator {
    fn default() -> Self {
        Self {
            retention_ratio: 0.80,
            keep_system_prompt: true,
            min_messages: 4,
        }
    }
}

impl ReactiveTruncator {
    /// 执行反应式截断
    /// 返回：(截断后的消息列表, 被丢弃的消息数)
    pub fn truncate(
        &self,
        messages: &[ChatMessage],
    ) -> (Vec<ChatMessage>, usize) {
        if messages.len() <= self.min_messages {
            return (messages.to_vec(), 0);
        }

        let mut result = Vec::new();
        let mut dropped = 0;

        // 1. 始终保留系统提示
        if self.keep_system_prompt {
            if let Some(sys) = messages.first().filter(|m| m.role == MessageRole::System) {
                result.push(sys.clone());
            }
        }

        // 2. 计算要保留的非系统消息数量
        let non_system: Vec<&ChatMessage> = messages
            .iter()
            .filter(|m| m.role != MessageRole::System)
            .collect();

        let keep_count = (non_system.len() as f64 * self.retention_ratio)
            .ceil() as usize;
        let keep_count = keep_count.max(self.min_messages);

        // 3. 保留尾部消息（最近的对话）
        let start = non_system.len().saturating_sub(keep_count);
        dropped = start;

        for msg in non_system[start..].iter() {
            result.push((*msg).clone());
        }

        tracing::warn!(
            total = messages.len(),
            kept = result.len(),
            dropped = dropped,
            "L4 Reactive-Truncate executed: dropped {} oldest messages",
            dropped,
        );

        (result, dropped)
    }

    /// 检查 API 错误是否为上下文长度超限
    pub fn is_context_length_error(error: &LlmError) -> bool {
        match error {
            LlmError::ApiError { message, .. } => {
                let msg_lower = message.to_lowercase();
                msg_lower.contains("prompt_too_long")
                    || msg_lower.contains("maximum context length")
                    || msg_lower.contains("context_length_exceeded")
                    || msg_lower.contains("token limit")
            }
            LlmError::ContextLengthExceeded => true,
            _ => false,
        }
    }
}
```

### 10. RollingSummaryPacket — 滚动摘要包

```rust
/// 滚动摘要数据包
///
/// Summary Agent 的返回协议。
/// 父 Agent 默认只合并此结构体，不直接回灌子 Agent 的完整推理过程。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RollingSummaryPacket {
    /// 当前轮次 ID
    pub round_id: u64,
    /// 钉住信息更新（新约束、新决策）
    pub pinned_updates: Vec<String>,
    /// 摘要正文（Markdown 格式）
    pub summary_markdown: String,
    /// 本轮关键决策列表
    pub key_decisions: Vec<String>,
    /// 未解决事项列表
    pub unresolved_items: Vec<String>,
    /// 可归档的旧条目（滚动窗口溢出时写入归档层）
    pub archive_candidates: Vec<String>,
    /// 原始 transcript 引用（按需恢复）
    pub transcript_ref: Option<PathBuf>,
}

impl RollingSummaryPacket {
    /// 验证摘要包的完整性
    pub fn validate(&self) -> bool {
        !self.summary_markdown.is_empty()
            && self.round_id > 0
    }

    /// 转换为可注入上下文的文本
    pub fn to_context_string(&self) -> String {
        let mut output = String::new();

        if !self.pinned_updates.is_empty() {
            output.push_str("### 钉住信息更新\n");
            for update in &self.pinned_updates {
                output.push_str(&format!("- {}\n", update));
            }
            output.push('\n');
        }

        output.push_str("### 滚动摘要\n");
        output.push_str(&self.summary_markdown);
        output.push('\n');

        if !self.key_decisions.is_empty() {
            output.push_str("### 关键决策\n");
            for decision in &self.key_decisions {
                output.push_str(&format!("- {}\n", decision));
            }
            output.push('\n');
        }

        if !self.unresolved_items.is_empty() {
            output.push_str("### 未解决事项\n");
            for item in &self.unresolved_items {
                output.push_str(&format!("- {}\n", item));
            }
        }

        output
    }
}
```

---

## 功能需求清单

### P3-1.1 平台环境检测

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| CTX-001 | 操作系统检测 | P0 | 支持 Windows/macOS/Linux/Android/WSL，编译期 cfg + 运行时 uname 双重检测 |
| CTX-002 | Shell 类型检测 | P0 | 支持 Bash/Zsh/Fish/Dash/Sh/Cmd/PowerShell/Pwsh/Ash，通过 $SHELL 和父进程双重检测 |
| CTX-003 | Shell 命令适配 | P0 | set_env_var 使用 shlex::try_quote 转义，maybe_wrap_command 安全包装 |
| CTX-004 | 文件编码检测 | P1 | 支持 UTF-8/GBK/Shift-JIS/EUC-KR/Big5 等，BOM + 内容特征双重检测 |
| CTX-005 | 路径处理 | P0 | normalize 消除 . 和 .. 段，跨平台分隔符统一 |
| CTX-006 | 包管理器检测 | P1 | 5s 超时，按 OS 类型检测可用包管理器 |
| CTX-007 | 开发工具链检测 | P1 | 检测 git/rustc/cargo/node/python/docker/go/java |
| CTX-008 | 终端信息检测 | P2 | TERM、TERM_PROGRAM、终端尺寸、颜色支持 |
| CTX-009 | WSL 特殊处理 | P1 | 检测 WSL 环境、Windows 挂载路径 |
| CTX-010 | 容器检测 | P2 | 检测 Docker/Kubernetes 环境 |
| CTX-011 | PlatformCache | P1 | HMAC 签名验证、TTL 过期、手动失效 |
| CTX-012 | to_context_block | P0 | 安全过滤敏感信息、限制长度、过滤控制字符 |
| CTX-013 | detect_executable_path | P0 | PATH 清理、哈希校验、安全注释 |
| CTX-014 | 平台信息三层注入 | P0 | 全局上下文池 + AgentFactory 强制注入 + 递归子 Agent 降级注入 |

### P3-1.2 上下文池管理

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| CTX-020 | 分层上下文池 | P0 | 三层结构：平台层(500t) + 项目知识层(8Kt) + 任务上下文层(7Kt) |
| CTX-021 | Agent 独立上下文 | P0 | 每个 Agent 按职责定制上下文 |
| CTX-022 | 上下文注入策略 | P1 | 支持 DirectInjection/CompressedSummary/Structured |
| CTX-023 | Token 预算管理 | P0 | 200K 窗口分配，各区域占比可配置 |
| CTX-024 | 递归上下文隔离 | P0 | 子 Agent 全新上下文，只注入平台层 + 任务焦点 |

### P3-1.3 四层压缩策略

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| CTX-030 | L0 保留策略 | P0 | 最近 N 轮完整保留，默认 2 轮 |
| CTX-031 | L1 微压缩 | P0 | 规则清除旧工具结果，零成本，>3 轮且 >10K 字符触发 |
| CTX-032 | L2 自动压缩 | P0 | LLM 生成摘要，Token >85% 触发，保留 6 类关键信息 |
| CTX-033 | L3 记忆压缩 | P1 | Token >90% 触发，提取到 .assistant-memory/ |
| CTX-034 | L4 暴力截断 | P0 | API 报错触发，保留尾部 80% |
| CTX-035 | L1 persist_to_disk | P1 | 使用 tokio::fs 异步持久化，seahash 哈希命名 |
| CTX-036 | L2 降级策略 | P1 | 输入超窗口 70% 先截断，L2 失败降级 L1 |
| CTX-037 | calculate_usage 优化 | P2 | 增量计数器方向注释 |
| CTX-038 | extract_code_change | P2 | OnceLock 正则缓存 |
| CTX-039 | 压缩协调器 | P0 | 统一入口，按顺序检查 L1-L4 |

### P3-1.4 滚动摘要

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| CTX-040 | RollingSummaryPacket | P1 | round_id、pinned_updates、summary_markdown 等字段 |
| CTX-041 | 摘要子 Agent | P1 | 独立上下文启动，默认只回传摘要 |
| CTX-042 | transcript 持久化 | P2 | .assistant-memory/subagents/，UUID 文件名，7 天自动清理 |
| CTX-043 | 恢复策略 | P2 | summary_only / transcript_on_demand / hard_resume |
| CTX-044 | 四层记忆拼装 | P1 | Pinned Info -> Rolling Summary -> Archive -> Current Round |

---

## 接口契约

### 平台检测接口

```rust
/// 平台检测 trait
pub trait PlatformDetector: Send + Sync {
    /// 执行完整平台检测
    async fn detect() -> anyhow::Result<PlatformInfo>;

    /// 检测 Shell 类型
    fn detect_shell_type() -> ShellType;

    /// 检测可执行文件路径（安全版本）
    async fn detect_executable_path(cmd_name: &str) -> String;
}
```

### 上下文池接口

```rust
/// 上下文池 trait
pub trait ContextProvider: Send + Sync {
    /// 为 Agent 构建完整上下文
    async fn build_context(&self, agent_id: &str, agent_type: &str) -> String;

    /// 更新项目知识
    async fn update_project_knowledge(&self, content: String);

    /// 更新任务上下文
    async fn update_task_context(&self, content: String);

    /// 估算 Token 消耗
    async fn estimate_tokens(&self) -> usize;
}
```

### 压缩器接口

```rust
/// 上下文压缩 trait
pub trait ContextCompressor: Send + Sync {
    /// 执行压缩，返回压缩后的消息列表
    async fn compress(
        &self,
        messages: &[ChatMessage],
        current_turn: usize,
        token_counter: &dyn TokenCounter,
        max_tokens: usize,
    ) -> anyhow::Result<CompressionResult>;
}

/// 压缩结果
pub struct CompressionResult {
    /// 压缩后的消息列表
    pub messages: Vec<ChatMessage>,
    /// 压缩统计
    pub stats: CompactStats,
    /// 执行的压缩层级
    pub level: u8,
}
```

---

## 测试要点

### 平台环境检测测试

| 测试场景 | 验证点 |
|----------|--------|
| OS 类型检测 | cfg 宏正确映射，运行时 uname 回退正确 |
| Shell 检测 | $SHELL 环境变量解析，父进程 comm 解析 |
| Shell 命令适配 | set_env_var 使用 shlex::try_quote 转义特殊字符 |
| Shell 命令适配 | maybe_wrap_command 正确包装跨 Shell 命令 |
| 路径 normalize | . 和 .. 段正确消除，连续分隔符合并 |
| 路径 normalize | Windows 盘符 C:/ 保持正确 |
| 编码检测 | BOM 检测正确（UTF-8 BOM、UTF-16 LE/BE） |
| 编码检测 | GBK/Shift-JIS/Big5 内容特征检测 |
| 包管理器检测 | 5s 超时生效，超时后不阻塞 |
| to_context_block | 不包含 API_KEY、PASSWORD 等敏感环境变量 |
| to_context_block | 输出长度不超过 2000 字符 |
| detect_executable_path | PATH 清理正确，排除 /tmp 等危险目录 |
| PlatformCache | HMAC 签名验证通过/拒绝 |
| PlatformCache | TTL 过期后重新检测 |
| PlatformCache | invalidate() 清除缓存 |

### 上下文池测试

| 测试场景 | 验证点 |
|----------|--------|
| 分层构建 | 平台层始终包含，项目层/任务层可选 |
| Agent 独立上下文 | 不同 Agent 获取不同上下文 |
| Token 估算 | 各层 Token 估算合理 |
| 递归隔离 | 子 Agent 只获取平台层 + 任务焦点 |

### 压缩策略测试

| 测试场景 | 验证点 |
|----------|--------|
| L1 微压缩 | >3 轮且 >10K 字符的工具结果被替换为占位符 |
| L1 微压缩 | >50K 字符的工具结果持久化到磁盘 |
| L1 微压缩 | 持久化失败降级为占位符 |
| L2 自动压缩 | Token >85% 触发压缩 |
| L2 自动压缩 | 压缩后保留 6 类关键信息 |
| L2 降级 | 输入超窗口 70% 先截断 |
| L2 降级 | LLM 调用失败降级到 L1 |
| L3 记忆压缩 | 正确提取代码变更、Bug 记录、编码约定 |
| L4 截断 | 保留系统提示 + 尾部 80% |
| L4 截断 | is_context_length_error 正确识别 API 错误 |
| calculate_usage | 增量计数器优化方向注释存在 |
| extract_code_change | OnceLock 正则缓存生效 |

### 滚动摘要测试

| 测试场景 | 验证点 |
|----------|--------|
| RollingSummaryPacket | validate() 正确验证完整性 |
| RollingSummaryPacket | to_context_string() 格式正确 |
| transcript 持久化 | 文件名使用 UUID |
| 恢复策略 | summary_only 模式不读取 transcript |

---

# P3-2 mc-memory — 记忆管理模块

## 模块概述

`mc-memory` 负责项目记忆系统和 Letta 式四层分层记忆。它为 Agent 系统提供长期记忆能力——将认知结果固化到磁盘，跨会话复用，并通过分层管理优化上下文窗口利用率。

**核心职责**：

1. **项目记忆管理**（MemoryManager）：管理 `.assistant-memory/` 目录下的结构化记忆文件，支持增量更新和失效检测
2. **Core Memory**：始终驻留在 Agent 上下文窗口中的核心记忆块，Agent 可自主读写
3. **Working Memory**：LRU 文件缓存，管理高频访问的文件
4. **Recall Memory**：完整对话历史存储，支持 SQLite + FTS5 搜索
5. **Archival Memory**：结构化知识库，tantivy 全文搜索
6. **用户偏好与规则**：自动学习用户偏好，硬性规则双层保障

---

## 大模型开发提示词

```
你正在开发 MoreCode Agent 系统的记忆管理模块 mc-memory。

## 技术栈
- Rust 2021 edition，异步运行时 tokio
- 持久化：SQLite（sqlx crate）、tantivy 全文搜索
- 序列化：serde + serde_json
- LRU 缓存：lru crate
- 时间处理：chrono
- 错误处理：thiserror + anyhow

## 关键设计约束
1. 共享记忆文件只能由 Coordinator 串行写入（mpsc channel 单写者模式）
2. Agent 不直接写 .assistant-memory/，只提交 MemoryUpdate 事件
3. Core Memory 的 Token 预算必须严格管理，超限返回错误
4. Working Memory 的 LruFileCache 使用双检锁模式，注意死锁风险
5. Recall Memory 的 SQLite 搜索应使用 FTS5 全文搜索扩展
6. Archival Memory 的 tantivy 批量索引只 commit 一次
7. compact_core_memory 使用两阶段：锁内 compact + 锁外异步写入
8. 用户规则采用双层保障：System Prompt 注入 + 输出后校验
9. 偏好学习使用 LLM 旁路提取，零额外 API 调用成本
10. 所有 I/O 使用 tokio::fs，不使用 std::fs 阻塞调用

## 编码规范
- 错误处理：库级用 thiserror，边界用 anyhow
- 异步：所有 I/O 使用 tokio::fs
- 日志：使用 tracing crate
- 测试：单元测试覆盖核心逻辑，集成测试覆盖跨模块交互
```

---

## 核心类型定义

### 1. MemoryManager — 项目记忆管理器

```rust
use std::path::{Path, PathBuf};
use tokio::sync::{mpsc, oneshot, RwLock};
use chrono::{DateTime, Utc, Duration};

/// 记忆管理器 - 管理项目记忆的创建、读取、更新和失效检测
pub struct MemoryManager {
    /// 记忆目录路径
    memory_dir: PathBuf,
    /// 项目根目录路径
    project_dir: PathBuf,
    /// Coordinator 持有的单写者队列发送端
    write_tx: mpsc::Sender<MemoryWriteRequest>,
    /// 当前加载的记忆
    current_memory: RwLock<Option<ProjectMemory>>,
    /// 过期阈值（天）
    stale_threshold_days: i64,
}

/// 项目记忆的完整状态
#[derive(Debug, Clone, Serialize)]
pub enum ProjectMemory {
    /// 无记忆（首次进入项目）
    Empty,
    /// 记忆已过期
    Stale(MetaJson),
    /// 记忆有效，包含所有记忆文件内容
    Valid {
        meta: MetaJson,
        overview: String,
        tech_stack: TechStack,
        module_map: ModuleMap,
        api_endpoints: ApiEndpoints,
        data_models: DataModels,
        conventions: String,
        risk_areas: RiskAreas,
        dependency_graph: DependencyGraph,
    },
}

/// 记忆元数据（10 个字段）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetaJson {
    /// 记忆格式版本
    pub version: String,
    /// 记忆创建时间
    pub created_at: DateTime<Utc>,
    /// 最后更新时间
    pub last_updated: DateTime<Utc>,
    /// 项目文件哈希
    pub project_hash: String,
    /// 当前 Git 分支
    pub git_branch: String,
    /// 当前 Git commit
    pub git_commit: String,
    /// 项目文件总数
    pub total_files: usize,
    /// 项目代码总行数
    pub total_lines: usize,
    /// 记忆状态（valid/stale/empty）
    pub memory_status: String,
    /// 过期阈值天数
    pub stale_threshold_days: i64,
}

/// 技术栈信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TechStack {
    pub language: String,
    pub edition: String,
    pub framework: std::collections::HashMap<String, String>,
    pub dev_tools: std::collections::HashMap<String, String>,
    pub key_dependencies: Vec<String>,
}

/// 模块地图
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleMap {
    pub modules: Vec<ModuleInfo>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleInfo {
    pub name: String,
    pub path: String,
    pub responsibility: String,
    pub key_files: Vec<String>,
    pub public_api: Vec<String>,
    pub dependencies: Vec<String>,
    pub dependents: Vec<String>,
}

/// API 端点清单
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiEndpoints {
    pub endpoints: Vec<ApiEndpoint>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiEndpoint {
    pub method: String,
    pub path: String,
    pub handler: String,
    pub request_type: Option<String>,
    pub response_type: Option<String>,
    pub auth_required: bool,
}

/// 数据模型清单
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataModels {
    pub models: Vec<DataModel>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataModel {
    pub name: String,
    pub file: String,
    pub fields: Vec<FieldInfo>,
    pub table: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FieldInfo {
    pub name: String,
    pub r#type: String,
    pub db_column: Option<String>,
}

/// 风险区域
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskAreas {
    pub risks: Vec<RiskInfo>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskInfo {
    pub area: String,
    pub r#type: String,
    pub description: String,
    pub severity: String,
    pub discovered_at: DateTime<Utc>,
    pub discovered_by: String,
}

/// 依赖关系图
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyGraph {
    pub nodes: Vec<String>,
    pub edges: Vec<DependencyEdge>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DependencyEdge {
    pub from: String,
    pub to: String,
    pub r#type: String,
}

/// 记忆更新事件（9 变体）
#[derive(Debug, Clone, Serialize)]
pub enum MemoryUpdate {
    FileModified { path: String, summary: String },
    FileAdded { path: String, module_name: Option<String> },
    FileDeleted { path: String, module_name: Option<String> },
    ApiAdded { endpoint: ApiEndpoint },
    ApiRemoved { method: String, path: String },
    DataModelChanged { model: String, change_type: String },
    RiskDiscovered { area: String, r#type: String, description: String, severity: String },
    RiskResolved { area: String },
    AgentNote { agent: String, topic: String, content: String },
}

/// 文件变更类型
#[derive(Debug, Clone)]
pub enum FileChange {
    Added { path: String },
    Modified { path: String },
    Deleted { path: String },
    Renamed { old_path: String, new_path: String },
}

/// Agent 产生的记忆写入请求
#[derive(Debug)]
struct MemoryWriteRequest {
    update: MemoryUpdate,
    ack: oneshot::Sender<anyhow::Result<()>>,
}
```

### 2. MemoryManager 核心实现

```rust
impl MemoryManager {
    /// 创建新的记忆管理器
    pub fn new(project_dir: &Path, write_tx: mpsc::Sender<MemoryWriteRequest>) -> Self {
        let memory_dir = project_dir.join(".assistant-memory");
        Self {
            memory_dir,
            project_dir: project_dir.to_path_buf(),
            write_tx,
            current_memory: RwLock::new(None),
            stale_threshold_days: 7,
        }
    }

    /// 加载项目记忆（async + tokio::fs）
    ///
    /// 按以下顺序检查:
    /// 1. 记忆目录是否存在
    /// 2. META.json 是否存在且有效
    /// 3. 记忆是否过期
    /// 4. 记忆是否与当前代码一致
    pub async fn load_memory(&self) -> anyhow::Result<ProjectMemory> {
        // 检查记忆目录是否存在
        if !tokio::fs::metadata(&self.memory_dir).await.is_ok() {
            tracing::info!("记忆目录不存在，标记为 Empty");
            return Ok(ProjectMemory::Empty);
        }

        // 读取 META.json（使用 tokio::fs）
        let meta_path = self.memory_dir.join("META.json");
        let meta_content = tokio::fs::read_to_string(&meta_path).await?;
        let meta: MetaJson = serde_json::from_str(&meta_content)?;

        // 检查是否过期
        if self.is_memory_stale(&meta).await? {
            tracing::info!(
                last_updated = %meta.last_updated,
                "记忆已过期，标记为 Stale"
            );
            return Ok(ProjectMemory::Stale(meta));
        }

        // 加载所有记忆文件
        let memory = self.load_valid_memory(&meta).await?;
        tracing::info!(
            modules = memory.module_map.modules.len(),
            "记忆加载成功"
        );

        // 缓存到内存
        {
            let mut cache = self.current_memory.write().await;
            *cache = Some(memory.clone());
        }

        Ok(ProjectMemory::Valid { meta, ..memory })
    }

    /// 检查记忆是否过期
    pub async fn is_memory_stale(&self, meta: &MetaJson) -> anyhow::Result<bool> {
        // 检查 1: 时间过期
        let threshold = Duration::days(self.stale_threshold_days);
        let age = Utc::now() - meta.last_updated;
        if age > threshold {
            return Ok(true);
        }

        // 检查 2: Git 变化
        if let Ok(current_commit) = self.get_current_git_commit().await {
            if current_commit != meta.git_commit {
                return Ok(true);
            }
        }

        // 检查 3: 分支变化
        if let Ok(current_branch) = self.get_current_git_branch().await {
            if current_branch != meta.git_branch {
                return Ok(true);
            }
        }

        Ok(false)
    }

    /// 增量更新记忆（条件惰性重载）
    ///
    /// 只在检测到文件变化时才重新加载和更新，避免不必要的 I/O。
    pub async fn incremental_update(&self) -> anyhow::Result<ProjectMemory> {
        // 检测文件变化
        let changes = self.detect_file_changes().await?;

        if changes.is_empty() {
            tracing::info!("没有检测到文件变化，无需更新");
            // 返回当前缓存
            let cache = self.current_memory.read().await;
            if let Some(memory) = cache.clone() {
                return Ok(memory);
            }
            return self.load_memory().await;
        }

        tracing::info!(changes = changes.len(), "检测到文件变化，开始增量更新");

        // 分类变更并执行更新
        let classified = self.classify_changes(&changes).await;
        for update in &classified {
            self.apply_update(update).await?;
        }

        // 更新 META.json
        self.update_meta().await?;

        // 按 MemoryUpdate 类型的条件重载逻辑（避免不必要的全量重载）
        // 权威定义来源：11-能力矩阵与代码实现.md §incremental_update
        let needs_reload = match &classified {
            updates => updates.iter().any(|update| match update {
                MemoryUpdate::CodeChange { new_dependencies, new_modules, .. } => {
                    !new_dependencies.is_empty() || !new_modules.is_empty()
                }
                MemoryUpdate::BugFixed { new_risk_areas, .. } => {
                    !new_risk_areas.is_empty()
                }
                MemoryUpdate::ArchitectureChange { .. } => true,  // 架构变更始终重载
                MemoryUpdate::DependencyChange { .. } => true,    // 依赖变更始终重载
                MemoryUpdate::ResearchCompleted { .. } => false,  // 调研结果不改变项目上下文
                _ => false,
            }),
        };

        if needs_reload {
            self.load_memory().await
        } else {
            Ok(memory)
        }
    }

    /// Agent 提交记忆更新（通过 mpsc channel）
    pub async fn agent_update(&self, update: MemoryUpdate) -> anyhow::Result<()> {
        let (ack_tx, ack_rx) = oneshot::channel();
        self.write_tx
            .send(MemoryWriteRequest { update, ack: ack_tx })
            .await?;

        ack_rx.await?
    }

    /// Coordinator 独占消费写入队列
    pub async fn run_write_loop(
        self: std::sync::Arc<Self>,
        mut rx: mpsc::Receiver<MemoryWriteRequest>,
    ) {
        while let Some(request) = rx.recv().await {
            let result = self.apply_agent_update(request.update).await;
            let _ = request.ack.send(result);
        }
    }

    /// 获取记忆摘要（用于注入 Coordinator 上下文）
    pub async fn get_memory_summary(&self) -> anyhow::Result<String> {
        let memory = self.current_memory.read().await;

        match memory.clone() {
            Some(ProjectMemory::Valid { ref overview, ref module_map, ref tech_stack, .. }) => {
                let mut summary = String::new();
                summary.push_str(&format!("## 项目概览\n{}\n\n", overview));
                summary.push_str(&format!("## 技术栈\n- 语言: {}\n", tech_stack.language));
                for (key, val) in &tech_stack.framework {
                    summary.push_str(&format!("- {}: {}\n", key, val));
                }
                summary.push_str("\n## 模块列表\n");
                for module in &module_map.modules {
                    summary.push_str(&format!(
                        "- **{}** ({}): {}\n",
                        module.name, module.path, module.responsibility
                    ));
                }
                Ok(summary)
            }
            Some(ProjectMemory::Stale(_)) => {
                Ok("[记忆已过期，建议运行 /memory-refresh]".to_string())
            }
            Some(ProjectMemory::Empty) | None => {
                Ok("[无项目记忆，首次进入项目将自动扫描]".to_string())
            }
        }
    }

    // --- 私有辅助方法 ---

    async fn load_valid_memory(&self, meta: &MetaJson) -> anyhow::Result<ValidMemoryFields> {
        let overview = tokio::fs::read_to_string(self.memory_dir.join("project-overview.md"))
            .await
            .unwrap_or_default();
        let tech_stack = self.load_json_file("tech-stack.json").await?;
        let module_map = self.load_json_file("module-map.json").await?;
        let api_endpoints = self.load_json_file("api-endpoints.json").await?;
        let data_models = self.load_json_file("data-models.json").await?;
        let conventions = tokio::fs::read_to_string(self.memory_dir.join("conventions.md"))
            .await
            .unwrap_or_default();
        let risk_areas = self.load_json_file("risk-areas.json").await?;
        let dependency_graph = self.load_json_file("dependency-graph.json").await?;

        Ok(ValidMemoryFields {
            meta: meta.clone(),
            overview,
            tech_stack,
            module_map,
            api_endpoints,
            data_models,
            conventions,
            risk_areas,
            dependency_graph,
        })
    }

    async fn load_json_file<T: serde::de::DeserializeOwned + Default>(
        &self,
        name: &str,
    ) -> anyhow::Result<T> {
        let path = self.memory_dir.join(name);
        if tokio::fs::metadata(&path).await.is_ok() {
            let content = tokio::fs::read_to_string(&path).await?;
            Ok(serde_json::from_str(&content)?)
        } else {
            Ok(T::default())
        }
    }

    async fn get_current_git_commit(&self) -> anyhow::Result<String> {
        let output = tokio::process::Command::new("git")
            .args(["rev-parse", "HEAD"])
            .current_dir(&self.project_dir)
            .output()
            .await?;
        Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
    }

    async fn get_current_git_branch(&self) -> anyhow::Result<String> {
        let output = tokio::process::Command::new("git")
            .args(["rev-parse", "--abbrev-ref", "HEAD"])
            .current_dir(&self.project_dir)
            .output()
            .await?;
        Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
    }

    async fn detect_file_changes(&self) -> anyhow::Result<Vec<FileChange>> {
        let output = tokio::process::Command::new("git")
            .args(["status", "--porcelain"])
            .current_dir(&self.project_dir)
            .output()
            .await?;

        let mut changes = Vec::new();
        for line in String::from_utf8_lossy(&output.stdout).lines() {
            if let Some(change) = self.parse_git_status_line(line) {
                changes.push(change);
            }
        }
        Ok(changes)
    }

    fn parse_git_status_line(&self, line: &str) -> Option<FileChange> {
        if line.len() < 4 {
            return None;
        }
        let status = &line[..2];
        let path = line[3..].trim();

        match status.trim() {
            "A" | "??" => Some(FileChange::Added { path: path.to_string() }),
            "M" | " M" => Some(FileChange::Modified { path: path.to_string() }),
            "D" | " D" => Some(FileChange::Deleted { path: path.to_string() }),
            "R" => {
                let parts: Vec<&str> = path.split(" -> ").collect();
                if parts.len() == 2 {
                    Some(FileChange::Renamed {
                        old_path: parts[0].to_string(),
                        new_path: parts[1].to_string(),
                    })
                } else {
                    None
                }
            }
            _ => None,
        }
    }

    async fn classify_changes(&self, changes: &[FileChange]) -> Vec<MemoryUpdate> {
        let mut updates = Vec::new();
        for change in changes {
            let update = match change {
                FileChange::Added { path } => MemoryUpdate::FileAdded {
                    path: path.clone(),
                    module_name: self.infer_module(path),
                },
                FileChange::Modified { path } => MemoryUpdate::FileModified {
                    path: path.clone(),
                    summary: format!("文件 {} 已修改", path),
                },
                FileChange::Deleted { path } => MemoryUpdate::FileDeleted {
                    path: path.clone(),
                    module_name: self.infer_module(path),
                },
                FileChange::Renamed { old_path, new_path } => {
                    // Renamed 拆分为 Delete + Add
                    updates.push(MemoryUpdate::FileDeleted {
                        path: old_path.clone(),
                        module_name: self.infer_module(old_path),
                    });
                    MemoryUpdate::FileAdded {
                        path: new_path.clone(),
                        module_name: self.infer_module(new_path),
                    }
                }
            };
            updates.push(update);
        }
        updates
    }

    fn infer_module(&self, path: &str) -> Option<String> {
        let parts: Vec<&str> = path.split('/').collect();
        if parts.len() >= 2 {
            Some(parts[1].to_string())
        } else {
            None
        }
    }

    async fn apply_update(&self, update: &MemoryUpdate) -> anyhow::Result<()> {
        match update {
            MemoryUpdate::FileAdded { path, module_name } => {
                tracing::info!(path = %path, module = ?module_name, "处理新增文件");
            }
            MemoryUpdate::FileModified { path, summary } => {
                tracing::info!(path = %path, "处理文件修改");
            }
            _ => {}
        }
        Ok(())
    }

    async fn update_meta(&self) -> anyhow::Result<()> {
        let commit = self.get_current_git_commit().await?;
        let branch = self.get_current_git_branch().await?;

        let meta = MetaJson {
            version: "1.0".to_string(),
            created_at: Utc::now(), // 简化，实际应保留原值
            last_updated: Utc::now(),
            project_hash: String::new(),
            git_branch: branch,
            git_commit: commit,
            total_files: 0,
            total_lines: 0,
            memory_status: "valid".to_string(),
            stale_threshold_days: self.stale_threshold_days,
        };

        let content = serde_json::to_string_pretty(&meta)?;
        tokio::fs::write(self.memory_dir.join("META.json"), content).await?;
        Ok(())
    }

    async fn apply_agent_update(&self, update: MemoryUpdate) -> anyhow::Result<()> {
        match update {
            MemoryUpdate::RiskDiscovered { area, r#type, description, severity } => {
                let risk_path = self.memory_dir.join("risk-areas.json");
                let mut risks: RiskAreas = if tokio::fs::metadata(&risk_path).await.is_ok() {
                    let content = tokio::fs::read_to_string(&risk_path).await?;
                    serde_json::from_str(&content)?
                } else {
                    RiskAreas { risks: vec![] }
                };

                risks.risks.push(RiskInfo {
                    area,
                    r#type,
                    description,
                    severity,
                    discovered_at: Utc::now(),
                    discovered_by: "agent".to_string(),
                });

                let content = serde_json::to_string_pretty(&risks)?;
                tokio::fs::write(&risk_path, content).await?;
            }
            MemoryUpdate::AgentNote { agent, topic, content } => {
                let notes_dir = self.memory_dir.join("agent-notes").join(&agent);
                tokio::fs::create_dir_all(&notes_dir).await?;
                let note_path = notes_dir.join(format!("{}.md", topic));
                tokio::fs::write(&note_path, content).await?;
            }
            // 其他更新类型...
            _ => {}
        }
        Ok(())
    }
}

/// 有效记忆的字段集合（内部使用）
#[derive(Debug, Clone, Serialize)]
struct ValidMemoryFields {
    meta: MetaJson,
    overview: String,
    tech_stack: TechStack,
    module_map: ModuleMap,
    api_endpoints: ApiEndpoints,
    data_models: DataModels,
    conventions: String,
    risk_areas: RiskAreas,
    dependency_graph: DependencyGraph,
}
```

### 3. Core Memory — Letta 式核心记忆

```rust
use std::collections::HashMap;

/// Core Memory 中的单个记忆块
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MemoryBlock {
    /// 唯一标识符，格式: "{category}:{short_id}"
    pub id: String,
    /// 记忆分类
    pub category: MemoryCategory,
    /// 记忆内容（纯文本，Agent 可读写）
    pub content: String,
    /// 优先级 1-10，1 = 最高（始终保留），10 = 最低（可被压缩）
    pub priority: u8,
    /// 版本号，每次修改递增
    pub version: u32,
    /// 创建时间
    pub created_at: DateTime<Utc>,
    /// 最后修改时间
    pub updated_at: DateTime<Utc>,
    /// 最后由哪个 Agent 修改
    pub last_modified_by: String,
    /// 访问频率统计（用于优先级动态调整）
    pub access_count: u64,
}

/// 记忆分类枚举（6 变体）
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum MemoryCategory {
    /// 用户偏好：编码风格、命名习惯、常用框架
    UserPreference,
    /// 项目约定：架构决策、代码规范、目录结构
    ProjectConvention,
    /// 任务状态：当前任务进度、待办事项、阻塞项
    TaskState,
    /// 错误模式：已遇到的错误及解决方案
    ErrorPattern,
    /// 上下文信息：项目背景、业务领域知识
    Context,
    /// 自定义分类
    Custom(String),
}

impl MemoryCategory {
    /// 返回分类的默认优先级
    pub fn default_priority(&self) -> u8 {
        match self {
            MemoryCategory::UserPreference => 2,
            MemoryCategory::ProjectConvention => 3,
            MemoryCategory::TaskState => 1,
            MemoryCategory::ErrorPattern => 4,
            MemoryCategory::Context => 5,
            MemoryCategory::Custom(_) => 6,
        }
    }

    /// 返回分类显示名
    pub fn display_name(&self) -> &str {
        match self {
            MemoryCategory::UserPreference => "用户偏好",
            MemoryCategory::ProjectConvention => "项目约定",
            MemoryCategory::TaskState => "任务状态",
            MemoryCategory::ErrorPattern => "错误模式",
            MemoryCategory::Context => "上下文信息",
            MemoryCategory::Custom(name) => name.as_str(),
        }
    }
}

/// Core Memory 管理器
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoreMemory {
    /// 所有记忆块，按 ID 索引
    blocks: HashMap<String, MemoryBlock>,
    /// Core Memory 的 Token 预算上限
    token_budget: usize,
    /// 当前已使用的 Token 估算
    current_tokens: usize,
}

/// 记忆系统错误类型
#[derive(Debug, thiserror::Error)]
pub enum MemoryError {
    #[error("Token 预算超限: 需要 {required} tokens, 可用 {available} tokens")]
    TokenBudgetExceeded { required: usize, available: usize },
    #[error("记忆块不存在: {0}")]
    BlockNotFound(String),
    #[error("序列化失败: {0}")]
    SerializationError(#[from] serde_json::Error),
    #[error("存储 IO 错误: {0}")]
    StorageError(#[from] std::io::Error),
}

impl CoreMemory {
    pub fn new(token_budget: usize) -> Self {
        Self {
            blocks: HashMap::new(),
            token_budget,
            current_tokens: 0,
        }
    }

    /// 添加或更新记忆块
    pub fn upsert_block(&mut self, mut block: MemoryBlock) -> Result<(), MemoryError> {
        let estimated_tokens = estimate_tokens(&block.content);

        if !self.blocks.contains_key(&block.id) {
            if self.current_tokens + estimated_tokens > self.token_budget {
                return Err(MemoryError::TokenBudgetExceeded {
                    required: estimated_tokens,
                    available: self.token_budget - self.current_tokens,
                });
            }
        } else {
            let old_tokens = self
                .blocks
                .get(&block.id)
                .map(|b| estimate_tokens(&b.content))
                .unwrap_or(0);
            self.current_tokens = self.current_tokens.saturating_sub(old_tokens);
        }

        block.version += 1;
        block.updated_at = Utc::now();
        self.current_tokens += estimated_tokens;
        self.blocks.insert(block.id.clone(), block);
        Ok(())
    }

    /// 删除记忆块
    pub fn remove_block(&mut self, id: &str) -> Option<MemoryBlock> {
        if let Some(block) = self.blocks.remove(id) {
            self.current_tokens = self
                .current_tokens
                .saturating_sub(estimate_tokens(&block.content));
            Some(block)
        } else {
            None
        }
    }

    /// 按分类获取记忆块
    pub fn get_by_category(&self, category: &MemoryCategory) -> Vec<&MemoryBlock> {
        self.blocks
            .values()
            .filter(|b| &b.category == category)
            .collect()
    }

    /// 获取所有记忆块（按优先级排序）
    pub fn get_all_sorted(&self) -> Vec<&MemoryBlock> {
        let mut blocks: Vec<&MemoryBlock> = self.blocks.values().collect();
        blocks.sort_by_key(|b| b.priority);
        blocks
    }

    /// 压缩低优先级记忆以释放 Token 空间
    pub fn compact(&mut self, target_tokens: usize) -> Vec<MemoryBlock> {
        let mut evicted = Vec::new();
        let mut blocks: Vec<_> = self.blocks.iter_mut().collect();

        // 按优先级降序排列（低优先级先淘汰）
        blocks.sort_by(|a, b| b.1.priority.cmp(&a.1.priority));

        for (_, block) in blocks.iter_mut() {
            if self.current_tokens <= target_tokens {
                break;
            }
            if block.priority >= 7 {
                let tokens = estimate_tokens(&block.content);
                self.current_tokens = self.current_tokens.saturating_sub(tokens);
                evicted.push(block.clone());
            }
        }

        for block in &evicted {
            self.blocks.remove(&block.id);
        }

        evicted
    }

    /// 序列化为上下文格式（注入 System Prompt）
    pub fn to_context_string(&self) -> String {
        let mut output = String::from("## Core Memory\n\n");
        let sorted = self.get_all_sorted();

        for block in &sorted {
            output.push_str(&format!(
                "### [{}] {} (v{}, priority:{})\n{}\n\n",
                block.category.display_name(),
                block.id,
                block.version,
                block.priority,
                block.content
            ));
        }

        output
    }

    /// 按关键词搜索记忆块
    pub fn search(&self, query: &str) -> Vec<MemoryBlock> {
        self.blocks
            .values()
            .filter(|b| b.content.contains(query))
            .cloned()
            .collect()
    }

    /// 按 ID 获取单个记忆块
    pub fn get_block(&self, id: &str) -> Option<&MemoryBlock> {
        self.blocks.get(id)
    }

    /// 获取剩余 Token 预算
    pub fn token_budget(&self) -> usize {
        self.token_budget.saturating_sub(self.current_tokens)
    }
}

/// 简易 Token 估算（约 4 字符 = 1 token）
fn estimate_tokens(text: &str) -> usize {
    (text.len() + 3) / 4
}
```

### 4. Working Memory — LRU 文件缓存

```rust
use lru::LruCache;

/// 文件缓存条目
#[derive(Debug, Clone)]
pub struct CachedFile {
    pub path: PathBuf,
    pub content: String,
    pub original_size: u64,
    pub cached_size: u64,
    pub is_summary: bool,
    pub last_accessed: std::time::Instant,
    pub modified_time: std::time::SystemTime,
}

/// LRU 文件缓存
///
/// **并发安全注意**：`cache` 和 `current_bytes` 使用两个独立的 RwLock，
/// 如果需要同时持有两个锁，必须按固定顺序获取（先 cache 后 current_bytes），
/// 否则可能死锁。
///
/// **优化方向**：可合并为单个 `Mutex<LruFileCacheInner>` 简化锁管理，
/// 或使用 `parking_lot::RwLock`（比 std 的更轻量且不支持中毒）。
pub struct LruFileCache {
    cache: RwLock<LruCache<PathBuf, Arc<CachedFile>>>,
    max_files: usize,
    max_bytes: u64,
    current_bytes: RwLock<u64>,
}

#[derive(Debug, Clone)]
pub struct CacheStats {
    pub file_count: usize,
    pub total_bytes: u64,
    pub max_files: usize,
    pub max_bytes: u64,
    pub utilization_ratio: f64,
}

#[derive(Debug, thiserror::Error)]
pub enum CacheError {
    #[error("文件读取失败: {0}")]
    ReadError(#[from] std::io::Error),
    #[error("缓存容量超限")]
    CapacityExceeded,
}

impl LruFileCache {
    pub fn new() -> Self {
        Self::with_capacity(100, 25 * 1024 * 1024)
    }

    pub fn with_capacity(max_files: usize, max_bytes: u64) -> Self {
        Self {
            cache: RwLock::new(LruCache::new(
                std::num::NonZeroUsize::new(max_files).unwrap(),
            )),
            max_files,
            max_bytes,
            current_bytes: RwLock::new(0),
        }
    }

    /// 获取文件内容（双检锁模式）
    ///
    /// **性能优化**：先释放锁再执行 I/O，避免在持有写锁期间执行同步文件操作。
    pub async fn get_or_read(&self, path: &Path) -> Result<Arc<CachedFile>, CacheError> {
        // 1. 快速路径：读锁检查缓存
        {
            let cache = self.cache.read().await;
            if let Some(cached) = cache.peek(path) {
                return Ok(Arc::clone(cached));
            }
        }

        // 2. 释放锁后执行 I/O（不持有任何锁）
        let metadata = tokio::fs::metadata(path).await?;
        let file_size = metadata.len();
        let modified_time = metadata.modified()?;

        let content = if file_size > 50_000 {
            self.read_with_smart_truncation(path, file_size).await?
        } else {
            tokio::fs::read_to_string(path).await?
        };

        let cached_size = content.len() as u64;
        let is_summary = cached_size < file_size;

        let cached_file = Arc::new(CachedFile {
            path: path.to_path_buf(),
            content,
            original_size: file_size,
            cached_size,
            is_summary,
            last_accessed: std::time::Instant::now(),
            modified_time,
        });

        // 3. 获取写锁，双检后插入
        {
            let mut cache = self.cache.write().await;
            if let Some(existing) = cache.get(path) {
                if existing.modified_time == modified_time {
                    return Ok(Arc::clone(existing));
                }
                cache.pop(path);
            }
            cache.put(path.clone(), Arc::clone(&cached_file));
        }

        // 4. 更新字节计数
        {
            let mut bytes = self.current_bytes.write().await;
            *bytes += cached_size;
        }

        Ok(cached_file)
    }

    async fn read_with_smart_truncation(
        &self,
        path: &Path,
        file_size: u64,
    ) -> Result<String, CacheError> {
        let head_size = 15_000usize;
        let tail_size = 15_000usize;

        let content = tokio::fs::read_to_string(path).await?;

        if content.len() <= head_size + tail_size {
            return Ok(content);
        }

        let head = &content[..head_size];
        let tail = &content[content.len() - tail_size..];

        Ok(format!(
            "{}\n\n... [文件过大，已截断: 原始 {} 字节，显示首尾各 ~15KB] ...\n\n{}",
            head, file_size, tail
        ))
    }

    /// 获取缓存统计信息
    pub async fn stats(&self) -> CacheStats {
        let cache = self.cache.read().await;
        let bytes = self.current_bytes.read().await;
        CacheStats {
            file_count: cache.len(),
            total_bytes: *bytes,
            max_files: self.max_files,
            max_bytes: self.max_bytes,
            utilization_ratio: *bytes as f64 / self.max_bytes as f64,
        }
    }

    /// 清空缓存
    pub async fn clear(&self) {
        let mut cache = self.cache.write().await;
        let mut bytes = self.current_bytes.write().await;
        cache.clear();
        *bytes = 0;
    }
}
```

### 5. Recall Memory — SQLite 对话存储

```rust
use async_trait::async_trait;

/// 单条对话记录
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConversationEntry {
    pub id: String,
    pub session_id: String,
    pub role: ConversationRole,
    pub content: String,
    pub tokens_used: u32,
    pub timestamp: DateTime<Utc>,
    pub tags: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ConversationRole {
    User,
    Agent(String),
    System,
    Tool,
}

/// 对话搜索参数
#[derive(Debug, Clone)]
pub struct SearchQuery {
    pub keyword: Option<String>,
    pub session_id: Option<String>,
    pub role: Option<ConversationRole>,
    pub start_time: Option<DateTime<Utc>>,
    pub end_time: Option<DateTime<Utc>>,
    pub limit: usize,
    pub offset: usize,
}

/// Recall Memory 存储接口
#[async_trait]
pub trait ConversationStore: Send + Sync {
    async fn append(&self, entry: ConversationEntry) -> Result<(), MemoryError>;
    async fn get_session(
        &self,
        session_id: &str,
        limit: Option<usize>,
    ) -> Result<Vec<ConversationEntry>, MemoryError>;
    async fn search(&self, query: &SearchQuery) -> Result<Vec<ConversationEntry>, MemoryError>;
    async fn get_session_summary(&self, session_id: &str) -> Result<String, MemoryError>;
}

/// SQLite 实现
///
/// **FTS5 注释**：当前 search() 使用 LIKE '%keyword%' 全表扫描，
/// 生产环境应使用 SQLite FTS5 全文搜索扩展：
///   CREATE VIRTUAL TABLE conversations_fts USING fts5(content, role, session_id);
///   SELECT * FROM conversations_fts WHERE conversations_fts MATCH ?;
pub struct SqliteConversationStore {
    pool: sqlx::SqlitePool,
}

impl SqliteConversationStore {
    pub async fn new(db_path: &Path) -> Result<Self, MemoryError> {
        let pool = sqlx::SqlitePool::connect_with(
            sqlx::sqlite::SqliteConnectOptions::from_str(
                &format!("sqlite:{}", db_path.display()),
            )?
            .create_if_missing(true),
        )
        .await?;

        sqlx::query(r#"
            CREATE TABLE IF NOT EXISTS conversations (
                id          TEXT PRIMARY KEY,
                session_id  TEXT NOT NULL,
                role        TEXT NOT NULL,
                content     TEXT NOT NULL,
                tokens_used INTEGER DEFAULT 0,
                timestamp   TEXT NOT NULL,
                tags        TEXT DEFAULT '[]'
            );
            CREATE INDEX IF NOT EXISTS idx_conv_session
                ON conversations(session_id, timestamp);
            CREATE INDEX IF NOT EXISTS idx_conv_timestamp
                ON conversations(timestamp);
        "#)
        .execute(&pool)
        .await?;

        Ok(Self { pool })
    }
}
```

### 6. Archival Memory — tantivy 全文搜索

```rust
use tantivy::schema::*;
use tantivy::{Index, IndexReader, IndexWriter};
use tantivy::collector::TopDocs;

/// 知识条目
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KnowledgeEntry {
    pub id: String,
    pub title: String,
    pub content: String,
    pub category: String,
    pub source: KnowledgeSource,
    pub tags: Vec<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub embedding: Option<Vec<f32>>,
    pub entities: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum KnowledgeSource {
    ConversationExtraction { session_id: String, entry_id: String },
    CoreMemoryDemotion { block_id: String },
    Manual,
    CodeComment { file_path: String },
}

/// 知识存储接口
#[async_trait]
pub trait KnowledgeStore: Send + Sync {
    async fn store(&self, entry: KnowledgeEntry) -> Result<String, MemoryError>;
    async fn retrieve(&self, id: &str) -> Result<Option<KnowledgeEntry>, MemoryError>;
    async fn search(&self, query: &str, limit: usize) -> Result<Vec<KnowledgeEntry>, MemoryError>;
    async fn delete(&self, id: &str) -> Result<bool, MemoryError>;
}

/// tantivy 全文搜索引擎
pub struct TantivySearchEngine {
    index: Index,
    reader: IndexReader,
    writer: IndexWriter,
    schema: Schema,
}

impl TantivySearchEngine {
    pub fn new(index_dir: &Path) -> Result<Self, MemoryError> {
        let mut schema_builder = Schema::builder();

        let title = schema_builder.add_text_field("title", TEXT | STORED);
        let content = schema_builder.add_text_field("content", TEXT | STORED);
        let category = schema_builder.add_text_field("category", STRING | STORED);
        let tags = schema_builder.add_text_field("tags", TEXT);
        let entry_id = schema_builder.add_text_field("entry_id", STRING | STORED);

        let schema = schema_builder.build();

        let index = Index::create_in_dir(index_dir, schema.clone())
            .unwrap_or_else(|_| Index::open_in_dir(index_dir).unwrap());

        let reader = index.reader()?;
        let writer = index.writer(50_000_000)?; // 50MB 缓冲区

        Ok(Self {
            index,
            reader,
            writer,
            schema,
        })
    }

    /// 索引单条知识条目
    pub fn index_entry(&self, entry: &KnowledgeEntry) -> Result<(), MemoryError> {
        let title = self.schema.get_field("title").unwrap();
        let content = self.schema.get_field("content").unwrap();
        let category = self.schema.get_field("category").unwrap();
        let tags = self.schema.get_field("tags").unwrap();
        let entry_id = self.schema.get_field("entry_id").unwrap();

        let mut doc = Document::new();
        doc.add_text(title, &entry.title);
        doc.add_text(content, &entry.content);
        doc.add_text(category, &entry.category);
        doc.add_text(tags, &entry.tags.join(" "));
        doc.add_text(entry_id, &entry.id);

        self.writer.add_document(doc)?;
        self.writer.commit()?;

        Ok(())
    }

    /// 批量索引知识条目（性能优化：所有条目插入后只 commit 一次）
    pub fn index_entries(&self, entries: &[KnowledgeEntry]) -> Result<(), MemoryError> {
        let title = self.schema.get_field("title").unwrap();
        let content = self.schema.get_field("content").unwrap();
        let category = self.schema.get_field("category").unwrap();
        let tags = self.schema.get_field("tags").unwrap();
        let entry_id = self.schema.get_field("entry_id").unwrap();

        for entry in entries {
            let mut doc = Document::new();
            doc.add_text(title, &entry.title);
            doc.add_text(content, &entry.content);
            doc.add_text(category, &entry.category);
            doc.add_text(tags, &entry.tags.join(" "));
            doc.add_text(entry_id, &entry.id);
            self.writer.add_document(doc)?;
        }
        // 所有条目插入后只 commit 一次
        self.writer.commit()?;

        Ok(())
    }

    /// 全文搜索
    pub fn search(&self, query: &str, limit: usize) -> Result<Vec<(String, f64)>, MemoryError> {
        let searcher = self.reader.searcher();
        let content = self.schema.get_field("content").unwrap();
        let title = self.schema.get_field("title").unwrap();
        let entry_id = self.schema.get_field("entry_id").unwrap();

        let query_parser = tantivy::query::QueryParser::for_index(&self.index, vec![title, content]);
        let query = query_parser.parse_query(query)?;
        let top_docs = searcher.search(&query, &TopDocs::with_limit(limit))?;

        let results: Vec<(String, f64)> = top_docs
            .iter()
            .map(|(score, addr)| {
                let retrieved = searcher.doc(*addr).unwrap();
                let id = retrieved.get_first(entry_id).unwrap();
                (id.as_text().unwrap().to_string(), *score)
            })
            .collect();

        Ok(results)
    }
}
```

### 7. compact_core_memory — 两阶段压缩

```rust
/// 压缩 Core Memory
///
/// **两阶段设计**：
/// - 阶段 1（锁内）：在写锁内完成内存操作（compact），快速释放锁
/// - 阶段 2（锁外）：释放锁后异步写入 Archival Memory，避免长时间持锁
pub async fn compact_core_memory(
    core_memory: &Arc<RwLock<CoreMemory>>,
    knowledge_store: &Arc<dyn KnowledgeStore>,
) -> Result<usize, MemoryError> {
    // 阶段 1：在写锁内完成内存操作（快速）
    let evicted = {
        let mut memory = core_memory.write().await;
        let budget = memory.token_budget();
        memory.compact(budget * 70 / 100)
    };
    // 写锁已释放

    // 阶段 2：异步写入 Archival Memory（无需持锁）
    for block in evicted {
        let entry = KnowledgeEntry {
            id: format!("demoted:{}", block.id),
            title: format!("归档记忆: {}", block.id),
            content: block.content,
            category: format!("demoted_{}", block.category.display_name()),
            source: KnowledgeSource::CoreMemoryDemotion {
                block_id: block.id.clone(),
            },
            tags: vec!["auto-demoted".into(), "core-memory".into()],
            created_at: block.created_at,
            updated_at: Utc::now(),
            embedding: None,
            entities: Vec::new(),
        };
        knowledge_store.store(entry).await?;
    }

    Ok(evicted.len())
}
```

### 8. 用户规则与偏好

```rust
/// 用户规则定义
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserRule {
    pub id: String,
    pub description: String,
    pub rule_type: RuleType,
    pub scope: RuleScope,
    pub created_at: chrono::DateTime<chrono::Utc>,
    pub source: RuleSource,
    pub enabled: bool,
}

/// 规则类型（6 变体）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RuleType {
    /// 禁用词/词黑名单
    ForbiddenWords { words: Vec<String>, case_sensitive: bool },
    /// 文件过滤
    FileFilter { patterns: Vec<String> },
    /// 代码约束
    CodeConstraint {
        forbidden_patterns: Vec<String>,
        required_patterns: Vec<String>,
    },
    /// 输出约束
    OutputConstraint {
        max_length: Option<u32>,
        language: Option<String>,
        forbidden_content: Vec<String>,
    },
    /// 命名约束
    NamingConstraint { target: String, style: String },
    /// 自由文本规则
    FreeText { instruction: String },
}

/// 规则作用域
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RuleScope {
    #[serde(rename = "user")]
    User,
    #[serde(rename = "project")]
    Project,
    #[serde(rename = "project_local")]
    ProjectLocal,
}

/// 规则来源
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RuleSource {
    #[serde(rename = "manual")]
    Manual,
    #[serde(rename = "llm_extracted")]
    LlmExtracted,
}

/// 规则校验结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleValidationResult {
    pub passed: bool,
    pub violations: Vec<RuleViolation>,
}

/// 规则违反记录
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleViolation {
    pub rule_id: String,
    pub rule_description: String,
    pub matched_content: String,
    pub location: String,
}

/// 规则校验器
pub struct RuleValidator;

impl RuleValidator {
    /// 校验 Agent 输出是否违反规则
    pub fn validate_output(output: &str, rules: &[UserRule]) -> RuleValidationResult {
        let mut violations = Vec::new();

        for rule in rules.iter().filter(|r| r.enabled) {
            match &rule.rule_type {
                RuleType::ForbiddenWords { words, case_sensitive } => {
                    let content = if *case_sensitive {
                        output.to_string()
                    } else {
                        output.to_lowercase()
                    };
                    for word in words {
                        let search_word = if *case_sensitive {
                            word.clone()
                        } else {
                            word.to_lowercase()
                        };
                        if content.contains(&search_word) {
                            violations.push(RuleViolation {
                                rule_id: rule.id.clone(),
                                rule_description: rule.description.clone(),
                                matched_content: word.clone(),
                                location: "output".into(),
                            });
                        }
                    }
                }
                RuleType::CodeConstraint { forbidden_patterns, .. } => {
                    for pattern in forbidden_patterns {
                        if let Ok(re) = regex::Regex::new(pattern) {
                            for cap in re.find_iter(output) {
                                violations.push(RuleViolation {
                                    rule_id: rule.id.clone(),
                                    rule_description: rule.description.clone(),
                                    matched_content: cap.as_str().to_string(),
                                    location: "code".into(),
                                });
                            }
                        }
                    }
                }
                RuleType::OutputConstraint { max_length, forbidden_content, .. } => {
                    if let Some(max_len) = max_length {
                        if output.chars().count() as u32 > *max_len {
                            violations.push(RuleViolation {
                                rule_id: rule.id.clone(),
                                rule_description: rule.description.clone(),
                                matched_content: format!(
                                    "长度 {} 超过限制 {}",
                                    output.chars().count(),
                                    max_len
                                ),
                                location: "output".into(),
                            });
                        }
                    }
                    for pattern in forbidden_content {
                        if let Ok(re) = regex::Regex::new(pattern) {
                            if re.is_match(output) {
                                violations.push(RuleViolation {
                                    rule_id: rule.id.clone(),
                                    rule_description: rule.description.clone(),
                                    matched_content: pattern.clone(),
                                    location: "output".into(),
                                });
                            }
                        }
                    }
                }
                RuleType::FileFilter { .. } => {}
                RuleType::NamingConstraint { .. } => {}
                RuleType::FreeText { .. } => {}
            }
        }

        RuleValidationResult {
            passed: violations.is_empty(),
            violations,
        }
    }
}
```

---

## 功能需求清单

### P3-2.1 项目记忆管理

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| MEM-001 | 记忆目录初始化 | P0 | .assistant-memory/ 目录结构创建 |
| MEM-002 | load_memory | P0 | async + tokio::fs，检查 Empty/Stale/Valid |
| MEM-003 | 失效检测 | P0 | 时间过期 + Git 变化 + 分支切换 |
| MEM-004 | incremental_update | P0 | 条件惰性重载，检测到变化才更新 |
| MEM-005 | 写入队列 | P0 | mpsc channel 单写者模式 |
| MEM-006 | META.json 10 字段 | P0 | version/created_at/last_updated/project_hash/git_branch/git_commit/total_files/total_lines/memory_status/stale_threshold_days |
| MEM-007 | ModuleMap/ModuleInfo | P0 | 模块地图结构 |
| MEM-008 | ApiEndpoints/ApiEndpoint | P1 | API 端点清单 |
| MEM-009 | DataModels/DataModel/FieldInfo | P1 | 数据模型清单 |
| MEM-010 | RiskAreas/RiskInfo | P1 | 风险区域记录 |
| MEM-011 | DependencyGraph/DependencyEdge | P1 | 依赖关系图 |
| MEM-012 | MemoryUpdate 9 变体 | P0 | FileModified/FileAdded/FileDeleted/ApiAdded/ApiRemoved/DataModelChanged/RiskDiscovered/RiskResolved/AgentNote |
| MEM-013 | FileChange 枚举 | P0 | Added/Modified/Deleted/Renamed |
| MEM-014 | 记忆摘要注入 | P1 | get_memory_summary 生成上下文片段 |

### P3-2.2 Core Memory

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| MEM-020 | MemoryBlock 结构 | P0 | id/category/content/priority/version/timestamps/access_count |
| MEM-021 | MemoryCategory 6 变体 | P0 | UserPreference/ProjectConvention/TaskState/ErrorPattern/Context/Custom |
| MEM-022 | upsert_block | P0 | Token 预算检查，版本递增 |
| MEM-023 | remove_block | P0 | 删除并回收 Token |
| MEM-024 | get_by_category | P1 | 按分类过滤 |
| MEM-025 | compact | P0 | 低优先级块降级到 Archival |
| MEM-026 | to_context_string | P0 | 序列化为 System Prompt 格式 |
| MEM-027 | search | P1 | 关键词搜索 |
| MEM-028 | token_budget | P0 | 剩余预算查询 |

### P3-2.3 Working Memory

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| MEM-030 | LruFileCache | P0 | 100 文件 / 25MB 上限 |
| MEM-031 | get_or_read 双检锁 | P0 | 先读锁检查，释放锁后 I/O，写锁双检插入 |
| MEM-032 | 死锁注释 | P0 | 两个 RwLock 的获取顺序说明 |
| MEM-033 | stats | P1 | 缓存统计信息 |
| MEM-034 | clear | P1 | 清空缓存 |
| MEM-035 | 大文件智能截断 | P1 | 首尾各 15KB |

### P3-2.4 Recall Memory

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| MEM-040 | ConversationEntry | P0 | id/session_id/role/content/tokens_used/timestamp/tags |
| MEM-041 | ConversationRole | P0 | User/Agent/System/Tool |
| MEM-042 | SearchQuery | P1 | keyword/session_id/role/time_range/limit/offset |
| MEM-043 | SqliteConversationStore | P0 | SQLite 持久化，索引优化 |
| MEM-044 | FTS5 注释 | P2 | LIKE 替代方案的性能注释 |

### P3-2.5 Archival Memory

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| MEM-050 | KnowledgeEntry | P0 | id/title/content/category/source/tags/embedding/entities |
| MEM-051 | KnowledgeSource | P1 | ConversationExtraction/CoreMemoryDemotion/Manual/CodeComment |
| MEM-052 | TantivySearchEngine | P1 | tantivy 全文搜索 |
| MEM-053 | index_entry | P1 | 单条索引（每次 commit） |
| MEM-054 | index_entries 批量 | P1 | 批量索引（只 commit 一次） |
| MEM-055 | search | P1 | BM25 排序全文搜索 |

### P3-2.6 compact_core_memory

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| MEM-060 | 两阶段压缩 | P0 | 锁内 compact + 锁外异步写入 |
| MEM-061 | 降级到 Archival | P0 | 被淘汰块写入 KnowledgeStore |

### P3-2.7 用户规则

| 编号 | 需求 | 优先级 | 说明 |
|------|------|--------|------|
| MEM-070 | UserRule 结构 | P0 | id/description/rule_type/scope/source/enabled |
| MEM-071 | RuleType 6 变体 | P0 | ForbiddenWords/FileFilter/CodeConstraint/OutputConstraint/NamingConstraint/FreeText |
| MEM-072 | RuleScope | P0 | User/Project/ProjectLocal |
| MEM-073 | RuleSource | P0 | Manual/LlmExtracted |
| MEM-074 | RuleValidator | P0 | validate_output 正则校验 |
| MEM-075 | RuleValidationResult | P0 | passed/violations |
| MEM-076 | RuleViolation | P0 | rule_id/rule_description/matched_content/location |
| MEM-077 | 双层保障 | P0 | System Prompt 注入 + 输出后校验 |
| MEM-078 | 规则加载优先级 | P1 | user < project < project_local |

---

## 接口契约

### 记忆管理接口

```rust
/// 记忆管理 trait
pub trait MemoryManagerTrait: Send + Sync {
    /// 加载项目记忆
    async fn load_memory(&self) -> anyhow::Result<ProjectMemory>;
    /// 增量更新
    async fn incremental_update(&self) -> anyhow::Result<ProjectMemory>;
    /// Agent 提交更新
    async fn agent_update(&self, update: MemoryUpdate) -> anyhow::Result<()>;
    /// 获取记忆摘要
    async fn get_memory_summary(&self) -> anyhow::Result<String>;
}
```

### Core Memory 接口

```rust
/// Core Memory 管理 trait
pub trait CoreMemoryManager: Send + Sync {
    fn upsert_block(&mut self, block: MemoryBlock) -> Result<(), MemoryError>;
    fn remove_block(&mut self, id: &str) -> Option<MemoryBlock>;
    fn get_by_category(&self, category: &MemoryCategory) -> Vec<&MemoryBlock>;
    fn compact(&mut self, target_tokens: usize) -> Vec<MemoryBlock>;
    fn to_context_string(&self) -> String;
    fn search(&self, query: &str) -> Vec<MemoryBlock>;
    fn token_budget(&self) -> usize;
}
```

### 知识存储接口

```rust
/// 知识存储 trait
#[async_trait]
pub trait KnowledgeStore: Send + Sync {
    async fn store(&self, entry: KnowledgeEntry) -> Result<String, MemoryError>;
    async fn retrieve(&self, id: &str) -> Result<Option<KnowledgeEntry>, MemoryError>;
    async fn search(&self, query: &str, limit: usize) -> Result<Vec<KnowledgeEntry>, MemoryError>;
    async fn delete(&self, id: &str) -> Result<bool, MemoryError>;
}
```

### 规则校验接口

```rust
/// 规则校验 trait
pub trait RuleValidatorTrait: Send + Sync {
    fn validate_output(&self, output: &str, rules: &[UserRule]) -> RuleValidationResult;
}
```

---

## 测试要点

### MemoryManager 测试

| 测试场景 | 验证点 |
|----------|--------|
| load_memory（空目录） | 返回 ProjectMemory::Empty |
| load_memory（有效记忆） | 返回 ProjectMemory::Valid，字段完整 |
| load_memory（过期记忆） | 返回 ProjectMemory::Stale |
| is_memory_stale（时间过期） | 超过阈值返回 true |
| is_memory_stale（Git 变化） | commit 不匹配返回 true |
| is_memory_stale（分支切换） | branch 不匹配返回 true |
| incremental_update（无变化） | 返回缓存，不执行 I/O |
| incremental_update（有变化） | 正确分类变更并更新 |
| agent_update | 通过 mpsc channel 发送，Coordinator 串行处理 |
| 写入队列 | 多个 Agent 并发提交不丢失 |
| get_memory_summary | 正确生成上下文片段 |
| FileChange 解析 | git status --porcelain 各状态正确解析 |
| Renamed 处理 | 拆分为 Delete + Add |
| tokio::fs 使用 | 所有 I/O 使用异步文件操作 |

### Core Memory 测试

| 测试场景 | 验证点 |
|----------|--------|
| upsert_block（新块） | Token 预算检查，超限返回错误 |
| upsert_block（更新块） | 旧 Token 回收，版本递增 |
| remove_block | Token 回收，返回被删除的块 |
| get_by_category | 正确过滤 |
| compact | 低优先级块被淘汰，Token 回收 |
| to_context_string | 格式正确，按优先级排序 |
| search | 关键词匹配正确 |
| token_budget | 剩余预算计算正确 |
| MemoryCategory | 6 变体 default_priority 正确 |

### Working Memory 测试

| 测试场景 | 验证点 |
|----------|--------|
| get_or_read（缓存命中） | 直接返回缓存，不执行 I/O |
| get_or_read（缓存未命中） | 读取文件并缓存 |
| get_or_read（双检锁） | 等待写锁期间其他任务已插入，不重复读取 |
| LRU 淘汰 | 超过容量时淘汰最久未访问的条目 |
| 大文件截断 | >50KB 文件首尾各 15KB |
| stats | 统计信息正确 |
| clear | 缓存完全清空 |

### Recall Memory 测试

| 测试场景 | 验证点 |
|----------|--------|
| append | 正确写入 SQLite |
| get_session | 按 session_id 查询，limit 生效 |
| search | 多条件组合查询 |

### Archival Memory 测试

| 测试场景 | 验证点 |
|----------|--------|
| index_entry | 单条索引正确 |
| index_entries（批量） | 所有条目只 commit 一次 |
| search | BM25 排序返回正确 |

### compact_core_memory 测试

| 测试场景 | 验证点 |
|----------|--------|
| 两阶段压缩 | 锁内 compact 完成后释放锁 |
| 降级写入 | 被淘汰块正确写入 KnowledgeStore |
| Token 回收 | compact 后 current_tokens 正确减少 |

### 用户规则测试

| 测试场景 | 验证点 |
|----------|--------|
| ForbiddenWords 校验 | 大小写敏感/不敏感匹配 |
| CodeConstraint 校验 | 正则匹配代码模式 |
| OutputConstraint 校验 | 长度检查、内容过滤 |
| FileFilter | 文件访问时校验 |
| FreeText | 不在输出校验中处理 |
| 多规则组合 | 所有规则独立校验，结果合并 |
| 规则加载优先级 | project_local > project > user |

---

## 模块依赖关系

```
mc-context
├── mc-core（基础类型、错误处理）
├── mc-llm（LlmClient trait，用于 L2 压缩）
└── mc-memory（MemoryStore trait，用于 L3 压缩）

mc-memory
├── mc-core（基础类型、错误处理）
├── tokio（异步运行时）
├── sqlx（SQLite 持久化）
├── tantivy（全文搜索）
├── lru（LRU 缓存）
└── serde（序列化）
```

---

## 开发顺序建议

### P3-1 mc-context（5-7 天）

1. **Day 1-2**：平台环境检测（PlatformInfo、ShellType、ShellConfig、PathHandler、PlatformCache）
2. **Day 3**：上下文池（ContextPool、InjectionStrategy）
3. **Day 4-5**：四层压缩策略（MicroCompactor、AutoCompactor、MemoryCompactor、ReactiveTruncator）
4. **Day 6-7**：滚动摘要（RollingSummaryPacket）、压缩协调器、集成测试

### P3-2 mc-memory（5-7 天，与 P3-1 并发）

1. **Day 1-2**：MemoryManager、ProjectMemory、MetaJson、MemoryUpdate
2. **Day 3**：Core Memory（MemoryBlock、MemoryCategory、CoreMemory）
3. **Day 4**：Working Memory（LruFileCache）、Recall Memory（SqliteConversationStore）
4. **Day 5**：Archival Memory（TantivySearchEngine）、compact_core_memory
5. **Day 6-7**：用户规则（UserRule、RuleValidator）、集成测试
