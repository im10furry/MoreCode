# MoreCode 开发需求文档 — Part 4: Agent 实现层

> **文档版本**: v1.0
> **最后更新**: 2026-04-17
> **所属系列**: MoreCode 开发需求文档（Part 1 ~ Part N）
> **本篇范围**: P4 Agent 实现层 — mc-agent trait + 认知层 Agent + 执行层 Agent + 专项 Agent

---

## 目录

- [P4-1 mc-agent（Agent trait + Registry）](#p4-1-mc-agentagent-trait--registry)
- [P4-2 认知层 Agent（Explorer + ImpactAnalyzer + Planner）](#p4-2-认知层-agentexplorer--impactanalyzer--planner)
- [P4-3 执行层 Agent（Coder + Reviewer + Tester）](#p4-3-执行层-agentcoder--reviewer--tester)
- [P4-4 专项 Agent（Research + DocWriter + Debugger）](#p4-4-专项-agentresearch--docwriter--debugger)

---

# P4-1 mc-agent（Agent trait + Registry）

## P4-1.1 模块概述

`mc-agent` 是 MoreCode 系统的 Agent 基础设施层，定义了所有 Agent 的核心抽象、注册机制、上下文构建、生命周期管理和执行引擎。它是整个 Agent 生态的基石，为认知层、执行层和专项 Agent 提供统一的 trait 约束和运行时支撑。

### 核心职责

1. **Agent 抽象定义**：通过 `Agent` trait 统一所有 Agent 的行为契约
2. **Agent 注册与发现**：通过 `AgentRegistry` 实现 Agent 的动态注册、查询和工厂创建
3. **上下文管理**：`AgentContext` 封装任务执行所需的全部运行时信息
4. **生命周期管理**：`AgentLifecycle` trait 提供 Agent 执行各阶段的钩子回调
5. **执行引擎**：`execute_with_context` 和 `execute_streaming` 提供同步与流式两种执行模式
6. **错误处理**：`AgentError` 统一所有 Agent 相关的错误类型

### 模块边界

```
mc-agent
├── traits/              # Agent trait 定义
│   ├── mod.rs
│   ├── agent.rs         # Agent trait
│   └── lifecycle.rs     # AgentLifecycle trait
├── context/             # 上下文管理
│   ├── mod.rs
│   └── agent_context.rs # AgentContext
├── registry/            # 注册中心
│   ├── mod.rs
│   └── agent_registry.rs # AgentRegistry
├── config/              # 配置
│   ├── mod.rs
│   └── agent_config.rs  # AgentConfig
├── error/               # 错误类型
│   ├── mod.rs
│   └── agent_error.rs   # AgentError
├── execution/           # 执行引擎
│   ├── mod.rs
│   ├── sync_executor.rs
│   └── stream_executor.rs
└── lib.rs
```

---

## P4-1.2 架构文档引用

| 引用文档 | 相关章节 | 关联说明 |
|---------|---------|---------|
| `04-执行层Agent.md` | §Agent trait | Agent trait 的设计原则、方法签名语义、扩展约束 |
| `11-能力矩阵与代码实现.md` | §能力矩阵表 | 各 Agent 的能力声明（递归、并行、流式输出等） |
| `25-代码目录与文件命名设计.md` | §mc-agent 目录结构 | 模块文件组织、命名规范、公开 API 导出规则 |

---

## P4-1.3 大模型开发提示词

```
你是一位精通 Rust 异步编程和 trait 系统的高级系统架构师。请实现 mc-agent 模块，
这是 MoreCode AI 编码助手的 Agent 基础设施层。

设计约束：
1. Agent trait 必须是 object-safe 的，支持 dyn Agent 动态分发
2. AgentRegistry 使用 RwLock 实现并发安全的注册与查询
3. AgentContext 通过 Arc 共享，避免大对象拷贝
4. 生命周期回调（AgentLifecycle）必须是可选的，通过 Option<LifecycleHandler> 注入
5. 流式输出通过 StreamForwarder trait 抽象，支持 SSE/WebSocket/Stdout 多种后端
6. 取消机制使用 tokio_util::sync::CancellationToken
7. 错误类型必须实现 std::error::Error + Send + Sync + Serialize

关键设计决策：
- Agent trait 的 execute 方法接收 &AgentContext 而非拥有所有权
- 工厂方法 create_agent 返回 Box<dyn Agent>，由 Registry 管理生命周期
- AgentConfig 支持从 TOML 文件加载，也支持运行时动态修改
- event_bus 使用 publish/subscribe 模式，Agent 执行事件通过 EventBus 广播
```

---

## P4-1.4 核心类型定义

### P4-1.4.1 AgentType 枚举

```rust
/// Agent 类型标识，用于注册、路由和日志记录
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum AgentType {
    // ── 认知层 Agent ──
    Explorer,
    ImpactAnalyzer,
    Planner,

    // ── 执行层 Agent ──
    Coder,
    Reviewer,
    Tester,

    // ── 专项 Agent ──
    Research,
    DocWriter,
    Debugger,
}

impl AgentType {
    /// 返回 Agent 的层级分类
    pub fn layer(&self) -> AgentLayer {
        match self {
            Self::Explorer | Self::ImpactAnalyzer | Self::Planner => AgentLayer::Cognitive,
            Self::Coder | Self::Reviewer | Self::Tester => AgentLayer::Execution,
            Self::Research | Self::DocWriter | Self::Debugger => AgentLayer::Specialized,
        }
    }

    /// 返回 Agent 的显示名称
    pub fn display_name(&self) -> &'static str {
        match self {
            Self::Explorer => "Explorer",
            Self::ImpactAnalyzer => "ImpactAnalyzer",
            Self::Planner => "Planner",
            Self::Coder => "Coder",
            Self::Reviewer => "Reviewer",
            Self::Tester => "Tester",
            Self::Research => "Research",
            Self::DocWriter => "DocWriter",
            Self::Debugger => "Debugger",
        }
    }

    /// 返回 Agent 的唯一标识字符串
    pub fn identifier(&self) -> &'static str {
        match self {
            Self::Explorer => "mc.explorer",
            Self::ImpactAnalyzer => "mc.impact_analyzer",
            Self::Planner => "mc.planner",
            Self::Coder => "mc.coder",
            Self::Reviewer => "mc.reviewer",
            Self::Tester => "mc.tester",
            Self::Research => "mc.research",
            Self::DocWriter => "mc.doc_writer",
            Self::Debugger => "mc.debugger",
        }
    }
}

/// Agent 层级分类
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum AgentLayer {
    Cognitive,    // 认知层：理解、分析、规划
    Execution,    // 执行层：编码、审查、测试
    Specialized,  // 专项：调研、文档、调试
}
```

### P4-1.4.2 Agent trait

```rust
use async_trait::async_trait;
use tokio_util::sync::CancellationToken;
use std::collections::HashMap;
use serde::{Serialize, Deserialize};

/// Agent 核心特征 — 所有 Agent 必须实现此 trait
///
/// 设计原则：
/// - Object-safe：支持 dyn Agent 动态分发
/// - 上下文驱动：通过 AgentContext 获取全部运行时信息
/// - 生命周期可选：通过 AgentLifecycle trait 扩展
#[async_trait]
pub trait Agent: Send + Sync {
    // ── 元信息 ──

    /// 返回 Agent 类型标识
    fn agent_type(&self) -> AgentType;

    /// 是否支持递归执行（Agent 可以调用自身处理子任务）
    fn supports_recursion(&self) -> bool {
        false
    }

    /// 是否支持并行执行（多个实例可同时运行）
    fn supports_parallel(&self) -> bool {
        true
    }

    /// 是否支持流式输出
    fn supports_streaming(&self) -> bool {
        false
    }

    /// 返回 Agent 的能力描述
    fn capabilities(&self) -> AgentCapabilities {
        AgentCapabilities {
            agent_type: self.agent_type(),
            supports_recursion: self.supports_recursion(),
            supports_parallel: self.supports_parallel(),
            supports_streaming: self.supports_streaming(),
        }
    }

    // ── 上下文构建 ──

    /// 根据任务描述构建 Agent 执行上下文
    ///
    /// 此方法负责：
    /// 1. 从 TaskDescription 提取关键信息
    /// 2. 加载项目上下文（如已存在）
    /// 3. 准备工具注册表
    /// 4. 初始化内存管理器
    async fn build_context(
        &self,
        task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError>;

    // ── 执行 ──

    /// 同步执行 Agent 任务，返回完整结果
    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError>;

    /// 流式执行 Agent 任务，通过 StreamForwarder 逐步输出
    ///
    /// 默认实现回退到 execute + 一次性转发
    async fn execute_streaming(
        &self,
        ctx: &AgentContext,
        forwarder: &mut dyn StreamForwarder,
    ) -> Result<AgentExecutionReport, AgentError> {
        let report = self.execute(ctx).await?;
        forwarder.forward_final(&report).await?;
        Ok(report)
    }

    // ── 配置 ──

    /// 返回 Agent 的默认配置
    fn default_config(&self) -> AgentConfig;

    /// 更新 Agent 配置（运行时热更新）
    fn update_config(&mut self, config: AgentConfig);
}
```

### P4-1.4.3 AgentCapabilities

```rust
/// Agent 能力声明，用于能力矩阵查询和路由决策
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentCapabilities {
    pub agent_type: AgentType,
    pub supports_recursion: bool,
    pub supports_parallel: bool,
    pub supports_streaming: bool,
}

impl AgentCapabilities {
    /// 检查是否具备指定能力
    pub fn has_capability(&self, cap: AgentCapability) -> bool {
        match cap {
            AgentCapability::Recursion => self.supports_recursion,
            AgentCapability::Parallel => self.supports_parallel,
            AgentCapability::Streaming => self.supports_streaming,
        }
    }
}

/// 单项能力标识
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AgentCapability {
    Recursion,
    Parallel,
    Streaming,
}
```

### P4-1.4.4 AgentContext

```rust
use tokio_util::sync::CancellationToken;
use std::sync::Arc;

/// Agent 执行上下文 — 封装任务执行所需的全部运行时信息
///
/// AgentContext 通过 Arc 共享，避免大对象拷贝。
/// 内部可变状态使用 tokio::sync::RwLock 保护。
#[derive(Clone)]
pub struct AgentContext {
    // ── 任务信息 ──
    /// 当前任务描述
    pub task: Arc<TaskDescription>,

    /// 任务执行 ID，用于追踪和日志关联
    pub execution_id: Uuid,

    /// 父任务 ID（如果是子任务）
    pub parent_execution_id: Option<Uuid>,

    // ── 项目信息 ──
    /// 项目上下文（由 Explorer 生成或从缓存加载）
    pub project_ctx: Option<Arc<ProjectContext>>,

    /// 影响分析报告（由 ImpactAnalyzer 生成）
    pub impact_report: Option<Arc<ImpactReport>>,

    /// 执行计划（由 Planner 生成）
    pub execution_plan: Option<Arc<ExecutionPlan>>,

    // ── 运行时资源 ──
    /// Agent 间数据传递通道
    pub handoff: Arc<AgentHandoff>,

    /// LLM 客户端
    pub llm_client: Arc<dyn LlmClient>,

    /// 工具注册表
    pub tool_registry: Arc<ToolRegistry>,

    /// 内存管理器（对话历史、上下文窗口管理）
    pub memory_manager: Arc<MemoryManager>,

    /// 事件总线（Agent 间事件通信）
    pub event_bus: Arc<dyn EventBus>,

    // ── 控制信号 ──
    /// 取消令牌
    pub cancel_token: CancellationToken,

    /// 流式输出转发器
    pub stream_forwarder: Option<Arc<dyn StreamForwarder>>,

    // ── 执行元数据 ──
    /// Agent 配置
    pub config: Arc<AgentConfig>,

    /// 执行开始时间
    pub started_at: chrono::DateTime<chrono::Utc>,

    /// 重试计数
    pub retry_count: u32,

    /// 最大重试次数
    pub max_retries: u32,

    /// 额外参数（Agent 特定的键值对）
    pub extra_params: HashMap<String, serde_json::Value>,
}

impl AgentContext {
    /// 创建新的 AgentContext
    pub fn new(
        task: TaskDescription,
        shared: &SharedResources,
        config: AgentConfig,
    ) -> Self {
        Self {
            task: Arc::new(task),
            execution_id: Uuid::new_v4(),
            parent_execution_id: None,
            project_ctx: None,
            impact_report: None,
            execution_plan: None,
            handoff: Arc::new(AgentHandoff::new()),
            llm_client: shared.llm_client.clone(),
            tool_registry: shared.tool_registry.clone(),
            memory_manager: shared.memory_manager.clone(),
            event_bus: shared.event_bus.clone(),
            cancel_token: CancellationToken::new(),
            stream_forwarder: None,
            config: Arc::new(config),
            started_at: chrono::Utc::now(),
            retry_count: 0,
            max_retries: 3,
            extra_params: HashMap::new(),
        }
    }

    /// 创建子任务上下文（继承父上下文资源）
    pub fn create_child_context(&self, sub_task: TaskDescription) -> Self {
        Self {
            task: Arc::new(sub_task),
            execution_id: Uuid::new_v4(),
            parent_execution_id: Some(self.execution_id),
            project_ctx: self.project_ctx.clone(),
            impact_report: self.impact_report.clone(),
            execution_plan: self.execution_plan.clone(),
            handoff: Arc::new(AgentHandoff::with_parent(self.handoff.clone())),
            llm_client: self.llm_client.clone(),
            tool_registry: self.tool_registry.clone(),
            memory_manager: self.memory_manager.clone(),
            event_bus: self.event_bus.clone(),
            cancel_token: self.cancel_token.child_token(),
            stream_forwarder: self.stream_forwarder.clone(),
            config: self.config.clone(),
            started_at: chrono::Utc::now(),
            retry_count: 0,
            max_retries: self.max_retries,
            extra_params: HashMap::new(),
        }
    }

    /// 检查是否已取消
    pub fn is_cancelled(&self) -> bool {
        self.cancel_token.is_cancelled()
    }

    /// 获取执行耗时
    pub fn elapsed(&self) -> std::time::Duration {
        chrono::Utc::now()
            .signed_duration_since(self.started_at)
            .to_std()
            .unwrap_or_default()
    }

    /// 设置流式输出转发器
    pub fn with_stream_forwarder(mut self, forwarder: Arc<dyn StreamForwarder>) -> Self {
        self.stream_forwarder = Some(forwarder);
        self
    }

    /// 注入额外参数
    pub fn with_extra_param(mut self, key: impl Into<String>, value: serde_json::Value) -> Self {
        self.extra_params.insert(key.into(), value);
        self
    }

    /// 获取额外参数
    pub fn get_extra_param<T: serde::de::DeserializeOwned>(&self, key: &str) -> Option<T> {
        self.extra_params
            .get(key)
            .and_then(|v| serde_json::from_value(v.clone()).ok())
    }
}
```

### P4-1.4.5 AgentHandoff

```rust
/// Agent 间数据传递通道
///
/// 支持 Agent 之间传递结构化数据，如 ProjectContext、ImpactReport、
/// ExecutionPlan 等。数据通过类型擦除的 Any 存储，通过 TypeId 检索。
#[derive(Debug, Clone)]
pub struct AgentHandoff {
    inner: Arc<RwLock<HandoffData>>,
    parent: Option<Arc<AgentHandoff>>,
}

#[derive(Debug, Default)]
struct HandoffData {
    data: HashMap<std::any::TypeId, Box<dyn std::any::Any + Send + Sync>>,
}

impl AgentHandoff {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(RwLock::new(HandoffData::default())),
            parent: None,
        }
    }

    pub fn with_parent(parent: Arc<AgentHandoff>) -> Self {
        Self {
            inner: Arc::new(RwLock::new(HandoffData::default())),
            parent: Some(parent),
        }
    }

    /// 存入数据
    pub async fn put<T: Send + Sync + 'static>(&self, value: T) {
        let mut data = self.inner.write().await;
        data.data.insert(std::any::TypeId::of::<T>(), Box::new(value));
    }

    /// 取出数据（当前层级）
    pub async fn get<T: Clone + Send + Sync + 'static>(&self) -> Option<T> {
        let data = self.inner.read().await;
        data.data
            .get(&std::any::TypeId::of::<T>())
            .and_then(|v| v.downcast_ref::<T>())
            .cloned()
    }

    /// 取出数据（向上查找父层级）
    pub async fn get_with_fallback<T: Clone + Send + Sync + 'static>(&self) -> Option<T> {
        if let Some(val) = self.get::<T>().await {
            return Some(val);
        }
        if let Some(ref parent) = self.parent {
            return parent.get_with_fallback::<T>().await;
        }
        None
    }

    /// 清空当前层级数据
    pub async fn clear(&self) {
        let mut data = self.inner.write().await;
        data.data.clear();
    }
}
```

### P4-1.4.6 AgentRegistry

```rust
use std::collections::HashMap;
use std::sync::RwLock;

/// Agent 注册中心 — 管理所有 Agent 的注册、查询和工厂创建
///
/// 线程安全：使用 RwLock 实现读多写少的并发访问模式。
/// 注册操作在启动时完成，运行时以只读查询为主。
pub struct AgentRegistry {
    /// Agent 类型 -> 工厂函数
    factories: RwLock<HashMap<AgentType, AgentFactory>>,

    /// 已注册 Agent 的能力缓存
    capabilities: RwLock<HashMap<AgentType, AgentCapabilities>>,

    /// Agent 实例缓存（单例模式）
    instances: RwLock<HashMap<AgentType, Arc<RwLock<Box<dyn Agent>>>>>,
}

/// Agent 工厂函数类型
type AgentFactory = Box<dyn Fn(&SharedResources, &AgentConfig) -> Box<dyn Agent> + Send + Sync>;

impl AgentRegistry {
    /// 创建空的注册中心
    pub fn new() -> Self {
        Self {
            factories: RwLock::new(HashMap::new()),
            capabilities: RwLock::new(HashMap::new()),
            instances: RwLock::new(HashMap::new()),
        }
    }

    /// 注册 Agent 工厂
    ///
    /// # Errors
    /// - `AgentError::DuplicateRegistration` — 同类型 Agent 已注册
    pub fn register<F>(&self, agent_type: AgentType, factory: F) -> Result<(), AgentError>
    where
        F: Fn(&SharedResources, &AgentConfig) -> Box<dyn Agent> + Send + Sync + 'static,
    {
        let mut factories = self.factories.write().unwrap();

        if factories.contains_key(&agent_type) {
            return Err(AgentError::DuplicateRegistration {
                agent_type,
                message: format!("Agent {:?} is already registered", agent_type),
            });
        }

        factories.insert(agent_type, Box::new(factory));
        Ok(())
    }

    /// 批量注册 Agent
    pub fn register_all(
        &self,
        registrations: Vec<(AgentType, AgentFactory)>,
    ) -> Result<(), AgentError> {
        for (agent_type, factory) in registrations {
            self.register(agent_type, |shared, config| factory(shared, config))?;
        }
        Ok(())
    }

    /// 获取指定类型的 Agent 实例（单例模式）
    ///
    /// 如果实例不存在，通过工厂方法创建并缓存。
    pub fn get(
        &self,
        agent_type: &AgentType,
        shared: &SharedResources,
        config: &AgentConfig,
    ) -> Result<Arc<RwLock<Box<dyn Agent>>>, AgentError> {
        // 先检查实例缓存
        {
            let instances = self.instances.read().unwrap();
            if let Some(instance) = instances.get(agent_type) {
                return Ok(instance.clone());
            }
        }

        // 创建新实例
        let factory = {
            let factories = self.factories.read().unwrap();
            factories
                .get(agent_type)
                .ok_or_else(|| AgentError::AgentNotFound {
                    agent_type: *agent_type,
                    message: format!("No factory registered for {:?}", agent_type),
                })?
                .as_ref()
        };

        let agent = factory(shared, config);
        let agent: Arc<RwLock<Box<dyn Agent>>> =
            Arc::new(RwLock::new(Box::new(agent) as Box<dyn Agent>));

        // 缓存实例
        {
            let mut instances = self.instances.write().unwrap();
            instances.insert(*agent_type, agent.clone());
        }

        // 缓存能力
        {
            let agent_guard = agent.read().unwrap();
            let caps = agent_guard.capabilities();
            let mut caps_map = self.capabilities.write().unwrap();
            caps_map.insert(*agent_type, caps);
        }

        Ok(agent)
    }

    /// 创建新的 Agent 实例（非单例，每次创建新实例）
    ///
    /// 适用于需要并行执行的场景，每个并行任务使用独立实例。
    pub fn create_agent(
        &self,
        agent_type: &AgentType,
        shared: &SharedResources,
        config: &AgentConfig,
    ) -> Result<Box<dyn Agent>, AgentError> {
        let factory = {
            let factories = self.factories.read().unwrap();
            factories
                .get(agent_type)
                .ok_or_else(|| AgentError::AgentNotFound {
                    agent_type: *agent_type,
                    message: format!("No factory registered for {:?}", agent_type),
                })?
                .as_ref()
        };

        Ok(factory(shared, config))
    }

    /// 列出所有已注册的 Agent 类型
    pub fn list_all(&self) -> Vec<AgentType> {
        let factories = self.factories.read().unwrap();
        factories.keys().copied().collect()
    }

    /// 列出指定层级的所有 Agent
    pub fn list_by_layer(&self, layer: AgentLayer) -> Vec<AgentType> {
        let factories = self.factories.read().unwrap();
        factories
            .keys()
            .filter(|at| at.layer() == layer)
            .copied()
            .collect()
    }

    /// 查询 Agent 能力
    pub fn get_capabilities(&self, agent_type: &AgentType) -> Option<AgentCapabilities> {
        let caps = self.capabilities.read().unwrap();
        caps.get(agent_type).cloned()
    }

    /// 检查 Agent 是否已注册
    pub fn is_registered(&self, agent_type: &AgentType) -> bool {
        let factories = self.factories.read().unwrap();
        factories.contains_key(agent_type)
    }

    /// 获取已注册 Agent 数量
    pub fn count(&self) -> usize {
        let factories = self.factories.read().unwrap();
        factories.len()
    }

    /// 清除所有注册和缓存
    pub fn clear(&self) {
        let mut factories = self.factories.write().unwrap();
        let mut capabilities = self.capabilities.write().unwrap();
        let mut instances = self.instances.write().unwrap();
        factories.clear();
        capabilities.clear();
        instances.clear();
    }
}

impl Default for AgentRegistry {
    fn default() -> Self {
        Self::new()
    }
}
```

### P4-1.4.7 AgentError

```rust
use thiserror::Error;

/// Agent 系统统一错误类型
#[derive(Debug, Error, Serialize, Deserialize)]
pub enum AgentError {
    // ── 注册错误 ──
    #[error("Agent already registered: {agent_type:?} — {message}")]
    DuplicateRegistration {
        agent_type: AgentType,
        message: String,
    },

    #[error("Agent not found: {agent_type:?} — {message}")]
    AgentNotFound {
        agent_type: AgentType,
        message: String,
    },

    // ── 执行错误 ──
    #[error("Agent execution failed: {agent_type:?} — {message}")]
    ExecutionFailed {
        agent_type: AgentType,
        message: String,
        #[serde(skip)]
        source: Option<Box<dyn std::error::Error + Send + Sync>>,
    },

    #[error("Agent execution timed out after {timeout_ms}ms: {agent_type:?}")]
    ExecutionTimeout {
        agent_type: AgentType,
        timeout_ms: u64,
    },

    #[error("Agent execution cancelled: {agent_type:?}")]
    ExecutionCancelled {
        agent_type: AgentType,
    },

    // ── 上下文错误 ──
    #[error("Context build failed: {message}")]
    ContextBuildFailed {
        message: String,
        #[serde(skip)]
        source: Option<Box<dyn std::error::Error + Send + Sync>>,
    },

    #[error("Missing context data: {data_type}")]
    MissingContextData {
        data_type: String,
    },

    // ── LLM 错误 ──
    #[error("LLM request failed: {message}")]
    LlmError {
        message: String,
        #[serde(skip)]
        source: Option<Box<dyn std::error::Error + Send + Sync>>,
    },

    #[error("LLM response parse failed: {message}")]
    LlmParseError {
        message: String,
    },

    // ── 工具错误 ──
    #[error("Tool execution failed: {tool_name} — {message}")]
    ToolError {
        tool_name: String,
        message: String,
    },

    #[error("Tool not found: {tool_name}")]
    ToolNotFound {
        tool_name: String,
    },

    // ── 配置错误 ──
    #[error("Invalid agent config: {message}")]
    InvalidConfig {
        message: String,
    },

    // ── 生命周期错误 ──
    #[error("Lifecycle error at stage {stage}: {message}")]
    LifecycleError {
        stage: String,
        message: String,
    },

    // ── 流式输出错误 ──
    #[error("Stream forwarder error: {message}")]
    StreamError {
        message: String,
    },

    // ── 通用错误 ──
    #[error("Agent internal error: {message}")]
    Internal {
        message: String,
        #[serde(skip)]
        source: Option<Box<dyn std::error::Error + Send + Sync>>,
    },
}

impl AgentError {
    /// 获取错误分类
    pub fn category(&self) -> ErrorCategory {
        match self {
            Self::DuplicateRegistration { .. } | Self::AgentNotFound { .. } => {
                ErrorCategory::Registration
            }
            Self::ExecutionFailed { .. }
            | Self::ExecutionTimeout { .. }
            | Self::ExecutionCancelled { .. } => ErrorCategory::Execution,
            Self::ContextBuildFailed { .. } | Self::MissingContextData { .. } => {
                ErrorCategory::Context
            }
            Self::LlmError { .. } | Self::LlmParseError { .. } => ErrorCategory::Llm,
            Self::ToolError { .. } | Self::ToolNotFound { .. } => ErrorCategory::Tool,
            Self::InvalidConfig { .. } => ErrorCategory::Config,
            Self::LifecycleError { .. } => ErrorCategory::Lifecycle,
            Self::StreamError { .. } => ErrorCategory::Stream,
            Self::Internal { .. } => ErrorCategory::Internal,
        }
    }

    /// 是否可重试
    pub fn is_retryable(&self) -> bool {
        matches!(
            self,
            Self::LlmError { .. } | Self::ExecutionTimeout { .. } | Self::ToolError { .. }
        )
    }

    /// 获取建议的重试延迟（毫秒）
    pub fn retry_delay_ms(&self) -> u64 {
        match self {
            Self::LlmError { .. } => 1000,
            Self::ExecutionTimeout { .. } => 2000,
            Self::ToolError { .. } => 500,
            _ => 1000,
        }
    }
}

/// 错误分类
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ErrorCategory {
    Registration,
    Execution,
    Context,
    Llm,
    Tool,
    Config,
    Lifecycle,
    Stream,
    Internal,
}
```

### P4-1.4.8 AgentLifecycle trait

```rust
/// Agent 生命周期钩子 trait
///
/// 提供 Agent 执行各阶段的回调接口，用于：
/// - 日志记录和指标收集
/// - 状态持久化和恢复
/// - 事件通知
/// - 资源清理
#[async_trait]
pub trait AgentLifecycle: Send + Sync {
    /// Agent 开始执行前回调
    async fn on_start(&self, ctx: &AgentContext) -> Result<(), AgentError>;

    /// Agent 成功完成执行后回调
    async fn on_complete(
        &self,
        ctx: &AgentContext,
        report: &AgentExecutionReport,
    ) -> Result<(), AgentError>;

    /// Agent 执行出错后回调
    async fn on_error(
        &self,
        ctx: &AgentContext,
        error: &AgentError,
    ) -> Result<(), AgentError>;

    /// Agent 被取消后回调
    async fn on_cancel(&self, ctx: &AgentContext) -> Result<(), AgentError>;
}

/// 默认的空实现生命周期处理器
pub struct NoopLifecycle;

#[async_trait]
impl AgentLifecycle for NoopLifecycle {
    async fn on_start(&self, _ctx: &AgentContext) -> Result<(), AgentError> { Ok(()) }
    async fn on_complete(
        &self, _ctx: &AgentContext, _report: &AgentExecutionReport,
    ) -> Result<(), AgentError> { Ok(()) }
    async fn on_error(
        &self, _ctx: &AgentContext, _error: &AgentError,
    ) -> Result<(), AgentError> { Ok(()) }
    async fn on_cancel(&self, _ctx: &AgentContext) -> Result<(), AgentError> { Ok(()) }
}

/// 日志记录生命周期处理器
pub struct LoggingLifecycle {
    logger: Arc<dyn Logger>,
}

impl LoggingLifecycle {
    pub fn new(logger: Arc<dyn Logger>) -> Self {
        Self { logger }
    }
}

#[async_trait]
impl AgentLifecycle for LoggingLifecycle {
    async fn on_start(&self, ctx: &AgentContext) -> Result<(), AgentError> {
        self.logger.info(&format!(
            "[Lifecycle] Agent {:?} started, execution_id={}",
            ctx.config.agent_type, ctx.execution_id
        ));
        Ok(())
    }

    async fn on_complete(
        &self, ctx: &AgentContext, report: &AgentExecutionReport,
    ) -> Result<(), AgentError> {
        self.logger.info(&format!(
            "[Lifecycle] Agent {:?} completed in {:?}, status={:?}",
            ctx.config.agent_type, ctx.elapsed(), report.status
        ));
        Ok(())
    }

    async fn on_error(
        &self, ctx: &AgentContext, error: &AgentError,
    ) -> Result<(), AgentError> {
        self.logger.error(&format!(
            "[Lifecycle] Agent {:?} failed: {}",
            ctx.config.agent_type, error
        ));
        Ok(())
    }

    async fn on_cancel(&self, ctx: &AgentContext) -> Result<(), AgentError> {
        self.logger.warn(&format!(
            "[Lifecycle] Agent {:?} cancelled after {:?}",
            ctx.config.agent_type, ctx.elapsed()
        ));
        Ok(())
    }
}
```

### P4-1.4.9 AgentConfig

```rust
/// Agent 配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentConfig {
    /// Agent 类型
    pub agent_type: AgentType,

    /// LLM 模型配置
    pub llm_config: LlmAgentConfig,

    /// 最大执行时间（毫秒），0 表示无限制
    pub timeout_ms: u64,

    /// 最大重试次数
    pub max_retries: u32,

    /// 是否启用流式输出
    pub streaming_enabled: bool,

    /// 并行度限制（0 表示不限制）
    pub max_parallelism: u32,

    /// 上下文窗口大小限制（token 数）
    pub context_window_limit: u32,

    /// 是否启用预飞检查（仅适用于 Coder Agent）
    pub preflight_enabled: bool,

    /// 自定义参数
    pub custom_params: HashMap<String, serde_json::Value>,
}

/// Agent 级别的 LLM 配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LlmAgentConfig {
    pub model_id: String,
    pub temperature: f32,
    pub max_output_tokens: u32,
    pub system_prompt_template: String,
    pub function_calling_enabled: bool,
    pub max_function_rounds: u32,
}

impl Default for AgentConfig {
    fn default() -> Self {
        Self {
            agent_type: AgentType::Coder,
            llm_config: LlmAgentConfig::default(),
            timeout_ms: 300_000,
            max_retries: 3,
            streaming_enabled: false,
            max_parallelism: 0,
            context_window_limit: 128_000,
            preflight_enabled: true,
            custom_params: HashMap::new(),
        }
    }
}

impl Default for LlmAgentConfig {
    fn default() -> Self {
        Self {
            model_id: "default".to_string(),
            temperature: 0.3,
            max_output_tokens: 4096,
            system_prompt_template: "default".to_string(),
            function_calling_enabled: true,
            max_function_rounds: 10,
        }
    }
}

impl AgentConfig {
    /// 为指定 Agent 类型创建默认配置
    pub fn for_agent_type(agent_type: AgentType) -> Self {
        let mut config = Self::default();
        config.agent_type = agent_type;
        match agent_type {
            AgentType::Explorer => {
                config.timeout_ms = 120_000;
                config.llm_config.temperature = 0.2;
            }
            AgentType::ImpactAnalyzer => {
                config.timeout_ms = 60_000;
                config.llm_config.temperature = 0.1;
            }
            AgentType::Planner => {
                config.timeout_ms = 90_000;
                config.llm_config.temperature = 0.3;
            }
            AgentType::Coder => {
                config.timeout_ms = 300_000;
                config.llm_config.temperature = 0.2;
                config.llm_config.max_output_tokens = 8192;
                config.preflight_enabled = true;
            }
            AgentType::Reviewer => {
                config.timeout_ms = 120_000;
                config.llm_config.temperature = 0.2;
            }
            AgentType::Tester => {
                config.timeout_ms = 180_000;
                config.llm_config.temperature = 0.2;
            }
            AgentType::Research => {
                config.timeout_ms = 180_000;
                config.llm_config.temperature = 0.4;
            }
            AgentType::DocWriter => {
                config.timeout_ms = 120_000;
                config.llm_config.temperature = 0.3;
            }
            AgentType::Debugger => {
                config.timeout_ms = 180_000;
                config.llm_config.temperature = 0.2;
            }
        }
        config
    }

    /// 从 TOML 文件加载配置
    pub fn from_toml_file(path: &std::path::Path) -> Result<Self, AgentError> {
        let content = std::fs::read_to_string(path).map_err(|e| AgentError::InvalidConfig {
            message: format!("Failed to read config file {}: {}", path.display(), e),
        })?;
        let config: Self = toml::from_str(&content).map_err(|e| AgentError::InvalidConfig {
            message: format!("Failed to parse config file {}: {}", path.display(), e),
        })?;
        Ok(config)
    }

    /// 合并自定义参数（不覆盖已有值）
    pub fn with_custom_param(mut self, key: impl Into<String>, value: serde_json::Value) -> Self {
        self.custom_params.entry(key.into()).or_insert(value);
        self
    }
}
```

### P4-1.4.10 AgentExecutionReport

```rust
/// Agent 执行报告 — 所有 Agent execute 方法的统一返回类型
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentExecutionReport {
    pub execution_id: Uuid,
    pub agent_type: AgentType,
    pub status: ExecutionStatus,
    pub result: Option<serde_json::Value>,
    pub tool_calls: Vec<ToolCallRecord>,
    pub llm_stats: LlmCallStats,
    pub duration_ms: u64,
    pub error: Option<String>,
    pub files_affected: Vec<FileChange>,
    pub sub_reports: Vec<AgentExecutionReport>,
    pub handoff_summary: HashMap<String, String>,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ExecutionStatus {
    Success,
    PartialSuccess,
    Failed,
    Cancelled,
    Timeout,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolCallRecord {
    pub tool_name: String,
    pub input: serde_json::Value,
    pub output: serde_json::Value,
    pub duration_ms: u64,
    pub success: bool,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct LlmCallStats {
    pub total_calls: u32,
    pub total_input_tokens: u32,
    pub total_output_tokens: u32,
    pub total_duration_ms: u64,
    pub cache_hit_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileChange {
    pub path: String,
    pub change_type: FileChangeType,
    pub lines_added: u32,
    pub lines_removed: u32,
    pub description: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FileChangeType {
    Created,
    Modified,
    Deleted,
    Renamed,
}

impl AgentExecutionReport {
    pub fn success(agent_type: AgentType, execution_id: Uuid, result: serde_json::Value) -> Self {
        Self {
            execution_id, agent_type, status: ExecutionStatus::Success,
            result: Some(result), tool_calls: Vec::new(),
            llm_stats: LlmCallStats::default(), duration_ms: 0,
            error: None, files_affected: Vec::new(),
            sub_reports: Vec::new(), handoff_summary: HashMap::new(),
            timestamp: chrono::Utc::now(),
        }
    }

    pub fn failed(agent_type: AgentType, execution_id: Uuid, error: impl Into<String>) -> Self {
        Self {
            execution_id, agent_type, status: ExecutionStatus::Failed,
            result: None, tool_calls: Vec::new(),
            llm_stats: LlmCallStats::default(), duration_ms: 0,
            error: Some(error.into()), files_affected: Vec::new(),
            sub_reports: Vec::new(), handoff_summary: HashMap::new(),
            timestamp: chrono::Utc::now(),
        }
    }
}
```

### P4-1.4.11 StreamForwarder trait

```rust
/// 流式输出转发器 trait
#[async_trait]
pub trait StreamForwarder: Send + Sync {
    /// 转发一个文本 chunk
    async fn forward_chunk(&mut self, chunk: &str) -> Result<(), AgentError>;

    /// 转发结构化事件
    async fn forward_event(&mut self, event: StreamEvent) -> Result<(), AgentError>;

    /// 转发最终结果
    async fn forward_final(&mut self, report: &AgentExecutionReport) -> Result<(), AgentError>;

    /// 刷新缓冲区
    async fn flush(&mut self) -> Result<(), AgentError>;
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StreamEvent {
    pub event_type: StreamEventType,
    pub agent_type: AgentType,
    pub execution_id: Uuid,
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub data: serde_json::Value,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum StreamEventType {
    Thinking, ToolCallStart, ToolCallComplete,
    FileChange, Progress, Warning, Error, FinalResult,
}

/// Stdout 流式转发器（用于 CLI 模式）
pub struct StdoutStreamForwarder { buffer: String }

impl StdoutStreamForwarder {
    pub fn new() -> Self { Self { buffer: String::new() } }
}

#[async_trait]
impl StreamForwarder for StdoutStreamForwarder {
    async fn forward_chunk(&mut self, chunk: &str) -> Result<(), AgentError> {
        print!("{}", chunk);
        std::io::stdout().flush().map_err(|e| AgentError::StreamError {
            message: format!("Failed to flush stdout: {}", e),
        })?;
        Ok(())
    }

    async fn forward_event(&mut self, event: StreamEvent) -> Result<(), AgentError> {
        let json = serde_json::to_string(&event).map_err(|e| AgentError::StreamError {
            message: format!("Failed to serialize event: {}", e),
        })?;
        println!("[STREAM] {}", json);
        Ok(())
    }

    async fn forward_final(&mut self, report: &AgentExecutionReport) -> Result<(), AgentError> {
        let json = serde_json::to_string_pretty(report).map_err(|e| AgentError::StreamError {
            message: format!("Failed to serialize final report: {}", e),
        })?;
        println!("[FINAL] {}", json);
        Ok(())
    }

    async fn flush(&mut self) -> Result<(), AgentError> {
        std::io::stdout().flush().map_err(|e| AgentError::StreamError {
            message: format!("Failed to flush stdout: {}", e),
        })?;
        Ok(())
    }
}
```

### P4-1.4.12 SharedResources

```rust
/// 共享资源容器 — 在 Agent 之间共享的运行时资源
#[derive(Clone)]
pub struct SharedResources {
    pub llm_client: Arc<dyn LlmClient>,
    pub tool_registry: Arc<ToolRegistry>,
    pub memory_manager: Arc<MemoryManager>,
    pub event_bus: Arc<dyn EventBus>,
    pub config: Arc<GlobalConfig>,
}

impl SharedResources {
    pub fn new(
        llm_client: Arc<dyn LlmClient>,
        tool_registry: Arc<ToolRegistry>,
        memory_manager: Arc<MemoryManager>,
        event_bus: Arc<dyn EventBus>,
        config: Arc<GlobalConfig>,
    ) -> Self {
        Self { llm_client, tool_registry, memory_manager, event_bus, config }
    }
}
```

### P4-1.4.13 execute_with_context 和 execute_streaming 辅助方法

```rust
/// 带完整生命周期管理的 Agent 执行方法
pub async fn execute_with_context(
    agent: &dyn Agent,
    ctx: &AgentContext,
    lifecycle: Option<&dyn AgentLifecycle>,
) -> Result<AgentExecutionReport, AgentError> {
    // 1. 生命周期：on_start
    if let Some(lc) = lifecycle {
        lc.on_start(ctx).await?;
    }

    // 2. 执行（带超时和取消检测）
    let result = execute_with_timeout_and_retry(agent, ctx).await;

    // 3. 生命周期回调
    match &result {
        Ok(report) => {
            if let Some(lc) = lifecycle { lc.on_complete(ctx, report).await?; }
        }
        Err(error) => {
            if error.category() == ErrorCategory::Execution {
                if let Some(lc) = lifecycle { lc.on_error(ctx, error).await?; }
            }
        }
    }
    result
}

/// 带超时和重试的执行
async fn execute_with_timeout_and_retry(
    agent: &dyn Agent,
    ctx: &AgentContext,
) -> Result<AgentExecutionReport, AgentError> {
    let timeout = if ctx.config.timeout_ms > 0 {
        Some(tokio::time::Duration::from_millis(ctx.config.timeout_ms))
    } else {
        None
    };

    let mut last_error = None;
    let max_retries = ctx.max_retries;

    for attempt in 0..=max_retries {
        if ctx.is_cancelled() {
            return Err(AgentError::ExecutionCancelled {
                agent_type: agent.agent_type(),
            });
        }

        let exec_future = agent.execute(ctx);
        let result = if let Some(timeout) = timeout {
            tokio::time::timeout(timeout, exec_future).await
        } else {
            Ok(exec_future.await)
        };

        match result {
            Ok(Ok(report)) => return Ok(report),
            Ok(Err(error)) => {
                if error.is_retryable() && attempt < max_retries {
                    tokio::time::sleep(
                        tokio::time::Duration::from_millis(error.retry_delay_ms())
                    ).await;
                    last_error = Some(error);
                    continue;
                }
                return Err(error);
            }
            Err(_) => {
                if attempt < max_retries {
                    tokio::time::sleep(
                        tokio::time::Duration::from_millis(1000)
                    ).await;
                    continue;
                }
                return Err(AgentError::ExecutionTimeout {
                    agent_type: agent.agent_type(),
                    timeout_ms: ctx.config.timeout_ms,
                });
            }
        }
    }

    Err(last_error.unwrap_or_else(|| AgentError::Internal {
        message: "Unexpected execution state".to_string(),
        source: None,
    }))
}

/// 流式执行辅助方法
pub async fn execute_streaming_with_context(
    agent: &dyn Agent,
    ctx: &AgentContext,
    forwarder: &mut dyn StreamForwarder,
    lifecycle: Option<&dyn AgentLifecycle>,
) -> Result<AgentExecutionReport, AgentError> {
    if let Some(lc) = lifecycle { lc.on_start(ctx).await?; }

    let result = agent.execute_streaming(ctx, forwarder).await;

    match &result {
        Ok(report) => {
            if let Some(lc) = lifecycle { lc.on_complete(ctx, report).await?; }
        }
        Err(error) => {
            if let Some(lc) = lifecycle { lc.on_error(ctx, error).await?; }
        }
    }
    result
}
```

---

## P4-1.5 功能需求清单

### FR-P4-1.01 Agent 注册

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-1.01-01 | 支持通过 `AgentRegistry::register` 注册单个 Agent 工厂 | P0 |
| FR-P4-1.01-02 | 支持通过 `AgentRegistry::register_all` 批量注册 | P0 |
| FR-P4-1.01-03 | 重复注册同类型 Agent 时返回 `DuplicateRegistration` 错误 | P0 |
| FR-P4-1.01-04 | 注册操作线程安全（RwLock 写锁保护） | P0 |
| FR-P4-1.01-05 | 支持查询已注册 Agent 列表（`list_all`） | P1 |
| FR-P4-1.01-06 | 支持按层级过滤已注册 Agent（`list_by_layer`） | P1 |
| FR-P4-1.01-07 | 支持检查 Agent 是否已注册（`is_registered`） | P1 |

### FR-P4-1.02 Agent 创建

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-1.02-01 | `get` 方法返回单例 Agent 实例（首次创建后缓存） | P0 |
| FR-P4-1.02-02 | `create_agent` 方法每次创建新实例（适用于并行场景） | P0 |
| FR-P4-1.02-03 | 创建不存在的 Agent 类型时返回 `AgentNotFound` 错误 | P0 |
| FR-P4-1.02-04 | 创建时自动缓存 Agent 能力信息 | P1 |
| FR-P4-1.02-05 | 支持通过 `get_capabilities` 查询 Agent 能力 | P1 |

### FR-P4-1.03 生命周期管理

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-1.03-01 | 提供 `AgentLifecycle` trait 定义四个阶段钩子 | P0 |
| FR-P4-1.03-02 | 提供 `NoopLifecycle` 默认空实现 | P0 |
| FR-P4-1.03-03 | 提供 `LoggingLifecycle` 日志记录实现 | P1 |
| FR-P4-1.03-04 | 生命周期回调通过 `Option` 注入，不强制要求 | P0 |
| FR-P4-1.03-05 | `on_error` 回调接收错误详情 | P0 |
| FR-P4-1.03-06 | 生命周期回调错误不影响主执行流程（仅记录日志） | P1 |

### FR-P4-1.04 上下文构建

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-1.04-01 | `AgentContext::new` 创建基础上下文 | P0 |
| FR-P4-1.04-02 | `create_child_context` 创建子任务上下文（继承资源） | P0 |
| FR-P4-1.04-03 | 子上下文继承 project_ctx、impact_report、execution_plan | P0 |
| FR-P4-1.04-04 | 子上下文使用 `child_token` 实现级联取消 | P0 |
| FR-P4-1.04-05 | `AgentHandoff` 支持类型安全的数据传递 | P0 |
| FR-P4-1.04-06 | `AgentHandoff` 支持父子层级回退查询 | P1 |

### FR-P4-1.05 执行引擎

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-1.05-01 | `execute_with_context` 提供完整的生命周期管理执行 | P0 |
| FR-P4-1.05-02 | 支持超时控制（可配置 timeout_ms） | P0 |
| FR-P4-1.05-03 | 支持取消检测（CancellationToken） | P0 |
| FR-P4-1.05-04 | 支持可重试错误的自动重试（指数退避） | P0 |
| FR-P4-1.05-05 | `execute_streaming_with_context` 提供流式执行 | P0 |
| FR-P4-1.05-06 | 流式输出通过 `StreamForwarder` trait 抽象 | P0 |
| FR-P4-1.05-07 | 提供 `StdoutStreamForwarder` CLI 模式实现 | P1 |

### FR-P4-1.06 配置管理

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-1.06-01 | `AgentConfig` 支持为每种 Agent 类型提供默认配置 | P0 |
| FR-P4-1.06-02 | 支持从 TOML 文件加载配置 | P1 |
| FR-P4-1.06-03 | 支持运行时动态修改配置（`update_config`） | P1 |
| FR-P4-1.06-04 | 支持自定义参数扩展（`custom_params`） | P2 |

---

## P4-1.6 接口契约

### IC-P4-1.01 Agent trait 契约

```
前置条件：
  - Agent 已通过 AgentRegistry 注册
  - SharedResources 已初始化（LLM、工具、内存、事件总线）

Agent::build_context 契约：
  输入：TaskDescription + Option<ProjectContext> + SharedResources
  输出：AgentContext
  保证：
    - 返回的 AgentContext 包含有效的 execution_id（UUID v4）
    - cancel_token 未被取消
    - started_at 为当前 UTC 时间
  错误：
    - ContextBuildFailed：项目上下文加载失败
    - MissingContextData：必需的上下文数据缺失

Agent::execute 契约：
  输入：&AgentContext
  输出：AgentExecutionReport
  保证：
    - report.execution_id == ctx.execution_id
    - report.agent_type == self.agent_type()
    - 成功时 status == Success 且 error == None
    - 失败时 status == Failed 且 error 为 Some
  错误：
    - ExecutionFailed / ExecutionCancelled / LlmError / ToolError
```

### IC-P4-1.02 AgentRegistry 契约

```
注册契约：
  register(agent_type, factory) -> Result<(), AgentError>
  保证：
    - 注册成功后 is_registered(&agent_type) == true
    - 重复注册返回 DuplicateRegistration
    - 注册操作原子性

查询契约：
  get(&agent_type, shared, config) -> Result<Arc<RwLock<Box<dyn Agent>>>>
  保证：
    - 返回的 Agent 实例 agent_type() == 传入的 agent_type
    - 同一 agent_type 多次调用 get 返回同一实例（单例）
    - create_agent 每次返回不同实例

并发契约：
  - 多线程并发读安全（RwLock 读锁）
  - 读写互斥（RwLock 写锁）
  - 无死锁风险
```

### IC-P4-1.03 生命周期契约

```
回调顺序保证：
  正常流程：on_start -> execute -> on_complete
  错误流程：on_start -> execute -> on_error
  取消流程：on_start -> (检测到取消) -> on_cancel

回调错误处理：
  - on_start 失败：中止执行，返回错误
  - on_complete / on_error / on_cancel 失败：不影响主流程，仅记录日志
```

---

## P4-1.7 测试要点

### TP-P4-1.01 Agent 注册测试

```rust
#[cfg(test)]
mod tests {
    use super::*;

    // TP-P4-1.01-01: 正常注册
    #[tokio::test]
    async fn test_register_agent_success() {
        let registry = AgentRegistry::new();
        let result = registry.register(
            AgentType::Coder,
            |_shared, _config| Box::new(MockCoderAgent::new()),
        );
        assert!(result.is_ok());
        assert!(registry.is_registered(&AgentType::Coder));
    }

    // TP-P4-1.01-02: 重复注册
    #[tokio::test]
    async fn test_register_duplicate_fails() {
        let registry = AgentRegistry::new();
        registry.register(
            AgentType::Coder,
            |_shared, _config| Box::new(MockCoderAgent::new()),
        ).unwrap();
        let result = registry.register(
            AgentType::Coder,
            |_shared, _config| Box::new(MockCoderAgent::new()),
        );
        assert!(matches!(result, Err(AgentError::DuplicateRegistration { .. })));
    }

    // TP-P4-1.01-03: 列出所有已注册 Agent
    #[tokio::test]
    async fn test_list_all_agents() {
        let registry = AgentRegistry::new();
        registry.register(AgentType::Coder,
            |_s, _c| Box::new(MockCoderAgent::new())).unwrap();
        registry.register(AgentType::Reviewer,
            |_s, _c| Box::new(MockReviewerAgent::new())).unwrap();
        let all = registry.list_all();
        assert_eq!(all.len(), 2);
    }

    // TP-P4-1.01-04: 按层级过滤
    #[tokio::test]
    async fn test_list_by_layer() {
        let registry = AgentRegistry::new();
        registry.register(AgentType::Explorer,
            |_s, _c| Box::new(MockExplorerAgent::new())).unwrap();
        registry.register(AgentType::Coder,
            |_s, _c| Box::new(MockCoderAgent::new())).unwrap();
        let cognitive = registry.list_by_layer(AgentLayer::Cognitive);
        assert_eq!(cognitive.len(), 1);
        assert_eq!(cognitive[0], AgentType::Explorer);
    }
}
```

### TP-P4-1.02 Agent 创建测试

```rust
    // TP-P4-1.02-01: 单例获取
    #[tokio::test]
    async fn test_get_singleton() {
        let registry = AgentRegistry::new();
        let shared = create_test_shared_resources();
        let config = AgentConfig::for_agent_type(AgentType::Coder);
        registry.register(AgentType::Coder,
            |_s, _c| Box::new(MockCoderAgent::new())).unwrap();
        let i1 = registry.get(&AgentType::Coder, &shared, &config).unwrap();
        let i2 = registry.get(&AgentType::Coder, &shared, &config).unwrap();
        assert!(Arc::ptr_eq(&i1, &i2));
    }

    // TP-P4-1.02-02: 工厂创建新实例
    #[tokio::test]
    async fn test_create_agent_new_instance() {
        let registry = AgentRegistry::new();
        let shared = create_test_shared_resources();
        let config = AgentConfig::for_agent_type(AgentType::Coder);
        registry.register(AgentType::Coder,
            |_s, _c| Box::new(MockCoderAgent::new())).unwrap();
        let a1 = registry.create_agent(&AgentType::Coder, &shared, &config).unwrap();
        let a2 = registry.create_agent(&AgentType::Coder, &shared, &config).unwrap();
        assert_eq!(a1.agent_type(), AgentType::Coder);
        assert_eq!(a2.agent_type(), AgentType::Coder);
    }

    // TP-P4-1.02-03: 获取未注册的 Agent
    #[tokio::test]
    async fn test_get_unregistered_agent_fails() {
        let registry = AgentRegistry::new();
        let shared = create_test_shared_resources();
        let config = AgentConfig::for_agent_type(AgentType::Coder);
        let result = registry.get(&AgentType::Coder, &shared, &config);
        assert!(matches!(result, Err(AgentError::AgentNotFound { .. })));
    }
```

### TP-P4-1.03 上下文测试

```rust
    // TP-P4-1.03-01: 子上下文继承
    #[tokio::test]
    async fn test_child_context_inheritance() {
        let parent_ctx = create_test_context();
        let child_ctx = parent_ctx.create_child_context(
            TaskDescription::simple("sub task")
        );
        assert!(child_ctx.project_ctx.is_some());
        assert_eq!(child_ctx.parent_execution_id, Some(parent_ctx.execution_id));
        assert_ne!(child_ctx.execution_id, parent_ctx.execution_id);
    }

    // TP-P4-1.03-02: 级联取消
    #[tokio::test]
    async fn test_cascading_cancel() {
        let parent_ctx = create_test_context();
        let child_ctx = parent_ctx.create_child_context(
            TaskDescription::simple("sub task")
        );
        parent_ctx.cancel_token.cancel();
        assert!(child_ctx.is_cancelled());
    }

    // TP-P4-1.03-03: Handoff 数据传递
    #[tokio::test]
    async fn test_handoff_data_transfer() {
        let handoff = AgentHandoff::new();
        handoff.put(ProjectContext::default()).await;
        let result: Option<ProjectContext> = handoff.get().await;
        assert!(result.is_some());
    }
```

### TP-P4-1.04 执行引擎测试

```rust
    // TP-P4-1.04-01: 正常执行流程
    #[tokio::test]
    async fn test_execute_success() {
        let agent = MockCoderAgent::new();
        let ctx = create_test_context();
        let lifecycle = LoggingLifecycle::new(create_test_logger());
        let result = execute_with_context(&agent, &ctx, Some(&lifecycle)).await;
        assert!(result.is_ok());
        assert_eq!(result.unwrap().status, ExecutionStatus::Success);
    }

    // TP-P4-1.04-02: 超时控制
    #[tokio::test]
    async fn test_execute_timeout() {
        let agent = SlowAgent::new(std::time::Duration::from_secs(10));
        let mut ctx = create_test_context();
        ctx.config = Arc::new(AgentConfig {
            timeout_ms: 100,
            ..AgentConfig::for_agent_type(AgentType::Coder)
        });
        let result = execute_with_context(&agent, &ctx, None).await;
        assert!(matches!(result, Err(AgentError::ExecutionTimeout { .. })));
    }

    // TP-P4-1.04-03: 取消执行
    #[tokio::test]
    async fn test_execute_cancel() {
        let agent = SlowAgent::new(std::time::Duration::from_secs(10));
        let ctx = create_test_context();
        let cancel_token = ctx.cancel_token.clone();
        tokio::spawn(async move {
            tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
            cancel_token.cancel();
        });
        let result = execute_with_context(&agent, &ctx, None).await;
        assert!(matches!(result, Err(AgentError::ExecutionCancelled { .. })));
    }

    // TP-P4-1.04-04: 自动重试
    #[tokio::test]
    async fn test_execute_retry() {
        let agent = RetryableAgent::new(2);
        let ctx = create_test_context();
        let result = execute_with_context(&agent, &ctx, None).await;
        assert!(result.is_ok());
    }
```

### TP-P4-1.05 错误处理测试

```rust
    // TP-P4-1.05-01: 错误分类
    #[test]
    fn test_error_category() {
        let err = AgentError::DuplicateRegistration {
            agent_type: AgentType::Coder,
            message: "test".into(),
        };
        assert_eq!(err.category(), ErrorCategory::Registration);

        let err = AgentError::LlmError {
            message: "rate limit".into(), source: None,
        };
        assert_eq!(err.category(), ErrorCategory::Llm);
    }

    // TP-P4-1.05-02: 可重试判断
    #[test]
    fn test_retryable_errors() {
        assert!(AgentError::LlmError {
            message: "timeout".into(), source: None,
        }.is_retryable());
        assert!(!AgentError::AgentNotFound {
            agent_type: AgentType::Coder,
            message: "not found".into(),
        }.is_retryable());
    }
```

---

# P4-2 认知层 Agent（Explorer + ImpactAnalyzer + Planner）

## P4-2.1 模块概述

认知层 Agent 是 MoreCode 系统的"大脑"，负责理解项目结构、分析变更影响、制定执行计划。它们在执行层 Agent 动手之前完成全部认知工作，确保后续执行有充分的信息支撑和合理的策略指导。

### 三层认知流水线

```
用户任务 → [Explorer] → [ImpactAnalyzer] → [Planner] → 执行层
              │                │                │
              ▼                ▼                ▼
         ProjectContext   ImpactReport    ExecutionPlan
```

1. **Explorer**：扫描项目，理解结构，生成 `ProjectContext`
2. **ImpactAnalyzer**：基于 `ProjectContext` 分析变更影响，生成 `ImpactReport`
3. **Planner**：基于 `ProjectContext` + `ImpactReport` 制定执行计划，生成 `ExecutionPlan`

### 模块边界

```
mc-agent/cognitive/
├── mod.rs
├── explorer/
│   ├── mod.rs
│   └── explorer.rs
├── impact_analyzer/
│   ├── mod.rs
│   └── impact_analyzer.rs
└── planner/
    ├── mod.rs
    └── planner.rs
```

---

## P4-2.2 架构文档引用

| 引用文档 | 相关章节 | 关联说明 |
|---------|---------|---------|
| `03-认知层Agent.md` | 全文 | 认知层 Agent 的设计哲学、职责划分、协作模式 |
| `07-路由决策机制.md` | §认知层路由 | 认知层 Agent 的路由决策逻辑和触发条件 |
| `24-Agent系统提示词定义.md` | 系统提示词模板 | 系统提示词模板（{{variable}} 变量机制、分层架构） |

---

## P4-2.3 大模型开发提示词

```
你是一位精通 Rust 和 AI Agent 架构的高级工程师。请实现 MoreCode 系统的认知层 Agent，
包括 Explorer、ImpactAnalyzer 和 Planner。

设计约束：
1. 三个 Agent 形成 Pipeline：Explorer → ImpactAnalyzer → Planner
2. 每个 Agent 的输出通过 AgentHandoff 传递给下一个 Agent
3. Explorer 需要高效扫描大型项目（支持增量扫描和缓存）
4. ImpactAnalyzer 需要分析直接和间接影响，评估风险等级
5. Planner 需要生成 DAG 执行计划，支持并行分组和提交点设计
6. 所有 Agent 的 LLM 交互使用结构化输出（JSON Schema 约束）

Explorer 关键设计：
- 使用 .gitignore 规则过滤无关文件
- 识别技术栈（通过 package.json/Cargo.toml/go.mod/pyproject.toml 等）
- 提取模块依赖关系图
- 生成项目摘要（文件数、代码行数、目录结构）

ImpactAnalyzer 关键设计：
- 分析变更的直接影响（修改的文件、函数、类型）
- 传播分析间接影响（依赖链上的下游模块）
- 评估风险等级（Low/Medium/High/Critical）
- 生成兼容性说明和缓解建议

Planner 关键设计：
- 将任务分解为子任务（SubTask）
- 设计并行执行分组（ParallelGroup）
- 识别提交点（CommitPoint）用于增量提交
- 验证计划可行性（DAG 无环检查、资源约束检查）
```

---

## P4-2.4 核心类型定义

### P4-2.4.1 Explorer Agent

```rust
/// Explorer Agent — 项目探索与上下文生成
pub struct Explorer {
    config: AgentConfig,
    file_scanner: Arc<FileScanner>,
    tech_detector: Arc<TechDetector>,
}

impl Explorer {
    pub fn new(
        config: AgentConfig,
        file_scanner: Arc<FileScanner>,
        tech_detector: Arc<TechDetector>,
    ) -> Self {
        Self { config, file_scanner, tech_detector }
    }
}

#[async_trait]
impl Agent for Explorer {
    fn agent_type(&self) -> AgentType { AgentType::Explorer }
    fn supports_streaming(&self) -> bool { true }
    fn default_config(&self) -> AgentConfig { AgentConfig::for_agent_type(AgentType::Explorer) }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self,
        task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());

        // 增量模式：已有 ProjectContext 则直接使用
        if let Some(pc) = project_ctx {
            ctx.project_ctx = Some(Arc::new(pc));
            return Ok(ctx);
        }

        // 全量扫描模式
        let project_root = task.project_root().ok_or_else(|| AgentError::ContextBuildFailed {
            message: "Task missing project_root path".to_string(), source: None,
        })?;

        let scan_result = self.file_scanner.scan(&project_root).await
            .map_err(|e| AgentError::ContextBuildFailed {
                message: format!("File scan failed: {}", e), source: None,
            })?;

        let tech_stack = self.tech_detector.detect(&project_root, &scan_result.key_files).await
            .map_err(|e| AgentError::ContextBuildFailed {
                message: format!("Tech detection failed: {}", e), source: None,
            })?;

        let project_context = ProjectContext {
            root_path: project_root,
            file_tree: scan_result.file_tree,
            key_files: scan_result.key_files,
            tech_stack,
            module_graph: scan_result.module_graph,
            total_files: scan_result.total_files,
            total_lines: scan_result.total_lines,
            directory_structure: scan_result.directory_structure,
            metadata: HashMap::new(),
        };

        ctx.project_ctx = Some(Arc::new(project_context));
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let project_ctx = ctx.project_ctx.as_ref()
            .ok_or_else(|| AgentError::MissingContextData {
                data_type: "ProjectContext".to_string(),
            })?;

        let system_prompt = self.build_system_prompt();
        let user_prompt = self.build_user_prompt(project_ctx);

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(ctx.config.llm_config.temperature)
            .with_max_tokens(ctx.config.llm_config.max_output_tokens)
            .with_response_format(ResponseFormat::Json);

        let response = ctx.llm_client.complete(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let enhanced_context: serde_json::Value = serde_json::from_str(&response.content)
            .map_err(|e| AgentError::LlmParseError {
                message: format!("Failed to parse Explorer response: {}", e),
            })?;

        // 通过 handoff 传递 ProjectContext
        ctx.handoff.put((*project_ctx).clone()).await;

        Ok(AgentExecutionReport::success(
            AgentType::Explorer, ctx.execution_id, enhanced_context,
        ))
    }

    async fn execute_streaming(
        &self, ctx: &AgentContext, forwarder: &mut dyn StreamForwarder,
    ) -> Result<AgentExecutionReport, AgentError> {
        forwarder.forward_event(StreamEvent {
            event_type: StreamEventType::Thinking,
            agent_type: AgentType::Explorer,
            execution_id: ctx.execution_id,
            timestamp: chrono::Utc::now(),
            data: serde_json::json!({"message": "Scanning project structure..."}),
        }).await?;
        let report = self.execute(ctx).await?;
        forwarder.forward_event(StreamEvent {
            event_type: StreamEventType::FinalResult,
            agent_type: AgentType::Explorer,
            execution_id: ctx.execution_id,
            timestamp: chrono::Utc::now(),
            data: report.result.clone().unwrap_or_default(),
        }).await?;
        Ok(report)
    }
}

impl Explorer {
    fn build_system_prompt(&self) -> String {
        r#"
你是 MoreCode 系统的 Explorer Agent。你的职责是分析项目结构并生成项目上下文。
输出格式要求（JSON）：
{
  "project_summary": "项目的一句话描述",
  "architecture_pattern": "架构模式",
  "key_modules": ["模块1", "模块2"],
  "entry_points": ["main.rs", "index.ts"],
  "configuration_files": ["config.toml"],
  "test_framework": "测试框架名称",
  "build_system": "构建系统名称",
  "notable_patterns": ["设计模式1", "设计模式2"]
}
"#.to_string()
    }

    fn build_user_prompt(&self, pc: &ProjectContext) -> String {
        format!(
            "请分析以下项目结构并生成项目上下文摘要：\n根目录：{}\n文件总数：{}\n代码总行数：{}\n技术栈：{:?}\n关键文件：{:?}\n目录结构：\n{}",
            pc.root_path.display(), pc.total_files, pc.total_lines,
            pc.tech_stack, pc.key_files, pc.directory_structure,
        )
    }
}
```

### P4-2.4.2 ProjectContext

```rust
/// 项目上下文 — Explorer Agent 的核心输出
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectContext {
    pub root_path: std::path::PathBuf,
    pub file_tree: FileTree,
    pub key_files: Vec<KeyFile>,
    pub tech_stack: TechStack,
    pub module_graph: ModuleGraph,
    pub total_files: usize,
    pub total_lines: usize,
    pub directory_structure: String,
    pub metadata: HashMap<String, String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileTree {
    pub path: String,
    pub is_dir: bool,
    pub children: Vec<FileTree>,
    pub size_bytes: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KeyFile {
    pub path: String,
    pub file_type: KeyFileType,
    pub description: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum KeyFileType {
    PackageConfig, Entry, Config, TestConfig, CiConfig, Dockerfile, Readme, License,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TechStack {
    pub primary_language: String,
    pub languages: Vec<LanguageInfo>,
    pub frameworks: Vec<String>,
    pub package_manager: Option<String>,
    pub build_tool: Option<String>,
    pub runtime: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LanguageInfo {
    pub name: String,
    pub version: Option<String>,
    pub file_count: usize,
    pub line_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleGraph {
    pub nodes: Vec<ModuleNode>,
    pub edges: Vec<ModuleEdge>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleNode {
    pub id: String,
    pub name: String,
    pub path: String,
    pub module_type: ModuleType,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ModuleType { Library, Binary, Test, Example, Benchmark, Workspace }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleEdge {
    pub from: String,
    pub to: String,
    pub edge_type: DependencyType,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DependencyType { Direct, Dev, Peer, Optional, Transitive }
```

### P4-2.4.3 ImpactAnalyzer Agent

```rust
/// ImpactAnalyzer Agent — 变更影响分析
pub struct ImpactAnalyzer {
    config: AgentConfig,
}

impl ImpactAnalyzer {
    pub fn new(config: AgentConfig) -> Self { Self { config } }
}

#[async_trait]
impl Agent for ImpactAnalyzer {
    fn agent_type(&self) -> AgentType { AgentType::ImpactAnalyzer }
    fn default_config(&self) -> AgentConfig {
        AgentConfig::for_agent_type(AgentType::ImpactAnalyzer)
    }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self, task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());
        let pc = project_ctx.ok_or_else(|| AgentError::MissingContextData {
            data_type: "ProjectContext".to_string(),
        })?;
        ctx.project_ctx = Some(Arc::new(pc));
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let project_ctx = ctx.project_ctx.as_ref()
            .ok_or_else(|| AgentError::MissingContextData {
                data_type: "ProjectContext".to_string(),
            })?;

        let system_prompt = self.build_system_prompt();
        let user_prompt = self.build_user_prompt(ctx, project_ctx);

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(ctx.config.llm_config.temperature)
            .with_max_tokens(ctx.config.llm_config.max_output_tokens)
            .with_response_format(ResponseFormat::Json);

        let response = ctx.llm_client.complete(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let impact_report: ImpactReport = serde_json::from_str(&response.content)
            .map_err(|e| AgentError::LlmParseError {
                message: format!("Failed to parse ImpactReport: {}", e),
            })?;

        ctx.handoff.put(impact_report.clone()).await;

        let result = serde_json::to_value(&impact_report).map_err(|e| AgentError::Internal {
            message: format!("Failed to serialize ImpactReport: {}", e), source: None,
        })?;

        Ok(AgentExecutionReport::success(AgentType::ImpactAnalyzer, ctx.execution_id, result))
    }
}

/// 影响分析报告
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImpactReport {
    pub direct_impacts: Vec<Change>,
    pub indirect_impacts: Vec<Change>,
    pub risk_assessment: Vec<RiskAssessment>,
    pub compatibility_notes: Vec<String>,
    pub recommendations: Vec<String>,
    pub overall_risk_level: RiskLevel,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum RiskLevel { Low, Medium, High, Critical }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskAssessment {
    pub description: String,
    pub level: RiskLevel,
    pub mitigation: String,
    pub affected_files: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Change {
    pub file: String,
    pub change_type: ChangeType,
    pub description: String,
    pub affected_symbols: Vec<String>,
    pub risk_level: RiskLevel,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ChangeType {
    AddFile, ModifyFile, DeleteFile, AddDependency, ModifyConfig, DatabaseMigration,
}

impl ImpactAnalyzer {
    fn build_system_prompt(&self) -> String {
        r#"
你是 MoreCode 系统的 ImpactAnalyzer Agent。分析代码变更的影响范围。
输出格式要求（JSON）：
{
  "direct_impacts": [...],
  "indirect_impacts": [...],
  "risk_assessment": [...],
  "compatibility_notes": [...],
  "recommendations": [...],
  "overall_risk_level": "Low|Medium|High|Critical"
}
风险评估标准：
- Low：不影响现有功能，纯新增
- Medium：可能影响少量现有功能
- High：影响核心功能或多个模块
- Critical：破坏性变更，影响系统稳定性
"#.to_string()
    }

    fn build_user_prompt(&self, ctx: &AgentContext, pc: &ProjectContext) -> String {
        format!(
            "请分析以下变更的影响范围：\n项目根目录：{}\n技术栈：{:?}\n模块数：{}\n变更描述：{}\n任务详情：{}",
            pc.root_path.display(),
            pc.tech_stack.primary_language,
            pc.module_graph.nodes.len(),
            ctx.task.description(),
            ctx.task.details(),
        )
    }
}
```

### P4-2.4.4 Planner Agent

```rust
/// Planner Agent — 执行计划生成
pub struct Planner {
    config: AgentConfig,
}

impl Planner {
    pub fn new(config: AgentConfig) -> Self { Self { config } }
}

#[async_trait]
impl Agent for Planner {
    fn agent_type(&self) -> AgentType { AgentType::Planner }
    fn default_config(&self) -> AgentConfig { AgentConfig::for_agent_type(AgentType::Planner) }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self, task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());
        let pc = project_ctx.ok_or_else(|| AgentError::MissingContextData {
            data_type: "ProjectContext".to_string(),
        })?;
        ctx.project_ctx = Some(Arc::new(pc));
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let project_ctx = ctx.project_ctx.as_ref()
            .ok_or_else(|| AgentError::MissingContextData {
                data_type: "ProjectContext".to_string(),
            })?;

        let system_prompt = self.build_system_prompt();
        let user_prompt = self.build_user_prompt(ctx, project_ctx);

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(ctx.config.llm_config.temperature)
            .with_max_tokens(ctx.config.llm_config.max_output_tokens)
            .with_response_format(ResponseFormat::Json);

        let response = ctx.llm_client.complete(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let mut execution_plan: ExecutionPlan = serde_json::from_str(&response.content)
            .map_err(|e| AgentError::LlmParseError {
                message: format!("Failed to parse ExecutionPlan: {}", e),
            })?;

        self.validate_plan(&execution_plan)?;
        ctx.handoff.put(execution_plan.clone()).await;

        let result = serde_json::to_value(&execution_plan).map_err(|e| AgentError::Internal {
            message: format!("Failed to serialize ExecutionPlan: {}", e), source: None,
        })?;

        Ok(AgentExecutionReport::success(AgentType::Planner, ctx.execution_id, result))
    }
}

/// 执行计划
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionPlan {
    pub parallel_groups: Vec<ParallelGroup>,
    pub sub_tasks: Vec<SubTask>,
    pub commit_points: Vec<CommitPoint>,
    pub dependencies: Vec<TaskDependency>,
    pub estimated_duration_ms: u64,
    pub summary: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParallelGroup {
    pub group_id: String,
    pub task_ids: Vec<String>,
    pub description: String,
    pub order: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubTask {
    pub id: String,
    pub description: String,
    pub assigned_agent: AgentType,
    pub complexity: TaskComplexity,
    pub input_requirements: Vec<String>,
    pub expected_outputs: Vec<String>,
    pub requires_preflight: bool,
    pub params: HashMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TaskComplexity { Trivial, Simple, Moderate, Complex, Critical }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommitPoint {
    pub id: String,
    pub task_ids: Vec<String>,
    pub commit_message: String,
    pub commit_type: CommitType,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CommitType { Feature, Bugfix, Refactor, Test, Docs, Chore }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskDependency {
    pub from_task_id: String,
    pub to_task_id: String,
    pub dep_type: DependencyConstraint,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DependencyConstraint { MustComplete, CanStartAfterPartial, DataDependency }

impl Planner {
    /// 验证执行计划的可行性
    fn validate_plan(&self, plan: &ExecutionPlan) -> Result<(), AgentError> {
        self.check_dag_acyclic(plan)?;
        self.check_all_tasks_in_groups(plan)?;
        self.check_dependency_references(plan)?;
        self.check_commit_point_references(plan)?;
        Ok(())
    }

    /// DAG 无环检查（Kahn 算法拓扑排序）
    fn check_dag_acyclic(&self, plan: &ExecutionPlan) -> Result<(), AgentError> {
        let task_ids: std::collections::HashSet<&str> =
            plan.sub_tasks.iter().map(|t| t.id.as_str()).collect();

        let mut adj: HashMap<&str, Vec<&str>> = HashMap::new();
        let mut in_degree: HashMap<&str, usize> = HashMap::new();

        for task in &plan.sub_tasks {
            adj.entry(task.id.as_str()).or_default();
            in_degree.entry(task.id.as_str()).or_insert(0);
        }
        for dep in &plan.dependencies {
            adj.entry(dep.from_task_id.as_str()).or_default()
                .push(dep.to_task_id.as_str());
            *in_degree.entry(dep.to_task_id.as_str()).or_insert(0) += 1;
        }

        let mut queue: Vec<&str> = in_degree.iter()
            .filter(|(_, &deg)| deg == 0).map(|(&id, _)| id).collect();
        let mut sorted_count = 0;

        while let Some(node) = queue.pop() {
            sorted_count += 1;
            if let Some(neighbors) = adj.get(node) {
                for &neighbor in neighbors {
                    if let Some(deg) = in_degree.get_mut(neighbor) {
                        *deg -= 1;
                        if *deg == 0 { queue.push(neighbor); }
                    }
                }
            }
        }

        if sorted_count != task_ids.len() {
            return Err(AgentError::ExecutionFailed {
                agent_type: AgentType::Planner,
                message: format!("Execution plan contains cycle: sorted {}/{} tasks",
                    sorted_count, task_ids.len()),
                source: None,
            });
        }
        Ok(())
    }

    fn check_all_tasks_in_groups(&self, plan: &ExecutionPlan) -> Result<(), AgentError> {
        let grouped: std::collections::HashSet<&str> = plan.parallel_groups.iter()
            .flat_map(|g| g.task_ids.iter().map(|id| id.as_str())).collect();
        for task in &plan.sub_tasks {
            if !grouped.contains(task.id.as_str()) {
                return Err(AgentError::ExecutionFailed {
                    agent_type: AgentType::Planner,
                    message: format!("Task '{}' not in any parallel group", task.id),
                    source: None,
                });
            }
        }
        Ok(())
    }

    fn check_dependency_references(&self, plan: &ExecutionPlan) -> Result<(), AgentError> {
        let valid_ids: std::collections::HashSet<&str> =
            plan.sub_tasks.iter().map(|t| t.id.as_str()).collect();
        for dep in &plan.dependencies {
            if !valid_ids.contains(dep.from_task_id.as_str())
                || !valid_ids.contains(dep.to_task_id.as_str()) {
                return Err(AgentError::ExecutionFailed {
                    agent_type: AgentType::Planner,
                    message: "Dependency references non-existent task".to_string(),
                    source: None,
                });
            }
        }
        Ok(())
    }

    fn check_commit_point_references(&self, plan: &ExecutionPlan) -> Result<(), AgentError> {
        let valid_ids: std::collections::HashSet<&str> =
            plan.sub_tasks.iter().map(|t| t.id.as_str()).collect();
        for cp in &plan.commit_points {
            for task_id in &cp.task_ids {
                if !valid_ids.contains(task_id.as_str()) {
                    return Err(AgentError::ExecutionFailed {
                        agent_type: AgentType::Planner,
                        message: format!("Commit point '{}' references non-existent task: '{}'",
                            cp.id, task_id),
                        source: None,
                    });
                }
            }
        }
        Ok(())
    }

    fn build_system_prompt(&self) -> String {
        r#"
你是 MoreCode 系统的 Planner Agent。将任务分解为可执行的子任务计划。
输出格式要求（JSON）：
{
  "parallel_groups": [...],
  "sub_tasks": [...],
  "commit_points": [...],
  "dependencies": [...],
  "estimated_duration_ms": 0,
  "summary": "计划摘要"
}
子任务分配规则：
- 文件创建/修改 → Coder | 代码审查 → Reviewer | 测试生成/执行 → Tester
- 技术调研 → Research | 文档编写 → DocWriter | 问题调试 → Debugger
"#.to_string()
    }

    fn build_user_prompt(&self, ctx: &AgentContext, pc: &ProjectContext) -> String {
        format!(
            "请为以下任务生成执行计划：\n项目根目录：{}\n技术栈：{:?}\n模块数：{}\n任务描述：{}",
            pc.root_path.display(),
            pc.tech_stack.primary_language,
            pc.module_graph.nodes.len(),
            ctx.task.description(),
        )
    }
}
```

---

## P4-2.5 功能需求清单

### FR-P4-2.01 Explorer

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-2.01-01 | 扫描项目文件树，生成 `FileTree` 结构 | P0 |
| FR-P4-2.01-02 | 识别关键文件（配置文件、入口文件等） | P0 |
| FR-P4-2.01-03 | 检测技术栈（语言、框架、构建工具） | P0 |
| FR-P4-2.01-04 | 分析模块依赖关系图 | P0 |
| FR-P4-2.01-05 | 支持 .gitignore 规则过滤 | P1 |
| FR-P4-2.01-06 | 支持增量扫描（基于 git diff） | P1 |
| FR-P4-2.01-07 | 生成项目上下文摘要（LLM 增强） | P0 |
| FR-P4-2.01-08 | 通过 `AgentHandoff` 传递 `ProjectContext` | P0 |

### FR-P4-2.02 ImpactAnalyzer

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-2.02-01 | 分析变更的直接影响范围 | P0 |
| FR-P4-2.02-02 | 通过依赖链传播分析间接影响 | P0 |
| FR-P4-2.02-03 | 评估每个影响点的风险等级 | P0 |
| FR-P4-2.02-04 | 生成兼容性说明 | P1 |
| FR-P4-2.02-05 | 提供缓解建议 | P1 |
| FR-P4-2.02-06 | 输出总体风险等级（Low/Medium/High/Critical） | P0 |

### FR-P4-2.03 Planner

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-2.03-01 | 将任务分解为子任务（`SubTask`） | P0 |
| FR-P4-2.03-02 | 设计并行执行分组（`ParallelGroup`） | P0 |
| FR-P4-2.03-03 | 识别提交点（`CommitPoint`） | P1 |
| FR-P4-2.03-04 | 定义任务依赖关系（DAG） | P0 |
| FR-P4-2.03-05 | DAG 无环检查 | P0 |
| FR-P4-2.03-06 | 资源约束检查 | P1 |
| FR-P4-2.03-07 | 为子任务分配 Agent 类型 | P0 |

---

## P4-2.6 接口契约

### IC-P4-2.01 Explorer 契约

```
前置条件：task.project_root() 返回有效的项目根目录路径
build_context：增量模式下直接使用已有 ProjectContext；全量模式下执行扫描
execute：输出包含项目摘要 JSON，通过 handoff 传递 ProjectContext
错误：项目根目录不存在 → ContextBuildFailed | LLM 失败 → LlmError
```

### IC-P4-2.02 ImpactAnalyzer 契约

```
前置条件：ctx.project_ctx 必须为 Some
execute：输出 ImpactReport，包含 direct_impacts、indirect_impacts、overall_risk_level
通过 handoff.put(ImpactReport) 传递
错误：缺少 ProjectContext → MissingContextData | 解析失败 → LlmParseError
```

### IC-P4-2.03 Planner 契约

```
前置条件：ctx.project_ctx 必须为 Some
execute：输出 ExecutionPlan，通过 DAG 无环检查
验证：DAG 无环（Kahn 算法）、任务覆盖、引用完整性
错误：包含环 / 任务未分组 / 引用不存在 → ExecutionFailed
```

---

## P4-2.7 测试要点

```rust
#[cfg(test)]
mod cognitive_tests {
    // TP-P4-2.01-01: Explorer 全量扫描
    #[tokio::test]
    async fn test_explorer_full_scan() {
        let explorer = Explorer::new(
            AgentConfig::for_agent_type(AgentType::Explorer),
            create_test_file_scanner(), create_test_tech_detector(),
        );
        let task = TaskDescription::with_root("scan", &create_test_project_dir());
        let ctx = explorer.build_context(&task, None, &test_shared()).await.unwrap();
        assert!(ctx.project_ctx.is_some());
    }

    // TP-P4-2.01-02: Explorer 增量模式
    #[tokio::test]
    async fn test_explorer_incremental() {
        let explorer = Explorer::new(
            AgentConfig::for_agent_type(AgentType::Explorer),
            create_test_file_scanner(), create_test_tech_detector(),
        );
        let ctx = explorer.build_context(
            &TaskDescription::simple("inc"),
            Some(ProjectContext::default()), &test_shared(),
        ).await.unwrap();
        assert!(ctx.project_ctx.is_some());
    }

    // TP-P4-2.01-03: 缺少项目根目录
    #[tokio::test]
    async fn test_explorer_missing_root() {
        let explorer = Explorer::new(
            AgentConfig::for_agent_type(AgentType::Explorer),
            create_test_file_scanner(), create_test_tech_detector(),
        );
        let result = explorer.build_context(
            &TaskDescription::simple("no root"), None, &test_shared(),
        ).await;
        assert!(matches!(result, Err(AgentError::ContextBuildFailed { .. })));
    }

    // TP-P4-2.02-01: ImpactAnalyzer 缺少上下文
    #[tokio::test]
    async fn test_impact_missing_context() {
        let analyzer = ImpactAnalyzer::new(
            AgentConfig::for_agent_type(AgentType::ImpactAnalyzer)
        );
        let result = analyzer.build_context(
            &TaskDescription::simple("change"), None, &test_shared(),
        ).await;
        assert!(matches!(result, Err(AgentError::MissingContextData { .. })));
    }

    // TP-P4-2.03-01: Planner DAG 无环检查通过
    #[test]
    fn test_planner_dag_acyclic() {
        let planner = Planner::new(AgentConfig::for_agent_type(AgentType::Planner));
        assert!(planner.validate_plan(&create_valid_plan()).is_ok());
    }

    // TP-P4-2.03-02: Planner DAG 环检测
    #[test]
    fn test_planner_dag_cycle_detection() {
        let planner = Planner::new(AgentConfig::for_agent_type(AgentType::Planner));
        assert!(matches!(
            planner.validate_plan(&create_cyclic_plan()),
            Err(AgentError::ExecutionFailed { .. })
        ));
    }

    // TP-P4-2.03-03: 任务未分组检测
    #[test]
    fn test_planner_unassigned_task() {
        let planner = Planner::new(AgentConfig::for_agent_type(AgentType::Planner));
        assert!(matches!(
            planner.validate_plan(&create_unassigned_plan()),
            Err(AgentError::ExecutionFailed { .. })
        ));
    }

    // TP-P4-2.03-04: 依赖引用不存在检测
    #[test]
    fn test_planner_invalid_dep_ref() {
        let planner = Planner::new(AgentConfig::for_agent_type(AgentType::Planner));
        assert!(matches!(
            planner.validate_plan(&create_invalid_dep_plan()),
            Err(AgentError::ExecutionFailed { .. })
        ));
    }
}
```

---

# P4-3 执行层 Agent（Coder + Reviewer + Tester）

## P4-3.1 模块概述

执行层 Agent 是 MoreCode 系统的"双手"，负责实际的代码编写、审查和测试工作。它们接收认知层生成的 `ExecutionPlan`，按照计划有序地完成代码变更。

### 执行层协作模式

```
ExecutionPlan
    │
    ├── Coder ──→ [PreFlightPlan] ──→ Reviewer (预飞审查)
    │                                      │
    │                              ┌───────┴────────┐
    │                              ▼                ▼
    │                        Approved        NeedsAdjustment
    │                            │                │
    │                            ▼                ▼
    │                     Coder (执行)      Coder (调整)
    │                            │
    │                            ▼
    │                      Reviewer (常规审查)
    │                            │
    │                            ▼
    │                       Tester (测试)
    │
    └── (循环直到所有 sub_tasks 完成)
```

### 模块边界

```
mc-agent/execution/
├── mod.rs
├── coder/
│   ├── mod.rs
│   ├── coder.rs
│   ├── preflight.rs
│   └── caveat.rs
├── reviewer/
│   ├── mod.rs
│   ├── reviewer.rs
│   └── preflight_review.rs
└── tester/
    ├── mod.rs
    └── tester.rs
```

---

## P4-3.2 架构文档引用

| 引用文档 | 相关章节 | 关联说明 |
|---------|---------|---------|
| `04-执行层Agent.md` | 全文 | 执行层 Agent 的设计原则、预飞检查机制、协作流程 |
| `04-执行层Agent.md` | §6.2.1 预飞检查 | 预飞检查的触发条件、流程、输出格式 |
| `24-Agent系统提示词定义.md` | 系统提示词模板 | Coder/Reviewer/Tester 系统提示词模板 |

---

## P4-3.3 大模型开发提示词

```
你是一位精通 Rust 和 AI 代码生成的资深工程师。请实现 MoreCode 系统的执行层 Agent，
包括 Coder、Reviewer 和 Tester。

设计约束：
1. Coder Agent 实现预飞检查模式（§6.2.1）：
   - 生成 PreFlightPlan 后交由 Reviewer 预飞审查
   - 根据 PreFlightReviewResult 决定是否执行或调整
   - 支持 Caveat 约束执行模式
2. Reviewer Agent 同时支持预飞审查和常规审查两种模式
3. Tester Agent 支持测试生成和测试执行两种模式
4. 所有 Agent 通过 AgentHandoff 传递结构化数据
5. 文件操作通过 ToolRegistry 中的文件工具完成

Coder 预飞检查流程（§6.2.1）：
1. Coder 分析任务，生成 PreFlightPlan
2. PreFlightPlan 包含：plan_description、file_changes、affected_modules、
   identified_risks、new_dependencies、database_migrations、api_changes
3. 将 PreFlightPlan 发送给 Reviewer 进行预飞审查
4. Reviewer 返回 PreFlightReviewResult（verdict + caveats + adjustments）
5. Approved → Coder 注入 Caveat 后执行
6. NeedsAdjustment → Coder 调整后重新审查（最多 2 轮）
7. Rejected → 中止执行

预飞检查适用条件：
- 任务类型：代码修改、功能添加、重构
- 文件数：涉及 3 个以上文件修改
- 复杂度：Moderate 及以上
- 高风险变更：API 变更、数据库迁移、核心模块修改
```

---

## P4-3.4 核心类型定义

### P4-3.4.1 Coder Agent

```rust
/// Coder Agent — 代码编写与文件修改
pub struct Coder {
    config: AgentConfig,
    file_tool: Arc<dyn FileTool>,
    dependency_tool: Arc<dyn DependencyTool>,
}

impl Coder {
    pub fn new(
        config: AgentConfig,
        file_tool: Arc<dyn FileTool>,
        dependency_tool: Arc<dyn DependencyTool>,
    ) -> Self {
        Self { config, file_tool, dependency_tool }
    }

    /// 判断是否需要预飞检查
    fn should_preflight(&self, ctx: &AgentContext) -> bool {
        if !self.config.preflight_enabled { return false; }

        // 条件 1：任务类型
        match ctx.task.task_type() {
            TaskType::CodeModification | TaskType::FeatureAddition | TaskType::Refactoring => {}
            TaskType::Documentation | TaskType::Research | TaskType::Configuration => return false,
        }

        // 条件 2：文件数
        if let Some(plan) = &ctx.execution_plan {
            let file_count = plan.sub_tasks.iter()
                .filter(|t| t.assigned_agent == AgentType::Coder).count();
            if file_count >= 3 { return true; }
        }

        // 条件 3：复杂度
        if let Some(complexity) = ctx.task.complexity() {
            if complexity >= TaskComplexity::Moderate { return true; }
        }

        // 条件 4：高风险变更
        if let Ok(Some(impact)) = ctx.handoff.try_get_with_fallback::<ImpactReport>() {
            if impact.overall_risk_level >= RiskLevel::High { return true; }
            let has_high_risk = impact.direct_impacts.iter().any(|c| {
                matches!(c.change_type, ChangeType::AddDependency | ChangeType::DatabaseMigration)
                    || c.risk_level >= RiskLevel::High
            });
            if has_high_risk { return true; }
        }

        false
    }
}

#[async_trait]
impl Agent for Coder {
    fn agent_type(&self) -> AgentType { AgentType::Coder }
    fn supports_streaming(&self) -> bool { true }
    fn default_config(&self) -> AgentConfig { AgentConfig::for_agent_type(AgentType::Coder) }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self, task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());
        if let Some(pc) = project_ctx {
            ctx.project_ctx = Some(Arc::new(pc));
        }
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        if self.should_preflight(ctx) {
            return self.execute_with_preflight(ctx).await;
        }
        self.execute_direct(ctx).await
    }
}

impl Coder {
    /// 预飞检查模式执行
    async fn execute_with_preflight(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        // 步骤 1：生成 PreFlightPlan
        let preflight_plan = self.generate_preflight_plan(ctx).await?;

        // 步骤 2：发送给 Reviewer 预飞审查
        let review_result = self.request_preflight_review(ctx, &preflight_plan).await?;

        // 步骤 3：根据审查结果决定下一步
        match review_result.verdict {
            PreFlightVerdict::Approved => {
                self.execute_with_caveats(ctx, &review_result.caveats).await
            }
            PreFlightVerdict::NeedsAdjustment => {
                self.adjust_and_retry(ctx, &preflight_plan, &review_result, 2).await
            }
            PreFlightVerdict::Rejected => {
                Ok(AgentExecutionReport::failed(
                    AgentType::Coder, ctx.execution_id,
                    format!("Pre-flight review rejected: {:?}", review_result.suggested_adjustments),
                ))
            }
        }
    }

    /// 直接执行（无预飞检查）
    async fn execute_direct(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let system_prompt = self.build_coding_system_prompt(ctx);
        let user_prompt = self.build_coding_user_prompt(ctx);

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(ctx.config.llm_config.temperature)
            .with_max_tokens(ctx.config.llm_config.max_output_tokens)
            .with_tools(self.get_available_tools())
            .with_function_calling(ctx.config.llm_config.function_calling_enabled)
            .with_max_function_rounds(ctx.config.llm_config.max_function_rounds);

        let response = ctx.llm_client.complete_with_tools(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let files_affected = self.collect_file_changes(&response.tool_calls);

        Ok(AgentExecutionReport::success(AgentType::Coder, ctx.execution_id,
            serde_json::json!({
                "files_modified": files_affected.len(),
                "tool_calls": response.tool_calls.len(),
            }),
        ))
    }

    /// 生成预飞计划
    async fn generate_preflight_plan(&self, ctx: &AgentContext) -> Result<PreFlightPlan, AgentError> {
        let llm_request = LlmRequest::new(&self.build_preflight_system_prompt(),
            &self.build_preflight_user_prompt(ctx))
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(0.2)
            .with_max_tokens(4096)
            .with_response_format(ResponseFormat::Json);

        let response = ctx.llm_client.complete(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        serde_json::from_str(&response.content).map_err(|e| AgentError::LlmParseError {
            message: format!("Failed to parse PreFlightPlan: {}", e),
        })
    }

    /// 请求预飞审查
    async fn request_preflight_review(
        &self, ctx: &AgentContext, plan: &PreFlightPlan,
    ) -> Result<PreFlightReviewResult, AgentError> {
        ctx.handoff.put(plan.clone()).await;

        let reviewer = Reviewer::new(AgentConfig::for_agent_type(AgentType::Reviewer));
        let review_ctx = ctx.create_child_context(TaskDescription::simple("preflight review"));
        review_ctx.extra_params.insert(
            "review_mode".to_string(), serde_json::json!("preflight"),
        );

        let _report = reviewer.execute(&review_ctx).await?;

        ctx.handoff.get_with_fallback::<PreFlightReviewResult>().await
            .ok_or_else(|| AgentError::MissingContextData {
                data_type: "PreFlightReviewResult".to_string(),
            })
    }

    /// 带约束执行（注入 Caveat 注意点）
    async fn execute_with_caveats(
        &self, ctx: &AgentContext, caveats: &[Caveat],
    ) -> Result<AgentExecutionReport, AgentError> {
        let caveat_instructions: Vec<String> = caveats.iter()
            .map(|c| format!("[{}] {} (优先级: {:?})", c.category, c.description, c.priority))
            .collect();

        let user_prompt = format!(
            "{}\n\n## 注意事项（必须遵守）\n{}",
            self.build_coding_user_prompt(ctx),
            caveat_instructions.join("\n"),
        );

        let llm_request = LlmRequest::new(&self.build_coding_system_prompt(ctx), &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(ctx.config.llm_config.temperature)
            .with_max_tokens(ctx.config.llm_config.max_output_tokens)
            .with_tools(self.get_available_tools())
            .with_function_calling(true);

        let response = ctx.llm_client.complete_with_tools(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        Ok(AgentExecutionReport::success(AgentType::Coder, ctx.execution_id,
            serde_json::json!({
                "files_modified": self.collect_file_changes(&response.tool_calls).len(),
                "caveats_applied": caveats.len(),
            }),
        ))
    }

    /// 调整计划并重试
    async fn adjust_and_retry(
        &self, ctx: &AgentContext, _plan: &PreFlightPlan,
        review: &PreFlightReviewResult, remaining: u32,
    ) -> Result<AgentExecutionReport, AgentError> {
        if remaining == 0 {
            return Ok(AgentExecutionReport::failed(
                AgentType::Coder, ctx.execution_id,
                "Pre-flight review adjustments exhausted",
            ));
        }
        let adjusted = self.generate_preflight_plan(ctx).await?;
        let new_review = self.request_preflight_review(ctx, &adjusted).await?;
        match new_review.verdict {
            PreFlightVerdict::Approved => self.execute_with_caveats(ctx, &new_review.caveats).await,
            PreFlightVerdict::NeedsAdjustment => {
                Box::pin(self.adjust_and_retry(ctx, &adjusted, &new_review, remaining - 1)).await
            }
            PreFlightVerdict::Rejected => Ok(AgentExecutionReport::failed(
                AgentType::Coder, ctx.execution_id,
                "Pre-flight review rejected after adjustment",
            )),
        }
    }

    fn collect_file_changes(&self, tool_calls: &[ToolCall]) -> Vec<FileChange> {
        tool_calls.iter()
            .filter(|tc| tc.tool_name == "file_write" || tc.tool_name == "file_edit")
            .filter_map(|tc| {
                let path = tc.input.get("path")?.as_str()?.to_string();
                let change_type = if tc.tool_name == "file_write" {
                    FileChangeType::Created
                } else {
                    FileChangeType::Modified
                };
                Some(FileChange { path, change_type, lines_added: 0, lines_removed: 0, description: None })
            })
            .collect()
    }

    fn get_available_tools(&self) -> Vec<ToolDefinition> {
        vec![
            ToolDefinition::new("file_read", "读取文件内容"),
            ToolDefinition::new("file_write", "创建或覆盖文件"),
            ToolDefinition::new("file_edit", "编辑文件的指定部分"),
            ToolDefinition::new("file_delete", "删除文件"),
            ToolDefinition::new("search_files", "搜索文件内容"),
            ToolDefinition::new("list_directory", "列出目录内容"),
            ToolDefinition::new("add_dependency", "添加项目依赖"),
            ToolDefinition::new("run_command", "执行 shell 命令"),
        ]
    }

    fn build_coding_system_prompt(&self, ctx: &AgentContext) -> String {
        let tech = ctx.project_ctx.as_ref()
            .map(|pc| format!("技术栈：{}\n语言：{}",
                pc.tech_stack.frameworks.join(", "), pc.tech_stack.primary_language))
            .unwrap_or_default();
        format!(
            r#"你是 MoreCode 系统的 Coder Agent。你是一位经验丰富的软件工程师。
{}
项目规范：遵循现有代码风格、添加错误处理、编写清晰注释、确保可编译可测试。
工具使用规则：修改前先读取、每次只修改一个文件、修改后验证语法。"#,
            tech
        )
    }

    fn build_coding_user_prompt(&self, ctx: &AgentContext) -> String {
        format!("## 任务\n{}\n\n## 项目上下文\n{}\n请使用工具完成代码修改。",
            ctx.task.description(),
            ctx.project_ctx.as_ref().map(|pc| pc.directory_structure.clone())
                .unwrap_or_else(|| "无".to_string()),
        )
    }

    fn build_preflight_system_prompt(&self) -> String {
        r#"
你是 MoreCode 系统的 Coder Agent（预飞检查模式）。生成详细执行计划。
输出格式要求（JSON）：
{
  "plan_description": "计划整体描述",
  "file_changes": [{"file_path": "", "change_type": "Create|Modify|Delete|Rename",
    "description": "", "estimated_lines_changed": 0}],
  "affected_modules": [],
  "identified_risks": [],
  "new_dependencies": [],
  "database_migrations": [],
  "api_changes": [{"method": "", "path": "", "change_type": "Add|Modify|Remove", "breaking": false}]
}
"#.to_string()
    }

    fn build_preflight_user_prompt(&self, ctx: &AgentContext) -> String {
        format!("请为以下任务生成预飞执行计划：\n## 任务描述\n{}\n## 项目信息\n{}",
            ctx.task.description(),
            ctx.project_ctx.as_ref().map(|pc| format!("根目录：{}", pc.root_path.display()))
                .unwrap_or_else(|| "无".to_string()),
        )
    }
}
```

### P4-3.4.2 预飞检查类型定义

```rust
/// 预飞计划 — Coder 在执行前生成的详细执行方案
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PreFlightPlan {
    pub plan_description: String,
    pub file_changes: Vec<PlannedFileChange>,
    pub affected_modules: Vec<String>,
    pub identified_risks: Vec<String>,
    pub new_dependencies: Vec<String>,
    pub database_migrations: Vec<String>,
    pub api_changes: Vec<ApiChange>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlannedFileChange {
    pub file_path: String,
    pub change_type: PlannedChangeType,
    pub description: String,
    pub estimated_lines_changed: u32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PlannedChangeType { Create, Modify, Delete, Rename }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiChange {
    pub method: String,
    pub path: String,
    pub change_type: ApiChangeType,
    pub breaking: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ApiChangeType { Add, Modify, Remove }
```

### P4-3.4.3 Caveat 约束类型

```rust
/// 注意事项/约束条件 — 由 Reviewer 预飞审查生成
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Caveat {
    pub category: CaveatCategory,
    pub priority: CaveatPriority,
    pub description: String,
    pub related_files: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CaveatCategory {
    EdgeCase, BackwardCompatibility, Performance, Security, Convention, Testing,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum CaveatPriority { Low, Medium, High }
```

### P4-3.4.4 Reviewer Agent

```rust
/// Reviewer Agent — 代码审查与预飞检查
pub struct Reviewer {
    config: AgentConfig,
}

impl Reviewer {
    pub fn new(config: AgentConfig) -> Self { Self { config } }
}

#[async_trait]
impl Agent for Reviewer {
    fn agent_type(&self) -> AgentType { AgentType::Reviewer }
    fn supports_streaming(&self) -> bool { true }
    fn default_config(&self) -> AgentConfig { AgentConfig::for_agent_type(AgentType::Reviewer) }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self, task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());
        if let Some(pc) = project_ctx { ctx.project_ctx = Some(Arc::new(pc)); }
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let mode = ctx.get_extra_param::<String>("review_mode")
            .unwrap_or_else(|| "standard".to_string());
        match mode.as_str() {
            "preflight" => self.execute_preflight_review(ctx).await,
            _ => self.execute_standard_review(ctx).await,
        }
    }
}

impl Reviewer {
    /// 预飞审查
    async fn execute_preflight_review(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let plan = ctx.handoff.get_with_fallback::<PreFlightPlan>().await
            .ok_or_else(|| AgentError::MissingContextData {
                data_type: "PreFlightPlan".to_string(),
            })?;

        let llm_request = LlmRequest::new(&self.build_preflight_system_prompt(),
            &self.build_preflight_user_prompt(&plan, ctx))
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(0.2)
            .with_max_tokens(4096)
            .with_response_format(ResponseFormat::Json);

        let response = ctx.llm_client.complete(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let review_result: PreFlightReviewResult = serde_json::from_str(&response.content)
            .map_err(|e| AgentError::LlmParseError {
                message: format!("Failed to parse PreFlightReviewResult: {}", e),
            })?;

        ctx.handoff.put(review_result.clone()).await;

        let result = serde_json::to_value(&review_result).map_err(|e| AgentError::Internal {
            message: format!("Failed to serialize: {}", e), source: None,
        })?;

        Ok(AgentExecutionReport::success(AgentType::Reviewer, ctx.execution_id, result))
    }

    /// 常规代码审查
    async fn execute_standard_review(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let llm_request = LlmRequest::new(&self.build_standard_system_prompt(),
            &self.build_standard_user_prompt(ctx))
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(0.2)
            .with_max_tokens(4096)
            .with_response_format(ResponseFormat::Json);

        let response = ctx.llm_client.complete(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let review_result: ReviewResult = serde_json::from_str(&response.content)
            .map_err(|e| AgentError::LlmParseError {
                message: format!("Failed to parse ReviewResult: {}", e),
            })?;

        let result = serde_json::to_value(&review_result).map_err(|e| AgentError::Internal {
            message: format!("Failed to serialize: {}", e), source: None,
        })?;

        Ok(AgentExecutionReport::success(AgentType::Reviewer, ctx.execution_id, result))
    }

    fn build_preflight_system_prompt(&self) -> String {
        r#"
你是 MoreCode 系统的 Reviewer Agent（预飞审查模式）。
审查维度：正确性、完整性、兼容性、安全性、最佳实践
输出格式要求（JSON）：
{
  "verdict": "Approved|NeedsAdjustment|Rejected",
  "feasibility": {
    "correctness": "Good|Acceptable|Concerning|Problematic",
    "completeness": "Good|Acceptable|Concerning|Problematic",
    "compatibility": "Good|Acceptable|Concerning|Problematic",
    "security": "Good|Acceptable|Concerning|Problematic",
    "notes": "总体评价"
  },
  "caveats": [{
    "category": "EdgeCase|BackwardCompatibility|Performance|Security|Convention|Testing",
    "priority": "High|Medium|Low",
    "description": "注意事项描述",
    "related_files": ["file1.rs"]
  }],
  "suggested_adjustments": ["调整建议1"]
}
"#.to_string()
    }

    fn build_preflight_user_prompt(&self, plan: &PreFlightPlan, ctx: &AgentContext) -> String {
        format!(
            r#"请审查以下预飞执行计划：
## 计划描述
{}
## 文件变更
{}
## 受影响模块
{}
## 已识别风险
{}
## 新依赖
{}
## 数据库迁移
{}
## API 变更
{}
## 项目上下文
{}
请从正确性、完整性、兼容性、安全性等维度进行审查。"#,
            plan.plan_description,
            plan.file_changes.iter().map(|fc|
                format!("- {} ({:?}): {}", fc.file_path, fc.change_type, fc.description)
            ).collect::<Vec<_>>().join("\n"),
            plan.affected_modules.join(", "),
            plan.identified_risks.join("\n"),
            plan.new_dependencies.join(", "),
            plan.database_migrations.join("\n"),
            plan.api_changes.iter().map(|ac|
                format!("- {} {} ({:?}, breaking={})", ac.method, ac.path, ac.change_type, ac.breaking)
            ).collect::<Vec<_>>().join("\n"),
            ctx.project_ctx.as_ref()
                .map(|pc| format!("技术栈：{}", pc.tech_stack.primary_language))
                .unwrap_or_else(|| "无".to_string()),
        )
    }

    fn build_standard_system_prompt(&self) -> String {
        r#"
你是 MoreCode 系统的 Reviewer Agent（常规审查模式）。
审查维度：代码质量、正确性、安全性、性能、测试覆盖
输出格式要求（JSON）：
{
  "issues": [{"severity": "High|Medium|Low", "file": "", "line": 0,
    "description": "", "suggestion": ""}],
  "suggestions": [{"file": "", "description": "", "code_example": ""}],
  "approved": true,
  "summary": "审查总结"
}
"#.to_string()
    }

    fn build_standard_user_prompt(&self, ctx: &AgentContext) -> String {
        format!("请审查以下代码变更：\n## 任务\n{}\n## 项目上下文\n{}",
            ctx.task.description(),
            ctx.project_ctx.as_ref()
                .map(|pc| pc.directory_structure.clone())
                .unwrap_or_else(|| "无".to_string()),
        )
    }
}
```

### P4-3.4.5 预飞审查结果类型

```rust
/// 预飞审查结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PreFlightReviewResult {
    /// 审查判定
    pub verdict: PreFlightVerdict,

    /// 可行性分析
    pub feasibility: FeasibilityAnalysis,

    /// 注意事项列表
    pub caveats: Vec<Caveat>,

    /// 建议调整
    pub suggested_adjustments: Vec<String>,
}

/// 预飞审查判定
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PreFlightVerdict {
    Approved,
    NeedsAdjustment,
    Rejected,
}

/// 可行性分析
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FeasibilityAnalysis {
    pub correctness: FeasibilityRating,
    pub completeness: FeasibilityRating,
    pub compatibility: FeasibilityRating,
    pub security: FeasibilityRating,
    pub notes: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FeasibilityRating {
    Good,
    Acceptable,
    Concerning,
    Problematic,
}

/// 常规审查结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReviewResult {
    pub issues: Vec<ReviewIssue>,
    pub suggestions: Vec<ReviewSuggestion>,
    pub approved: bool,
    pub summary: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReviewIssue {
    pub severity: IssueSeverity,
    pub file: String,
    pub line: Option<u32>,
    pub description: String,
    pub suggestion: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum IssueSeverity { Low, Medium, High }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReviewSuggestion {
    pub file: String,
    pub description: String,
    pub code_example: Option<String>,
}
```

### P4-3.4.6 Tester Agent

```rust
/// Tester Agent — 测试生成与执行
pub struct Tester {
    config: AgentConfig,
    test_runner: Arc<dyn TestRunner>,
}

impl Tester {
    pub fn new(config: AgentConfig, test_runner: Arc<dyn TestRunner>) -> Self {
        Self { config, test_runner }
    }
}

#[async_trait]
impl Agent for Tester {
    fn agent_type(&self) -> AgentType { AgentType::Tester }
    fn supports_streaming(&self) -> bool { true }
    fn default_config(&self) -> AgentConfig { AgentConfig::for_agent_type(AgentType::Tester) }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self, task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());
        if let Some(pc) = project_ctx { ctx.project_ctx = Some(Arc::new(pc)); }
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        // 步骤 1：生成测试代码
        let test_gen_result = self.generate_tests(ctx).await?;

        // 步骤 2：执行测试
        let test_exec_result = self.run_tests(ctx, &test_gen_result).await?;

        // 通过 handoff 传递测试结果
        ctx.handoff.put(test_exec_result.clone()).await;

        let result = serde_json::to_value(&test_exec_result).map_err(|e| AgentError::Internal {
            message: format!("Failed to serialize TestResult: {}", e), source: None,
        })?;

        Ok(AgentExecutionReport::success(AgentType::Tester, ctx.execution_id, result))
    }
}

/// 测试结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestResult {
    /// 生成的测试文件列表
    pub test_files: Vec<String>,

    /// 覆盖率估算（百分比）
    pub coverage_estimate: f64,

    /// 通过的测试数
    pub passed: u32,

    /// 失败的测试数
    pub failed: u32,

    /// 失败的测试详情
    pub failure_details: Vec<TestFailure>,

    /// 跳过的测试数
    pub skipped: u32,

    /// 总执行时间（毫秒）
    pub duration_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestFailure {
    pub test_name: String,
    pub file: String,
    pub error_message: String,
    pub expected: Option<String>,
    pub actual: Option<String>,
}

/// 测试生成结果
#[derive(Debug, Clone)]
struct TestGenResult {
    files_created: Vec<String>,
}

impl Tester {
    /// 生成测试代码
    async fn generate_tests(&self, ctx: &AgentContext) -> Result<TestGenResult, AgentError> {
        let system_prompt = self.build_test_gen_system_prompt(ctx);
        let user_prompt = self.build_test_gen_user_prompt(ctx);

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(ctx.config.llm_config.temperature)
            .with_max_tokens(ctx.config.llm_config.max_output_tokens)
            .with_tools(self.get_test_tools())
            .with_function_calling(true);

        let response = ctx.llm_client.complete_with_tools(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let files_created: Vec<String> = response.tool_calls.iter()
            .filter(|tc| tc.tool_name == "file_write")
            .filter_map(|tc| tc.input.get("path").and_then(|p| p.as_str()).map(String::from))
            .collect();

        Ok(TestGenResult { files_created })
    }

    /// 执行测试
    async fn run_tests(&self, ctx: &AgentContext, gen_result: &TestGenResult) -> Result<TestResult, AgentError> {
        if gen_result.files_created.is_empty() {
            return Ok(TestResult {
                test_files: vec![],
                coverage_estimate: 0.0,
                passed: 0, failed: 0, skipped: 0,
                failure_details: vec![],
                duration_ms: 0,
            });
        }

        let project_root = ctx.project_ctx.as_ref()
            .map(|pc| pc.root_path.clone())
            .ok_or_else(|| AgentError::MissingContextData {
                data_type: "ProjectContext.root_path".to_string(),
            })?;

        let run_result = self.test_runner.run(&project_root).await
            .map_err(|e| AgentError::ToolError {
                tool_name: "test_runner".to_string(),
                message: format!("Test execution failed: {}", e),
            })?;

        Ok(TestResult {
            test_files: gen_result.files_created.clone(),
            coverage_estimate: run_result.coverage_estimate,
            passed: run_result.passed,
            failed: run_result.failed,
            skipped: run_result.skipped,
            failure_details: run_result.failures.into_iter().map(|f| TestFailure {
                test_name: f.test_name,
                file: f.file,
                error_message: f.error_message,
                expected: f.expected,
                actual: f.actual,
            }).collect(),
            duration_ms: run_result.duration_ms,
        })
    }

    fn get_test_tools(&self) -> Vec<ToolDefinition> {
        vec![
            ToolDefinition::new("file_read", "读取源文件"),
            ToolDefinition::new("file_write", "创建测试文件"),
            ToolDefinition::new("search_files", "搜索代码模式"),
            ToolDefinition::new("list_directory", "列出目录"),
            ToolDefinition::new("run_command", "执行命令"),
        ]
    }

    fn build_test_gen_system_prompt(&self, ctx: &AgentContext) -> String {
        let framework = ctx.project_ctx.as_ref()
            .and_then(|pc| pc.tech_stack.frameworks.first())
            .map(|f| format!("测试框架：基于 {} 生态", f))
            .unwrap_or_else(|| "测试框架：根据项目语言自动选择".to_string());

        format!(
            r#"你是 MoreCode 系统的 Tester Agent。生成高质量的单元测试和集成测试。
{}
测试编写原则：
- 覆盖正常路径和边界情况
- 使用描述性的测试名称
- 遵循 AAA 模式（Arrange-Act-Assert）
- Mock 外部依赖
- 每个测试文件对应一个源文件"#,
            framework
        )
    }

    fn build_test_gen_user_prompt(&self, ctx: &AgentContext) -> String {
        format!("## 任务\n{}\n## 项目上下文\n{}\n请生成测试代码。",
            ctx.task.description(),
            ctx.project_ctx.as_ref().map(|pc| pc.directory_structure.clone())
                .unwrap_or_else(|| "无".to_string()),
        )
    }
}
```

---

## P4-3.5 功能需求清单

### FR-P4-3.01 Coder

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-3.01-01 | 支持代码编写（新文件创建、现有文件修改） | P0 |
| FR-P4-3.01-02 | 支持依赖添加和配置修改 | P0 |
| FR-P4-3.01-03 | 预飞检查模式：生成 PreFlightPlan | P0 |
| FR-P4-3.01-04 | 预飞检查适用条件判断（任务类型/文件数/复杂度/风险） | P0 |
| FR-P4-3.01-05 | 预飞审查通过后注入 Caveat 执行 | P0 |
| FR-P4-3.01-06 | 预飞审查需调整时自动重试（最多 2 轮） | P0 |
| FR-P4-3.01-07 | 预飞审查拒绝时中止执行并返回失败 | P0 |
| FR-P4-3.01-08 | 直接执行模式（无预飞检查） | P0 |
| FR-P4-3.01-09 | 通过工具调用完成文件操作 | P0 |
| FR-P4-3.01-10 | 收集并报告文件变更记录 | P1 |

### FR-P4-3.02 Reviewer

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-3.02-01 | 预飞审查：评估 PreFlightPlan 可行性 | P0 |
| FR-P4-3.02-02 | 预飞审查：输出 PreFlightVerdict（Approved/NeedsAdjustment/Rejected） | P0 |
| FR-P4-3.02-03 | 预飞审查：输出 FeasibilityAnalysis（多维度评分） | P0 |
| FR-P4-3.02-04 | 预飞审查：生成 Caveat 列表 | P0 |
| FR-P4-3.02-05 | 预飞审查：提供调整建议 | P1 |
| FR-P4-3.02-06 | 常规审查：输出 ReviewResult（issues + suggestions + approved） | P0 |
| FR-P4-3.02-07 | 审查模式通过 extra_params 切换 | P0 |

### FR-P4-3.03 Tester

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-3.03-01 | 根据源代码生成测试文件 | P0 |
| FR-P4-3.03-02 | 执行测试并收集结果 | P0 |
| FR-P4-3.03-03 | 输出 TestResult（passed/failed/coverage） | P0 |
| FR-P4-3.03-04 | 记录测试失败详情（test_name/error/expected/actual） | P0 |
| FR-P4-3.03-05 | 自动选择测试框架（基于项目技术栈） | P1 |

---

## P4-3.6 接口契约

### IC-P4-3.01 Coder 契约

```
预飞检查流程契约：
  1. should_preflight 返回 true 时进入预飞模式
  2. 生成 PreFlightPlan（包含 file_changes、api_changes 等）
  3. 通过 handoff 传递给 Reviewer
  4. Reviewer 返回 PreFlightReviewResult
  5. Approved → execute_with_caveats
  6. NeedsAdjustment → adjust_and_retry（最多 2 轮）
  7. Rejected → 返回失败报告

直接执行契约：
  - 使用 LLM + 工具调用完成文件修改
  - 收集 tool_calls 中的文件变更记录

适用条件契约：
  - 任务类型为 CodeModification/FeatureAddition/Refactoring
  - 文件数 >= 3 或复杂度 >= Moderate 或风险等级 >= High
  - 满足任一条件即触发预飞检查
```

### IC-P4-3.02 Reviewer 契约

```
预飞审查契约：
  - 从 handoff 获取 PreFlightPlan
  - 输出 PreFlightReviewResult
  - verdict 必须为 Approved/NeedsAdjustment/Rejected 之一
  - feasibility 各维度必须为 Good/Acceptable/Concerning/Problematic 之一
  - 通过 handoff 传递结果

常规审查契约：
  - 输出 ReviewResult
  - issues 包含 severity（High/Medium/Low）
  - approved 为布尔值
```

### IC-P4-3.03 Tester 契约

```
测试生成契约：
  - 根据项目技术栈选择测试框架
  - 生成的测试文件路径可追踪

测试执行契约：
  - 在项目根目录下执行测试
  - 收集 passed/failed/skipped 计数
  - 记录失败测试的详细信息
  - 输出 TestResult 通过 handoff 传递
```

---

## P4-3.7 测试要点

```rust
#[cfg(test)]
mod execution_tests {
    // TP-P4-3.01-01: Coder 预飞检查触发条件
    #[test]
    fn test_coder_preflight_trigger_by_file_count() {
        let coder = Coder::new(
            AgentConfig::for_agent_type(AgentType::Coder),
            create_test_file_tool(), create_test_dep_tool(),
        );
        let ctx = create_test_context_with_plan(5); // 5 个文件
        assert!(coder.should_preflight(&ctx));
    }

    // TP-P4-3.01-02: Coder 预飞检查不触发（简单任务）
    #[test]
    fn test_coder_preflight_skip_simple_task() {
        let coder = Coder::new(
            AgentConfig::for_agent_type(AgentType::Coder),
            create_test_file_tool(), create_test_dep_tool(),
        );
        let ctx = create_test_context_simple();
        assert!(!coder.should_preflight(&ctx));
    }

    // TP-P4-3.01-03: Coder 预飞检查不触发（文档任务）
    #[test]
    fn test_coder_preflight_skip_doc_task() {
        let coder = Coder::new(
            AgentConfig::for_agent_type(AgentType::Coder),
            create_test_file_tool(), create_test_dep_tool(),
        );
        let ctx = create_test_context_doc_task();
        assert!(!coder.should_preflight(&ctx));
    }

    // TP-P4-3.02-01: Reviewer 预飞审查模式切换
    #[tokio::test]
    async fn test_reviewer_preflight_mode() {
        let reviewer = Reviewer::new(AgentConfig::for_agent_type(AgentType::Reviewer));
        let mut ctx = create_test_context();
        ctx.extra_params.insert(
            "review_mode".to_string(), serde_json::json!("preflight"),
        );
        // 验证 execute 会调用 execute_preflight_review
        // (需要 mock LLM 返回)
    }

    // TP-P4-3.02-02: Reviewer 常规审查模式
    #[tokio::test]
    async fn test_reviewer_standard_mode() {
        let reviewer = Reviewer::new(AgentConfig::for_agent_type(AgentType::Reviewer));
        let ctx = create_test_context();
        // 默认模式为 standard
    }

    // TP-P4-3.03-01: Tester 测试生成
    #[tokio::test]
    async fn test_tester_generate_tests() {
        let tester = Tester::new(
            AgentConfig::for_agent_type(AgentType::Tester),
            create_test_runner(),
        );
        let ctx = create_test_context();
        let result = tester.execute(&ctx).await;
        assert!(result.is_ok());
    }

    // TP-P4-3.03-02: Tester 空测试文件
    #[tokio::test]
    async fn test_tester_no_files() {
        let tester = Tester::new(
            AgentConfig::for_agent_type(AgentType::Tester),
            create_test_runner(),
        );
        let ctx = create_test_context();
        let result = tester.execute(&ctx).await.unwrap();
        // 验证 TestResult 结构完整
    }
}
```

---

# P4-4 专项 Agent（Research + DocWriter + Debugger）

## P4-4.1 模块概述

专项 Agent 是 MoreCode 系统的"专家顾问"，提供特定领域的高级能力。它们在认知层和执行层之外独立运作，按需被调度以完成专项任务。

### 三个专项 Agent

| Agent | 职责 | supports_recursion | supports_parallel |
|-------|------|--------------------|--------------------|
| Research | 外部调研、技术选型、API 文档查阅 | true | true |
| DocWriter | 文档生成、README、API 文档 | false | true |
| Debugger | 错误诊断、日志分析、修复建议 | true | true |

### 模块边界

```
mc-agent/specialized/
├── mod.rs
├── research/
│   ├── mod.rs
│   └── research.rs
├── doc_writer/
│   ├── mod.rs
│   └── doc_writer.rs
└── debugger/
    ├── mod.rs
    └── debugger.rs
```

---

## P4-4.2 架构文档引用

| 引用文档 | 相关章节 | 关联说明 |
|---------|---------|---------|
| `05-专项能力Agent.md` | 全文 | 专项 Agent 的设计原则、能力边界、调度策略 |

---

## P4-4.3 大模型开发提示词

```
你是一位精通 Rust 和 AI Agent 架构的高级工程师。请实现 MoreCode 系统的专项 Agent，
包括 Research、DocWriter 和 Debugger。

设计约束：
1. Research Agent 支持递归调用（可以启动子调研任务）
2. Debugger Agent 支持递归和并行（可以同时分析多个错误）
3. DocWriter 支持并行（可以同时生成多个文档文件）
4. Research Agent 需要访问外部工具（WebSearch、WebFetch、APIDocReader）
5. Debugger Agent 需要访问日志工具、错误堆栈分析工具
6. DocWriter 需要访问文件写入工具、模板引擎

Research 关键设计：
- 支持多轮调研（递归调用自身深化分析）
- 输出结构化的 ResearchReport（findings、recommendations、sources）
- 支持技术选型对比分析
- 支持 API 文档查阅和摘要生成

DocWriter 关键设计：
- 支持多种文档类型（README、API 文档、CHANGELOG、贡献指南）
- 基于项目上下文自动生成文档内容
- 支持文档模板定制
- 输出 Documentation（files_created、content_summary）

Debugger 关键设计：
- 支持错误堆栈分析
- 支持日志模式识别
- 支持修复建议生成
- 输出 FixReport（root_cause、fix_suggestion、verified）
```

---

## P4-4.4 核心类型定义

### P4-4.4.1 Research Agent

```rust
/// Research Agent — 外部调研、技术选型、API 文档查阅
///
/// supports_recursion: true — 可以启动子调研任务深化分析
/// supports_parallel: true — 可以并行执行多个调研方向
pub struct Research {
    config: AgentConfig,
    web_search: Arc<dyn WebSearchTool>,
    web_fetch: Arc<dyn WebFetchTool>,
    api_doc_reader: Arc<dyn ApiDocReader>,
}

impl Research {
    pub fn new(
        config: AgentConfig,
        web_search: Arc<dyn WebSearchTool>,
        web_fetch: Arc<dyn WebFetchTool>,
        api_doc_reader: Arc<dyn ApiDocReader>,
    ) -> Self {
        Self { config, web_search, web_fetch, api_doc_reader }
    }
}

#[async_trait]
impl Agent for Research {
    fn agent_type(&self) -> AgentType { AgentType::Research }
    fn supports_recursion(&self) -> bool { true }
    fn supports_parallel(&self) -> bool { true }
    fn supports_streaming(&self) -> bool { true }
    fn default_config(&self) -> AgentConfig { AgentConfig::for_agent_type(AgentType::Research) }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self, task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());
        if let Some(pc) = project_ctx { ctx.project_ctx = Some(Arc::new(pc)); }
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let system_prompt = self.build_system_prompt();
        let user_prompt = self.build_user_prompt(ctx);

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(ctx.config.llm_config.temperature)
            .with_max_tokens(ctx.config.llm_config.max_output_tokens)
            .with_tools(self.get_research_tools())
            .with_function_calling(true);

        let response = ctx.llm_client.complete_with_tools(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let research_report: ResearchReport = serde_json::from_str(&response.content)
            .map_err(|e| AgentError::LlmParseError {
                message: format!("Failed to parse ResearchReport: {}", e),
            })?;

        ctx.handoff.put(research_report.clone()).await;

        let result = serde_json::to_value(&research_report).map_err(|e| AgentError::Internal {
            message: format!("Failed to serialize: {}", e), source: None,
        })?;

        Ok(AgentExecutionReport::success(AgentType::Research, ctx.execution_id, result))
    }
}

/// 调研报告
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResearchReport {
    /// 调研发现
    pub findings: Vec<ResearchFinding>,

    /// 建议
    pub recommendations: Vec<String>,

    /// 信息来源
    pub sources: Vec<ResearchSource>,

    /// 调研摘要
    pub summary: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResearchFinding {
    pub topic: String,
    pub description: String,
    pub details: String,
    pub confidence: f64,
    pub related_findings: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResearchSource {
    pub url: String,
    pub title: String,
    pub retrieved_at: chrono::DateTime<chrono::Utc>,
    pub relevance: f64,
}

impl Research {
    fn get_research_tools(&self) -> Vec<ToolDefinition> {
        vec![
            ToolDefinition::new("web_search", "搜索互联网"),
            ToolDefinition::new("web_fetch", "获取网页内容"),
            ToolDefinition::new("api_doc_read", "读取 API 文档"),
            ToolDefinition::new("file_read", "读取本地文件"),
        ]
    }

    fn build_system_prompt(&self) -> String {
        r#"
你是 MoreCode 系统的 Research Agent。你是一位资深的技术调研专家。
职责：外部调研、技术选型、API 文档查阅、最佳实践分析。
输出格式要求（JSON）：
{
  "findings": [{"topic": "", "description": "", "details": "",
    "confidence": 0.9, "related_findings": []}],
  "recommendations": ["建议1"],
  "sources": [{"url": "", "title": "", "retrieved_at": "", "relevance": 0.9}],
  "summary": "调研摘要"
}
调研原则：
- 优先使用权威来源（官方文档、RFC、知名技术博客）
- 标注信息来源和可信度
- 提供对比分析（如技术选型）
- 给出明确的建议和理由
"#.to_string()
    }

    fn build_user_prompt(&self, ctx: &AgentContext) -> String {
        format!("## 调研任务\n{}\n## 项目上下文\n{}",
            ctx.task.description(),
            ctx.project_ctx.as_ref()
                .map(|pc| format!("技术栈：{}", pc.tech_stack.primary_language))
                .unwrap_or_else(|| "无".to_string()),
        )
    }
}
```

### P4-4.4.2 DocWriter Agent

```rust
/// DocWriter Agent — 文档生成、README、API 文档
///
/// supports_parallel: true — 可以并行生成多个文档文件
pub struct DocWriter {
    config: AgentConfig,
    template_engine: Arc<dyn TemplateEngine>,
}

impl DocWriter {
    pub fn new(config: AgentConfig, template_engine: Arc<dyn TemplateEngine>) -> Self {
        Self { config, template_engine }
    }
}

#[async_trait]
impl Agent for DocWriter {
    fn agent_type(&self) -> AgentType { AgentType::DocWriter }
    fn supports_parallel(&self) -> bool { true }
    fn supports_streaming(&self) -> bool { true }
    fn default_config(&self) -> AgentConfig { AgentConfig::for_agent_type(AgentType::DocWriter) }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self, task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());
        if let Some(pc) = project_ctx { ctx.project_ctx = Some(Arc::new(pc)); }
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        let system_prompt = self.build_system_prompt(ctx);
        let user_prompt = self.build_user_prompt(ctx);

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(ctx.config.llm_config.temperature)
            .with_max_tokens(ctx.config.llm_config.max_output_tokens)
            .with_tools(self.get_doc_tools())
            .with_function_calling(true);

        let response = ctx.llm_client.complete_with_tools(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let files_created: Vec<String> = response.tool_calls.iter()
            .filter(|tc| tc.tool_name == "file_write")
            .filter_map(|tc| tc.input.get("path").and_then(|p| p.as_str()).map(String::from))
            .collect();

        let content_summary = files_created.iter()
            .map(|f| format!("- {}", f))
            .collect::<Vec<_>>()
            .join("\n");

        let documentation = Documentation {
            files_created,
            content_summary,
        };

        ctx.handoff.put(documentation.clone()).await;

        let result = serde_json::to_value(&documentation).map_err(|e| AgentError::Internal {
            message: format!("Failed to serialize: {}", e), source: None,
        })?;

        Ok(AgentExecutionReport::success(AgentType::DocWriter, ctx.execution_id, result))
    }
}

/// 文档输出
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Documentation {
    /// 创建的文件列表
    pub files_created: Vec<String>,

    /// 内容摘要
    pub content_summary: String,
}

impl DocWriter {
    fn get_doc_tools(&self) -> Vec<ToolDefinition> {
        vec![
            ToolDefinition::new("file_read", "读取源文件"),
            ToolDefinition::new("file_write", "创建文档文件"),
            ToolDefinition::new("search_files", "搜索代码注释"),
            ToolDefinition::new("list_directory", "列出目录结构"),
        ]
    }

    fn build_system_prompt(&self, ctx: &AgentContext) -> String {
        let lang = ctx.project_ctx.as_ref()
            .map(|pc| pc.tech_stack.primary_language.as_str())
            .unwrap_or("通用");

        format!(
            r#"你是 MoreCode 系统的 DocWriter Agent。你是一位技术文档专家。
当前项目语言：{}
支持的文档类型：README、API 文档、CHANGELOG、贡献指南、架构文档
文档编写原则：
- 使用清晰简洁的语言
- 包含代码示例
- 保持文档结构一致
- 使用 Markdown 格式
- 适配目标受众（开发者/用户/贡献者）
"#, lang)
    }

    fn build_user_prompt(&self, ctx: &AgentContext) -> String {
        format!("## 文档任务\n{}\n## 项目上下文\n{}",
            ctx.task.description(),
            ctx.project_ctx.as_ref()
                .map(|pc| pc.directory_structure.clone())
                .unwrap_or_else(|| "无".to_string()),
        )
    }
}
```

### P4-4.4.3 Debugger Agent

```rust
/// Debugger Agent — 错误诊断、日志分析、修复建议
///
/// supports_recursion: true — 可以递归分析嵌套错误
/// supports_parallel: true — 可以并行分析多个错误
pub struct Debugger {
    config: AgentConfig,
    log_analyzer: Arc<dyn LogAnalyzer>,
    stack_trace_parser: Arc<dyn StackTraceParser>,
}

impl Debugger {
    pub fn new(
        config: AgentConfig,
        log_analyzer: Arc<dyn LogAnalyzer>,
        stack_trace_parser: Arc<dyn StackTraceParser>,
    ) -> Self {
        Self { config, log_analyzer, stack_trace_parser }
    }
}

#[async_trait]
impl Agent for Debugger {
    fn agent_type(&self) -> AgentType { AgentType::Debugger }
    fn supports_recursion(&self) -> bool { true }
    fn supports_parallel(&self) -> bool { true }
    fn supports_streaming(&self) -> bool { true }
    fn default_config(&self) -> AgentConfig { AgentConfig::for_agent_type(AgentType::Debugger) }
    fn update_config(&mut self, config: AgentConfig) { self.config = config; }

    async fn build_context(
        &self, task: &TaskDescription,
        project_ctx: Option<ProjectContext>,
        shared: &SharedResources,
    ) -> Result<AgentContext, AgentError> {
        let mut ctx = AgentContext::new(task.clone(), shared, self.config.clone());
        if let Some(pc) = project_ctx { ctx.project_ctx = Some(Arc::new(pc)); }
        Ok(ctx)
    }

    async fn execute(&self, ctx: &AgentContext) -> Result<AgentExecutionReport, AgentError> {
        // 步骤 1：分析错误信息
        let error_analysis = self.analyze_error(ctx).await?;

        // 步骤 2：生成修复建议
        let fix_suggestion = self.generate_fix(ctx, &error_analysis).await?;

        // 步骤 3：尝试验证修复（可选）
        let verified = self.verify_fix(ctx, &fix_suggestion).await.unwrap_or(false);

        let fix_report = FixReport {
            root_cause: error_analysis.root_cause,
            error_type: error_analysis.error_type,
            affected_files: error_analysis.affected_files,
            fix_suggestion,
            verified,
            confidence: error_analysis.confidence,
        };

        ctx.handoff.put(fix_report.clone()).await;

        let result = serde_json::to_value(&fix_report).map_err(|e| AgentError::Internal {
            message: format!("Failed to serialize: {}", e), source: None,
        })?;

        Ok(AgentExecutionReport::success(AgentType::Debugger, ctx.execution_id, result))
    }
}

/// 修复报告
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FixReport {
    /// 根本原因
    pub root_cause: String,

    /// 错误类型
    pub error_type: ErrorType,

    /// 受影响的文件
    pub affected_files: Vec<String>,

    /// 修复建议
    pub fix_suggestion: FixSuggestion,

    /// 是否已验证
    pub verified: bool,

    /// 置信度（0.0 ~ 1.0）
    pub confidence: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ErrorType {
    SyntaxError,
    TypeError,
    LogicError,
    RuntimeError,
    ConfigurationError,
    DependencyError,
    ConcurrencyError,
    Unknown,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FixSuggestion {
    /// 修复描述
    pub description: String,

    /// 需要修改的文件及具体变更
    pub changes: Vec<SuggestedChange>,

    /// 修复步骤
    pub steps: Vec<String>,

    /// 预防措施
    pub prevention: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SuggestedChange {
    pub file: String,
    pub change_type: String,
    pub description: String,
    pub code_diff: Option<String>,
}

/// 错误分析中间结果
#[derive(Debug, Clone)]
struct ErrorAnalysis {
    root_cause: String,
    error_type: ErrorType,
    affected_files: Vec<String>,
    confidence: f64,
}

impl Debugger {
    /// 分析错误信息
    async fn analyze_error(&self, ctx: &AgentContext) -> Result<ErrorAnalysis, AgentError> {
        let system_prompt = r#"
你是 MoreCode 系统的 Debugger Agent（错误分析阶段）。
分析错误信息，识别根本原因、错误类型和受影响文件。
输出格式要求（JSON）：
{
  "root_cause": "根本原因描述",
  "error_type": "SyntaxError|TypeError|LogicError|RuntimeError|ConfigurationError|DependencyError|ConcurrencyError|Unknown",
  "affected_files": ["file1.rs"],
  "confidence": 0.9,
  "analysis_details": "详细分析过程"
}
"#.to_string();

        let user_prompt = format!("## 错误信息\n{}\n## 项目上下文\n{}",
            ctx.task.description(),
            ctx.project_ctx.as_ref()
                .map(|pc| pc.directory_structure.clone())
                .unwrap_or_else(|| "无".to_string()),
        );

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(0.2)
            .with_max_tokens(4096)
            .with_response_format(ResponseFormat::Json);

        let response = ctx.llm_client.complete(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        let parsed: serde_json::Value = serde_json::from_str(&response.content)
            .map_err(|e| AgentError::LlmParseError {
                message: format!("Failed to parse error analysis: {}", e),
            })?;

        Ok(ErrorAnalysis {
            root_cause: parsed["root_cause"].as_str().unwrap_or("Unknown").to_string(),
            error_type: parsed["error_type"].as_str()
                .and_then(|s| serde_json::from_value(serde_json::json!(s)).ok())
                .unwrap_or(ErrorType::Unknown),
            affected_files: parsed["affected_files"].as_array()
                .map(|arr| arr.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                .unwrap_or_default(),
            confidence: parsed["confidence"].as_f64().unwrap_or(0.5),
        })
    }

    /// 生成修复建议
    async fn generate_fix(&self, ctx: &AgentContext, analysis: &ErrorAnalysis) -> Result<FixSuggestion, AgentError> {
        let system_prompt = r#"
你是 MoreCode 系统的 Debugger Agent（修复建议阶段）。
基于错误分析结果，生成具体的修复方案。
输出格式要求（JSON）：
{
  "description": "修复方案描述",
  "changes": [{"file": "", "change_type": "", "description": "", "code_diff": ""}],
  "steps": ["步骤1"],
  "prevention": ["预防措施1"]
}
"#.to_string();

        let analysis_json = serde_json::to_string(analysis).unwrap_or_default();
        let user_prompt = format!(
            "## 错误分析\n{}\n## 项目上下文\n{}\n请生成修复方案。",
            analysis_json,
            ctx.project_ctx.as_ref()
                .map(|pc| pc.directory_structure.clone())
                .unwrap_or_else(|| "无".to_string()),
        );

        let llm_request = LlmRequest::new(&system_prompt, &user_prompt)
            .with_model(&ctx.config.llm_config.model_id)
            .with_temperature(0.2)
            .with_max_tokens(4096)
            .with_response_format(ResponseFormat::Json);

        let response = ctx.llm_client.complete(llm_request).await
            .map_err(|e| AgentError::LlmError { message: e.to_string(), source: None })?;

        serde_json::from_str(&response.content).map_err(|e| AgentError::LlmParseError {
            message: format!("Failed to parse fix suggestion: {}", e),
        })
    }

    /// 验证修复（可选）
    async fn verify_fix(&self, ctx: &AgentContext, fix: &FixSuggestion) -> Result<bool, AgentError> {
        // 如果有测试运行器，尝试运行相关测试
        if fix.changes.is_empty() {
            return Ok(false);
        }
        // 简单验证：检查建议的文件是否存在
        if let Some(pc) = &ctx.project_ctx {
            for change in &fix.changes {
                let file_path = pc.root_path.join(&change.file);
                if !file_path.exists() {
                    return Ok(false);
                }
            }
        }
        Ok(true)
    }
}
```

---

## P4-4.5 功能需求清单

### FR-P4-4.01 Research

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-4.01-01 | 支持互联网搜索调研 | P0 |
| FR-P4-4.01-02 | 支持网页内容获取和摘要 | P0 |
| FR-P4-4.01-03 | 支持 API 文档查阅 | P0 |
| FR-P4-4.01-04 | 输出结构化 ResearchReport | P0 |
| FR-P4-4.01-05 | 标注信息来源和可信度 | P1 |
| FR-P4-4.01-06 | supports_recursion: true（支持递归深化调研） | P0 |
| FR-P4-4.01-07 | supports_parallel: true（支持并行调研方向） | P1 |

### FR-P4-4.02 DocWriter

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-4.02-01 | 支持生成 README 文档 | P0 |
| FR-P4-4.02-02 | 支持 API 文档生成 | P0 |
| FR-P4-4.02-03 | 支持 CHANGELOG 生成 | P1 |
| FR-P4-4.02-04 | 基于项目上下文自动生成内容 | P0 |
| FR-P4-4.02-05 | 输出 Documentation（files_created + content_summary） | P0 |
| FR-P4-4.02-06 | supports_parallel: true（并行生成多个文档） | P1 |

### FR-P4-4.03 Debugger

| 需求 ID | 描述 | 优先级 |
|---------|------|--------|
| FR-P4-4.03-01 | 分析错误信息，识别根本原因 | P0 |
| FR-P4-4.03-02 | 识别错误类型（Syntax/Type/Logic/Runtime 等） | P0 |
| FR-P4-4.03-03 | 生成修复建议（FixSuggestion） | P0 |
| FR-P4-4.03-04 | 输出 FixReport（root_cause + fix_suggestion + verified） | P0 |
| FR-P4-4.03-05 | supports_recursion: true（递归分析嵌套错误） | P0 |
| FR-P4-4.03-06 | supports_parallel: true（并行分析多个错误） | P1 |
| FR-P4-4.03-07 | 修复验证（可选） | P2 |

---

## P4-4.6 接口契约

### IC-P4-4.01 Research 契约

```
前置条件：无特殊前置条件（不依赖 ProjectContext）
execute：输出 ResearchReport
  - findings：调研发现列表（含 topic、description、confidence）
  - recommendations：建议列表
  - sources：信息来源列表（含 url、title、relevance）
  - summary：调研摘要
通过 handoff.put(ResearchReport) 传递
```

### IC-P4-4.02 DocWriter 契约

```
前置条件：ctx.project_ctx 建议提供（用于生成项目相关文档）
execute：输出 Documentation
  - files_created：创建的文档文件路径列表
  - content_summary：内容摘要
通过 handoff.put(Documentation) 传递
```

### IC-P4-4.03 Debugger 契约

```
前置条件：ctx.task 包含错误信息（错误堆栈、日志片段等）
execute：三阶段执行
  1. analyze_error → ErrorAnalysis（root_cause、error_type、confidence）
  2. generate_fix → FixSuggestion（description、changes、steps、prevention）
  3. verify_fix → bool（可选验证）
输出 FixReport 通过 handoff.put(FixReport) 传递
```

---

## P4-4.7 测试要点

```rust
#[cfg(test)]
mod specialized_tests {
    // TP-P4-4.01-01: Research 能力声明
    #[test]
    fn test_research_capabilities() {
        let research = Research::new(
            AgentConfig::for_agent_type(AgentType::Research),
            create_test_web_search(), create_test_web_fetch(), create_test_api_doc_reader(),
        );
        let caps = research.capabilities();
        assert!(caps.supports_recursion);
        assert!(caps.supports_parallel);
        assert!(caps.supports_streaming);
    }

    // TP-P4-4.01-02: Research 执行
    #[tokio::test]
    async fn test_research_execute() {
        let research = Research::new(
            AgentConfig::for_agent_type(AgentType::Research),
            create_test_web_search(), create_test_web_fetch(), create_test_api_doc_reader(),
        );
        let ctx = create_test_context();
        let result = research.execute(&ctx).await;
        assert!(result.is_ok());
    }

    // TP-P4-4.02-01: DocWriter 能力声明
    #[test]
    fn test_doc_writer_capabilities() {
        let doc_writer = DocWriter::new(
            AgentConfig::for_agent_type(AgentType::DocWriter),
            create_test_template_engine(),
        );
        let caps = doc_writer.capabilities();
        assert!(!caps.supports_recursion);
        assert!(caps.supports_parallel);
    }

    // TP-P4-4.02-02: DocWriter 执行
    #[tokio::test]
    async fn test_doc_writer_execute() {
        let doc_writer = DocWriter::new(
            AgentConfig::for_agent_type(AgentType::DocWriter),
            create_test_template_engine(),
        );
        let ctx = create_test_context();
        let result = doc_writer.execute(&ctx).await;
        assert!(result.is_ok());
    }

    // TP-P4-4.03-01: Debugger 能力声明
    #[test]
    fn test_debugger_capabilities() {
        let debugger = Debugger::new(
            AgentConfig::for_agent_type(AgentType::Debugger),
            create_test_log_analyzer(), create_test_stack_parser(),
        );
        let caps = debugger.capabilities();
        assert!(caps.supports_recursion);
        assert!(caps.supports_parallel);
    }

    // TP-P4-4.03-02: Debugger 执行
    #[tokio::test]
    async fn test_debugger_execute() {
        let debugger = Debugger::new(
            AgentConfig::for_agent_type(AgentType::Debugger),
            create_test_log_analyzer(), create_test_stack_parser(),
        );
        let ctx = create_test_context_with_error();
        let result = debugger.execute(&ctx).await;
        assert!(result.is_ok());
    }

    // TP-P4-4.03-03: Debugger FixReport 结构验证
    #[tokio::test]
    async fn test_debugger_fix_report_structure() {
        let debugger = Debugger::new(
            AgentConfig::for_agent_type(AgentType::Debugger),
            create_test_log_analyzer(), create_test_stack_parser(),
        );
        let ctx = create_test_context_with_error();
        let report = debugger.execute(&ctx).await.unwrap();
        let result = report.result.unwrap();
        assert!(result.get("root_cause").is_some());
        assert!(result.get("fix_suggestion").is_some());
        assert!(result.get("verified").is_some());
        assert!(result.get("confidence").is_some());
    }
}
```

---

> **文档结束** — MoreCode 开发需求文档 Part 4: Agent 实现层