# MoreCode Agent — 开发需求文档 Part 5

> **版本**：v1.0
> **日期**：2026-04-17
> **范围**：P5 编排与递归层 + P6 高级模式层 + P7 集成与入口
> **定位**：递归编排引擎（mc-recursive）、协调器（mc-coordinator）、Daemon 模式（mc-daemon）、终端界面（mc-tui）、CLI 入口（mc-cli）、端到端集成测试

---

## 目录

- [P5-1 mc-recursive 递归编排引擎](#p5-1-mc-recursive-递归编排引擎)
- [P5-2 mc-coordinator 协调器](#p5-2-mc-coordinator-协调器)
- [P6-1 mc-daemon Daemon 模式](#p6-1-mc-daemon-daemon-模式)
- [P6-2 mc-tui 终端界面](#p6-2-mc-tui-终端界面)
- [P7-1 mc-cli CLI 入口](#p7-1-mc-cli-cli-入口)
- [P7-2 端到端集成测试](#p7-2-端到端集成测试)

---

# P5-1 mc-recursive 递归编排引擎

## P5-1 模块概述

`mc-recursive` 是递归编排引擎，实现 Map-Filter-Reduce 三阶段并行执行模式。任何 Agent 都可以临时成为"迷你协调器"，将自身任务拆分给子 Agent 并行执行。核心优势在于上下文隔离（每个子 Agent 独立构建上下文窗口）、并行加速（多个子 Agent 同时执行）、质量提升（每个子 Agent 聚焦单一方向）和 Token 节省（通过筛选压缩避免上下文爆炸）。

递归编排不是无限制的——系统通过递归深度限制（最多 2-3 层）和子 Agent 禁止再递归（除非特别复杂）来防止失控。简单场景使用并行执行，复杂场景才启用递归拆分。

**Crate 路径**：`crates/mc-recursive/`

**依赖关系**：
- 依赖 `mc-core`（核心类型：AgentType、TokenUsage、TaskId）
- 依赖 `mc-llm`（LLM 调用，用于 Filter/Reduce 阶段）
- 依赖 `mc-context`（子 Agent 上下文构建）
- 被依赖：`mc-coordinator`、`mc-agent`

## P5-1 架构文档引用

- **主文档**：`17-递归编排模式.md`（全文）——递归编排的核心思想、Map-Filter-Reduce 范式、各 Agent 递归场景、上下文隔离规则、代码阅读递归编排、按需展开策略、Rust 代码实现

## P5-1 大模型开发提示词

```
你正在实现 MoreCode Agent 系统的递归编排引擎（mc-recursive crate）。

核心职责：
1. 实现 Map-Filter-Reduce 三阶段并行执行模式
2. 管理子 Agent 的创建、执行和结果聚合
3. 通过 FilterStrategy 对子 Agent 结果进行筛选去噪
4. 通过 TokenBudgetAllocator 在父子 Agent 间分配 Token 预算
5. 通过 ResourceLimiter 防止递归失控

关键设计约束：
- 子 Agent 之间完全隔离，彼此不知道对方的存在
- 每个子 Agent 只获得与自身焦点相关的文件和上下文（最小注入原则）
- 递归深度最多 3 层（默认 2 层），超过则拒绝
- 单层子 Agent 最多 5 个，全局 Agent 总数最多 20 个
- 所有子 Agent Token 预算之和不超过父 Agent 预算的 80%
- 父 Agent 的 CancellationToken 必须传播到所有子任务
- 简单场景（1-2 个子任务）使用并行执行，复杂场景（3+ 个子任务）使用递归

参考架构文档：17-递归编排模式.md
```

## P5-1 核心类型定义

### RecursiveConfig

```rust
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::{Duration, Instant};

use anyhow::{Context, Result};
use regex::Regex;
use serde::{Deserialize, Serialize};
use tokio::sync::Mutex;
use tokio::task::JoinSet;
use tokio_util::sync::CancellationToken;

use mc_core::agent::AgentType;
use mc_core::token::TokenUsage;

/// 递归编排配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecursiveConfig {
    /// 单层最大子 Agent 数量（默认 5）
    #[serde(default = "default_max_sub_agents")]
    pub max_sub_agents: usize,

    /// 最大递归深度（默认 2，最大 3）
    #[serde(default = "default_max_depth")]
    pub max_depth: usize,

    /// 全局最大 Agent 总数（跨所有层级，默认 20）
    #[serde(default = "default_max_total")]
    pub max_total: usize,

    /// 子 Agent 最小 Token 预算（默认 2000）
    #[serde(default = "default_min_child_budget")]
    pub min_child_budget: u64,

    /// 子 Agent 默认超时时间（秒，默认 120）
    #[serde(default = "default_sub_agent_timeout")]
    pub sub_agent_timeout_secs: u64,

    /// 聚合结果最大 Token 总量（默认 50_000）
    #[serde(default = "default_max_aggregate_tokens")]
    pub max_aggregate_tokens: usize,
}

fn default_max_sub_agents() -> usize { 5 }
fn default_max_depth() -> usize { 2 }
fn default_max_total() -> usize { 20 }
fn default_min_child_budget() -> u64 { 2000 }
fn default_sub_agent_timeout() -> u64 { 120 }
fn default_max_aggregate_tokens() -> usize { 50_000 }

impl Default for RecursiveConfig {
    fn default() -> Self {
        Self {
            max_sub_agents: default_max_sub_agents(),
            max_depth: default_max_depth(),
            max_total: default_max_total(),
            min_child_budget: default_min_child_budget(),
            sub_agent_timeout_secs: default_sub_agent_timeout(),
            max_aggregate_tokens: default_max_aggregate_tokens(),
        }
    }
}

impl RecursiveConfig {
    /// 验证配置合法性
    pub fn validate(&self) -> Result<()> {
        if self.max_sub_agents == 0 {
            anyhow::bail!("max_sub_agents 不能为 0");
        }
        if self.max_depth == 0 {
            anyhow::bail!("max_depth 不能为 0");
        }
        if self.max_depth > 3 {
            anyhow::bail!("max_depth 不能超过 3，当前值: {}", self.max_depth);
        }
        if self.max_total == 0 {
            anyhow::bail!("max_total 不能为 0");
        }
        if self.min_child_budget == 0 {
            anyhow::bail!("min_child_budget 不能为 0");
        }
        Ok(())
    }
}
```

### RecursiveTask & RecursiveTaskStatus

```rust
/// 递归任务
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecursiveTask {
    /// 任务唯一 ID
    pub id: String,
    /// 任务描述
    pub description: String,
    /// 当前递归深度
    pub current_depth: usize,
    /// 任务状态
    pub status: RecursiveTaskStatus,
    /// 子 Agent 规格
    pub sub_agent_specs: Vec<SubAgentSpec>,
    /// Token 预算
    pub token_budget: u64,
    /// 创建时间
    pub created_at: chrono::DateTime<chrono::Utc>,
    /// 父任务 ID（顶层任务为 None）
    pub parent_task_id: Option<String>,
}

/// 递归任务状态
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RecursiveTaskStatus {
    /// 正在拆分方向
    SplittingDirections,
    /// 正在启动子 Agent
    LaunchingSubAgents,
    /// 等待子 Agent 完成
    WaitingForSubAgents,
    /// 正在筛选结果
    Filtering,
    /// 正在聚合分析
    Aggregating,
    /// 已完成
    Completed,
    /// 已失败
    Failed(String),
    /// 已取消
    Cancelled,
}
```

### SubAgentSpec & SubAgentResult

```rust
/// 子 Agent 规格（权威定义）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubAgentSpec {
    /// 子 Agent ID
    pub id: String,
    /// Agent 类型
    pub agent_type: AgentType,
    /// 任务焦点描述（1-2 句话）
    pub focus: String,
    /// 相关文件列表（最小注入原则）
    pub context_files: Vec<PathBuf>,
    /// Token 预算
    pub token_budget: usize,
    /// 超时时间（秒）
    pub timeout_secs: u64,
    /// 允许的工具子集（受限）
    pub allowed_tools: Vec<String>,
}

/// 子 Agent 执行结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubAgentResult {
    /// 子 Agent ID
    pub sub_agent_id: String,
    /// 原始输出
    pub raw_output: String,
    /// 筛选后输出
    pub filtered_output: Option<String>,
    /// Token 使用量
    pub token_usage: TokenUsage,
    /// 执行耗时
    pub duration: Duration,
    /// 子 Agent 规格（用于追溯）
    pub spec: SubAgentSpec,
    /// 执行状态
    pub status: SubAgentStatus,
}

/// 子 Agent 执行状态
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum SubAgentStatus {
    Pending,
    Running,
    Completed,
    Timeout,
    Failed(String),
    Cancelled,
}
```

### FilterStrategy + 实现（Regex/Contains/StartsWith/Custom）

```rust
/// 筛选策略
#[derive(Debug, Clone)]
pub enum FilterStrategy {
    /// LLM 辅助筛选
    LlmFiltered {
        filter_prompt: String,
        /// 最大保留比例 (0.0 - 1.0)
        max_retention_ratio: f64,
    },
    /// 基于规则的筛选
    RuleBased {
        keep_rules: Vec<FilterRule>,
        discard_rules: Vec<FilterRule>,
    },
    /// 摘要压缩
    Summarize {
        max_summary_tokens: usize,
    },
    /// 保留全部（不筛选）
    KeepAll,
}

/// 筛选规则
#[derive(Debug, Clone)]
pub struct FilterRule {
    pub pattern: String,
    pub rule_type: FilterRuleType,
    pub priority: FilterRulePriority,
}

/// 筛选规则类型
#[derive(Debug, Clone)]
pub enum FilterRuleType {
    /// 正则匹配
    Regex(String),
    /// 包含匹配
    Contains(String),
    /// 前缀匹配
    StartsWith(String),
    /// 自定义匹配函数
    Custom(fn(&str) -> bool),
}

/// 筛选规则优先级
#[derive(Debug, Clone, PartialEq)]
pub enum FilterRulePriority {
    Keep,
    Discard,
    Compress,
}

/// 筛选后的结果
#[derive(Debug, Clone, Serialize)]
pub struct FilteredResult {
    /// 保留的内容
    pub retained: Vec<String>,
    /// 被丢弃的内容统计
    pub discarded_count: usize,
    /// 被压缩的内容
    pub compressed: Vec<CompressedEntry>,
    /// 原始 Token 数
    pub original_tokens: usize,
    /// 筛选后 Token 数
    pub filtered_tokens: usize,
    /// 压缩率
    pub compression_ratio: f64,
}

/// 压缩条目
#[derive(Debug, Clone, Serialize)]
pub struct CompressedEntry {
    pub original_summary: String,
    pub compressed_to: String,
    pub original_tokens: usize,
    pub compressed_tokens: usize,
}
```

### matches_rule（Mutex<HashMap> 正则缓存）

```rust
/// 正则缓存（matches_rule 使用）
pub struct RegexCache {
    cache: Mutex<HashMap<String, Regex>>,
}

impl RegexCache {
    pub fn new() -> Self {
        Self {
            cache: Mutex::new(HashMap::new()),
        }
    }

    /// 获取或编译正则表达式
    pub async fn get_or_compile(&self, pattern: &str) -> Result<Regex> {
        let mut cache = self.cache.lock().await;
        if let Some(regex) = cache.get(pattern) {
            return Ok(regex.clone());
        }
        let regex = Regex::new(pattern)
            .with_context(|| format!("无效的正则表达式: {}", pattern))?;
        cache.insert(pattern.to_string(), regex.clone());
        Ok(regex)
    }
}

impl Default for RegexCache {
    fn default() -> Self {
        Self::new()
    }
}

/// 检查文本是否匹配筛选规则
pub async fn matches_rule(
    text: &str,
    rule: &FilterRule,
    regex_cache: &RegexCache,
) -> bool {
    match &rule.rule_type {
        FilterRuleType::Regex(pattern) => {
            regex_cache.get_or_compile(pattern).await
                .map(|re| re.is_match(text))
                .unwrap_or(false)
        }
        FilterRuleType::Contains(s) => text.contains(s),
        FilterRuleType::StartsWith(s) => text.starts_with(s),
        FilterRuleType::Custom(f) => f(text),
    }
}
```

### AggregatedResult & Contradiction

```rust
/// 聚合结果
#[derive(Debug, Clone, Serialize)]
pub struct AggregatedResult {
    /// 汇总发现
    pub findings: Vec<String>,
    /// 各子 Agent 的置信度评分
    pub confidence_scores: HashMap<String, f64>,
    /// 检测到的矛盾
    pub contradictions: Vec<Contradiction>,
    /// 总 Token 使用量
    pub total_tokens_used: usize,
    /// 使用的子 Agent 数量
    pub sub_agents_used: usize,
    /// 达到的递归深度
    pub depth_reached: usize,
    /// 汇总摘要
    pub summary: String,
}

/// 矛盾记录
#[derive(Debug, Clone, Serialize)]
pub struct Contradiction {
    /// 矛盾描述
    pub description: String,
    /// 子 Agent A 的结论
    pub agent_a_id: String,
    pub agent_a_conclusion: String,
    /// 子 Agent B 的结论
    pub agent_b_id: String,
    pub agent_b_conclusion: String,
    /// 矛盾严重程度
    pub severity: ContradictionSeverity,
}

/// 矛盾严重程度
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ContradictionSeverity {
    /// 信息冲突（可忽略）
    Info,
    /// 逻辑矛盾（需要人工判断）
    Warning,
    /// 事实矛盾（必须解决）
    Error,
}
```

### RecursiveDecision & should_recursively_split()

```rust
/// 递归决策
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RecursiveDecision {
    /// 继续递归拆分
    Proceed {
        suggested_sub_agents: usize,
        split_dimension: String,
    },
    /// 子任务太少，不值得递归
    TooFewTasks {
        actual_count: usize,
        min_threshold: usize,
    },
    /// 递归深度超限
    TooDeep {
        current_depth: usize,
        max_depth: usize,
    },
    /// Token 预算不足
    InsufficientBudget {
        required: u64,
        available: u64,
    },
    /// 降级为并行执行
    Degrade {
        reason: String,
    },
}

/// 判断是否应该递归拆分
pub fn should_recursively_split(
    task_complexity: TaskComplexity,
    current_depth: usize,
    max_depth: usize,
    available_budget: u64,
    estimated_child_budget: u64,
    min_child_budget: u64,
    sub_task_count: usize,
) -> RecursiveDecision {
    // 深度检查
    if current_depth >= max_depth {
        return RecursiveDecision::TooDeep { current_depth, max_depth };
    }

    // 预算检查
    let total_required = estimated_child_budget * sub_task_count as u64;
    if total_required > available_budget {
        if available_budget >= min_child_budget * 2 {
            return RecursiveDecision::Degrade {
                reason: format!(
                    "预算不足（需要 {}，可用 {}），降级为并行执行",
                    total_required, available_budget
                ),
            };
        }
        return RecursiveDecision::InsufficientBudget {
            required: total_required, available,
        };
    }

    // 子任务数量检查
    if sub_task_count < 2 {
        return RecursiveDecision::TooFewTasks {
            actual_count: sub_task_count, min_threshold: 2,
        };
    }

    // 复杂度检查
    match task_complexity {
        TaskComplexity::Light => {
            if sub_task_count <= 2 {
                return RecursiveDecision::Degrade {
                    reason: "轻量级任务且子任务数 <= 2，使用并行执行".to_string(),
                };
            }
        }
        TaskComplexity::Normal => {}
        TaskComplexity::Heavy | TaskComplexity::Deep => {}
    }

    RecursiveDecision::Proceed {
        suggested_sub_agents: sub_task_count,
        split_dimension: "default".to_string(),
    }
}
```

### TaskComplexity

```rust
/// 任务复杂度（用于递归决策）
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum TaskComplexity {
    /// 轻量级（权重 0.5）
    Light,
    /// 正常（权重 1.0）
    Normal,
    /// 重量级（权重 1.3）
    Heavy,
    /// 深度（权重 1.5）
    Deep,
}

impl TaskComplexity {
    /// 获取 Token 预算权重
    pub fn weight(&self) -> f64 {
        match self {
            TaskComplexity::Light => 0.5,
            TaskComplexity::Normal => 1.0,
            TaskComplexity::Heavy => 1.3,
            TaskComplexity::Deep => 1.5,
        }
    }
}
```

### TokenBudgetAllocator（多模型支持）

```rust
/// Agent 模型配置（多模型支持）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentModelConfig {
    /// Agent 类型
    pub agent_type: AgentType,
    /// 模型名称
    pub model_name: String,
    /// 输入 Token 单价（美元/1K tokens）
    pub input_price_per_1k: f64,
    /// 输出 Token 单价（美元/1K tokens）
    pub output_price_per_1k: f64,
    /// 最大上下文窗口
    pub max_context_tokens: u64,
    /// 建议的输出 Token 比例（0.0-1.0）
    pub output_ratio: f64,
}

/// Token 预算分配器
pub struct TokenBudgetAllocator {
    /// 已注册的 Agent 模型配置
    model_configs: HashMap<AgentType, AgentModelConfig>,
    /// 默认输出比例
    default_output_ratio: f64,
    /// 父 Agent 预算保留比例
    child_budget_ratio: f64,
}

impl TokenBudgetAllocator {
    pub fn new() -> Self {
        Self {
            model_configs: HashMap::new(),
            default_output_ratio: 0.3,
            child_budget_ratio: 0.8,
        }
    }

    /// 注册 Agent 模型配置
    pub fn register_agent_model(&mut self, config: AgentModelConfig) {
        self.model_configs.insert(config.agent_type, config);
    }

    /// 计算子 Agent 的 Token 预算
    pub fn calculate_child_budget(
        &self,
        parent_budget: u64,
        child_count: usize,
        depth: usize,
    ) -> Vec<u64> {
        if child_count == 0 {
            return vec![];
        }
        // 深度衰减因子：每深一层，预算乘以 0.7
        let depth_factor = 0.7_f64.powi(depth as i32);
        let total_child_budget = (parent_budget as f64
            * self.child_budget_ratio * depth_factor) as u64;
        let per_child = total_child_budget / child_count as u64;
        vec![per_child; child_count]
    }

    /// 计算父 Agent（Reduce 阶段）的 Token 预算
    pub fn calculate_parent_budget(
        &self,
        parent_budget: u64,
        child_count: usize,
        depth: usize,
    ) -> u64 {
        let child_budgets = self.calculate_child_budget(parent_budget, child_count, depth);
        let total_child: u64 = child_budgets.iter().sum();
        parent_budget.saturating_sub(total_child)
    }

    /// 估算成本（美元）
    pub fn estimate_cost(
        &self,
        agent_type: AgentType,
        input_tokens: u64,
        output_tokens: u64,
    ) -> f64 {
        if let Some(config) = self.model_configs.get(&agent_type) {
            let input_cost = input_tokens as f64 / 1000.0 * config.input_price_per_1k;
            let output_cost = output_tokens as f64 / 1000.0 * config.output_price_per_1k;
            input_cost + output_cost
        } else {
            // 默认估算（GPT-4 级别定价）
            input_tokens as f64 / 1000.0 * 0.03 + output_tokens as f64 / 1000.0 * 0.06
        }
    }
}

impl Default for TokenBudgetAllocator {
    fn default() -> Self { Self::new() }
}
```

### ResourceLimiter

```rust
/// 资源限制器（防止递归失控）
#[derive(Debug, Clone)]
pub struct ResourceLimiter {
    /// 单层最大子 Agent 数量
    pub max_sub_agents: usize,
    /// 最大递归深度
    pub max_depth: usize,
    /// 全局最大 Agent 总数
    pub max_total: usize,
    /// 当前全局 Agent 计数
    current_total: std::sync::atomic::AtomicUsize,
}

impl ResourceLimiter {
    pub fn new(max_sub_agents: usize, max_depth: usize, max_total: usize) -> Self {
        Self {
            max_sub_agents, max_depth, max_total,
            current_total: std::sync::atomic::AtomicUsize::new(0),
        }
    }

    /// 检查是否可以启动新的子 Agent
    pub fn can_spawn(&self, current_depth: usize, sub_agent_count: usize) -> bool {
        if current_depth >= self.max_depth { return false; }
        if sub_agent_count > self.max_sub_agents { return false; }
        let current = self.current_total.load(std::sync::atomic::Ordering::SeqCst);
        current + sub_agent_count <= self.max_total
    }

    /// 分配 Agent 槽位（CAS 操作）
    pub fn acquire(&self, count: usize) -> bool {
        loop {
            let current = self.current_total.load(std::sync::atomic::Ordering::SeqCst);
            if current + count > self.max_total { return false; }
            if self.current_total.compare_exchange_weak(
                std::sync::atomic::Ordering::SeqCst,
                std::sync::atomic::Ordering::SeqCst,
                current, current + count,
            ).is_ok() { return true; }
        }
    }

    /// 释放 Agent 槽位
    pub fn release(&self, count: usize) {
        self.current_total.fetch_sub(count, std::sync::atomic::Ordering::SeqCst);
    }

    /// 获取当前全局 Agent 数量
    pub fn current_count(&self) -> usize {
        self.current_total.load(std::sync::atomic::Ordering::SeqCst)
    }
}

impl Default for ResourceLimiter {
    fn default() -> Self { Self::new(5, 2, 20) }
}
```

### RecursiveStats（权威定义）

```rust
/// 递归编排统计（权威定义）
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RecursiveStats {
    /// 总任务数
    pub total_tasks: usize,
    /// 成功任务数
    pub successful_tasks: usize,
    /// 失败任务数
    pub failed_tasks: usize,
    /// 平均递归深度
    pub avg_depth: f64,
    /// 最大递归深度
    pub max_depth_reached: usize,
    /// 总子 Agent 数
    pub total_sub_agents: usize,
    /// 总 Token 使用量
    pub total_tokens_used: u64,
    /// 总耗时（毫秒）
    pub total_duration_ms: u64,
    /// 各 Agent 类型的调用次数
    pub agent_call_counts: HashMap<AgentType, usize>,
}

impl RecursiveStats {
    /// 记录一次 Agent 执行
    pub fn record_agent(
        &mut self,
        agent_type: AgentType,
        depth: usize,
        tokens_used: u64,
        duration_ms: u64,
        success: bool,
    ) {
        self.total_tasks += 1;
        self.total_sub_agents += 1;
        self.total_tokens_used += tokens_used;
        self.total_duration_ms += duration_ms;

        if success { self.successful_tasks += 1; }
        else { self.failed_tasks += 1; }

        if depth > self.max_depth_reached {
            self.max_depth_reached = depth;
        }

        // 增量计算平均深度
        let prev_total = self.total_tasks - 1;
        if prev_total > 0 {
            let prev_avg = self.avg_depth;
            self.avg_depth = (prev_avg * prev_total as f64 + depth as f64)
                / self.total_tasks as f64;
        } else {
            self.avg_depth = depth as f64;
        }

        *self.agent_call_counts.entry(agent_type).or_insert(0) += 1;
    }
}
```

### RecursiveResult<T> & SubResult<T>

```rust
/// 递归执行结果（泛型包装）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecursiveResult<T> {
    /// 最终聚合结果
    pub aggregated: T,
    /// 各子 Agent 的结果
    pub sub_results: Vec<SubResult<T>>,
    /// 递归统计
    pub stats: RecursiveStats,
    /// 达到的递归深度
    pub depth_reached: usize,
}

/// 子 Agent 结果（泛型包装）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubResult<T> {
    /// 子 Agent ID
    pub sub_agent_id: String,
    /// 子 Agent 类型
    pub agent_type: AgentType,
    /// 结果数据
    pub result: Option<T>,
    /// Token 使用量
    pub token_usage: TokenUsage,
    /// 执行耗时
    pub duration: Duration,
    /// 是否成功
    pub success: bool,
    /// 错误信息
    pub error: Option<String>,
}
```

### RecursiveOrchestrator（Map-Filter-Reduce 三阶段流程）

```rust
/// Agent 工厂 trait
#[async_trait::async_trait]
pub trait AgentFactory: Send + Sync {
    async fn create_agent(
        &self,
        agent_type: AgentType,
        spec: SubAgentSpec,
    ) -> Result<Box<dyn SubAgentExecutor>>;
}

/// 子 Agent 执行器 trait
#[async_trait::async_trait]
pub trait SubAgentExecutor: Send + Sync {
    async fn execute(&mut self, cancel: CancellationToken) -> Result<String>;
    fn token_usage(&self) -> TokenUsage;
}

/// 递归编排器
pub struct RecursiveOrchestrator {
    agent_factory: Arc<dyn AgentFactory>,
    config: RecursiveConfig,
    filter_strategy: FilterStrategy,
    budget_allocator: TokenBudgetAllocator,
    resource_limiter: ResourceLimiter,
    regex_cache: RegexCache,
    stats: RecursiveStats,
}

impl RecursiveOrchestrator {
    pub fn new(agent_factory: Arc<dyn AgentFactory>, config: RecursiveConfig) -> Result<Self> {
        config.validate()?;
        Ok(Self {
            agent_factory, config,
            filter_strategy: FilterStrategy::KeepAll,
            budget_allocator: TokenBudgetAllocator::new(),
            resource_limiter: ResourceLimiter::new(
                config.max_sub_agents, config.max_depth, config.max_total,
            ),
            regex_cache: RegexCache::new(),
            stats: RecursiveStats::default(),
        })
    }

    pub fn with_filter_strategy(mut self, strategy: FilterStrategy) -> Self {
        self.filter_strategy = strategy;
        self
    }

    /// 设置最大深度（Result 返回，max > 3 报错）
    pub fn with_max_depth(mut self, max: usize) -> Result<Self> {
        if max > 3 {
            anyhow::bail!("递归深度不能超过 3 层，请求值: {}", max);
        }
        self.config.max_depth = max;
        self.resource_limiter.max_depth = max;
        Ok(self)
    }

    /// 执行递归编排（Map-Filter-Reduce 三阶段流程）
    pub async fn execute_recursive(
        &self,
        task: &str,
        sub_agent_specs: Vec<SubAgentSpec>,
        parent_cancel: CancellationToken,
        depth: usize,
    ) -> Result<AggregatedResult> {
        if depth >= self.config.max_depth {
            anyhow::bail!("递归深度超限: {} >= {}", depth, self.config.max_depth);
        }
        if !self.resource_limiter.can_spawn(depth, sub_agent_specs.len()) {
            anyhow::bail!("资源限制：无法启动 {} 个子 Agent", sub_agent_specs.len());
        }

        // Phase 1: Map - 并行执行子 Agent
        let sub_results = self
            .execute_sub_agents(task, sub_agent_specs, parent_cancel.child_token())
            .await?;

        // Phase 2: Filter - 筛选子 Agent 结果
        let mut filtered_results = Vec::new();
        let mut all_retained = Vec::new();
        for result in &sub_results {
            let filtered = self.filter_result(&result.raw_output).await?;
            all_retained.extend(filtered.retained.clone());
            filtered_results.push(filtered);
        }

        // Phase 3: Reduce - 聚合分析（Token 总量检查 50K 上限、超限截断）
        let aggregated = self.reduce_results(
            task, &all_retained, &filtered_results, &sub_results, depth,
        ).await?;

        Ok(aggregated)
    }

    /// Phase 1: 并行执行所有子 Agent
    async fn execute_sub_agents(
        &self, parent_task: &str, specs: Vec<SubAgentSpec>,
        parent_cancel: CancellationToken,
    ) -> Result<Vec<SubAgentResult>> {
        if !self.resource_limiter.acquire(specs.len()) {
            anyhow::bail!("全局 Agent 总数超限");
        }
        let mut join_set = JoinSet::new();
        for spec in specs {
            let factory = self.agent_factory.clone();
            let task = parent_task.to_string();
            let task_cancel = parent_cancel.child_token();
            let timeout = Duration::from_secs(spec.timeout_secs);
            join_set.spawn(async move {
                let start = Instant::now();
                let mut agent = factory.create_agent(spec.agent_type, spec.clone()).await?;
                let output = tokio::select! {
                    _ = task_cancel.cancelled() => anyhow::bail!("子 Agent 收到取消信号"),
                    result = tokio::time::timeout(timeout, agent.execute(task_cancel)) => result?,
                };
                Ok::<SubAgentResult, anyhow::Error>(SubAgentResult {
                    sub_agent_id: spec.id.clone(), raw_output: output,
                    filtered_output: None, token_usage: agent.token_usage(),
                    duration: start.elapsed(), spec, status: SubAgentStatus::Completed,
                })
            });
        }
        let mut results = Vec::new();
        loop {
            tokio::select! {
                _ = parent_cancel.cancelled() => {
                    join_set.abort_all();
                    while join_set.join_next().await.is_some() {}
                    self.resource_limiter.release(results.len());
                    anyhow::bail!("父级取消");
                }
                result = join_set.join_next() => {
                    match result {
                        Some(Ok(Ok(r))) => results.push(r),
                        Some(Ok(Err(e))) => tracing::error!(error = %e, "子 Agent 失败"),
                        Some(Err(e)) => tracing::error!(error = %e, "子 Agent panic"),
                        None => break,
                    }
                }
            }
        }
        self.resource_limiter.release(results.len());
        Ok(results)
    }

    /// Phase 2: 筛选结果
    async fn filter_result(&self, output: &str) -> Result<FilteredResult> {
        match &self.filter_strategy {
            FilterStrategy::KeepAll => {
                let tokens = estimate_tokens(output);
                Ok(FilteredResult {
                    retained: vec![output.to_string()], discarded_count: 0,
                    compressed: vec![], original_tokens: tokens,
                    filtered_tokens: tokens, compression_ratio: 1.0,
                })
            }
            FilterStrategy::RuleBased { keep_rules, discard_rules } => {
                let mut retained = Vec::new();
                let mut discarded = 0usize;
                let original_tokens = estimate_tokens(output);
                for line in output.lines() {
                    let mut should_keep = true;
                    for rule in discard_rules {
                        if matches_rule(line, rule, &self.regex_cache).await {
                            should_keep = false; discarded += 1; break;
                        }
                    }
                    if should_keep && !keep_rules.is_empty() {
                        should_keep = false;
                        for rule in keep_rules {
                            if matches_rule(line, rule, &self.regex_cache).await {
                                should_keep = true; break;
                            }
                        }
                    }
                    if should_keep { retained.push(line.to_string()); }
                }
                let filtered_tokens = estimate_tokens(&retained.join("\n"));
                let ratio = if original_tokens > 0 {
                    filtered_tokens as f64 / original_tokens as f64
                } else { 1.0 };
                Ok(FilteredResult {
                    retained, discarded_count: discarded, compressed: vec![],
                    original_tokens, filtered_tokens, compression_ratio: ratio,
                })
            }
            FilterStrategy::Summarize { max_summary_tokens } => {
                let original_tokens = estimate_tokens(output);
                Ok(FilteredResult {
                    retained: vec![output.to_string()], discarded_count: 0,
                    compressed: vec![], original_tokens,
                    filtered_tokens: original_tokens.min(*max_summary_tokens),
                    compression_ratio: (*max_summary_tokens as f64 / original_tokens.max(1) as f64).min(1.0),
                })
            }
            FilterStrategy::LlmFiltered { max_retention_ratio, .. } => {
                let original_tokens = estimate_tokens(output);
                let max_tokens = (original_tokens as f64 * max_retention_ratio) as usize;
                Ok(FilteredResult {
                    retained: vec![output.to_string()], discarded_count: 0,
                    compressed: vec![], original_tokens,
                    filtered_tokens: original_tokens.min(max_tokens),
                    compression_ratio: *max_retention_ratio,
                })
            }
        }
    }

    /// Phase 3: 聚合结果（Token 总量检查 50K 上限、超限截断）
    async fn reduce_results(
        &self, task: &str, retained: &[String],
        filtered_results: &[FilteredResult], sub_results: &[SubAgentResult],
        depth: usize,
    ) -> Result<AggregatedResult> {
        let total_tokens: usize = filtered_results.iter().map(|r| r.filtered_tokens).sum();
        let mut final_retained: Vec<String> = retained.to_vec();

        if total_tokens > self.config.max_aggregate_tokens {
            tracing::warn!(total_tokens, max = self.config.max_aggregate_tokens, "聚合 Token 超限");
            let ratio = self.config.max_aggregate_tokens as f64 / total_tokens as f64;
            let target_lines = (final_retained.len() as f64 * ratio) as usize;
            final_retained.truncate(target_lines.max(1));
        }

        let contradictions = detect_contradictions(sub_results);
        let confidence_scores: HashMap<String, f64> = sub_results.iter()
            .map(|r| {
                let score = if r.status == SubAgentStatus::Completed {
                    1.0 - (r.duration.as_secs_f64() / 300.0).min(0.3)
                } else { 0.0 };
                (r.sub_agent_id.clone(), score)
            }).collect();

        let total_tokens_used: usize = sub_results.iter()
            .map(|r| r.token_usage.total_tokens as usize).sum();

        Ok(AggregatedResult {
            findings: final_retained.clone(),
            confidence_scores, contradictions, total_tokens_used,
            sub_agents_used: sub_results.len(), depth_reached: depth + 1,
            summary: format!("递归完成：{} 个子 Agent，深度 {}，{} 条发现",
                sub_results.len(), depth + 1, final_retained.len()),
        })
    }
}

/// 检测矛盾
fn detect_contradictions(results: &[SubAgentResult]) -> Vec<Contradiction> {
    let mut contradictions = Vec::new();
    let completed: Vec<_> = results.iter()
        .filter(|r| r.status == SubAgentStatus::Completed).collect();
    for i in 0..completed.len() {
        for j in (i + 1)..completed.len() {
            if has_contradiction(&completed[i].raw_output, &completed[j].raw_output) {
                contradictions.push(Contradiction {
                    description: format!("Agent {} 与 Agent {} 结论矛盾",
                        completed[i].sub_agent_id, completed[j].sub_agent_id),
                    agent_a_id: completed[i].sub_agent_id.clone(),
                    agent_a_conclusion: truncate_str(&completed[i].raw_output, 200),
                    agent_b_id: completed[j].sub_agent_id.clone(),
                    agent_b_conclusion: truncate_str(&completed[j].raw_output, 200),
                    severity: ContradictionSeverity::Warning,
                });
            }
        }
    }
    contradictions
}

fn has_contradiction(text_a: &str, text_b: &str) -> bool {
    let neg = ["不", "没有", "不存在", "无法", "not", "no", "cannot"];
    let pos = ["是", "有", "存在", "可以", "yes", "has", "exists"];
    for n in &neg { for p in &pos { if text_a.contains(*n) && text_b.contains(*p) { return true; } } }
    false
}

fn truncate_str(s: &str, max_len: usize) -> String {
    if s.len() <= max_len { s.to_string() } else { format!("{}...", &s[..max_len]) }
}

fn estimate_tokens(text: &str) -> usize { text.len() / 4 }
```

## P5-1 功能需求清单

| 编号 | 功能 | 优先级 | 说明 |
|------|------|--------|------|
| FR-REC-001 | RecursiveOrchestrator 创建与配置 | P0 | 支持通过 RecursiveConfig 初始化，验证配置合法性 |
| FR-REC-002 | Map 阶段：并行执行子 Agent | P0 | 使用 JoinSet 并行启动，支持 CancellationToken 传播 |
| FR-REC-003 | Filter 阶段：规则筛选 | P0 | 支持 Regex/Contains/StartsWith/Custom 四种规则 |
| FR-REC-004 | Filter 阶段：正则缓存 | P1 | Mutex<HashMap> 缓存编译后的正则 |
| FR-REC-005 | Reduce 阶段：结果聚合 | P0 | 聚合子 Agent 结果，检测矛盾，计算置信度 |
| FR-REC-006 | Reduce 阶段：Token 总量检查 | P0 | 聚合结果不超过 50K Token 上限，超限截断 |
| FR-REC-007 | should_recursively_split 决策 | P0 | 基于复杂度、深度、预算、子任务数判断 |
| FR-REC-008 | with_max_depth Result 返回 | P0 | max > 3 返回 Err |
| FR-REC-009 | TokenBudgetAllocator 多模型支持 | P1 | 不同 Agent 类型使用不同模型和定价 |
| FR-REC-010 | TokenBudgetAllocator 预算分配 | P0 | calculate_child_budget / calculate_parent_budget |
| FR-REC-011 | ResourceLimiter 全局限制 | P0 | max_sub_agents=5、max_depth=2、max_total=20 |
| FR-REC-012 | RecursiveStats 统计 | P1 | 权威定义，Default，record_agent |
| FR-REC-013 | RecursiveResult<T> 泛型 | P1 | 泛型包装递归执行结果 |
| FR-REC-014 | 简单场景并行执行 | P0 | 1-2 个子任务使用并行，不启用递归 |
| FR-REC-015 | 复杂场景递归执行 | P0 | 3+ 个子任务启用递归拆分 |
| FR-REC-016 | 取消信号传播 | P0 | 父 CancellationToken 传播到所有子任务 |
| FR-REC-017 | AggregatedResult 矛盾检测 | P2 | 检测子 Agent 结果间的逻辑矛盾 |

## P5-1 接口契约

```rust
impl RecursiveOrchestrator {
    pub fn new(agent_factory: Arc<dyn AgentFactory>, config: RecursiveConfig) -> Result<Self>;
    pub fn with_filter_strategy(self, strategy: FilterStrategy) -> Self;
    pub fn with_max_depth(self, max: usize) -> Result<Self>;
    pub async fn execute_recursive(
        &self, task: &str, sub_agent_specs: Vec<SubAgentSpec>,
        parent_cancel: CancellationToken, depth: usize,
    ) -> Result<AggregatedResult>;
}

pub fn should_recursively_split(
    task_complexity: TaskComplexity, current_depth: usize, max_depth: usize,
    available_budget: u64, estimated_child_budget: u64,
    min_child_budget: u64, sub_task_count: usize,
) -> RecursiveDecision;

pub async fn matches_rule(text: &str, rule: &FilterRule, regex_cache: &RegexCache) -> bool;

#[async_trait::async_trait]
pub trait AgentFactory: Send + Sync {
    async fn create_agent(&self, agent_type: AgentType, spec: SubAgentSpec)
        -> Result<Box<dyn SubAgentExecutor>>;
}

#[async_trait::async_trait]
pub trait SubAgentExecutor: Send + Sync {
    async fn execute(&mut self, cancel: CancellationToken) -> Result<String>;
    fn token_usage(&self) -> TokenUsage;
}
```

## P5-1 测试要点

| 测试场景 | 验证内容 | 预期结果 |
|----------|----------|----------|
| RecursiveOrchestrator 创建 | 默认参数 | max_sub_agents=5, max_depth=2 |
| 递归编排完整流程 | Map(Filter(Reduce)) | 结果正确聚合，Token 不超限 |
| RecursiveConfig 验证 | max_depth=0 / max_depth=4 | 返回 Err |
| RecursiveTask 状态转换 | SplittingDirections -> ... -> Completed | 状态按序转换 |
| RecursiveTask 失败 | 任意阶段失败 | 状态变为 Failed |
| SubAgentSpec 构建 | agent_type, focus, token_budget | 字段完整赋值 |
| SubAgentResult 状态 | Pending -> Running -> Completed/Timeout/Failed | 状态正确转换 |
| FilterStrategy::KeepAll | 保留所有结果 | retained == 原始输出 |
| FilterStrategy::RuleBased | Regex/Contains/StartsWith/Custom | 规则正确匹配 |
| AggregatedResult 构建 | findings + confidence_scores + contradictions | 字段完整 |
| Contradiction 检测 | 矛盾结论 | 记录 Contradiction |
| should_recursively_split | 复杂任务 | 返回 Proceed |
| should_recursively_split | 深度超限 | 返回 TooDeep |
| should_recursively_split | 预算不足 | 返回 InsufficientBudget |
| should_recursively_split | 降级 | 返回 Degrade |
| TaskComplexity 权重 | Light(0.5) < Normal(1.0) < Heavy(1.3) < Deep(1.5) | 权重正确 |
| TokenBudgetAllocator 分配 | 深度衰减 | 0.7^n |
| TokenBudgetAllocator 最小预算 | 不低于 min_child_budget | 不低于 2000 |
| ResourceLimiter 全局限制 | max_total=20 | 超限返回 false |
| ResourceLimiter 单层限制 | max_sub_agents=5 | 超限返回 false |
| ResourceLimiter 深度限制 | max_depth=2 | 超限返回 false |
| RecursiveStats 统计 | record_agent | 统计正确 |
| RecursiveResult<T> 泛型 | 泛型参数 | 类型安全 |
| with_max_depth | max=4 | 返回 Err |
| 取消信号传播 | 父取消 -> 子取消 | 所有子任务停止 |

---

# P5-2 mc-coordinator 协调器

## P5-2 模块概述

`mc-coordinator` 是整个多 Agent 系统的大脑和中枢，负责接收用户请求、理解意图、决策路由、监控执行、整合结果并最终交付。它是用户与 Agent 系统之间的唯一接口。Coordinator 本身不执行具体任务，只做决策和协调。

核心工作流程是九步管道：接收请求 -> 识别意图 -> 补全信息 -> 加载记忆 -> 评估复杂度 -> 路由决策 -> 分发执行 -> 整合结果 -> 最终交付。

**Crate 路径**：`crates/mc-coordinator/`

**依赖关系**：
- 依赖 `mc-core`、`mc-agent`、`mc-recursive`、`mc-llm`、`mc-context`、`mc-memory`、`mc-communication`
- 被依赖：`mc-cli`、`mc-daemon`

## P5-2 架构文档引用

- **主文档**：`02-Coordinator.md`（全文）——Coordinator 角色定位、六步管道、意图识别、路由决策、复杂度评估、结果整合、项目记忆集成
- **补充文档**：`07-路由决策机制.md`——决策矩阵、Agent 启动策略、复杂度评估规则、记忆感知路由

## P5-2 大模型开发提示词

```
你正在实现 MoreCode Agent 系统的协调器（mc-coordinator crate）。

核心职责：
1. 实现完整的九步管道
2. 意图识别采用三级策略：LLM 主 + 关键词快速路径 + 关键词回退
3. 复杂度评估支持可外部化配置和自动校准
4. 路由决策按复杂度最小化 Agent 集合
5. Agent 间通信使用结构化交接替代自然语言摘要
6. 流式输出通过 StreamForwarder 集成

关键设计约束：
- Coordinator 不执行具体任务，只做决策和协调
- LLM 输出解析失败不能静默回退，必须显式上报 IntentParseFailed
- parse_or_repair_json 使用 JSON mode 结构化提取，temperature=0.0
- 步骤 1 + 2 合并为一次结构化调用
- load_project_memory 返回 Option<ProjectContext>，正常流程不报错
- handle_daemon_task 共享上下文，通信零开销

参考架构文档：02-Coordinator.md、07-路由决策机制.md
```

## P5-2 核心类型定义

### Coordinator struct（pub config、pub(crate) 字段、9 个只读查询方法）

```rust
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Instant;

use anyhow::Result;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;

use mc_core::agent::AgentType;
use mc_core::token::TokenUsage;

// ─── CoordinatorConfig ────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoordinatorConfig {
    #[serde(default = "default_max_token_budget")]
    pub max_token_budget: u64,
    #[serde(default = "default_max_recursion_depth")]
    pub max_recursion_depth: usize,
    #[serde(default = "default_agent_timeout")]
    pub agent_timeout_secs: u64,
    #[serde(default = "default_max_retries")]
    pub max_retries: u32,
    #[serde(default = "default_true")]
    pub memory_aware_routing: bool,
    #[serde(default = "default_true")]
    pub recursive_orchestration: bool,
    #[serde(default = "default_memory_stale_days")]
    pub memory_stale_threshold_days: u64,
}

fn default_max_token_budget() -> u64 { 200_000 }
fn default_max_recursion_depth() -> usize { 2 }
fn default_agent_timeout() -> u64 { 300 }
fn default_max_retries() -> u32 { 3 }
fn default_true() -> bool { true }
fn default_memory_stale_days() -> u64 { 7 }

impl Default for CoordinatorConfig {
    fn default() -> Self {
        Self {
            max_token_budget: default_max_token_budget(),
            max_recursion_depth: default_max_recursion_depth(),
            agent_timeout_secs: default_agent_timeout(),
            max_retries: default_max_retries(),
            memory_aware_routing: default_true(),
            recursive_orchestration: default_true(),
            memory_stale_threshold_days: default_memory_stale_days(),
        }
    }
}

// ─── Coordinator struct ───────────────────────────────────

pub struct Coordinator {
    pub config: CoordinatorConfig,
    llm_client: Arc<dyn LlmProvider>,
    agent_registry: Arc<AgentRegistry>,
    project_context: Option<Arc<ProjectContext>>,
    complexity_evaluator: Arc<RwLock<ComplexityEvaluator>>,
    event_bus: Arc<EventBus>,
    recursive_orchestrator: Option<Arc<RecursiveOrchestrator>>,
    project_root: PathBuf,
    pub(crate) execution_status: Arc<RwLock<Option<ExecutionStatus>>>,
    pub(crate) memory_manager: Option<Arc<MemoryManager>>,
}

impl Coordinator {
    /// 9 个只读查询方法
    pub fn config(&self) -> &CoordinatorConfig { &self.config }
    pub fn project_root(&self) -> &PathBuf { &self.project_root }
    pub async fn execution_status(&self) -> Option<ExecutionStatus> {
        self.execution_status.read().await.clone()
    }
    pub async fn is_busy(&self) -> bool { self.execution_status.read().await.is_some() }
    pub fn project_context(&self) -> Option<&Arc<ProjectContext>> {
        self.project_context.as_ref()
    }
    pub async fn complexity_config(&self) -> ComplexityConfig {
        self.complexity_evaluator.read().await.config.clone()
    }
    pub async fn memory_state(&self) -> Option<MemoryState> {
        self.memory_manager.as_ref().map(|m| m.state())
    }
    pub fn registered_agents(&self) -> Vec<AgentType> {
        self.agent_registry.list_types()
    }
    pub async fn recursive_stats(&self) -> Option<RecursiveStats> {
        self.recursive_orchestrator.as_ref().map(|o| o.stats())
    }
}
```

### handle_request（完整九步管道）

```rust
impl Coordinator {
    /// 处理用户请求（完整九步管道）
    pub async fn handle_request(&self, request: &str) -> Result<CoordinatorResponse> {
        let start = Instant::now();

        // 步骤 1：接收请求
        tracing::info!(request_len = request.len(), "收到用户请求");

        // 步骤 2：识别意图（三级策略）
        let intent_analysis = self.recognize_intent(request).await?;

        // 步骤 3：补全信息
        if let Some(clarification) = &intent_analysis.clarifications {
            if !clarification.questions.is_empty() {
                return Ok(CoordinatorResponse {
                    response_type: ResponseType::ClarificationNeeded,
                    content: serde_json::to_string_pretty(clarification)?,
                    ..Default::default()
                });
            }
        }
        let intent = intent_analysis.intent;

        // 步骤 4：加载项目记忆
        let project_ctx = self.load_project_memory(&self.project_root).await?;

        // 步骤 5：评估复杂度
        let route_level = {
            let evaluator = self.complexity_evaluator.read().await;
            evaluator.evaluate(&intent, project_ctx.as_ref())
        };
        tracing::info!(route_level = ?route_level, "路由决策完成");

        // 步骤 6：路由决策 — 按复杂度最小化 Agent 集合
        let agents = self.select_agents(&route_level, &intent);
        let budget = self.allocate_budget(&agents, &route_level);

        // 步骤 7：分发执行（含流式输出）
        let results = self.dispatch_tasks_streaming(&agents, &intent, &budget).await?;

        // 步骤 8：整合结果
        let integration_context = IntegrationContext {
            project_context: project_ctx, impact_report: None, research_report: None,
        };
        let integration = self.integrate_results(&results, &integration_context).await;

        // 步骤 9：最终交付
        let response = CoordinatorResponse {
            response_type: ResponseType::Completed,
            content: self.format_delivery(&intent, &integration),
            changed_files: integration.changed_files,
            test_results: integration.test_results,
            total_tokens_used: integration.total_tokens_used,
            total_duration_ms: start.elapsed().as_millis() as u64,
            ..Default::default()
        };

        self.record_calibration(&intent, &route_level, &integration).await;
        Ok(response)
    }
}
```

### recognize_intent（三级策略：LLM 主 + 关键词快速路径 + 关键词回退）

```rust
impl Coordinator {
    async fn recognize_intent(&self, request: &str) -> Result<IntentAnalysis> {
        // 第一级：关键词快速路径（零 LLM 调用）
        if let Some(quick_intent) = self.keyword_fast_path(request) {
            tracing::info!(intent = ?quick_intent.task_type, "关键词快速路径命中");
            return Ok(IntentAnalysis { intent: quick_intent, clarifications: None });
        }
        // 第二级：LLM 主识别
        match self.llm_intent_analysis(request).await {
            Ok(analysis) => Ok(analysis),
            Err(e) => {
                tracing::warn!(error = %e, "LLM 意图识别失败，关键词回退");
                let fallback = self.keyword_fallback(request);
                Ok(IntentAnalysis { intent: fallback, clarifications: None })
            }
        }
    }

    fn keyword_fast_path(&self, request: &str) -> Option<UserIntent> {
        let lower = request.to_lowercase();
        if lower.starts_with("/full-analysis") {
            return Some(UserIntent {
                raw_request: request.to_string(),
                task_type: TaskType::CodeReview,
                target_files: vec![], domains: vec![],
                estimated_complexity: Complexity::Complex,
                needs_project_context: true, needs_research: false,
            });
        }
        let patterns: &[(&str, TaskType, Complexity)] = &[
            ("修复 typo", TaskType::BugFix, Complexity::Simple),
            ("格式化代码", TaskType::Refactoring, Complexity::Simple),
            ("添加注释", TaskType::Documentation, Complexity::Simple),
            ("运行测试", TaskType::Testing, Complexity::Simple),
            ("先调研", TaskType::Other("research".into()), Complexity::Research),
            ("深入排查", TaskType::Debugging, Complexity::Complex),
        ];
        for (keyword, task_type, complexity) in patterns {
            if lower.contains(keyword) {
                return Some(UserIntent {
                    raw_request: request.to_string(), task_type: task_type.clone(),
                    target_files: vec![], domains: vec![],
                    estimated_complexity: complexity.clone(),
                    needs_project_context: matches!(complexity, Complexity::Complex | Complexity::Research),
                    needs_research: matches!(complexity, Complexity::Research),
                });
            }
        }
        None
    }

    fn keyword_fallback(&self, request: &str) -> UserIntent {
        let lower = request.to_lowercase();
        let (task_type, complexity) = if lower.contains("修复") || lower.contains("fix") {
            (TaskType::BugFix, Complexity::Medium)
        } else if lower.contains("重构") || lower.contains("refactor") {
            (TaskType::Refactoring, Complexity::Complex)
        } else if lower.contains("添加") || lower.contains("功能") {
            (TaskType::FeatureDevelopment, Complexity::Medium)
        } else if lower.contains("测试") || lower.contains("test") {
            (TaskType::Testing, Complexity::Medium)
        } else if lower.contains("文档") || lower.contains("doc") {
            (TaskType::Documentation, Complexity::Simple)
        } else {
            (TaskType::Other("general".into()), Complexity::Medium)
        };
        UserIntent {
            raw_request: request.to_string(), task_type, target_files: vec![], domains: vec![],
            estimated_complexity: complexity,
            needs_project_context: matches!(complexity, Complexity::Complex | Complexity::Research),
            needs_research: matches!(complexity, Complexity::Research),
        }
    }
}
```

### keyword_fallback

（已包含在上方 recognize_intent 实现中）

### ComplexityEvaluator + ComplexityConfig（可外部化配置）

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComplexityConfig {
    pub llm_complexity_weights: HashMap<Complexity, i32>,
    pub file_count_tiers: Vec<(usize, usize, i32)>,
    pub task_type_weights: HashMap<String, i32>,
    pub needs_context_bonus: i32,
    pub domain_bonus: i32,
    pub project_size_tiers: Vec<(usize, usize, i32)>,
    pub route_thresholds: RouteThresholds,
    pub llm_weight_multiplier: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteThresholds {
    pub simple_max: i32,
    pub medium_max: i32,
}

impl Default for ComplexityConfig {
    fn default() -> Self {
        Self {
            llm_complexity_weights: HashMap::from([
                (Complexity::Simple, 0), (Complexity::Medium, 10), (Complexity::Complex, 25),
            ]),
            file_count_tiers: vec![
                (0, 1, 0), (2, 5, 10), (6, 15, 25), (16, usize::MAX, 40),
            ],
            task_type_weights: HashMap::from([
                ("FeatureDevelopment".into(), 20), ("BugFix".into(), 15),
                ("Refactoring".into(), 30), ("Documentation".into(), 5),
                ("Testing".into(), 10), ("Configuration".into(), 5),
                ("CodeReview".into(), 10), ("Debugging".into(), 15),
            ]),
            needs_context_bonus: 10, domain_bonus: 5,
            project_size_tiers: vec![
                (0, 50, 0), (51, 200, 5), (201, 500, 10), (501, usize::MAX, 15),
            ],
            route_thresholds: RouteThresholds { simple_max: 15, medium_max: 35 },
            llm_weight_multiplier: 1.0,
        }
    }
}
```

### CalibrationRecord & ComplexityFactors

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalibrationRecord {
    pub factors: ComplexityFactors,
    pub evaluated_score: i32,
    pub evaluated_route: RouteLevel,
    pub actual_needed_more_agents: bool,
    pub actual_tokens_used: u64,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComplexityFactors {
    pub file_count: usize,
    pub task_type: String,
    pub needs_context: bool,
    pub domain_count: usize,
    pub project_size: usize,
    pub llm_complexity: Complexity,
}
```

### calibrate_from_history

```rust
impl ComplexityEvaluator {
    pub fn calibrate_from_history(&mut self) -> Option<ComplexityConfig> {
        if self.calibration_history.len() < 20 { return None; }
        let mut adjusted = self.config.clone();
        let mut type_adjustments: HashMap<String, i32> = HashMap::new();
        for record in &self.calibration_history {
            if record.actual_needed_more_agents {
                let delta = 3i32.min(50 - record.evaluated_score);
                *type_adjustments.entry(record.factors.task_type.clone()).or_insert(0) += delta;
            } else if record.evaluated_score > 30 && record.actual_tokens_used < 5000 {
                let delta = -3i32.max(-(record.evaluated_score - 10));
                *type_adjustments.entry(record.factors.task_type.clone()).or_insert(0) += delta;
            }
        }
        for (type_key, delta) in &type_adjustments {
            let clamped = delta.clamp(-10, 10);
            if let Some(weight) = adjusted.task_type_weights.get_mut(type_key) {
                *weight = (*weight + clamped).max(1);
            }
        }
        let mut scores: Vec<i32> = self.calibration_history.iter().map(|r| r.evaluated_score).collect();
        scores.sort();
        if scores.len() >= 20 {
            adjusted.route_thresholds.simple_max = scores[scores.len() / 3];
            adjusted.route_thresholds.medium_max = scores[scores.len() * 2 / 3];
        }
        Some(adjusted)
    }

    pub fn record_calibration(
        &mut self, factors: ComplexityFactors, evaluated_score: i32,
        evaluated_route: RouteLevel, actual_needed_more_agents: bool, actual_tokens_used: u64,
    ) {
        self.calibration_history.push(CalibrationRecord {
            factors, evaluated_score, evaluated_route,
            actual_needed_more_agents, actual_tokens_used, timestamp: Utc::now(),
        });
        if self.calibration_history.len() > 500 {
            self.calibration_history.drain(..self.calibration_history.len() - 500);
        }
    }
}
```

### RouteLevel（Simple/Medium/Complex/Research）

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RouteLevel { Simple, Medium, Complex, Research }
```

### 路由决策：按复杂度最小化 Agent 集合

```rust
impl Coordinator {
    fn select_agents(&self, route_level: &RouteLevel, intent: &UserIntent) -> Vec<AgentType> {
        match route_level {
            RouteLevel::Simple => vec![self.match_agent_for_task(&intent.task_type)],
            RouteLevel::Medium => vec![AgentType::Explorer, AgentType::Coder, AgentType::Reviewer],
            RouteLevel::Complex => vec![
                AgentType::Explorer, AgentType::ImpactAnalyzer,
                AgentType::Planner, AgentType::Coder,
                AgentType::Reviewer, AgentType::Tester,
            ],
            RouteLevel::Research => vec![AgentType::Research],
        }
    }
}
```

### HandoffFormat

```rust
pub enum HandoffFormat {
    Structured,
    CompressedSummary,
    DirectInjection,
}
```

### handle_daemon_task（共享上下文、通信零开销）

```rust
impl Coordinator {
    pub async fn handle_daemon_task(&self, task: DaemonTask) -> Result<TaskResult> {
        let shared_context = self.project_context.as_ref()
            .ok_or_else(|| anyhow::anyhow!("Daemon 模式需要预加载项目上下文"))?;
        match task.route_level {
            RouteLevel::Simple => {
                let coder = self.create_agent(AgentType::Coder)?;
                coder.execute_with_context(&task.description, shared_context).await
            }
            RouteLevel::Medium => {
                let plan = self.planner.plan(&task.description, shared_context).await?;
                let coder = self.create_agent(AgentType::Coder)?;
                coder.execute_plan(plan, shared_context).await
            }
            _ => self.dispatch_complex(task, shared_context).await,
        }
    }
}
```

### dispatch_tasks_streaming（StreamForwarder 集成）

```rust
impl Coordinator {
    async fn dispatch_tasks_streaming(
        &self, agents: &[AgentType], intent: &UserIntent,
        budget: &HashMap<AgentType, u32>,
    ) -> Result<Vec<AgentResult>> {
        let mut handles = Vec::new();
        for agent_type in agents {
            let agent = self.create_agent(*agent_type)?;
            let event_bus = self.event_bus.clone();
            let task_desc = intent.raw_request.clone();
            let token_budget = budget.get(agent_type).copied().unwrap_or(0) as u64;
            let handle = tokio::spawn(async move {
                let forwarder = StreamForwarder::new(agent.agent_id().to_string(), event_bus);
                agent.execute_streaming(&task_desc, token_budget, &forwarder).await
            });
            handles.push(handle);
        }
        let mut results = Vec::new();
        for handle in handles {
            match handle.await {
                Ok(Ok(result)) => results.push(result),
                Ok(Err(e)) => tracing::error!(error = %e, "Agent 执行失败"),
                Err(e) => tracing::error!(error = %e, "Agent panic"),
            }
        }
        Ok(results)
    }
}
```

### integrate_results（IntegrationContext）

```rust
#[derive(Debug, Clone)]
struct IntegrationContext {
    project_context: Option<ProjectContext>,
    impact_report: Option<ImpactReport>,
    research_report: Option<ResearchReport>,
}

#[derive(Debug, Clone, Default)]
struct IntegrationResult {
    pub changed_files: Vec<String>,
    pub test_results: Vec<TestReport>,
    pub review_issues: Vec<String>,
    pub total_tokens_used: usize,
    pub total_duration_ms: u64,
}

impl Coordinator {
    async fn integrate_results(
        &self, results: &[AgentResult], ctx: &IntegrationContext,
    ) -> IntegrationResult {
        let mut changed_files = Vec::new();
        let mut test_results = Vec::new();
        let mut review_issues = Vec::new();
        for result in results {
            match result.agent_type {
                AgentType::Coder => {
                    if let Some(handoff) = &result.handoff {
                        changed_files.extend(handoff.changed_files.clone());
                    }
                }
                AgentType::Reviewer => {
                    if let Some(report) = &result.review_report {
                        if report.verdict != ReviewVerdict::Passed {
                            review_issues.extend(report.issues.clone());
                        }
                    }
                }
                AgentType::Tester => {
                    if let Some(report) = &result.test_report { test_results.push(report.clone()); }
                }
                _ => {}
            }
        }
        IntegrationResult {
            changed_files, test_results, review_issues,
            total_tokens_used: results.iter().map(|r| r.tokens_used).sum(),
            total_duration_ms: results.iter().map(|r| r.duration_ms).sum(),
        }
    }
}
```

### load_project_memory（返回 Option<ProjectContext>，正常流程不报错）

```rust
impl Coordinator {
    pub async fn load_project_memory(
        &self, project_root: &PathBuf,
    ) -> Result<Option<ProjectContext>> {
        let memory_dir = project_root.join(".assistant-memory");
        let meta_path = memory_dir.join("memory-meta.json");
        if !meta_path.exists() { return Ok(None); }
        let meta_content = match tokio::fs::read_to_string(&meta_path).await {
            Ok(c) => c, Err(_) => return Ok(None),
        };
        let meta: MemoryMeta = match serde_json::from_str(&meta_content) {
            Ok(m) => m, Err(_) => return Ok(None),
        };
        if !meta.is_valid() { return Ok(None); }
        let overview_path = memory_dir.join("project-overview.md");
        let overview = match tokio::fs::read_to_string(&overview_path).await {
            Ok(c) => c, Err(_) => return Ok(None),
        };
        Ok(Some(ProjectContext { overview, ..Default::default() }))
    }
}
```

### parse_or_repair_json（JSON mode 结构化提取、temperature=0.0）

```rust
impl Coordinator {
    async fn parse_or_repair_json<T>(
        &self, schema_name: &str, user_request: &str, raw: &str,
    ) -> Result<T> where T: serde::de::DeserializeOwned {
        match serde_json::from_str(raw) {
            Ok(value) => Ok(value),
            Err(first_err) => {
                tracing::warn!(%schema_name, %first_err, "JSON parse failed, structured extraction");
                let extract_prompt = format!(
                    r#"从以下文本中提取结构化信息，输出为合法 JSON。
要求：1. 仅提取原文中明确存在的信息 2. 无法确定用 null 3. 直接输出 JSON
原始请求：{user_request}
目标结构名：{schema_name}
待提取文本：{raw}"#
                );
                let repaired = self.llm_client.complete_with_options(LlmRequest {
                    messages: vec![ChatMessage::system(&extract_prompt)],
                    response_format: Some(ResponseFormat::Json),
                    temperature: Some(0.0), max_tokens: Some(500),
                    ..Default::default()
                }).await?.content;
                serde_json::from_str(&repaired).map_err(|second_err| {
                    anyhow::anyhow!("IntentParseFailed: first={first_err}; extract={second_err}")
                })
            }
        }
    }
}
```

### Agent 间通信优化策略（4 种优化） & 量化效果表

| 优化策略 | 说明 |
|----------|------|
| 优化 1：按复杂度最小化 Agent 集合 | Simple 1-2 个，Medium 3-4 个，Complex 5-7 个 |
| 优化 2：结构化交接替代自然语言摘要 | 使用 AgentExecutionReport，零 LLM 调用 |
| 优化 3：Daemon 模式通信零开销 | 项目上下文预加载，Agent 间无需重复传递 |
| 优化 4：批量任务复用上下文 | 连续处理多个任务时共享上下文 |

| 场景 | 优化前 | 优化后 | 节省 |
|------|--------|--------|------|
| Simple（单文件修复） | ~2K tokens | 0 tokens | 100% |
| Medium（新功能） | ~6K tokens | ~1K tokens | 83% |
| Complex（架构变更） | ~12K tokens | ~4K tokens | 67% |
| Daemon 批量（10 Simple） | ~20K tokens | ~0 tokens | ~100% |

## P5-2 功能需求清单

| 编号 | 功能 | 优先级 | 说明 |
|------|------|--------|------|
| FR-CRD-001 | Coordinator struct | P0 | pub config + pub(crate) + 9 只读方法 |
| FR-CRD-002 | CoordinatorConfig | P0 | 8 个配置项 |
| FR-CRD-003 | handle_request 九步管道 | P0 | 完整九步 |
| FR-CRD-004 | recognize_intent 三级策略 | P0 | LLM + 关键词快速 + 关键词回退 |
| FR-CRD-005 | keyword_fast_path | P0 | 零 LLM 调用 |
| FR-CRD-006 | keyword_fallback | P0 | LLM 失败时使用 |
| FR-CRD-007 | ComplexityEvaluator | P0 | 可外部化配置 |
| FR-CRD-008 | calibrate_from_history | P1 | 自动校准（20+ 条） |
| FR-CRD-009 | record_calibration | P1 | 保留 500 条 |
| FR-CRD-010 | RouteLevel 路由 | P0 | 四级路由 |
| FR-CRD-011 | 按复杂度最小化 Agent | P0 | 最小 Agent 集合 |
| FR-CRD-012 | HandoffFormat | P1 | 三种格式 |
| FR-CRD-013 | handle_daemon_task | P0 | 共享上下文 |
| FR-CRD-014 | dispatch_tasks_streaming | P0 | StreamForwarder |
| FR-CRD-015 | integrate_results | P0 | IntegrationContext |
| FR-CRD-016 | load_project_memory | P0 | Option 返回，不报错 |
| FR-CRD-017 | parse_or_repair_json | P0 | JSON mode, temp=0.0 |

## P5-2 接口契约

```rust
impl Coordinator {
    pub fn new(config: CoordinatorConfig, llm_client: Arc<dyn LlmProvider>,
               agent_registry: Arc<AgentRegistry>, project_root: PathBuf) -> Result<Self>;
    pub async fn handle_request(&self, request: &str) -> Result<CoordinatorResponse>;
    pub async fn handle_daemon_task(&self, task: DaemonTask) -> Result<TaskResult>;
    pub async fn load_project_memory(&self, project_root: &PathBuf) -> Result<Option<ProjectContext>>;
    // 9 个只读查询方法
    pub fn config(&self) -> &CoordinatorConfig;
    pub fn project_root(&self) -> &PathBuf;
    pub async fn execution_status(&self) -> Option<ExecutionStatus>;
    pub async fn is_busy(&self) -> bool;
    pub fn project_context(&self) -> Option<&Arc<ProjectContext>>;
    pub async fn complexity_config(&self) -> ComplexityConfig;
    pub async fn memory_state(&self) -> Option<MemoryState>;
    pub fn registered_agents(&self) -> Vec<AgentType>;
    pub async fn recursive_stats(&self) -> Option<RecursiveStats>;
}
```

## P5-2 测试要点

| 测试场景 | 验证内容 | 预期结果 |
|----------|----------|----------|
| handle_request 完整流程 | 九步管道 | 返回 CoordinatorResponse |
| recognize_intent LLM 主 | 正常响应 | IntentAnalysis |
| recognize_intent 关键词快速 | "修复 typo" | 快速路径，零 LLM |
| recognize_intent 关键词回退 | LLM 失败 | keyword_fallback |
| parse_or_repair_json 首次成功 | 合法 JSON | 直接解析 |
| parse_or_repair_json 二次失败 | 非法 JSON | IntentParseFailed |
| ComplexityConfig 默认值 | Default | simple_max=15 |
| calibrate_from_history | 20+ 条 | 调整后配置 |
| calibrate_from_history | < 20 条 | None |
| RouteLevel 路由 | Simple/Medium/Complex/Research | 正确 Agent 集合 |
| handle_daemon_task | 共享上下文 | 零交接 |
| dispatch_tasks_streaming | StreamForwarder | 实时推送 |
| integrate_results | 多 Agent | 正确聚合 |
| load_project_memory | 有效记忆 | Some |
| load_project_memory | 不存在 | None，不报错 |

---

# P6-1 mc-daemon Daemon 模式

## P6-1 模块概述

`mc-daemon` 实现 7x24 小时自主运行的守护模式。支持三种自主级别：SemiAuto（半自动）、FullAuto（全自动）、MonitorOnly（仅监控）。核心挑战包括错误恢复、上下文窗口管理、进度持久化、通知机制和成本控制。

**Crate 路径**：`crates/mc-daemon/`

## P6-1 架构文档引用

- **主文档**：`20-Daemon模式.md`（全文）
- **补充文档**：`22-中断与取消机制.md`

## P6-1 大模型开发提示词

```
你正在实现 MoreCode Agent 系统的 Daemon 模式（mc-daemon crate）。

核心职责：
1. Daemon 生命周期管理（Idle -> Running -> Paused -> WaitingApproval -> ShuttingDown）
2. 基于 tokio::select! 的事件驱动主循环（8 个事件源）
3. 优雅关闭（CancellationToken + 信号处理 + 10s 宽限）
4. 任务去重（全角->半角中文标准化 + xxhash）
5. 重试策略（tokio::spawn 异步延迟入队）
6. Checkpoint 安全（符号链接检查、原子写入、目录权限 700）
7. 自适应超时（5s~600s）
8. 健康检查和 PID 管理

参考架构文档：20-Daemon模式.md、22-中断与取消机制.md
```

## P6-1 核心类型定义

### Daemon struct & DaemonConfig

```rust
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Duration;

use chrono::{DateTime, NaiveTime, Utc};
use serde::{Deserialize, Serialize};
use tokio::sync::{watch, mpsc, RwLock};
use tokio_util::sync::CancellationToken;

pub struct Daemon {
    pub config: DaemonConfig,
    state: RwLock<DaemonState>,
    cancel_token: CancellationToken,
    event_tx: mpsc::Sender<DaemonEvent>,
    event_rx: RwLock<Option<mpsc::Receiver<DaemonEvent>>>,
    project_root: PathBuf,
    pid_file: PathBuf,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum DaemonState {
    Idle,
    Running { started_at: DateTime<Utc>, tasks_completed: usize, tasks_failed: usize },
    Paused { reason: String },
    WaitingApproval { pending_id: String, timeout: DateTime<Utc> },
    ShuttingDown,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DaemonConfig {
    pub autonomy_level: AutonomyLevel,
    pub max_run_duration: Option<Duration>,
    pub task_sources: Vec<TaskSource>,
    pub approval_policy: ApprovalPolicy,
    pub notification_config: NotificationConfig,
    pub resource_limits: ResourceLimits,
    pub checkpoint_config: CheckpointConfig,
    pub architecture_config: ArchitectureConfig,
}

impl Default for DaemonConfig {
    fn default() -> Self {
        Self {
            autonomy_level: AutonomyLevel::SemiAuto,
            max_run_duration: None,
            task_sources: vec![TaskSource::UserRequest],
            approval_policy: ApprovalPolicy::default(),
            notification_config: NotificationConfig::default(),
            resource_limits: ResourceLimits::default(),
            checkpoint_config: CheckpointConfig::default(),
            architecture_config: ArchitectureConfig::default(),
        }
    }
}
```

### AutonomyLevel

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum AutonomyLevel { SemiAuto, FullAuto, MonitorOnly }
```

### ApprovalPolicy

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApprovalPolicy {
    #[serde(default = "default_true")]
    pub deploy_requires_approval: bool,
    #[serde(default = "default_true")]
    pub architecture_requires_approval: bool,
    #[serde(default = "default_true")]
    pub breaking_change_requires_approval: bool,
    #[serde(default = "default_bug_severity")]
    pub max_auto_fix_severity: BugSeverity,
    #[serde(default = "default_approval_timeout")]
    pub approval_timeout: Duration,
}

fn default_true() -> bool { true }
fn default_bug_severity() -> BugSeverity { BugSeverity::Medium }
fn default_approval_timeout() -> Duration { Duration::from_secs(30 * 60) }
```

### BugSeverity

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord)]
pub enum BugSeverity { Low, Medium, High, Critical }
```

### NotificationConfig & NotificationChannel

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NotificationConfig {
    pub channels: Vec<NotificationChannel>,
    pub important_events: Vec<EventType>,
    pub quiet_hours: Option<(NaiveTime, NaiveTime)>,
    #[serde(default)]
    pub digest_mode: bool,
}

impl Default for NotificationConfig {
    fn default() -> Self {
        Self {
            channels: vec![NotificationChannel::Terminal { bell: true }],
            important_events: vec![
                EventType::TaskFailed, EventType::ApprovalNeeded,
                EventType::CostWarning, EventType::ErrorEscalation,
            ],
            quiet_hours: None, digest_mode: false,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum NotificationChannel {
    Terminal { bell: bool },
    Desktop { os_notification: bool },
    Webhook { url: String, headers: HashMap<String, String> },
    Email { smtp_config: SmtpConfig },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SmtpConfig {
    pub server: String, pub port: u16,
    pub username: String, pub password: String,
    pub from: String, pub to: Vec<String>,
}
```

### EventType（10 变体）

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum EventType {
    TaskCompleted, TaskFailed, BugFixed, ApprovalNeeded,
    CheckpointCreated, CostWarning, ErrorEscalation,
    ArchitecturePlanReady, DependencyUpdated, PerformanceDegradation,
}
```

### ResourceLimits

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceLimits {
    #[serde(default = "default_max_concurrent")]
    pub max_concurrent_tasks: usize,
    #[serde(default = "default_hourly_tokens")]
    pub max_tokens_per_hour: usize,
    #[serde(default = "default_daily_cost")]
    pub max_cost_per_day: f64,
    #[serde(default = "default_commits_per_hour")]
    pub max_git_commits_per_hour: usize,
    #[serde(default = "default_cooldown")]
    pub cooldown_between_tasks: Duration,
}

fn default_max_concurrent() -> usize { 3 }
fn default_hourly_tokens() -> usize { 500_000 }
fn default_daily_cost() -> f64 { 10.0 }
fn default_commits_per_hour() -> usize { 10 }
fn default_cooldown() -> Duration { Duration::from_secs(30) }

impl Default for ResourceLimits {
    fn default() -> Self {
        Self {
            max_concurrent_tasks: default_max_concurrent(),
            max_tokens_per_hour: default_hourly_tokens(),
            max_cost_per_day: default_daily_cost(),
            max_git_commits_per_hour: default_commits_per_hour(),
            cooldown_between_tasks: default_cooldown(),
        }
    }
}
```

### TaskSource（6 变体）

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum TaskSource {
    GitHook { event_type: String },
    LogMonitor { pattern: String, log_path: String },
    CronSchedule { cron_expr: String, task_type: String },
    UserRequest,
    DependencyUpdate { check_interval: Duration },
    PerformanceMonitor { metric_type: String },
}
```

### TaskPriority（5 级）

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum TaskPriority { Critical = 0, High = 1, Medium = 2, Low = 3, Info = 4 }
```

### CheckpointConfig & Checkpoint

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CheckpointConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    #[serde(default = "default_checkpoint_interval")]
    pub interval: Duration,
    #[serde(default = "default_max_checkpoints")]
    pub max_checkpoints: usize,
    #[serde(default = "default_true")]
    pub on_error: bool,
}

fn default_checkpoint_interval() -> Duration { Duration::from_secs(5 * 60) }
fn default_max_checkpoints() -> usize { 100 }

impl Default for CheckpointConfig {
    fn default() -> Self {
        Self { enabled: true, interval: default_checkpoint_interval(),
            max_checkpoints: default_max_checkpoints(), on_error: true }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Checkpoint {
    pub id: String,
    pub created_at: DateTime<Utc>,
    pub daemon_state: DaemonState,
    /// task_queue_snapshot 存储优化注释：
    /// 仅存储任务 ID 和优先级，不存储完整任务描述，
    /// 完整任务数据从持久化队列恢复。
    pub task_queue_snapshot: Vec<(String, TaskPriority)>,
    pub active_task_ids: Vec<String>,
    pub cost_snapshot: CostSnapshot,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CostSnapshot {
    pub tokens_used_today: u64,
    pub cost_today: f64,
    pub tokens_used_this_hour: u64,
}
```

### ArchitectureConfig & RefactorScope

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArchitectureConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    pub max_refactor_scope: RefactorScope,
    #[serde(default = "default_true")]
    pub require_design_doc: bool,
    #[serde(default)]
    pub design_doc_review: bool,
    #[serde(default = "default_true")]
    pub rollback_on_failure: bool,
}

impl Default for ArchitectureConfig {
    fn default() -> Self {
        Self { enabled: true, max_refactor_scope: RefactorScope::CrossModule,
            require_design_doc: true, design_doc_review: false, rollback_on_failure: true }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RefactorScope { Module, CrossModule, ProjectWide }
```

### run_loop（interval 定时器、8 个事件）

```rust
impl Daemon {
    pub async fn run_loop(&self) {
        let mut checkpoint_timer = tokio::time::interval(self.config.checkpoint_config.interval);
        let mut cost_check_interval = tokio::time::interval(Duration::from_secs(60));

        loop {
            let state = self.state.read().await.clone();
            if matches!(state, DaemonState::ShuttingDown) { break; }

            tokio::select! {
                // 事件 1：新任务到达
                Some(task) = self.task_queue.next(), if self.is_running() => {
                    self.handle_new_task(task).await;
                }
                // 事件 2：编排器返回结果
                result = self.orchestrator.next_result() => {
                    self.handle_task_result(result).await;
                }
                // 事件 3：审批响应
                Some(response) = self.approval_rx.recv() => {
                    self.handle_approval_response(response).await;
                }
                // 事件 4：定期检查点
                _ = checkpoint_timer.tick(), if self.config.checkpoint_config.enabled => {
                    self.create_checkpoint().await;
                }
                // 事件 5：关闭信号
                _ = self.cancel_token.cancelled() => {
                    self.graceful_shutdown().await; break;
                }
                // 事件 6：配置热重载
                _ = self.config_watch.rx.changed() => {
                    self.reload_config().await;
                }
                // 事件 7：审批超时
                _ = tokio::time::sleep_until(self.next_approval_timeout()) => {
                    self.handle_approval_timeout().await;
                }
                // 事件 8：成本检查
                _ = cost_check_interval.tick() => {
                    self.check_cost_limits().await;
                }
            }
        }
    }

    fn is_running(&self) -> bool {
        matches!(*self.state.read().blocking_read(), DaemonState::Running { .. })
    }
}
```

### graceful_shutdown（CancellationToken + 信号处理）

```rust
impl Daemon {
    pub async fn graceful_shutdown(&self) {
        *self.state.write().await = DaemonState::ShuttingDown;
        self.task_queue.shutdown().await;
        let drain_result = tokio::time::timeout(
            Duration::from_secs(300), self.orchestrator.drain(),
        ).await;
        if drain_result.is_err() {
            tracing::warn!("优雅关闭超时，强制终止");
            self.orchestrator.abort_all();
        }
        self.create_checkpoint().await;
        tracing::info!("Daemon 优雅关闭完成");
    }
}
```

### SignalHandler（AtomicUsize ctrl_c_count、grace_timeout 可配置）

```rust
pub struct SignalHandler {
    cancel_token: CancellationToken,
    force_cancel_token: CancellationToken,
    shutdown_complete: CancellationToken,
    ctrl_c_count: AtomicUsize,
    grace_timeout: Duration,
}

impl SignalHandler {
    pub fn new(cancel_token: CancellationToken, grace_timeout: Duration) -> Self {
        Self {
            force_cancel_token: cancel_token.child_token(),
            shutdown_complete: CancellationToken::new(),
            cancel_token, ctrl_c_count: AtomicUsize::new(0), grace_timeout,
        }
    }

    pub async fn run(&mut self) {
        loop {
            tokio::signal::ctrl_c().await.unwrap();
            let count = self.ctrl_c_count.fetch_add(1, Ordering::SeqCst) + 1;
            match count {
                1 => self.start_graceful_cancel().await,
                2 => self.force_cancel_token.cancel(),
                _ => {
                    tracing::error!("第三次 Ctrl+C，紧急清理");
                    self.force_cancel_token.cancel();
                    tokio::time::sleep(Duration::from_millis(100)).await;
                    break;
                }
            }
        }
    }

    async fn start_graceful_cancel(&self) {
        self.cancel_token.cancel();
        let force = self.force_cancel_token.clone();
        let complete = self.shutdown_complete.clone();
        let timeout = self.grace_timeout;
        tokio::spawn(async move {
            tokio::select! {
                _ = complete.cancelled() => {}
                _ = tokio::time::sleep(timeout) => {
                    tracing::warn!("graceful shutdown timed out");
                    force.cancel();
                }
            }
        });
    }
}
```

### compute_dedup_hash（全角->半角中文标准化）

```rust
impl DaemonTask {
    pub fn compute_dedup_hash(description: &str, source: &TaskSource) -> String {
        use std::hash::{Hash, Hasher};
        use xxhash_rust::xxh3::Xxh3;
        let mut hasher = Xxh3::new();
        let normalized: String = description.chars().map(|c| {
            if c.is_ascii_uppercase() { c.to_ascii_lowercase() }
            else if ('\u{FF01}'..='\u{FF5E}').contains(&c) {
                char::from_u32(c as u32 - 0xFEE0).unwrap_or(c)
            } else { c }
        }).collect();
        let normalized: String = normalized.split_whitespace().collect::<Vec<_>>().join(" ");
        normalized.hash(&mut hasher);
        source.hash(&mut hasher);
        format!("{:x}", hasher.finish())
    }
}
```

### 重试策略（tokio::spawn 异步延迟入队）

```rust
impl Daemon {
    async fn handle_task_result(&self, result: TaskResult) {
        match result.status {
            ExecutionStatus::Completed => {
                if let DaemonState::Running { tasks_completed, .. } =
                    &mut *self.state.write().await { *tasks_completed += 1; }
            }
            ExecutionStatus::Failed { error } => {
                let retryable = is_recoverable_error(&error);
                if retryable && result.retry_count < result.max_retries {
                    let backoff = Duration::from_secs(1_i64 * 2_i64.pow(result.retry_count));
                    let task_queue = self.task_queue.clone();
                    let original_task = result.original_task.clone();
                    tokio::spawn(async move {
                        tokio::time::sleep(backoff).await;
                        task_queue.requeue_with_retry(original_task).await;
                    });
                } else {
                    if let DaemonState::Running { tasks_failed, .. } =
                        &mut *self.state.write().await { *tasks_failed += 1; }
                }
            }
        }
    }
}
```

### Checkpoint 安全要求（符号链接检查、原子写入、目录权限 700、定期清理）

```rust
impl CheckpointManager {
    pub async fn safe_write_checkpoint(
        &self, checkpoint: &Checkpoint, path: &Path,
    ) -> Result<()> {
        // 1. 符号链接检查
        if path.is_symlink() {
            anyhow::bail!("Checkpoint 路径是符号链接，拒绝写入: {:?}", path);
        }
        // 2. 目录权限 700
        if let Some(parent) = path.parent() {
            if parent.exists() {
                let perms = std::fs::metadata(parent)?.permissions();
                if (perms.mode() & 0o777) != 0o700 {
                    std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700))?;
                }
            } else {
                std::fs::create_dir_all(parent)?;
                std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700))?;
            }
        }
        // 3. 原子写入
        let temp_path = path.with_extension("tmp");
        let json = serde_json::to_string_pretty(checkpoint)?;
        tokio::fs::write(&temp_path, &json).await?;
        tokio::fs::rename(&temp_path, path).await?;
        // 4. 定期清理
        self.cleanup_old_checkpoints().await?;
        Ok(())
    }

    async fn cleanup_old_checkpoints(&self) -> Result<()> {
        let max = self.config.max_checkpoints;
        let entries: Vec<_> = tokio::fs::read_dir(&self.checkpoint_dir).await?
            .filter_map(|e| e.ok())
            .filter(|e| e.path().extension().map(|ext| ext == "json").unwrap_or(false))
            .collect();
        if entries.len() > max {
            let mut entries = entries;
            entries.sort_by_key(|e| e.metadata().ok().and_then(|m| m.modified().ok())
                .unwrap_or(std::time::SystemTime::UNIX_EPOCH));
            for entry in entries.iter().take(entries.len() - max) {
                tokio::fs::remove_file(entry.path()).await?;
            }
        }
        Ok(())
    }
}
```

### 自适应超时（硬性上下限 5s~600s、HMAC 校验）

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdaptiveTimeoutConfig {
    pub llm_call: Duration,
    pub tool_execution: Duration,
    pub code_execution: Duration,
    pub agent_total: Duration,
    pub pipeline_total: Duration,
    pub adaptive: bool,
}

impl Default for AdaptiveTimeoutConfig {
    fn default() -> Self {
        Self {
            llm_call: Duration::from_secs(60), tool_execution: Duration::from_secs(30),
            code_execution: Duration::from_secs(120), agent_total: Duration::from_secs(300),
            pipeline_total: Duration::from_secs(1800), adaptive: true,
        }
    }
}

impl AdaptiveTimeoutConfig {
    /// P95 + 20%，硬性上下限 5s~600s
    pub fn compute_adaptive_timeout(&self, timeout_type: &str, history: &[Duration]) -> Duration {
        if !self.adaptive || history.is_empty() { return self.get_default(timeout_type); }
        let mut sorted = history.to_vec();
        sorted.sort();
        let p95 = sorted.get((sorted.len() as f64 * 0.95) as usize.min(sorted.len() - 1))
            .copied().unwrap_or(Duration::from_secs(60));
        let adaptive = p95 + p95.mul_f32(0.2);
        adaptive.clamp(Duration::from_secs(5), Duration::from_secs(600))
    }

    fn get_default(&self, timeout_type: &str) -> Duration {
        match timeout_type {
            "llm_call" => self.llm_call, "tool_execution" => self.tool_execution,
            "code_execution" => self.code_execution, "agent_total" => self.agent_total,
            "pipeline_total" => self.pipeline_total, _ => Duration::from_secs(60),
        }
    }
}
```

### 健康检查、PID 管理

```rust
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum HealthStatus { Healthy, Degraded { reason: String }, Unhealthy { reason: String } }

impl Daemon {
    pub async fn health_check(&self) -> HealthStatus {
        if let Err(e) = self.llm_client.health_check().await {
            return HealthStatus::Degraded { reason: format!("LLM 不可达: {}", e) };
        }
        let queue_size = self.task_queue.len().await;
        if queue_size > 1000 {
            return HealthStatus::Degraded { reason: format!("队列积压: {}", queue_size) };
        }
        let cost = self.cost_tracker.cost_today().await;
        if cost > self.config.resource_limits.max_cost_per_day * 0.9 {
            return HealthStatus::Degraded { reason: format!("成本接近上限: ${:.2}", cost) };
        }
        HealthStatus::Healthy
    }

    pub async fn acquire_pid_file(&self) -> Result<()> {
        if self.pid_file.exists() {
            let existing = tokio::fs::read_to_string(&self.pid_file).await?;
            if is_process_running(&existing) {
                anyhow::bail!("Daemon 已运行（PID: {}）", existing.trim());
            }
        }
        tokio::fs::write(&self.pid_file, std::process::id().to_string()).await?;
        Ok(())
    }

    pub async fn release_pid_file(&self) {
        let _ = tokio::fs::remove_file(&self.pid_file).await;
    }
}

fn is_process_running(pid_str: &str) -> bool {
    let pid: u32 = match pid_str.trim().parse() { Ok(p) => p, Err(_) => return false };
    std::path::Path::new(&format!("/proc/{}", pid)).exists()
}
```

### IncrementalCheckpoint & CheckpointDelta（增量检查点）

```rust
/// 增量检查点（支持部分恢复）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IncrementalCheckpoint {
    pub base_id: String,
    pub delta: CheckpointDelta,
    pub changed_agents: Vec<String>,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CheckpointDelta {
    AgentCompleted { agent_id: String, result: TaskResult },
    FileChanged { path: String, content_hash: String },
    TokenUsageUpdate { delta: u64 },
}
```

### TimeoutConfig（分层超时配置）

```rust
/// 分层超时配置
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimeoutConfig {
    pub llm_call: Duration,        // 默认 60s
    pub tool_execution: Duration,  // 默认 30s
    pub code_execution: Duration,  // 默认 120s
    pub agent_total: Duration,     // 默认 300s
    pub pipeline_total: Duration,  // 默认 1800s
    pub adaptive: bool,            // 默认 true
}
```

## P6-1 功能需求清单

| 编号 | 功能 | 优先级 | 说明 |
|------|------|--------|------|
| FR-DMN-001 | Daemon struct | P0 | 完整配置和状态 |
| FR-DMN-002 | DaemonConfig | P0 | 8 个配置段 |
| FR-DMN-003 | AutonomyLevel | P0 | 三级 |
| FR-DMN-004 | ApprovalPolicy | P0 | deploy/architecture/breaking_change |
| FR-DMN-005 | EventType 10 变体 | P0 | 完整覆盖 |
| FR-DMN-006 | ResourceLimits | P0 | 5 个限制项 |
| FR-DMN-007 | TaskSource 6 变体 | P0 | 完整覆盖 |
| FR-DMN-008 | TaskPriority 5 级 | P0 | Critical~Info |
| FR-DMN-009 | CheckpointConfig | P0 | enabled/interval/max |
| FR-DMN-010 | Checkpoint struct | P0 | task_queue_snapshot 优化 |
| FR-DMN-011 | run_loop 8 事件 | P0 | tokio::select! |
| FR-DMN-012 | graceful_shutdown | P0 | CancellationToken |
| FR-DMN-013 | SignalHandler | P0 | ctrl_c_count + grace_timeout |
| FR-DMN-014 | compute_dedup_hash | P0 | 全角->半角 |
| FR-DMN-015 | 重试策略 | P0 | tokio::spawn |
| FR-DMN-016 | Checkpoint 安全 | P0 | 符号链接/原子写入/700 |
| FR-DMN-017 | 定期清理 | P1 | 保留 N 个 |
| FR-DMN-018 | 自适应超时 | P1 | 5s~600s |
| FR-DMN-019 | 健康检查 | P0 | 三级状态 |
| FR-DMN-020 | PID 管理 | P0 | 创建/冲突/清理 |

## P6-1 接口契约

```rust
impl Daemon {
    pub fn new(config: DaemonConfig, project_root: PathBuf) -> Result<Self>;
    pub async fn start(&self) -> Result<()>;
    pub async fn pause(&self, reason: &str);
    pub async fn resume(&self);
    pub async fn graceful_shutdown(&self);
    pub async fn health_check(&self) -> HealthStatus;
    pub async fn acquire_pid_file(&self) -> Result<()>;
    pub async fn release_pid_file(&self);
    pub async fn run_loop(&self);
}

impl DaemonTask {
    pub fn compute_dedup_hash(description: &str, source: &TaskSource) -> String;
}

impl CheckpointManager {
    pub async fn safe_write_checkpoint(&self, checkpoint: &Checkpoint, path: &Path) -> Result<()>;
    pub async fn restore_latest(&self) -> Result<Option<Checkpoint>>;
}

impl SignalHandler {
    pub fn new(cancel_token: CancellationToken, grace_timeout: Duration) -> Self;
    pub async fn run(&mut self);
}

impl AdaptiveTimeoutConfig {
    pub fn compute_adaptive_timeout(&self, timeout_type: &str, history: &[Duration]) -> Duration;
}
```

## P6-1 测试要点

| 测试场景 | 验证内容 | 预期结果 |
|----------|----------|----------|
| Daemon 状态机 | Idle -> Running -> Paused -> ShuttingDown | 正确转换 |
| graceful_shutdown | CancellationToken | 所有任务完成 |
| shutdown 超时 | 超时 | abort_all |
| SIGINT 处理 | 信号 | shutdown 流程 |
| 健康检查 | 健康 | Healthy |
| PID 管理 | 冲突 | 拒绝启动 |
| compute_dedup_hash | 全角/半角 | 标准化一致 |
| 指数退避 | 1s->2s->4s | 上限 300s |
| Checkpoint 符号链接 | 符号链接 | 拒绝写入 |
| Checkpoint 原子写入 | 正常 | tmp + rename |
| Checkpoint 目录权限 | 非 700 | 修正为 700 |
| 自适应超时 | P95+20% | 5s~600s |

---

# P6-2 mc-tui 终端界面

## P6-2 模块概述

`mc-tui` 基于 Ratatui + Crossterm 构建终端用户界面，提供实时可视化展示 Agent 执行状态、任务进度、代码差异、日志输出和审批对话框。

**Crate 路径**：`crates/mc-tui/`

## P6-2 架构文档引用

- **主文档**：`28-CLI颜色设计.md`（全文）——SemanticColor 枚举、Theme trait、DarkTheme、颜色降级
- **补充文档**：`25-代码目录与文件命名设计.md`（3.14 节）

## P6-2 大模型开发提示词

```
你正在实现 MoreCode Agent 系统的终端界面（mc-tui crate）。

核心职责：
1. App struct（TUI 状态管理）
2. crossterm 事件处理（键盘、鼠标、调整大小）
3. 5 个视图：dashboard、agent_progress、code_diff、log_panel、approval_dialog
4. SemanticColor 体系集成
5. Theme trait 和 DarkTheme
6. 实时渲染（消费 AgentEvent）

参考架构文档：28-CLI颜色设计.md
```

## P6-2 核心类型定义

### App struct（TUI 状态）

```rust
use std::collections::VecDeque;
use crossterm::event::{Event, KeyCode, KeyEvent, MouseEvent, MouseEventKind};
use ratatui::style::Color;
use ratatui::Frame;
use serde::{Deserialize, Serialize};
use mc_core::agent::AgentType;

pub struct App {
    pub active_view: ActiveView,
    pub dashboard: DashboardState,
    pub agent_progress: AgentProgressState,
    pub code_diff: CodeDiffState,
    pub log_panel: LogPanelState,
    pub approval_dialog: Option<ApprovalDialogState>,
    pub should_quit: bool,
    pub event_queue: VecDeque<AgentEvent>,
    pub color_resolver: ColorResolver,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ActiveView { Dashboard, AgentProgress, CodeDiff, LogPanel, ApprovalDialog }

#[derive(Debug, Clone, Default)]
pub struct DashboardState {
    pub total_tasks: usize,
    pub completed_tasks: usize,
    pub failed_tasks: usize,
    pub active_agents: usize,
    pub token_usage: TokenUsageDisplay,
    pub cost_today: f64,
}

#[derive(Debug, Clone, Default)]
pub struct AgentProgressState { pub agents: Vec<AgentProgressEntry> }

#[derive(Debug, Clone)]
pub struct AgentProgressEntry {
    pub agent_type: AgentType,
    pub agent_id: String,
    pub status: AgentTuiStatus,
    pub progress_percent: f32,
    pub current_phase: String,
    pub tokens_used: usize,
}

#[derive(Debug, Clone, PartialEq)]
pub enum AgentTuiStatus { Pending, Running, Completed, Failed, Cancelled }

#[derive(Debug, Clone, Default)]
pub struct CodeDiffState {
    pub diffs: Vec<FileDiff>,
    pub scroll_offset: usize,
    pub selected_file: usize,
}

#[derive(Debug, Clone)]
pub struct FileDiff {
    pub file_path: String,
    pub diff_type: DiffType,
    pub additions: usize,
    pub deletions: usize,
    pub content: String,
}

#[derive(Debug, Clone, PartialEq)]
pub enum DiffType { Added, Modified, Deleted }

#[derive(Debug, Clone, Default)]
pub struct LogPanelState {
    pub logs: VecDeque<LogEntry>,
    pub max_logs: usize,
    pub filter_level: Option<LogLevel>,
    pub scroll_offset: usize,
    pub auto_scroll: bool,
}

#[derive(Debug, Clone)]
pub struct LogEntry {
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub level: LogLevel,
    pub source: String,
    pub message: String,
}

#[derive(Debug, Clone, PartialEq, PartialOrd)]
pub enum LogLevel { Trace, Debug, Info, Warn, Error }

#[derive(Debug, Clone)]
pub struct ApprovalDialogState {
    pub request_id: String,
    pub task_description: String,
    pub action: String,
    pub risk_level: String,
    pub selected_option: ApprovalOption,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ApprovalOption { Approve, Reject, Modify }

#[derive(Debug, Clone, Default)]
pub struct TokenUsageDisplay {
    pub input_tokens: usize,
    pub output_tokens: usize,
    pub total_tokens: usize,
    pub budget_percent: f32,
}
```

### 事件处理（crossterm）

```rust
impl App {
    pub fn handle_event(&mut self, event: Event) {
        match event {
            Event::Key(key) => self.handle_key_event(key),
            Event::Mouse(mouse) => self.handle_mouse_event(mouse),
            Event::Resize(_, _) => {}
            _ => {}
        }
    }

    fn handle_key_event(&mut self, key: KeyEvent) {
        if self.approval_dialog.is_some() {
            self.handle_approval_key(key);
            return;
        }
        match key.code {
            KeyCode::Char('q') | KeyCode::Esc => self.should_quit = true,
            KeyCode::Tab => self.cycle_view(),
            KeyCode::Char('1') => self.active_view = ActiveView::Dashboard,
            KeyCode::Char('2') => self.active_view = ActiveView::AgentProgress,
            KeyCode::Char('3') => self.active_view = ActiveView::CodeDiff,
            KeyCode::Char('4') => self.active_view = ActiveView::LogPanel,
            KeyCode::Char('j') | KeyCode::Down => self.scroll_down(),
            KeyCode::Char('k') | KeyCode::Up => self.scroll_up(),
            KeyCode::Char('G') => self.scroll_to_bottom(),
            KeyCode::Char('g') => self.scroll_to_top(),
            _ => {}
        }
    }

    fn handle_mouse_event(&mut self, mouse: MouseEvent) {
        match mouse.kind {
            MouseEventKind::ScrollDown => self.scroll_down(),
            MouseEventKind::ScrollUp => self.scroll_up(),
            _ => {}
        }
    }

    fn handle_approval_key(&mut self, key: KeyEvent) {
        if let Some(dialog) = &mut self.approval_dialog {
            match key.code {
                KeyCode::Char('y') | KeyCode::Char('Y') => dialog.selected_option = ApprovalOption::Approve,
                KeyCode::Char('n') | KeyCode::Char('N') => dialog.selected_option = ApprovalOption::Reject,
                KeyCode::Char('m') | KeyCode::Char('M') => dialog.selected_option = ApprovalOption::Modify,
                KeyCode::Enter => self.submit_approval(),
                KeyCode::Esc => self.approval_dialog = None,
                _ => {}
            }
        }
    }

    fn cycle_view(&mut self) {
        self.active_view = match self.active_view {
            ActiveView::Dashboard => ActiveView::AgentProgress,
            ActiveView::AgentProgress => ActiveView::CodeDiff,
            ActiveView::CodeDiff => ActiveView::LogPanel,
            ActiveView::LogPanel => ActiveView::Dashboard,
            ActiveView::ApprovalDialog => ActiveView::Dashboard,
        };
    }

    fn scroll_down(&mut self) {
        match self.active_view {
            ActiveView::LogPanel => self.log_panel.scroll_offset += 1,
            ActiveView::CodeDiff => self.code_diff.scroll_offset += 1,
            _ => {}
        }
    }

    fn scroll_up(&mut self) {
        match self.active_view {
            ActiveView::LogPanel => self.log_panel.scroll_offset = self.log_panel.scroll_offset.saturating_sub(1),
            ActiveView::CodeDiff => self.code_diff.scroll_offset = self.code_diff.scroll_offset.saturating_sub(1),
            _ => {}
        }
    }

    fn scroll_to_bottom(&mut self) {
        if matches!(self.active_view, ActiveView::LogPanel) {
            self.log_panel.scroll_offset = self.log_panel.logs.len().saturating_sub(1);
        }
    }

    fn scroll_to_top(&mut self) {
        match self.active_view {
            ActiveView::LogPanel => self.log_panel.scroll_offset = 0,
            ActiveView::CodeDiff => self.code_diff.scroll_offset = 0,
            _ => {}
        }
    }

    fn submit_approval(&mut self) {
        if let Some(dialog) = self.approval_dialog.take() {
            // 通过 EventBus 发送审批响应
        }
    }
}
```

### 视图：dashboard、agent_progress、code_diff、log_panel、approval_dialog

```rust
impl App {
    /// 渲染 dashboard 视图
    pub fn render_dashboard(&self, frame: &mut Frame, area: ratatui::layout::Rect) {
        // 使用 SemanticColor 渲染仪表盘
        // 显示：总任务数、完成数、失败数、活跃 Agent 数、Token 用量、成本
    }

    /// 渲染 agent_progress 视图
    pub fn render_agent_progress(&self, frame: &mut Frame, area: ratatui::layout::Rect) {
        // 每个 Agent 一行：类型颜色 + ID + 进度条 + Token 用量
        // 使用 SemanticColor::AgentCoder 等区分 Agent
    }

    /// 渲染 code_diff 视图
    pub fn render_code_diff(&self, frame: &mut Frame, area: ratatui::layout::Rect) {
        // 使用 SemanticColor::GitAdded/GitDeleted/GitModified 着色
        // 支持滚动和文件选择
    }

    /// 渲染 log_panel 视图
    pub fn render_log_panel(&self, frame: &mut Frame, area: ratatui::layout::Rect) {
        // 使用 SemanticColor::TextPrimary/TextSecondary/TextMuted
        // 支持日志级别过滤和滚动
    }

    /// 渲染 approval_dialog 视图
    pub fn render_approval_dialog(&self, frame: &mut Frame, area: ratatui::layout::Rect) {
        // 显示审批请求详情和 Y/N/M 操作提示
        // 使用 SemanticColor::Warning/Error/Info
    }
}
```

### SemanticColor 体系（28-CLI颜色设计.md）

（SemanticColor 枚举完整定义见 P6-2 核心类型定义中的 App struct 部分，共 70+ 个变体。完整 71 变体映射见 `28-CLI颜色设计.md`。）

### Theme trait、DarkTheme

```rust
pub trait Theme {
    fn color(&self, semantic: SemanticColor) -> Color;
    fn supports_truecolor(&self) -> bool;
    fn name(&self) -> &str;
}

pub struct DarkTheme;

impl Theme for DarkTheme {
    fn color(&self, semantic: SemanticColor) -> Color {
        match semantic {
            // Status (6)
            SemanticColor::Success => Color::Rgb(74, 222, 128),
            SemanticColor::Error => Color::Rgb(248, 113, 113),
            SemanticColor::Warning => Color::Rgb(251, 191, 36),
            SemanticColor::Info => Color::Rgb(96, 165, 250),
            SemanticColor::Tips => Color::Rgb(167, 139, 250),
            SemanticColor::Debug => Color::Rgb(148, 163, 184),
            // Agent (10)
            SemanticColor::AgentCoordinator => Color::Rgb(244, 114, 182),
            SemanticColor::AgentExplorer => Color::Rgb(251, 146, 60),
            SemanticColor::AgentImpact => Color::Rgb(251, 191, 36),
            SemanticColor::AgentPlanner => Color::Rgb(167, 139, 250),
            SemanticColor::AgentCoder => Color::Rgb(96, 165, 250),
            SemanticColor::AgentReviewer => Color::Rgb(45, 212, 191),
            SemanticColor::AgentTester => Color::Rgb(74, 222, 128),
            SemanticColor::AgentResearch => Color::Rgb(96, 165, 250),
            SemanticColor::AgentDocWriter => Color::Rgb(148, 163, 184),
            SemanticColor::AgentDebugger => Color::Rgb(248, 113, 113),
            // Route (4)
            SemanticColor::RouteSimple => Color::Rgb(74, 222, 128),
            SemanticColor::RouteMedium => Color::Rgb(251, 191, 36),
            SemanticColor::RouteComplex => Color::Rgb(248, 113, 113),
            SemanticColor::RouteResearch => Color::Rgb(96, 165, 250),
            // Command (6)
            SemanticColor::CommandRun => Color::Rgb(96, 165, 250),
            SemanticColor::CommandOutput => Color::Rgb(241, 245, 249),
            SemanticColor::CommandError => Color::Rgb(248, 113, 113),
            SemanticColor::CommandPath => Color::Rgb(45, 212, 191),
            SemanticColor::CommandArg => Color::Rgb(251, 191, 36),
            SemanticColor::CommandKeyword => Color::Rgb(167, 139, 250),
            // Syntax (12)
            SemanticColor::SyntaxKeyword => Color::Rgb(167, 139, 250),
            SemanticColor::SyntaxString => Color::Rgb(74, 222, 128),
            SemanticColor::SyntaxNumber => Color::Rgb(251, 191, 36),
            SemanticColor::SyntaxType => Color::Rgb(96, 165, 250),
            SemanticColor::SyntaxComment => Color::Rgb(100, 116, 139),
            SemanticColor::SyntaxFunction => Color::Rgb(96, 165, 250),
            SemanticColor::SyntaxMacro => Color::Rgb(251, 146, 60),
            SemanticColor::SyntaxLifetime => Color::Rgb(45, 212, 191),
            SemanticColor::SyntaxAttribute => Color::Rgb(167, 139, 250),
            SemanticColor::SyntaxVariable => Color::Rgb(241, 245, 249),
            SemanticColor::SyntaxOperator => Color::Rgb(148, 163, 184),
            SemanticColor::SyntaxPunctuation => Color::Rgb(100, 116, 139),
            // Git (9)
            SemanticColor::GitAdded => Color::Rgb(74, 222, 128),
            SemanticColor::GitDeleted => Color::Rgb(248, 113, 113),
            SemanticColor::GitModified => Color::Rgb(251, 191, 36),
            SemanticColor::GitHash => Color::Rgb(167, 139, 250),
            SemanticColor::GitBranch => Color::Rgb(96, 165, 250),
            SemanticColor::GitTag => Color::Rgb(45, 212, 191),
            SemanticColor::GitStaged => Color::Rgb(74, 222, 128),
            SemanticColor::GitUnstaged => Color::Rgb(251, 191, 36),
            SemanticColor::GitUntracked => Color::Rgb(148, 163, 184),
            // UI (15)
            SemanticColor::ProgressBar => Color::Rgb(59, 130, 246),
            SemanticColor::ProgressBg => Color::Rgb(55, 65, 81),
            SemanticColor::Border => Color::Rgb(71, 85, 105),
            SemanticColor::BorderHighlight => Color::Rgb(96, 165, 250),
            SemanticColor::SelectionBg => Color::Rgb(59, 130, 246),
            SemanticColor::SelectionFg => Color::Rgb(241, 245, 249),
            SemanticColor::InputBorder => Color::Rgb(96, 165, 250),
            SemanticColor::InputBg => Color::Rgb(30, 41, 59),
            SemanticColor::Scrollbar => Color::Rgb(55, 65, 81),
            SemanticColor::ScrollbarThumb => Color::Rgb(100, 116, 139),
            SemanticColor::Tooltip => Color::Rgb(241, 245, 249),
            SemanticColor::TooltipBg => Color::Rgb(51, 65, 85),
            SemanticColor::Dimmed => Color::Rgb(100, 116, 139),
            SemanticColor::Muted => Color::Rgb(71, 85, 105),
            SemanticColor::Highlight => Color::Rgb(251, 191, 36),
            // TextStyle (7)
            SemanticColor::TextPrimary => Color::Rgb(241, 245, 249),
            SemanticColor::TextSecondary => Color::Rgb(148, 163, 184),
            SemanticColor::TextMuted => Color::Rgb(100, 116, 139),
            SemanticColor::TextInverse => Color::Rgb(15, 23, 42),
            SemanticColor::TextLink => Color::Rgb(96, 165, 250),
            SemanticColor::TextCode => Color::Rgb(45, 212, 191),
            SemanticColor::TextHeading => Color::Rgb(241, 245, 249),
            // Background (5)
            SemanticColor::BgPrimary => Color::Rgb(15, 23, 42),
            SemanticColor::BgSecondary => Color::Rgb(30, 41, 59),
            SemanticColor::BgTertiary => Color::Rgb(51, 65, 85),
            SemanticColor::BgSurface => Color::Rgb(30, 41, 59),
            SemanticColor::BgOverlay => Color::Rgb(15, 23, 42),
        }
    }
    fn supports_truecolor(&self) -> bool { true }
    fn name(&self) -> &str { "dark" }
}
```

### 实时渲染（消费 AgentEvent）

```rust
impl App {
    /// 消费 AgentEvent 更新 TUI 状态
    pub fn process_agent_event(&mut self, event: AgentEvent) {
        match event {
            AgentEvent::TaskStarted { task_id, .. } => {
                self.dashboard.total_tasks += 1;
            }
            AgentEvent::TaskCompleted { task_id, .. } => {
                self.dashboard.completed_tasks += 1;
            }
            AgentEvent::TaskFailed { task_id, error, .. } => {
                self.dashboard.failed_tasks += 1;
                self.log_panel.logs.push_back(LogEntry {
                    timestamp: chrono::Utc::now(),
                    level: LogLevel::Error,
                    source: "system".to_string(),
                    message: format!("Task {} failed: {}", task_id, error),
                });
            }
            AgentEvent::AgentStatusChanged { agent_id, agent_type, status, .. } => {
                self.update_agent_progress(agent_id, agent_type, status);
            }
            AgentEvent::LlmStreamDelta { agent_id, content, .. } => {
                self.log_panel.logs.push_back(LogEntry {
                    timestamp: chrono::Utc::now(),
                    level: LogLevel::Info,
                    source: agent_id,
                    message: content,
                });
            }
            AgentEvent::ApprovalRequired { request, .. } => {
                self.approval_dialog = Some(ApprovalDialogState {
                    request_id: request.request_id,
                    task_description: request.task_description,
                    action: format!("{:?}", request.action),
                    risk_level: format!("{:?}", request.risk_level),
                    selected_option: ApprovalOption::Reject,
                });
            }
            _ => {}
        }
    }

    fn update_agent_progress(&mut self, agent_id: String, agent_type: AgentType, status: AgentTuiStatus) {
        if let Some(entry) = self.agent_progress.agents.iter_mut().find(|a| a.agent_id == agent_id) {
            entry.status = status;
        } else {
            self.agent_progress.agents.push(AgentProgressEntry {
                agent_type, agent_id, status,
                progress_percent: 0.0, current_phase: String::new(), tokens_used: 0,
            });
        }
    }
}
```

## P6-2 功能需求清单

| 编号 | 功能 | 优先级 | 说明 |
|------|------|--------|------|
| FR-TUI-001 | App struct | P0 | TUI 状态管理 |
| FR-TUI-002 | crossterm 事件处理 | P0 | 键盘/鼠标/调整大小 |
| FR-TUI-003 | dashboard 视图 | P0 | 仪表盘渲染 |
| FR-TUI-004 | agent_progress 视图 | P0 | Agent 进度 |
| FR-TUI-005 | code_diff 视图 | P0 | 代码差异 |
| FR-TUI-006 | log_panel 视图 | P0 | 日志面板 |
| FR-TUI-007 | approval_dialog 视图 | P0 | 审批对话框 |
| FR-TUI-008 | SemanticColor 体系 | P0 | 70+ 变体 |
| FR-TUI-009 | Theme trait | P0 | DarkTheme 默认 |
| FR-TUI-010 | 实时渲染 | P0 | 消费 AgentEvent |

## P6-2 接口契约

```rust
impl App {
    pub fn new(color_resolver: ColorResolver) -> Self;
    pub fn handle_event(&mut self, event: Event);
    pub fn process_agent_event(&mut self, event: AgentEvent);
    pub fn render(&mut self, frame: &mut Frame);
}

pub trait Theme {
    fn color(&self, semantic: SemanticColor) -> Color;
    fn supports_truecolor(&self) -> bool;
    fn name(&self) -> &str;
}
```

## P6-2 测试要点

| 测试场景 | 验证内容 | 预期结果 |
|----------|----------|----------|
| App 状态初始化 | 默认状态 | active_view=Dashboard |
| App 状态转换 | 面板切换 | Tab 循环 |
| 键盘事件 | q/Esc | should_quit=true |
| 键盘事件 | 1/2/3/4 | 切换视图 |
| 鼠标事件 | ScrollDown/Up | 滚动 |
| 审批对话框 | Y/N/M/Esc/Enter | 正确操作 |
| dashboard 渲染 | 渲染不 panic | 正常显示 |
| agent_progress | 10 Agent 状态 | 正确显示 |
| log_panel | 日志滚动/过滤 | 正常显示 |
| DarkTheme | 颜色映射 | 正确 RGB 值 |

---

# P7-1 mc-cli CLI 入口

## P7-1 模块概述

`mc-cli` 是 MoreCode Agent 系统的命令行入口，基于 clap 4.x 实现子命令解析。提供 `chat`、`daemon`、`config`、`version` 四个核心命令，负责配置初始化和 Agent 启动流程。

**Crate 路径**：`crates/mc-cli/`（二进制 crate）

## P7-1 架构文档引用

- **主文档**：`25-代码目录与文件命名设计.md`（3.15 节）——mc-cli 目录结构
- **补充文档**：`00-MoreCode-agent开发选型-总刚.md`——技术栈选型

## P7-1 大模型开发提示词

```
你正在实现 MoreCode Agent 系统的 CLI 入口（mc-cli crate）。

核心职责：
1. clap 命令行参数解析
2. 配置初始化（全局 + 项目级）
3. Agent 启动流程
4. 四个核心命令：chat、daemon、config、version

关键设计约束：
- 使用 clap 4.x derive 模式
- 配置文件路径：~/.config/morecode/config.toml + .morecode/config.toml
- chat 模式启动 TUI 或交互式 REPL
- daemon 模式启动后台守护进程
- config 命令支持 get/set/list 子命令

参考架构文档：25-代码目录与文件命名设计.md
```

## P7-1 核心类型定义

### clap 命令行参数

```rust
use clap::{Parser, Subcommand};
use std::path::PathBuf;

#[derive(Parser, Debug)]
#[command(name = "morecode", version, about = "MoreCode AI 编码助手")]
pub struct Cli {
    #[command(subcommand)]
    pub command: Commands,

    /// 配置文件路径
    #[arg(long, global = true)]
    pub config: Option<PathBuf>,

    /// 项目根目录
    #[arg(long, global = true)]
    pub project_root: Option<PathBuf>,

    /// 日志级别
    #[arg(long, global = true, default = "info")]
    pub log_level: String,

    /// 启用 TUI 模式
    #[arg(long, global = true)]
    pub tui: bool,
}

#[derive(Subcommand, Debug)]
pub enum Commands {
    /// 交互式对话模式
    Chat {
        /// 初始请求
        #[arg(trailing_var_arg = true)]
        message: Option<Vec<String>>,
    },
    /// 启动守护模式
    Daemon {
        /// 自主级别
        #[arg(long, default_value = "semi-auto")]
        autonomy: String,
        /// 配置文件
        #[arg(long)]
        daemon_config: Option<PathBuf>,
    },
    /// 配置管理
    Config {
        #[command(subcommand)]
        action: ConfigAction,
    },
    /// 显示版本信息
    Version,
}

#[derive(Subcommand, Debug)]
pub enum ConfigAction {
    /// 获取配置项
    Get { key: String },
    /// 设置配置项
    Set { key: String, value: String },
    /// 列出所有配置
    List,
    /// 重置为默认值
    Reset { key: Option<String> },
}
```

### 配置初始化

```rust
use mc_config::AppConfig;

/// 初始化配置（全局 + 项目级合并）
pub async fn init_config(cli: &Cli) -> Result<AppConfig> {
    // 1. 加载默认配置
    let mut config = AppConfig::default();

    // 2. 加载全局配置（~/.config/morecode/config.toml）
    let global_path = dirs::config_dir()
        .unwrap_or_else(|| PathBuf::from("~/.config"))
        .join("morecode/config.toml");

    if global_path.exists() {
        let global_config = AppConfig::from_file(&global_path)?;
        config.merge(global_config);
    }

    // 3. 加载项目级配置（.morecode/config.toml）
    let project_root = cli.project_root.as_ref()
        .unwrap_or(&std::env::current_dir()?)
        .clone();
    let project_config_path = project_root.join(".morecode/config.toml");

    if project_config_path.exists() {
        let project_config = AppConfig::from_file(&project_config_path)?;
        config.merge(project_config);
    }

    // 4. CLI 参数覆盖
    if let Some(config_path) = &cli.config {
        let cli_config = AppConfig::from_file(config_path)?;
        config.merge(cli_config);
    }

    Ok(config)
}
```

### Agent 启动流程

```rust
pub async fn run(cli: Cli) -> Result<()> {
    // 1. 初始化日志
    tracing_subscriber::fmt()
        .with_env_filter(&cli.log_level)
        .init();

    // 2. 初始化配置
    let config = init_config(&cli).await?;

    // 3. 根据命令启动
    match cli.command {
        Commands::Chat { message } => {
            let coordinator = create_coordinator(&config).await?;
            let initial_request = message.map(|m| m.join(" "));
            if cli.tui {
                // 启动 TUI 模式
                let app = App::new(/* color_resolver */);
                run_tui(app, coordinator, initial_request).await?;
            } else {
                // 交互式 REPL
                run_repl(coordinator, initial_request).await?;
            }
        }
        Commands::Daemon { autonomy, daemon_config } => {
            let daemon_config = load_daemon_config(daemon_config).await?;
            let daemon = Daemon::new(daemon_config, config.project_root)?;
            daemon.start().await?;
        }
        Commands::Config { action } => {
            handle_config_action(action).await?;
        }
        Commands::Version => {
            println!("morecode {}", env!("CARGO_PKG_VERSION"));
        }
    }

    Ok(())
}

async fn create_coordinator(config: &AppConfig) -> Result<Coordinator> {
    let llm_client = create_llm_provider(&config.provider)?;
    let agent_registry = AgentRegistry::new();
    agent_registry.register_defaults();
    let project_root = config.project_root.clone();
    Coordinator::new(config.coordinator.clone(), llm_client, agent_registry, project_root)
}
```

### 命令：chat、daemon、config、version

（已包含在上方的 `Cli`、`Commands`、`run()` 实现中）

## P7-1 功能需求清单

| 编号 | 功能 | 优先级 | 说明 |
|------|------|--------|------|
| FR-CLI-001 | clap 命令行解析 | P0 | derive 模式 |
| FR-CLI-002 | 配置初始化 | P0 | 全局 + 项目 + CLI 合并 |
| FR-CLI-003 | chat 命令 | P0 | TUI / REPL |
| FR-CLI-004 | daemon 命令 | P0 | 后台守护 |
| FR-CLI-005 | config 命令 | P1 | get/set/list/reset |
| FR-CLI-006 | version 命令 | P0 | 版本信息 |

## P7-1 接口契约

```rust
pub async fn run(cli: Cli) -> Result<()>;
pub async fn init_config(cli: &Cli) -> Result<AppConfig>;
async fn create_coordinator(config: &AppConfig) -> Result<Coordinator>;
```

## P7-1 测试要点

| 测试场景 | 验证内容 | 预期结果 |
|----------|----------|----------|
| clap 解析 | chat "hello" | Commands::Chat |
| clap 解析 | --daemon | Commands::Daemon |
| 配置初始化 | 无配置文件 | 默认值 |
| 配置合并 | 全局 + 项目 | 项目覆盖全局 |
| version | --version | 版本号输出 |

---

# P7-2 端到端集成测试

## P7-2 模块概述

端到端集成测试覆盖完整用户场景，从请求接收到最终交付的全流程测试。使用 Mock LLM Provider 避免真实 API 调用，确保测试快速、确定、可重复。

**目录路径**：`tests/e2e/`

## P7-2 架构文档引用

- **主文档**：`26-测试体系设计.md`（全文）——L1-L4 测试分层、测试基础设施、Mock Provider、测试固件工厂、自定义断言宏

## P7-2 大模型开发提示词

```
你正在编写 MoreCode Agent 系统的端到端集成测试。

核心职责：
1. MockProvider（with_response、with_stream、with_error、assert_call_count）
2. 测试固件工厂（minimal_task、full_sub_task、temp_project_context、sample_handoff）
3. 自定义断言宏（assert_err_variant、assert_completes_within、assert_recv_within）
4. L1-L4 测试分层
5. 端到端场景覆盖

参考架构文档：26-测试体系设计.md
```

## P7-2 核心类型定义

### MockProvider

```rust
use std::collections::VecDeque;
use std::sync::{Arc, Mutex};
use std::time::Duration;

/// Mock LLM Provider — 支持预设响应和延迟模拟
pub struct MockProvider {
    /// 预设的响应列表（按调用顺序返回）
    responses: Arc<Mutex<VecDeque<String>>>,
    /// 模拟延迟
    delay: Duration,
    /// 调用记录
    call_log: Arc<Mutex<Vec<String>>>,
    /// 模拟错误
    next_error: Arc<Mutex<Option<String>>>,
}

impl MockProvider {
    pub fn new() -> Self {
        Self {
            responses: Arc::new(Mutex::new(VecDeque::new())),
            delay: Duration::ZERO,
            call_log: Arc::new(Mutex::new(Vec::new())),
            next_error: Arc::new(Mutex::new(None)),
        }
    }

    /// 预设一个成功响应
    pub fn with_response(&self, content: &str) -> &Self {
        self.responses.lock().unwrap().push_back(content.to_string());
        self
    }

    /// 预设一个流式响应（多个 chunk）
    pub fn with_stream(&self, chunks: Vec<&str>) -> &Self {
        let combined = chunks.join("");
        self.responses.lock().unwrap().push_back(combined);
        self
    }

    /// 模拟 API 错误
    pub fn with_error(&self, error: &str) -> &Self {
        *self.next_error.lock().unwrap() = Some(error.to_string());
        self
    }

    /// 断言调用次数
    pub fn assert_call_count(&self, expected: usize) {
        let count = self.call_log.lock().unwrap().len();
        assert_eq!(count, expected, "LLM 调用次数不匹配");
    }

    /// 获取第 N 次调用的请求参数
    pub fn get_call(&self, index: usize) -> Option<String> {
        self.call_log.lock().unwrap().get(index).cloned()
    }
}

#[async_trait::async_trait]
impl LlmProvider for MockProvider {
    async fn complete(&self, prompt: &str) -> Result<String> {
        self.call_log.lock().unwrap().push(prompt.to_string());
        tokio::time::sleep(self.delay).await;

        if let Some(error) = self.next_error.lock().unwrap().take() {
            anyhow::bail!("Mock error: {}", error);
        }

        let mut responses = self.responses.lock().unwrap();
        responses.pop_front()
            .ok_or_else(|| anyhow::anyhow!("MockProvider: 无预设响应"))
    }
}
```

### 测试固件工厂

```rust
use tempfile::TempDir;

/// 创建最小化的 TaskDescription
pub fn minimal_task() -> TaskDescription {
    TaskDescription {
        id: "test-task-001".to_string(),
        description: "修复 typo".to_string(),
        task_type: TaskType::BugFix,
        affected_files: vec!["src/main.rs".to_string()],
        requires_new_dependency: false,
        involves_architecture_change: false,
        needs_external_research: false,
        requires_testing: false,
    }
}

/// 创建完整的 SubTask（含所有必填字段）
pub fn full_sub_task(agent: AgentType) -> SubTask {
    SubTask {
        id: format!("sub-{}", agent),
        agent_type: agent,
        description: format!("{:?} 子任务", agent),
        dependencies: vec![],
        token_budget: 8000,
        priority: 1,
    }
}

/// 创建 ProjectContext（指向临时目录）
pub fn temp_project_context(dir: &TempDir) -> ProjectContext {
    ProjectContext {
        overview: "测试项目".to_string(),
        tech_stack: TechStack {
            language: "Rust".to_string(),
            framework: "Axum".to_string(),
            database: "SQLite".to_string(),
        },
        total_files: 5,
        ..Default::default()
    }
}

/// 创建 AgentHandoff（含模拟发现）
pub fn sample_handoff() -> AgentHandoff {
    AgentHandoff {
        agent_type: AgentType::Coder,
        changed_files: vec!["src/main.rs".to_string()],
        findings: vec!["修复了 typo".to_string()],
        token_usage: TokenUsage {
            input_tokens: 500, output_tokens: 200, total_tokens: 700,
        },
        ..Default::default()
    }
}

/// 创建 CoordinatorConfig（测试用默认值）
pub fn test_coordinator_config() -> CoordinatorConfig {
    CoordinatorConfig {
        max_token_budget: 50_000,
        max_recursion_depth: 1,
        agent_timeout_secs: 30,
        max_retries: 1,
        memory_aware_routing: false,
        recursive_orchestration: false,
        memory_stale_threshold_days: 7,
    }
}

/// 创建带 Token 追踪的 MockProvider
pub fn mock_provider_with_tracking() -> (MockProvider, Arc<TokenTracker>) {
    let provider = MockProvider::new();
    let tracker = Arc::new(TokenTracker::new());
    (provider, tracker)
}
```

### 自定义断言宏

```rust
/// 断言 Result 是 Err 且匹配特定错误变体
#[macro_export]
macro_rules! assert_err_variant {
    ($result:expr, $pattern:pat) => {
        match $result {
            Err(e) => {
                let err_str = e.to_string();
                if !matches!(err_str.as_str(), $pattern) {
                    panic!("错误不匹配模式: err={}", err_str);
                }
            }
            Ok(v) => panic!("期望 Err，得到 Ok({:?})", v),
        }
    };
}

/// 断言在给定时间内完成
#[macro_export]
macro_rules! assert_completes_within {
    ($future:expr, $timeout:expr) => {
        let result = tokio::time::timeout($timeout, $future).await;
        match result {
            Ok(inner) => inner,
            Err(_) => panic!("操作超时: {:?}", $timeout),
        }
    };
}

/// 断言通道在超时内收到消息
#[macro_export]
macro_rules! assert_recv_within {
    ($receiver:expr, $timeout:expr) => {
        match tokio::time::timeout($timeout, $receiver).await {
            Ok(msg) => msg,
            Err(_) => panic!("通道接收超时: {:?}", $timeout),
        }
    };
}
```

### L1-L4 测试分层

| 层级 | 位置 | 职责 | 运行频率 |
|------|------|------|----------|
| L1 单元测试 | 各 crate `src/` 内 `#[cfg(test)]` | 纯逻辑验证 | 每次提交 |
| L2 集成测试 | `tests/integration/` | 多 crate 协作 | 每次 PR |
| L3 端到端测试 | `tests/e2e/` | 完整用户场景 | 每日 CI |
| L4 契约测试 | Provider crate 内 | API 格式验证 | 发布前 |

### 端到端场景

```rust
#[cfg(test)]
mod e2e_tests {
    use super::*;

    /// L3-E2E-001: Simple 任务端到端
    #[tokio::test]
    async fn test_simple_task_e2e() {
        let provider = MockProvider::new();
        provider.with_response(r#"{"task_type":"bugfix","estimated_complexity":"simple"}"#);
        provider.with_response("修复完成");

        let config = test_coordinator_config();
        let coordinator = create_test_coordinator(provider, config).await.unwrap();

        let result = coordinator.handle_request("修复 src/main.rs 中的 typo").await;
        assert!(result.is_ok());
        let response = result.unwrap();
        assert_eq!(response.response_type, ResponseType::Completed);
    }

    /// L3-E2E-002: Medium 任务含预飞检查
    #[tokio::test]
    async fn test_medium_task_with_preflight_e2e() {
        let provider = MockProvider::new();
        provider.with_response(r#"{"task_type":"feature","estimated_complexity":"medium"}"#);
        provider.with_response(r#"{"plan":"添加字段","steps":["修改model","修改handler"]}"#);
        provider.with_response("预飞检查通过");
        provider.with_response("编码完成");

        let config = test_coordinator_config();
        let coordinator = create_test_coordinator(provider, config).await.unwrap();

        let result = coordinator.handle_request("给 User 模型添加 email 字段").await;
        assert!(result.is_ok());
    }

    /// L3-E2E-003: Complex 任务含递归
    #[tokio::test]
    async fn test_complex_task_with_recursion_e2e() {
        let provider = MockProvider::new();
        provider.with_response(r#"{"task_type":"refactor","estimated_complexity":"complex"}"#);
        provider.with_response("项目结构分析完成");
        provider.with_response("影响分析完成");
        provider.with_response(r#"{"plan":"重构方案","sub_tasks":3}"#);
        provider.with_response("子任务 1 完成");
        provider.with_response("子任务 2 完成");
        provider.with_response("子任务 3 完成");
        provider.with_response("审查通过");

        let config = test_coordinator_config();
        config.recursive_orchestration = true;
        let coordinator = create_test_coordinator(provider, config).await.unwrap();

        let result = coordinator.handle_request("重构认证模块").await;
        assert!(result.is_ok());
    }

    /// L3-E2E-004: Daemon 批量处理
    #[tokio::test]
    async fn test_daemon_batch_processing_e2e() {
        let provider = MockProvider::new();
        // 预设 5 个 Simple 任务的响应
        for _ in 0..5 {
            provider.with_response(r#"{"task_type":"bugfix","estimated_complexity":"simple"}"#);
            provider.with_response("修复完成");
        }

        let daemon_config = DaemonConfig {
            autonomy_level: AutonomyLevel::FullAuto,
            resource_limits: ResourceLimits {
                max_concurrent_tasks: 2,
                ..Default::default()
            },
            ..Default::default()
        };

        let daemon = Daemon::new(daemon_config, PathBuf::from("/tmp/test-project")).unwrap();
        assert!(daemon.health_check().await == HealthStatus::Healthy);
    }
}
```

## P7-2 功能需求清单

| 编号 | 功能 | 优先级 | 说明 |
|------|------|--------|------|
| FR-E2E-001 | MockProvider | P0 | with_response/with_stream/with_error/assert_call_count |
| FR-E2E-002 | 测试固件工厂 | P0 | minimal_task/full_sub_task/temp_project_context/sample_handoff |
| FR-E2E-003 | 自定义断言宏 | P0 | assert_err_variant/assert_completes_within/assert_recv_within |
| FR-E2E-004 | L1-L4 测试分层 | P0 | 四层测试策略 |
| FR-E2E-005 | Simple 任务 E2E | P0 | 完整流程 |
| FR-E2E-006 | Medium 任务含预飞 | P0 | 预飞检查 |
| FR-E2E-007 | Complex 任务含递归 | P0 | 递归编排 |
| FR-E2E-008 | Daemon 批量处理 | P1 | 多任务处理 |

## P7-2 接口契约

```rust
// MockProvider
impl MockProvider {
    pub fn new() -> Self;
    pub fn with_response(&self, content: &str) -> &Self;
    pub fn with_stream(&self, chunks: Vec<&str>) -> &Self;
    pub fn with_error(&self, error: &str) -> &Self;
    pub fn assert_call_count(&self, expected: usize);
    pub fn get_call(&self, index: usize) -> Option<String>;
}

// 测试固件工厂
pub fn minimal_task() -> TaskDescription;
pub fn full_sub_task(agent: AgentType) -> SubTask;
pub fn temp_project_context(dir: &TempDir) -> ProjectContext;
pub fn sample_handoff() -> AgentHandoff;
pub fn test_coordinator_config() -> CoordinatorConfig;
pub fn mock_provider_with_tracking() -> (MockProvider, Arc<TokenTracker>);
```

## P7-2 测试要点

| 测试场景 | 验证内容 | 预期结果 |
|----------|----------|----------|
| MockProvider with_response | 预设响应 | 按序返回 |
| MockProvider with_error | 模拟错误 | 返回错误 |
| MockProvider assert_call_count | 调用次数 | 断言通过 |
| minimal_task | 最小任务 | 字段完整 |
| full_sub_task | 完整子任务 | 字段完整 |
| assert_err_variant | 错误匹配 | 匹配通过 |
| assert_completes_within | 超时 | panic |
| assert_recv_within | 通道超时 | panic |
| Simple E2E | 完整流程 | Completed |
| Medium E2E | 预飞检查 | 通过 |
| Complex E2E | 递归编排 | Completed |
| Daemon E2E | 批量 | 健康检查通过 |

---

> **文档结束**。本文档覆盖 P5 编排与递归层（mc-recursive + mc-coordinator）、P6 高级模式层（mc-daemon + mc-tui）、P7 集成与入口（mc-cli + 端到端集成测试），共 7 个模块，约 2500 行。